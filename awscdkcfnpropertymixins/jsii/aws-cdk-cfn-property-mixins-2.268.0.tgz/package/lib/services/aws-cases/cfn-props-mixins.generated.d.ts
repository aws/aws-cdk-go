import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-cases";
/**
 * Creates a case in the specified Cases domain.
 *
 * @cloudformationResource AWS::Cases::Case
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html
 */
export declare class CfnCasePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCaseMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Cases::Case`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCaseMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCase;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnCasePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html
 */
export interface CfnCaseMixinProps {
    /**
     * The full customer profile ARN for the case.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html#cfn-cases-case-customerid
     */
    readonly customerId?: string;
    /**
     * The unique identifier of the Cases domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html#cfn-cases-case-domainid
     */
    readonly domainId?: string;
    /**
     * A list of tags for the case.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html#cfn-cases-case-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * A unique identifier of a template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html#cfn-cases-case-templateid
     */
    readonly templateId?: string;
    /**
     * The title of the case.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-case.html#cfn-cases-case-title
     */
    readonly title?: string;
}
/**
 * Creates a new case rule.
 *
 * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
 *
 * @cloudformationResource AWS::Cases::CaseRule
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html
 */
export declare class CfnCaseRulePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCaseRuleMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Cases::CaseRule`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCaseRuleMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCaseRule;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCaseRulePropsMixin {
    /**
     * Represents what rule type should take place, under what conditions.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-caseruledetails.html
     */
    interface CaseRuleDetailsProperty {
        /**
         * Whether a field is visible, based on values in other fields.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-caseruledetails.html#cfn-cases-caserule-caseruledetails-hidden
         */
        readonly hidden?: CfnCaseRulePropsMixin.HiddenCaseRuleProperty | cdk.IResolvable;
        /**
         * Required rule type, used to indicate whether a field is required.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-caseruledetails.html#cfn-cases-caserule-caseruledetails-required
         */
        readonly required?: cdk.IResolvable | CfnCaseRulePropsMixin.RequiredCaseRuleProperty;
    }
    /**
     * Required rule type, used to indicate whether a field is required.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-requiredcaserule.html
     */
    interface RequiredCaseRuleProperty {
        /**
         * List of conditions for the required rule;
         *
         * the first condition to evaluate to true dictates the value of the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-requiredcaserule.html#cfn-cases-caserule-requiredcaserule-conditions
         */
        readonly conditions?: Array<CfnCaseRulePropsMixin.BooleanConditionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The value of the rule (that is, whether the field is required) should none of the conditions evaluate to true.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-requiredcaserule.html#cfn-cases-caserule-requiredcaserule-defaultvalue
         */
        readonly defaultValue?: boolean | cdk.IResolvable;
    }
    /**
     * Boolean condition for a rule.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleancondition.html
     */
    interface BooleanConditionProperty {
        /**
         * Tests that operandOne is equal to operandTwo.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleancondition.html#cfn-cases-caserule-booleancondition-equalto
         */
        readonly equalTo?: CfnCaseRulePropsMixin.BooleanOperandsProperty | cdk.IResolvable;
        /**
         * Tests that operandOne is not equal to operandTwo.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleancondition.html#cfn-cases-caserule-booleancondition-notequalto
         */
        readonly notEqualTo?: CfnCaseRulePropsMixin.BooleanOperandsProperty | cdk.IResolvable;
    }
    /**
     * Boolean operands for a condition.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleanoperands.html
     */
    interface BooleanOperandsProperty {
        /**
         * Represents the left hand operand in the condition.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleanoperands.html#cfn-cases-caserule-booleanoperands-operandone
         */
        readonly operandOne?: cdk.IResolvable | CfnCaseRulePropsMixin.OperandOneProperty;
        /**
         * Represents the right hand operand in the condition.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleanoperands.html#cfn-cases-caserule-booleanoperands-operandtwo
         */
        readonly operandTwo?: cdk.IResolvable | CfnCaseRulePropsMixin.OperandTwoProperty;
        /**
         * The value of the outer rule if the condition evaluates to true.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-booleanoperands.html#cfn-cases-caserule-booleanoperands-result
         */
        readonly result?: boolean | cdk.IResolvable;
    }
    /**
     * Represents the left hand operand in the condition.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandone.html
     */
    interface OperandOneProperty {
        /**
         * The field ID that this operand should take the value of.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandone.html#cfn-cases-caserule-operandone-fieldid
         */
        readonly fieldId?: string;
    }
    /**
     * Represents the right hand operand in the condition.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandtwo.html
     */
    interface OperandTwoProperty {
        /**
         * Boolean value type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandtwo.html#cfn-cases-caserule-operandtwo-booleanvalue
         */
        readonly booleanValue?: boolean | cdk.IResolvable;
        /**
         * Double value type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandtwo.html#cfn-cases-caserule-operandtwo-doublevalue
         */
        readonly doubleValue?: number;
        /**
         * Represents an empty operand value.
         *
         * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandtwo.html#cfn-cases-caserule-operandtwo-emptyvalue
         */
        readonly emptyValue?: any | cdk.IResolvable;
        /**
         * String value type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-operandtwo.html#cfn-cases-caserule-operandtwo-stringvalue
         */
        readonly stringValue?: string;
    }
    /**
     * A rule that controls field visibility based on conditions.
     *
     * Fields can be shown or hidden dynamically based on values in other fields.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-hiddencaserule.html
     */
    interface HiddenCaseRuleProperty {
        /**
         * A list of conditions that determine field visibility.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-hiddencaserule.html#cfn-cases-caserule-hiddencaserule-conditions
         */
        readonly conditions?: Array<CfnCaseRulePropsMixin.BooleanConditionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Whether the field is hidden when no conditions match.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-caserule-hiddencaserule.html#cfn-cases-caserule-hiddencaserule-defaultvalue
         */
        readonly defaultValue?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnCaseRulePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html
 */
export interface CfnCaseRuleMixinProps {
    /**
     * Description of a case rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html#cfn-cases-caserule-description
     */
    readonly description?: string;
    /**
     * Unique identifier of a Cases domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html#cfn-cases-caserule-domainid
     */
    readonly domainId?: string;
    /**
     * Name of the case rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html#cfn-cases-caserule-name
     */
    readonly name?: string;
    /**
     * Represents what rule type should take place, under what conditions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html#cfn-cases-caserule-rule
     */
    readonly rule?: CfnCaseRulePropsMixin.CaseRuleDetailsProperty | cdk.IResolvable;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-caserule.html#cfn-cases-caserule-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a domain, which is a container for all case data, such as cases, fields, templates and layouts.
 *
 * Each Amazon Connect instance can be associated with only one Cases domain.
 *
 * > This will not associate your connect instance to Cases domain. Instead, use the Amazon Connect [CreateIntegrationAssociation](https://docs.aws.amazon.com/connect/latest/APIReference/API_CreateIntegrationAssociation.html) API. You need specific IAM permissions to successfully associate the Cases domain. For more information, see [Onboard to Cases](https://docs.aws.amazon.com/connect/latest/adminguide/required-permissions-iam-cases.html#onboard-cases-iam) .
 *
 * @cloudformationResource AWS::Cases::Domain
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-domain.html
 */
export declare class CfnDomainPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDomainMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Cases::Domain`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDomainMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDomain;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnDomainPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-domain.html
 */
export interface CfnDomainMixinProps {
    /**
     * The name of the domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-domain.html#cfn-cases-domain-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-domain.html#cfn-cases-domain-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a field in the Cases domain.
 *
 * This field is used to define the case object model (that is, defines what data can be captured on cases) in a Cases domain.
 *
 * @cloudformationResource AWS::Cases::Field
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html
 */
export declare class CfnFieldPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnFieldMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Cases::Field`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnFieldMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnField;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnFieldPropsMixin {
    /**
     * Union of field attributes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-field-fieldattributes.html
     */
    interface FieldAttributesProperty {
        /**
         * Field attributes for Text field type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-field-fieldattributes.html#cfn-cases-field-fieldattributes-text
         */
        readonly text?: cdk.IResolvable | CfnFieldPropsMixin.TextAttributesProperty;
    }
    /**
     * Field attributes for Text field type.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-field-textattributes.html
     */
    interface TextAttributesProperty {
        /**
         * Attribute that defines rendering component and validation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-field-textattributes.html#cfn-cases-field-textattributes-ismultiline
         */
        readonly isMultiline?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnFieldPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html
 */
export interface CfnFieldMixinProps {
    /**
     * Union of field attributes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html#cfn-cases-field-attributes
     */
    readonly attributes?: CfnFieldPropsMixin.FieldAttributesProperty | cdk.IResolvable;
    /**
     * Description of the field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html#cfn-cases-field-description
     */
    readonly description?: string;
    /**
     * The unique identifier of the Cases domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html#cfn-cases-field-domainid
     */
    readonly domainId?: string;
    /**
     * Name of the field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html#cfn-cases-field-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html#cfn-cases-field-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Type of the field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-field.html#cfn-cases-field-type
     */
    readonly type?: string;
}
/**
 * Creates a layout in the Cases domain.
 *
 * Layouts define the following configuration in the top section and More Info tab of the Cases user interface:
 *
 * - Fields to display to the users
 * - Field ordering
 *
 * > Title and Status fields cannot be part of layouts since they are not configurable.
 *
 * @cloudformationResource AWS::Cases::Layout
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-layout.html
 */
export declare class CfnLayoutPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLayoutMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Cases::Layout`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLayoutMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLayout;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnLayoutPropsMixin {
    /**
     * Object to store union of different versions of layout content.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-layoutcontent.html
     */
    interface LayoutContentProperty {
        /**
         * Content specific to `BasicLayout` type.
         *
         * It configures fields in the top panel and More Info tab of agent application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-layoutcontent.html#cfn-cases-layout-layoutcontent-basic
         */
        readonly basic?: CfnLayoutPropsMixin.BasicLayoutProperty | cdk.IResolvable;
    }
    /**
     * Content specific to `BasicLayout` type.
     *
     * It configures fields in the top panel and More Info tab of agent application.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-basiclayout.html
     */
    interface BasicLayoutProperty {
        /**
         * This represents sections in a tab of the page layout.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-basiclayout.html#cfn-cases-layout-basiclayout-moreinfo
         */
        readonly moreInfo?: cdk.IResolvable | CfnLayoutPropsMixin.LayoutSectionsProperty;
        /**
         * This represents sections in a panel of the page layout.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-basiclayout.html#cfn-cases-layout-basiclayout-toppanel
         */
        readonly topPanel?: cdk.IResolvable | CfnLayoutPropsMixin.LayoutSectionsProperty;
    }
    /**
     * Ordered list containing different kinds of sections that can be added.
     *
     * A LayoutSections object can only contain one section.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-layoutsections.html
     */
    interface LayoutSectionsProperty {
        /**
         * Ordered list containing different kinds of sections that can be added.
         *
         * A LayoutSections object can only contain one section.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-layoutsections.html#cfn-cases-layout-layoutsections-sections
         */
        readonly sections?: Array<cdk.IResolvable | CfnLayoutPropsMixin.SectionProperty> | cdk.IResolvable;
    }
    /**
     * This represents a sections within a panel or tab of the page layout.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-section.html
     */
    interface SectionProperty {
        /**
         * Consists of a group of fields and associated properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-section.html#cfn-cases-layout-section-fieldgroup
         */
        readonly fieldGroup?: CfnLayoutPropsMixin.FieldGroupProperty | cdk.IResolvable;
    }
    /**
     * Object for a group of fields and associated properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-fieldgroup.html
     */
    interface FieldGroupProperty {
        /**
         * Represents an ordered list containing field related information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-fieldgroup.html#cfn-cases-layout-fieldgroup-fields
         */
        readonly fields?: Array<CfnLayoutPropsMixin.FieldItemProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Name of the field group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-fieldgroup.html#cfn-cases-layout-fieldgroup-name
         */
        readonly name?: string;
    }
    /**
     * Object for field related information.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-fielditem.html
     */
    interface FieldItemProperty {
        /**
         * Unique identifier of a field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-layout-fielditem.html#cfn-cases-layout-fielditem-id
         */
        readonly id?: string;
    }
}
/**
 * Properties for CfnLayoutPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-layout.html
 */
export interface CfnLayoutMixinProps {
    /**
     * Object to store union of different versions of layout content.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-layout.html#cfn-cases-layout-content
     */
    readonly content?: cdk.IResolvable | CfnLayoutPropsMixin.LayoutContentProperty;
    /**
     * The unique identifier of the Cases domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-layout.html#cfn-cases-layout-domainid
     */
    readonly domainId?: string;
    /**
     * The name of the layout.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-layout.html#cfn-cases-layout-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-layout.html#cfn-cases-layout-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a template in the Cases domain.
 *
 * This template is used to define the case object model (that is, to define what data can be captured on cases) in a Cases domain. A template must have a unique name within a domain, and it must reference existing field IDs and layout IDs. Additionally, multiple fields with same IDs are not allowed within the same Template. A template can be either Active or Inactive, as indicated by its status. Inactive templates cannot be used to create cases.
 *
 * Other template APIs are:
 *
 * - [DeleteTemplate](https://docs.aws.amazon.com/connect/latest/APIReference/API_connect-cases_DeleteTemplate.html)
 * - [GetTemplate](https://docs.aws.amazon.com/connect/latest/APIReference/API_connect-cases_GetTemplate.html)
 * - [ListTemplates](https://docs.aws.amazon.com/connect/latest/APIReference/API_connect-cases_ListTemplates.html)
 * - [UpdateTemplate](https://docs.aws.amazon.com/connect/latest/APIReference/API_connect-cases_UpdateTemplate.html)
 *
 * @cloudformationResource AWS::Cases::Template
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html
 */
export declare class CfnTemplatePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTemplateMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Cases::Template`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTemplateMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTemplate;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTemplatePropsMixin {
    /**
     * Object to store configuration of layouts associated to the template.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-layoutconfiguration.html
     */
    interface LayoutConfigurationProperty {
        /**
         * Unique identifier of a layout.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-layoutconfiguration.html#cfn-cases-template-layoutconfiguration-defaultlayout
         */
        readonly defaultLayout?: string;
    }
    /**
     * List of fields that must have a value provided to create a case.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-requiredfield.html
     */
    interface RequiredFieldProperty {
        /**
         * Unique identifier of a field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-requiredfield.html#cfn-cases-template-requiredfield-fieldid
         */
        readonly fieldId?: string;
    }
    /**
     * An association representing a case rule acting upon a field.
     *
     * In the Amazon Connect admin website, case rules are known as *case field conditions* . For more information about case field conditions, see [Add case field conditions to a case template](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-templaterule.html
     */
    interface TemplateRuleProperty {
        /**
         * Unique identifier of a case rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-templaterule.html#cfn-cases-template-templaterule-caseruleid
         */
        readonly caseRuleId?: string;
        /**
         * Unique identifier of a field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cases-template-templaterule.html#cfn-cases-template-templaterule-fieldid
         */
        readonly fieldId?: string;
    }
}
/**
 * Properties for CfnTemplatePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html
 */
export interface CfnTemplateMixinProps {
    /**
     * A brief description of the template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-description
     */
    readonly description?: string;
    /**
     * The unique identifier of the Cases domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-domainid
     */
    readonly domainId?: string;
    /**
     * Object to store configuration of layouts associated to the template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-layoutconfiguration
     */
    readonly layoutConfiguration?: cdk.IResolvable | CfnTemplatePropsMixin.LayoutConfigurationProperty;
    /**
     * The template name.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-name
     */
    readonly name?: string;
    /**
     * A list of fields that must contain a value for a case to be successfully created with this template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-requiredfields
     */
    readonly requiredFields?: Array<cdk.IResolvable | CfnTemplatePropsMixin.RequiredFieldProperty> | cdk.IResolvable;
    /**
     * A list of case rules (also known as [case field conditions](https://docs.aws.amazon.com/connect/latest/adminguide/case-field-conditions.html) ) on a template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-rules
     */
    readonly rules?: Array<cdk.IResolvable | CfnTemplatePropsMixin.TemplateRuleProperty> | cdk.IResolvable;
    /**
     * The status of the template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-status
     */
    readonly status?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cases-template.html#cfn-cases-template-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
