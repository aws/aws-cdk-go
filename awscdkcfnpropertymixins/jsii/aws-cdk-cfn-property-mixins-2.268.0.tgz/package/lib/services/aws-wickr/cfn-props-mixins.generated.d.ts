import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-wickr";
/**
 * Resource Type definition for AWS::Wickr::Network.
 *
 * Creates and manages an AWS Wickr network for secure enterprise communications.
 *
 * @cloudformationResource AWS::Wickr::Network
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wickr-network.html
 */
export declare class CfnNetworkPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNetworkMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Wickr::Network`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNetworkMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNetwork;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnNetworkPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wickr-network.html
 */
export interface CfnNetworkMixinProps {
    /**
     * The access level of the network, which determines available features and capabilities.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wickr-network.html#cfn-wickr-network-accesslevel
     */
    readonly accessLevel?: string;
    /**
     * The name of the network.
     *
     * Must be between 1 and 20 characters.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-wickr-network.html#cfn-wickr-network-networkname
     */
    readonly networkName?: string;
}
