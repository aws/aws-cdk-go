import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-mgn";
/**
 * Resource schema for AWS::MGN::NetworkMigrationDefinition.
 *
 * @cloudformationResource AWS::MGN::NetworkMigrationDefinition
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html
 */
export declare class CfnNetworkMigrationDefinitionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNetworkMigrationDefinitionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MGN::NetworkMigrationDefinition`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNetworkMigrationDefinitionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNetworkMigrationDefinition;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnNetworkMigrationDefinitionPropsMixin {
    /**
     * Configuration for a migration source environment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sourceconfiguration.html
     */
    interface SourceConfigurationProperty {
        /**
         * The source environment type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sourceconfiguration.html#cfn-mgn-networkmigrationdefinition-sourceconfiguration-sourceenvironment
         */
        readonly sourceEnvironment?: string;
        /**
         * S3 configuration for source network data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sourceconfiguration.html#cfn-mgn-networkmigrationdefinition-sourceconfiguration-sources3configuration
         */
        readonly sourceS3Configuration?: cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.SourceS3ConfigurationProperty;
    }
    /**
     * S3 configuration for source network data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html
     */
    interface SourceS3ConfigurationProperty {
        /**
         * The name of the S3 bucket containing source data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html#cfn-mgn-networkmigrationdefinition-sources3configuration-s3bucket
         */
        readonly s3Bucket?: string;
        /**
         * The AWS account ID of the S3 bucket owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html#cfn-mgn-networkmigrationdefinition-sources3configuration-s3bucketowner
         */
        readonly s3BucketOwner?: string;
        /**
         * The S3 key (path) for the source data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-sources3configuration.html#cfn-mgn-networkmigrationdefinition-sources3configuration-s3key
         */
        readonly s3Key?: string;
    }
    /**
     * S3 configuration for storing target network artifacts.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targets3configuration.html
     */
    interface TargetS3ConfigurationProperty {
        /**
         * The name of the S3 bucket for target artifacts.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targets3configuration.html#cfn-mgn-networkmigrationdefinition-targets3configuration-s3bucket
         */
        readonly s3Bucket?: string;
        /**
         * The AWS account ID of the S3 bucket owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targets3configuration.html#cfn-mgn-networkmigrationdefinition-targets3configuration-s3bucketowner
         */
        readonly s3BucketOwner?: string;
    }
    /**
     * Configuration for the target network topology and addressing.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html
     */
    interface TargetNetworkProperty {
        /**
         * The CIDR block for inbound traffic in the target network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-inboundcidr
         */
        readonly inboundCidr?: string;
        /**
         * The CIDR block for inspection traffic in the target network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-inspectioncidr
         */
        readonly inspectionCidr?: string;
        /**
         * The CIDR block for outbound traffic in the target network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-outboundcidr
         */
        readonly outboundCidr?: string;
        /**
         * The network topology type for the target environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mgn-networkmigrationdefinition-targetnetwork.html#cfn-mgn-networkmigrationdefinition-targetnetwork-topology
         */
        readonly topology?: string;
    }
}
/**
 * Properties for CfnNetworkMigrationDefinitionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html
 */
export interface CfnNetworkMigrationDefinitionMixinProps {
    /**
     * A description of the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-description
     */
    readonly description?: string;
    /**
     * The name of the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-name
     */
    readonly name?: string;
    /**
     * Scope tags map for the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-scopetags
     */
    readonly scopeTags?: cdk.IResolvable | Record<string, string>;
    /**
     * A list of source configurations for the network migration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-sourceconfigurations
     */
    readonly sourceConfigurations?: Array<cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.SourceConfigurationProperty> | cdk.IResolvable;
    /**
     * Tags to assign to the network migration definition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The target deployment configuration for the migrated network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-targetdeployment
     */
    readonly targetDeployment?: string;
    /**
     * Configuration for the target network topology and addressing.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-targetnetwork
     */
    readonly targetNetwork?: cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.TargetNetworkProperty;
    /**
     * S3 configuration for storing target network artifacts.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mgn-networkmigrationdefinition.html#cfn-mgn-networkmigrationdefinition-targets3configuration
     */
    readonly targetS3Configuration?: cdk.IResolvable | CfnNetworkMigrationDefinitionPropsMixin.TargetS3ConfigurationProperty;
}
