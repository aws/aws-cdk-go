import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-invoicing";
/**
 * An invoice unit is a set of mutually exclusive account that correspond to your business entity.
 *
 * Invoice units allow you separate AWS account costs and configures your invoice for each business entity going forward.
 *
 * @cloudformationResource AWS::Invoicing::InvoiceUnit
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html
 */
export declare class CfnInvoiceUnitPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnInvoiceUnitMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Invoicing::InvoiceUnit`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnInvoiceUnitMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnInvoiceUnit;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnInvoiceUnitPropsMixin {
    /**
     * The `InvoiceUnitRule` object used to update invoice units.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-rule.html
     */
    interface RuleProperty {
        /**
         * The list of `LINKED_ACCOUNT` IDs where charges are included within the invoice unit.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-rule.html#cfn-invoicing-invoiceunit-rule-linkedaccounts
         */
        readonly linkedAccounts?: Array<string>;
    }
    /**
     * The tag structure that contains a tag key and value.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-resourcetag.html
     */
    interface ResourceTagProperty {
        /**
         * The object key of your of your resource tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-resourcetag.html#cfn-invoicing-invoiceunit-resourcetag-key
         */
        readonly key?: string;
        /**
         * The specific value of the resource tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-resourcetag.html#cfn-invoicing-invoiceunit-resourcetag-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnInvoiceUnitPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html
 */
export interface CfnInvoiceUnitMixinProps {
    /**
     * The assigned description for an invoice unit.
     *
     * This information can't be modified or deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-description
     */
    readonly description?: string;
    /**
     * The account that receives invoices related to the invoice unit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-invoicereceiver
     */
    readonly invoiceReceiver?: string;
    /**
     * A unique name that is distinctive within your AWS .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-name
     */
    readonly name?: string;
    /**
     * The tag structure that contains a tag key and value.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-resourcetags
     */
    readonly resourceTags?: Array<CfnInvoiceUnitPropsMixin.ResourceTagProperty>;
    /**
     * An `InvoiceUnitRule` object used the categorize invoice units.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-rule
     */
    readonly rule?: cdk.IResolvable | CfnInvoiceUnitPropsMixin.RuleProperty;
    /**
     * Whether the invoice unit based tax inheritance is/ should be enabled or disabled.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-taxinheritancedisabled
     */
    readonly taxInheritanceDisabled?: boolean | cdk.IResolvable;
}
/**
 * Creates and manages a procurement portal preference configuration for e-invoice delivery and purchase order retrieval.
 *
 * @cloudformationResource AWS::Invoicing::ProcurementPortalPreference
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html
 */
export declare class CfnProcurementPortalPreferencePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnProcurementPortalPreferenceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Invoicing::ProcurementPortalPreference`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnProcurementPortalPreferenceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProcurementPortalPreference;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnProcurementPortalPreferencePropsMixin {
    /**
     * Specifies criteria for selecting which invoices should be processed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-procurementportalpreferenceselector.html
     */
    interface ProcurementPortalPreferenceSelectorProperty {
        /**
         * The Amazon Resource Name (ARN) of invoice unit identifiers to which this preference applies.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-procurementportalpreferenceselector.html#cfn-invoicing-procurementportalpreference-procurementportalpreferenceselector-invoiceunitarns
         */
        readonly invoiceUnitArns?: Array<string>;
    }
    /**
     * Configuration settings for the test environment of the procurement portal.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html
     */
    interface TestEnvPreferenceProperty {
        /**
         * The domain identifier for the buyer in the test environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference-buyerdomain
         */
        readonly buyerDomain?: string;
        /**
         * The unique identifier for the buyer in the test environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference-buyeridentifier
         */
        readonly buyerIdentifier?: string;
        /**
         * The endpoint URL for e-invoice delivery in the test environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference-procurementportalinstanceendpoint
         */
        readonly procurementPortalInstanceEndpoint?: string;
        /**
         * The shared secret for secure communication in the test environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference-procurementportalsharedsecret
         */
        readonly procurementPortalSharedSecret?: string;
        /**
         * The domain identifier for the supplier in the test environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference-supplierdomain
         */
        readonly supplierDomain?: string;
        /**
         * The unique identifier for the supplier in the test environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-testenvpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference-supplieridentifier
         */
        readonly supplierIdentifier?: string;
    }
    /**
     * Specifies the preferences for e-invoice delivery.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html
     */
    interface EinvoiceDeliveryPreferenceProperty {
        /**
         * The method to use for testing the connection to the procurement portal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference-connectiontestingmethod
         */
        readonly connectionTestingMethod?: string;
        /**
         * The ISO 8601 date-time when e-invoice delivery should be activated.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference-einvoicedeliveryactivationdate
         */
        readonly einvoiceDeliveryActivationDate?: string;
        /**
         * The types of attachments to include with the e-invoice delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference-einvoicedeliveryattachmenttypes
         */
        readonly einvoiceDeliveryAttachmentTypes?: Array<string>;
        /**
         * The types of e-invoice documents to be delivered.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference-einvoicedeliverydocumenttypes
         */
        readonly einvoiceDeliveryDocumentTypes?: Array<string>;
        /**
         * The communication protocol to use for e-invoice delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference-protocol
         */
        readonly protocol?: string;
        /**
         * The sources of purchase order data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-einvoicedeliverypreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference-purchaseorderdatasources
         */
        readonly purchaseOrderDataSources?: Array<cdk.IResolvable | CfnProcurementPortalPreferencePropsMixin.PurchaseOrderDataSourceProperty> | cdk.IResolvable;
    }
    /**
     * Specifies the source configuration for retrieving purchase order data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-purchaseorderdatasource.html
     */
    interface PurchaseOrderDataSourceProperty {
        /**
         * The type of e-invoice document that requires purchase order data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-purchaseorderdatasource.html#cfn-invoicing-procurementportalpreference-purchaseorderdatasource-einvoicedeliverydocumenttype
         */
        readonly einvoiceDeliveryDocumentType?: string;
        /**
         * The type of source for purchase order data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-purchaseorderdatasource.html#cfn-invoicing-procurementportalpreference-purchaseorderdatasource-purchaseorderdatasourcetype
         */
        readonly purchaseOrderDataSourceType?: string;
    }
    /**
     * Contact information for a person or role associated with the procurement portal preference.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-contact.html
     */
    interface ContactProperty {
        /**
         * The email address of the contact person or role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-contact.html#cfn-invoicing-procurementportalpreference-contact-email
         */
        readonly email?: string;
        /**
         * The name of the contact person or role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-procurementportalpreference-contact.html#cfn-invoicing-procurementportalpreference-contact-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnProcurementPortalPreferencePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html
 */
export interface CfnProcurementPortalPreferenceMixinProps {
    /**
     * The domain identifier for the buyer in the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-buyerdomain
     */
    readonly buyerDomain?: string;
    /**
     * The unique identifier for the buyer in the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-buyeridentifier
     */
    readonly buyerIdentifier?: string;
    /**
     * List of contact information for portal administrators and technical contacts.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-contacts
     */
    readonly contacts?: Array<CfnProcurementPortalPreferencePropsMixin.ContactProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Indicates whether e-invoice delivery is enabled for this procurement portal preference.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliveryenabled
     */
    readonly einvoiceDeliveryEnabled?: boolean | cdk.IResolvable;
    /**
     * Specifies the preferences for e-invoice delivery.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-einvoicedeliverypreference
     */
    readonly einvoiceDeliveryPreference?: CfnProcurementPortalPreferencePropsMixin.EinvoiceDeliveryPreferenceProperty | cdk.IResolvable;
    /**
     * The endpoint URL where e-invoices are delivered to the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-procurementportalinstanceendpoint
     */
    readonly procurementPortalInstanceEndpoint?: string;
    /**
     * The name of the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-procurementportalname
     */
    readonly procurementPortalName?: string;
    /**
     * The shared secret or authentication credential used for secure communication with the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-procurementportalsharedsecret
     */
    readonly procurementPortalSharedSecret?: string;
    /**
     * Indicates whether purchase order retrieval is enabled for this procurement portal preference.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-purchaseorderretrievalenabled
     */
    readonly purchaseOrderRetrievalEnabled?: boolean | cdk.IResolvable;
    /**
     * Specifies criteria for selecting which invoices should be processed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-selector
     */
    readonly selector?: cdk.IResolvable | CfnProcurementPortalPreferencePropsMixin.ProcurementPortalPreferenceSelectorProperty;
    /**
     * The domain identifier for the supplier in the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-supplierdomain
     */
    readonly supplierDomain?: string;
    /**
     * The unique identifier for the supplier in the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-supplieridentifier
     */
    readonly supplierIdentifier?: string;
    /**
     * The tags associated with this procurement portal preference.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Configuration settings for the test environment of the procurement portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-procurementportalpreference.html#cfn-invoicing-procurementportalpreference-testenvpreference
     */
    readonly testEnvPreference?: cdk.IResolvable | CfnProcurementPortalPreferencePropsMixin.TestEnvPreferenceProperty;
}
