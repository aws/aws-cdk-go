import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-opensearch";
/**
 * Creates a data source for an Amazon OpenSearch Service domain.
 *
 * @cloudformationResource AWS::OpenSearch::DataSource
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-opensearch-datasource.html
 */
export declare class CfnDataSourcePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDataSourceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::OpenSearch::DataSource`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDataSourceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDataSource;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDataSourcePropsMixin {
    /**
     * The type of data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-opensearch-datasource-datasourcetype.html
     */
    interface DataSourceTypeProperty {
        /**
         * Configuration for an S3 Glue Data Catalog data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-opensearch-datasource-datasourcetype.html#cfn-opensearch-datasource-datasourcetype-s3gluedatacatalog
         */
        readonly s3GlueDataCatalog?: cdk.IResolvable | CfnDataSourcePropsMixin.S3GlueDataCatalogProperty;
    }
    /**
     * Configuration for an S3 Glue Data Catalog data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-opensearch-datasource-s3gluedatacatalog.html
     */
    interface S3GlueDataCatalogProperty {
        /**
         * The ARN of the IAM role that grants OpenSearch Service permission to access the Glue Data Catalog.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-opensearch-datasource-s3gluedatacatalog.html#cfn-opensearch-datasource-s3gluedatacatalog-rolearn
         */
        readonly roleArn?: string;
    }
}
/**
 * Properties for CfnDataSourcePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-opensearch-datasource.html
 */
export interface CfnDataSourceMixinProps {
    /**
     * The type of data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-opensearch-datasource.html#cfn-opensearch-datasource-datasourcetype
     */
    readonly dataSourceType?: CfnDataSourcePropsMixin.DataSourceTypeProperty | cdk.IResolvable;
    /**
     * A description of the data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-opensearch-datasource.html#cfn-opensearch-datasource-description
     */
    readonly description?: string;
    /**
     * The name of the OpenSearch Service domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-opensearch-datasource.html#cfn-opensearch-datasource-domainname
     */
    readonly domainName?: string;
    /**
     * The name of the data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-opensearch-datasource.html#cfn-opensearch-datasource-name
     */
    readonly name?: string;
}
