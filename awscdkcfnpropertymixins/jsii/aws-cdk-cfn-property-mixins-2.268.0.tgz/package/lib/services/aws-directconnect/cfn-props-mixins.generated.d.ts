import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-directconnect";
import { aws_directconnect as directConnectRefs, aws_ec2 as ec2Refs } from "aws-cdk-lib/interfaces";
/**
 * Resource Type definition for AWS::DirectConnect::Connection.
 *
 * @cloudformationResource AWS::DirectConnect::Connection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html
 */
export declare class CfnConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::Connection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html
 */
export interface CfnConnectionMixinProps {
    /**
     * The bandwidth of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-bandwidth
     */
    readonly bandwidth?: string;
    /**
     * The name of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-connectionname
     */
    readonly connectionName?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-lagid
     */
    readonly lagId?: directConnectRefs.ILagRef | string;
    /**
     * The location of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-location
     */
    readonly location?: string;
    /**
     * The name of the service provider associated with the requested connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-providername
     */
    readonly providerName?: string;
    /**
     * Indicates whether you want the connection to support MAC Security (MACsec).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-requestmacsec
     */
    readonly requestMacSec?: boolean | cdk.IResolvable;
    /**
     * The tags associated with the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-connection.html#cfn-directconnect-connection-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::DirectConnect::DirectConnectGateway.
 *
 * @cloudformationResource AWS::DirectConnect::DirectConnectGateway
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgateway.html
 */
export declare class CfnDirectConnectGatewayPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDirectConnectGatewayMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::DirectConnectGateway`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDirectConnectGatewayMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDirectConnectGateway;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnDirectConnectGatewayPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgateway.html
 */
export interface CfnDirectConnectGatewayMixinProps {
    /**
     * The autonomous system number (ASN) for the Amazon side of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgateway.html#cfn-directconnect-directconnectgateway-amazonsideasn
     */
    readonly amazonSideAsn?: string;
    /**
     * The name of the Direct Connect gateway.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgateway.html#cfn-directconnect-directconnectgateway-directconnectgatewayname
     */
    readonly directConnectGatewayName?: string;
    /**
     * The tags associated with the Direct Connect gateway.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgateway.html#cfn-directconnect-directconnectgateway-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::DirectConnect::DirectConnectGatewayAssociation.
 *
 * @cloudformationResource AWS::DirectConnect::DirectConnectGatewayAssociation
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgatewayassociation.html
 */
export declare class CfnDirectConnectGatewayAssociationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDirectConnectGatewayAssociationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::DirectConnectGatewayAssociation`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDirectConnectGatewayAssociationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDirectConnectGatewayAssociation;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnDirectConnectGatewayAssociationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgatewayassociation.html
 */
export interface CfnDirectConnectGatewayAssociationMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the role to accept the Direct Connect Gateway association proposal.
     *
     * Needs directconnect:AcceptDirectConnectGatewayAssociationProposal permissions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgatewayassociation.html#cfn-directconnect-directconnectgatewayassociation-acceptdirectconnectgatewayassociationproposalrolearn
     */
    readonly acceptDirectConnectGatewayAssociationProposalRoleArn?: string;
    /**
     * The Amazon VPC prefixes to advertise to the Direct Connect gateway.
     *
     * This parameter is required when you create an association to a transit gateway.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgatewayassociation.html#cfn-directconnect-directconnectgatewayassociation-allowedprefixestodirectconnectgateway
     */
    readonly allowedPrefixesToDirectConnectGateway?: Array<string>;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgatewayassociation.html#cfn-directconnect-directconnectgatewayassociation-associatedgatewayid
     */
    readonly associatedGatewayId?: ec2Refs.ITransitGatewayRef | ec2Refs.IVPNGatewayRef | string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-directconnectgatewayassociation.html#cfn-directconnect-directconnectgatewayassociation-directconnectgatewayid
     */
    readonly directConnectGatewayId?: directConnectRefs.IDirectConnectGatewayRef | string;
}
/**
 * Resource Type definition for AWS::DirectConnect::Lag.
 *
 * @cloudformationResource AWS::DirectConnect::Lag
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html
 */
export declare class CfnLagPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLagMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::Lag`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLagMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLag;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnLagPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html
 */
export interface CfnLagMixinProps {
    /**
     * The bandwidth of the individual physical dedicated connections bundled by the LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-connectionsbandwidth
     */
    readonly connectionsBandwidth?: string;
    /**
     * The name of the LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-lagname
     */
    readonly lagName?: string;
    /**
     * The location for the LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-location
     */
    readonly location?: string;
    /**
     * The minimum number of physical dedicated connections that must be operational for the LAG itself to be operational.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-minimumlinks
     */
    readonly minimumLinks?: number;
    /**
     * The name of the service provider associated with the requested LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-providername
     */
    readonly providerName?: string;
    /**
     * Indicates whether you want the LAG to support MAC Security (MACsec).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-requestmacsec
     */
    readonly requestMacSec?: boolean | cdk.IResolvable;
    /**
     * The tags associated with the LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-lag.html#cfn-directconnect-lag-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::DirectConnect::PrivateVirtualInterface.
 *
 * @cloudformationResource AWS::DirectConnect::PrivateVirtualInterface
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html
 */
export declare class CfnPrivateVirtualInterfacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPrivateVirtualInterfaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::PrivateVirtualInterface`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPrivateVirtualInterfaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPrivateVirtualInterface;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPrivateVirtualInterfacePropsMixin {
    /**
     * Information about a BGP peer.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html
     */
    interface BgpPeerProperty {
        /**
         * The address family for the BGP peer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html#cfn-directconnect-privatevirtualinterface-bgppeer-addressfamily
         */
        readonly addressFamily?: string;
        /**
         * The IP address assigned to the Amazon interface.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html#cfn-directconnect-privatevirtualinterface-bgppeer-amazonaddress
         */
        readonly amazonAddress?: string;
        /**
         * The autonomous system (AS) number for Border Gateway Protocol (BGP) configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html#cfn-directconnect-privatevirtualinterface-bgppeer-asn
         */
        readonly asn?: string;
        /**
         * The authentication key for BGP configuration.
         *
         * This string has a minimum length of 6 characters and and a maximum length of 80 characters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html#cfn-directconnect-privatevirtualinterface-bgppeer-authkey
         */
        readonly authKey?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html#cfn-directconnect-privatevirtualinterface-bgppeer-bgppeerid
         */
        readonly bgpPeerId?: string;
        /**
         * The IP address assigned to the customer interface.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-privatevirtualinterface-bgppeer.html#cfn-directconnect-privatevirtualinterface-bgppeer-customeraddress
         */
        readonly customerAddress?: string;
    }
}
/**
 * Properties for CfnPrivateVirtualInterfacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html
 */
export interface CfnPrivateVirtualInterfaceMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the role to allocate the private virtual interface.
     *
     * Needs directconnect:AllocatePrivateVirtualInterface permissions and tag permissions if applicable.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-allocateprivatevirtualinterfacerolearn
     */
    readonly allocatePrivateVirtualInterfaceRoleArn?: string;
    /**
     * The BGP peers configured on this virtual interface.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-bgppeers
     */
    readonly bgpPeers?: Array<CfnPrivateVirtualInterfacePropsMixin.BgpPeerProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-connectionid
     */
    readonly connectionId?: directConnectRefs.IConnectionRef | directConnectRefs.ILagRef | string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-directconnectgatewayid
     */
    readonly directConnectGatewayId?: directConnectRefs.IDirectConnectGatewayRef | string;
    /**
     * Indicates whether to enable or disable SiteLink.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-enablesitelink
     */
    readonly enableSiteLink?: boolean | cdk.IResolvable;
    /**
     * The maximum transmission unit (MTU), in bytes.
     *
     * The supported values are 1500 and 9001. The default value is 1500.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-mtu
     */
    readonly mtu?: number;
    /**
     * The rate limit (bandwidth allocation) for the virtual interface.
     *
     * The value must be one of the supported bandwidth values (e.g., 50Mbps, 1Gbps, 10Gbps) and cannot exceed the bandwidth of the parent connection or LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-ratelimit
     */
    readonly rateLimit?: string;
    /**
     * The tags associated with the private virtual interface.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The ID or ARN of the virtual private gateway.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-virtualgatewayid
     */
    readonly virtualGatewayId?: string;
    /**
     * The name of the virtual interface assigned by the customer network.
     *
     * The name has a maximum of 100 characters. The following are valid characters: a-z, 0-9 and a hyphen (-).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-virtualinterfacename
     */
    readonly virtualInterfaceName?: string;
    /**
     * The ID of the VLAN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-privatevirtualinterface.html#cfn-directconnect-privatevirtualinterface-vlan
     */
    readonly vlan?: number;
}
/**
 * Resource Type definition for AWS::DirectConnect::PublicVirtualInterface.
 *
 * @cloudformationResource AWS::DirectConnect::PublicVirtualInterface
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html
 */
export declare class CfnPublicVirtualInterfacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPublicVirtualInterfaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::PublicVirtualInterface`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPublicVirtualInterfaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPublicVirtualInterface;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPublicVirtualInterfacePropsMixin {
    /**
     * Information about a BGP peer.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html
     */
    interface BgpPeerProperty {
        /**
         * The address family for the BGP peer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html#cfn-directconnect-publicvirtualinterface-bgppeer-addressfamily
         */
        readonly addressFamily?: string;
        /**
         * The IP address assigned to the Amazon interface.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html#cfn-directconnect-publicvirtualinterface-bgppeer-amazonaddress
         */
        readonly amazonAddress?: string;
        /**
         * The autonomous system (AS) number for Border Gateway Protocol (BGP) configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html#cfn-directconnect-publicvirtualinterface-bgppeer-asn
         */
        readonly asn?: string;
        /**
         * The authentication key for BGP configuration.
         *
         * This string has a minimum length of 6 characters and and a maximum length of 80 characters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html#cfn-directconnect-publicvirtualinterface-bgppeer-authkey
         */
        readonly authKey?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html#cfn-directconnect-publicvirtualinterface-bgppeer-bgppeerid
         */
        readonly bgpPeerId?: string;
        /**
         * The IP address assigned to the customer interface.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-publicvirtualinterface-bgppeer.html#cfn-directconnect-publicvirtualinterface-bgppeer-customeraddress
         */
        readonly customerAddress?: string;
    }
}
/**
 * Properties for CfnPublicVirtualInterfacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html
 */
export interface CfnPublicVirtualInterfaceMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the role to allocate the public virtual interface.
     *
     * Needs directconnect:AllocatePublicVirtualInterface permissions and tag permissions if applicable.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-allocatepublicvirtualinterfacerolearn
     */
    readonly allocatePublicVirtualInterfaceRoleArn?: string;
    /**
     * The BGP peers configured on this virtual interface.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-bgppeers
     */
    readonly bgpPeers?: Array<CfnPublicVirtualInterfacePropsMixin.BgpPeerProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-connectionid
     */
    readonly connectionId?: directConnectRefs.IConnectionRef | directConnectRefs.ILagRef | string;
    /**
     * The rate limit (bandwidth allocation) for the virtual interface.
     *
     * The value must be one of the supported bandwidth values (e.g., 50Mbps, 1Gbps, 10Gbps) and cannot exceed the bandwidth of the parent connection or LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-ratelimit
     */
    readonly rateLimit?: string;
    /**
     * The routes to be advertised to the AWS network in this region.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-routefilterprefixes
     */
    readonly routeFilterPrefixes?: Array<string>;
    /**
     * The tags associated with the public virtual interface.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the virtual interface assigned by the customer network.
     *
     * The name has a maximum of 100 characters. The following are valid characters: a-z, 0-9 and a hyphen (-).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-virtualinterfacename
     */
    readonly virtualInterfaceName?: string;
    /**
     * The ID of the VLAN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-publicvirtualinterface.html#cfn-directconnect-publicvirtualinterface-vlan
     */
    readonly vlan?: number;
}
/**
 * Resource Type definition for AWS::DirectConnect::TransitVirtualInterface.
 *
 * @cloudformationResource AWS::DirectConnect::TransitVirtualInterface
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html
 */
export declare class CfnTransitVirtualInterfacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTransitVirtualInterfaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DirectConnect::TransitVirtualInterface`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTransitVirtualInterfaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTransitVirtualInterface;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTransitVirtualInterfacePropsMixin {
    /**
     * A key-value pair to associate with a resource.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html
     */
    interface BgpPeerProperty {
        /**
         * The address family for the BGP peer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html#cfn-directconnect-transitvirtualinterface-bgppeer-addressfamily
         */
        readonly addressFamily?: string;
        /**
         * The IP address assigned to the Amazon interface.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html#cfn-directconnect-transitvirtualinterface-bgppeer-amazonaddress
         */
        readonly amazonAddress?: string;
        /**
         * The autonomous system (AS) number for Border Gateway Protocol (BGP) configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html#cfn-directconnect-transitvirtualinterface-bgppeer-asn
         */
        readonly asn?: string;
        /**
         * The authentication key for BGP configuration.
         *
         * This string has a minimum length of 6 characters and and a maximum length of 80 characters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html#cfn-directconnect-transitvirtualinterface-bgppeer-authkey
         */
        readonly authKey?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html#cfn-directconnect-transitvirtualinterface-bgppeer-bgppeerid
         */
        readonly bgpPeerId?: string;
        /**
         * The IP address assigned to the customer interface.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-directconnect-transitvirtualinterface-bgppeer.html#cfn-directconnect-transitvirtualinterface-bgppeer-customeraddress
         */
        readonly customerAddress?: string;
    }
}
/**
 * Properties for CfnTransitVirtualInterfacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html
 */
export interface CfnTransitVirtualInterfaceMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the role to allocate the TransitVifAllocation.
     *
     * Needs directconnect:AllocateTransitVirtualInterface permissions and tag permissions if applicable.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-allocatetransitvirtualinterfacerolearn
     */
    readonly allocateTransitVirtualInterfaceRoleArn?: string;
    /**
     * The BGP peers configured on this virtual interface..
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-bgppeers
     */
    readonly bgpPeers?: Array<CfnTransitVirtualInterfacePropsMixin.BgpPeerProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-connectionid
     */
    readonly connectionId?: directConnectRefs.IConnectionRef | directConnectRefs.ILagRef | string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-directconnectgatewayid
     */
    readonly directConnectGatewayId?: directConnectRefs.IDirectConnectGatewayRef | string;
    /**
     * Indicates whether to enable or disable SiteLink.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-enablesitelink
     */
    readonly enableSiteLink?: boolean | cdk.IResolvable;
    /**
     * The maximum transmission unit (MTU), in bytes.
     *
     * The supported values are 1500 and 9001. The default value is 1500.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-mtu
     */
    readonly mtu?: number;
    /**
     * The rate limit (bandwidth allocation) for the virtual interface.
     *
     * The value must be one of the supported bandwidth values (e.g., 50Mbps, 1Gbps, 10Gbps) and cannot exceed the bandwidth of the parent connection or LAG.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-ratelimit
     */
    readonly rateLimit?: string;
    /**
     * The tags associated with the private virtual interface.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the virtual interface assigned by the customer network.
     *
     * The name has a maximum of 100 characters. The following are valid characters: a-z, 0-9 and a hyphen (-).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-virtualinterfacename
     */
    readonly virtualInterfaceName?: string;
    /**
     * The ID of the VLAN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-directconnect-transitvirtualinterface.html#cfn-directconnect-transitvirtualinterface-vlan
     */
    readonly vlan?: number;
}
