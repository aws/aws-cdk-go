import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-identitystore";
/**
 * A group object, which contains a specified group’s metadata and attributes.
 *
 * @cloudformationResource AWS::IdentityStore::Group
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-group.html
 */
export declare class CfnGroupPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnGroupMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::IdentityStore::Group`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnGroupMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnGroup;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnGroupPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-group.html
 */
export interface CfnGroupMixinProps {
    /**
     * A string containing the description of the group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-group.html#cfn-identitystore-group-description
     */
    readonly description?: string;
    /**
     * The display name value for the group.
     *
     * The length limit is 1,024 characters. This value can consist of letters, accented characters, symbols, numbers, punctuation, tab, new line, carriage return, space, and nonbreaking space in this attribute. This value is specified at the time the group is created and stored as an attribute of the group object in the identity store.
     *
     * Prefix search supports a maximum of 1,000 characters for the string.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-group.html#cfn-identitystore-group-displayname
     */
    readonly displayName?: string;
    /**
     * The globally unique identifier for the identity store.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-group.html#cfn-identitystore-group-identitystoreid
     */
    readonly identityStoreId?: string;
}
/**
 * Creates a relationship between a member and a group.
 *
 * The following identifiers must be specified: `GroupId` , `IdentityStoreId` , and `MemberId` .
 *
 * @cloudformationResource AWS::IdentityStore::GroupMembership
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-groupmembership.html
 */
export declare class CfnGroupMembershipPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnGroupMembershipMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::IdentityStore::GroupMembership`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnGroupMembershipMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnGroupMembership;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnGroupMembershipPropsMixin {
    /**
     * An object that contains the identifier of a group member.
     *
     * Setting the `UserID` field to the specific identifier for a user indicates that the user is a member of the group.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-groupmembership-memberid.html
     */
    interface MemberIdProperty {
        /**
         * An object containing the identifiers of resources that can be members.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-groupmembership-memberid.html#cfn-identitystore-groupmembership-memberid-userid
         */
        readonly userId?: string;
    }
}
/**
 * Properties for CfnGroupMembershipPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-groupmembership.html
 */
export interface CfnGroupMembershipMixinProps {
    /**
     * The identifier for a group in the identity store.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-groupmembership.html#cfn-identitystore-groupmembership-groupid
     */
    readonly groupId?: string;
    /**
     * The globally unique identifier for the identity store.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-groupmembership.html#cfn-identitystore-groupmembership-identitystoreid
     */
    readonly identityStoreId?: string;
    /**
     * An object containing the identifier of a group member.
     *
     * Setting the `MemberId` 's `UserId` field to a specific User's ID indicates that user is a member of the group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-groupmembership.html#cfn-identitystore-groupmembership-memberid
     */
    readonly memberId?: cdk.IResolvable | CfnGroupMembershipPropsMixin.MemberIdProperty;
}
/**
 * Creates a user within the specified identity store.
 *
 * @cloudformationResource AWS::IdentityStore::User
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html
 */
export declare class CfnUserPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnUserMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::IdentityStore::User`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnUserMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnUser;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnUserPropsMixin {
    /**
     * The name of the user.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html
     */
    interface NameProperty {
        /**
         * The family name of the user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html#cfn-identitystore-user-name-familyname
         */
        readonly familyName?: string;
        /**
         * A string containing a formatted version of the name for display.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html#cfn-identitystore-user-name-formatted
         */
        readonly formatted?: string;
        /**
         * The given name of the user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html#cfn-identitystore-user-name-givenname
         */
        readonly givenName?: string;
        /**
         * The honorific prefix of the user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html#cfn-identitystore-user-name-honorificprefix
         */
        readonly honorificPrefix?: string;
        /**
         * The honorific suffix of the user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html#cfn-identitystore-user-name-honorificsuffix
         */
        readonly honorificSuffix?: string;
        /**
         * The middle name of the user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-name.html#cfn-identitystore-user-name-middlename
         */
        readonly middleName?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-emailsitems.html
     */
    interface EmailsItemsProperty {
        /**
         * Whether this is the primary email address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-emailsitems.html#cfn-identitystore-user-emailsitems-primary
         */
        readonly primary?: boolean | cdk.IResolvable;
        /**
         * The type of email address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-emailsitems.html#cfn-identitystore-user-emailsitems-type
         */
        readonly type?: string;
        /**
         * The email address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-emailsitems.html#cfn-identitystore-user-emailsitems-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html
     */
    interface AddressesItemsProperty {
        /**
         * The country of the address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-country
         */
        readonly country?: string;
        /**
         * A formatted version of the address for display.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-formatted
         */
        readonly formatted?: string;
        /**
         * A string of the address locality.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-locality
         */
        readonly locality?: string;
        /**
         * The postal code of the address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-postalcode
         */
        readonly postalCode?: string;
        /**
         * Whether this is the primary address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-primary
         */
        readonly primary?: boolean | cdk.IResolvable;
        /**
         * The region of the address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-region
         */
        readonly region?: string;
        /**
         * The street of the address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-streetaddress
         */
        readonly streetAddress?: string;
        /**
         * The type of address.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-addressesitems.html#cfn-identitystore-user-addressesitems-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-phonenumbersitems.html
     */
    interface PhoneNumbersItemsProperty {
        /**
         * Whether this is the primary phone number.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-phonenumbersitems.html#cfn-identitystore-user-phonenumbersitems-primary
         */
        readonly primary?: boolean | cdk.IResolvable;
        /**
         * The type of phone number.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-phonenumbersitems.html#cfn-identitystore-user-phonenumbersitems-type
         */
        readonly type?: string;
        /**
         * The phone number.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-phonenumbersitems.html#cfn-identitystore-user-phonenumbersitems-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-photositems.html
     */
    interface PhotosItemsProperty {
        /**
         * A display name for the photo.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-photositems.html#cfn-identitystore-user-photositems-display
         */
        readonly display?: string;
        /**
         * Whether this is the primary photo.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-photositems.html#cfn-identitystore-user-photositems-primary
         */
        readonly primary?: boolean | cdk.IResolvable;
        /**
         * The type of photo.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-photositems.html#cfn-identitystore-user-photositems-type
         */
        readonly type?: string;
        /**
         * The photo data or URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-photositems.html#cfn-identitystore-user-photositems-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-rolesitems.html
     */
    interface RolesItemsProperty {
        /**
         * Whether this is the primary role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-rolesitems.html#cfn-identitystore-user-rolesitems-primary
         */
        readonly primary?: boolean | cdk.IResolvable;
        /**
         * The type of role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-rolesitems.html#cfn-identitystore-user-rolesitems-type
         */
        readonly type?: string;
        /**
         * The role name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-identitystore-user-rolesitems.html#cfn-identitystore-user-rolesitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnUserPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html
 */
export interface CfnUserMixinProps {
    /**
     * A list of addresses associated with the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-addresses
     */
    readonly addresses?: Array<CfnUserPropsMixin.AddressesItemsProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The user's birthdate in YYYY-MM-DD format.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-birthdate
     */
    readonly birthdate?: string;
    /**
     * A string containing the name of the user for display.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-displayname
     */
    readonly displayName?: string;
    /**
     * A list of email addresses associated with the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-emails
     */
    readonly emails?: Array<CfnUserPropsMixin.EmailsItemsProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The globally unique identifier for the identity store.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-identitystoreid
     */
    readonly identityStoreId?: string;
    /**
     * The geographical region or location of the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-locale
     */
    readonly locale?: string;
    /**
     * The name of the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-name
     */
    readonly name?: cdk.IResolvable | CfnUserPropsMixin.NameProperty;
    /**
     * An alternate name for the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-nickname
     */
    readonly nickName?: string;
    /**
     * A list of phone numbers associated with the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-phonenumbers
     */
    readonly phoneNumbers?: Array<cdk.IResolvable | CfnUserPropsMixin.PhoneNumbersItemsProperty> | cdk.IResolvable;
    /**
     * A list of photos associated with the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-photos
     */
    readonly photos?: Array<cdk.IResolvable | CfnUserPropsMixin.PhotosItemsProperty> | cdk.IResolvable;
    /**
     * The preferred language of the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-preferredlanguage
     */
    readonly preferredLanguage?: string;
    /**
     * A URL associated with the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-profileurl
     */
    readonly profileUrl?: string;
    /**
     * A list of roles associated with the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-roles
     */
    readonly roles?: Array<cdk.IResolvable | CfnUserPropsMixin.RolesItemsProperty> | cdk.IResolvable;
    /**
     * The time zone for the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-timezone
     */
    readonly timezone?: string;
    /**
     * The title of the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-title
     */
    readonly title?: string;
    /**
     * A unique string used to identify the user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-username
     */
    readonly userName?: string;
    /**
     * A string indicating the type of user.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-usertype
     */
    readonly userType?: string;
    /**
     * The user's personal website or blog URL.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-identitystore-user.html#cfn-identitystore-user-website
     */
    readonly website?: string;
}
