import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-cloudhsm";
/**
 * Creates and manages an AWS CloudHSM cluster.
 *
 * @cloudformationResource AWS::CloudHSM::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html
 */
export declare class CfnClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CloudHSM::Cluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnClusterPropsMixin {
    /**
     * A policy that defines how the service retains backups.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cloudhsm-cluster-backupretentionpolicy.html
     */
    interface BackupRetentionPolicyProperty {
        /**
         * The type of backup retention policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cloudhsm-cluster-backupretentionpolicy.html#cfn-cloudhsm-cluster-backupretentionpolicy-type
         */
        readonly type?: string;
        /**
         * Use a value between 7 - 379.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cloudhsm-cluster-backupretentionpolicy.html#cfn-cloudhsm-cluster-backupretentionpolicy-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cloudhsm-cluster-tagsitems.html
     */
    interface TagsItemsProperty {
        /**
         * The key of the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cloudhsm-cluster-tagsitems.html#cfn-cloudhsm-cluster-tagsitems-key
         */
        readonly key?: string;
        /**
         * The value of the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cloudhsm-cluster-tagsitems.html#cfn-cloudhsm-cluster-tagsitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html
 */
export interface CfnClusterMixinProps {
    /**
     * A policy that defines how the service retains backups.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html#cfn-cloudhsm-cluster-backupretentionpolicy
     */
    readonly backupRetentionPolicy?: CfnClusterPropsMixin.BackupRetentionPolicyProperty | cdk.IResolvable;
    /**
     * The type of HSM to use in the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html#cfn-cloudhsm-cluster-hsmtype
     */
    readonly hsmType?: string;
    /**
     * The mode to use in the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html#cfn-cloudhsm-cluster-mode
     */
    readonly mode?: string;
    /**
     * The NetworkType to create a cluster with.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html#cfn-cloudhsm-cluster-networktype
     */
    readonly networkType?: string;
    /**
     * The identifiers (IDs) of the subnets where the cluster is created.
     *
     * You must specify at least one subnet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html#cfn-cloudhsm-cluster-subnetids
     */
    readonly subnetIds?: Array<string>;
    /**
     * Tags to apply to the CloudHSM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cloudhsm-cluster.html#cfn-cloudhsm-cluster-tags
     */
    readonly tags?: Array<CfnClusterPropsMixin.TagsItemsProperty>;
}
