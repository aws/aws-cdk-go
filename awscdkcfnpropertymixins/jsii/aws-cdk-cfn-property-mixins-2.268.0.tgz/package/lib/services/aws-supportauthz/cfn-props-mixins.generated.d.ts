import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-supportauthz";
/**
 * Resource Type definition for AWS::SupportAuthZ::SupportPermit.
 *
 * Represents a support permit that grants AWS support time-bounded access to one or more resources for a set of actions.
 *
 * @cloudformationResource AWS::SupportAuthZ::SupportPermit
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html
 */
export declare class CfnSupportPermitPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSupportPermitMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SupportAuthZ::SupportPermit`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSupportPermitMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSupportPermit;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSupportPermitPropsMixin {
    /**
     * The grant definition: which actions on which resources, optionally constrained by time conditions.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-permit.html
     */
    interface PermitProperty {
        /**
         * The set of actions a support permit grants.
         *
         * Exactly one of AllActions or Actions must be provided.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-permit.html#cfn-supportauthz-supportpermit-permit-actions
         */
        readonly actions?: CfnSupportPermitPropsMixin.ActionSetProperty | cdk.IResolvable;
        /**
         * Optional time-bound conditions (at most two).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-permit.html#cfn-supportauthz-supportpermit-permit-conditions
         */
        readonly conditions?: Array<CfnSupportPermitPropsMixin.ConditionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The set of resources a support permit applies to.
         *
         * Exactly one of AllResourcesInRegion or Resources must be provided.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-permit.html#cfn-supportauthz-supportpermit-permit-resources
         */
        readonly resources?: cdk.IResolvable | CfnSupportPermitPropsMixin.ResourceSetProperty;
    }
    /**
     * The set of actions a support permit grants.
     *
     * Exactly one of AllActions or Actions must be provided.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-actionset.html
     */
    interface ActionSetProperty {
        /**
         * An explicit list of actions to grant.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-actionset.html#cfn-supportauthz-supportpermit-actionset-actions
         */
        readonly actions?: Array<string>;
        /**
         * Grants all actions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-actionset.html#cfn-supportauthz-supportpermit-actionset-allactions
         */
        readonly allActions?: any | cdk.IResolvable;
    }
    /**
     * The set of resources a support permit applies to.
     *
     * Exactly one of AllResourcesInRegion or Resources must be provided.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-resourceset.html
     */
    interface ResourceSetProperty {
        /**
         * Applies to all resources in the region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-resourceset.html#cfn-supportauthz-supportpermit-resourceset-allresourcesinregion
         */
        readonly allResourcesInRegion?: any | cdk.IResolvable;
        /**
         * An explicit list of resource ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-resourceset.html#cfn-supportauthz-supportpermit-resourceset-resources
         */
        readonly resources?: Array<string>;
    }
    /**
     * A time-bound condition controlling when the permit is active.
     *
     * Exactly one of AllowAfter or AllowBefore must be provided.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-condition.html
     */
    interface ConditionProperty {
        /**
         * The permit is active only after this time.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-condition.html#cfn-supportauthz-supportpermit-condition-allowafter
         */
        readonly allowAfter?: string;
        /**
         * The permit is active only before this time.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-condition.html#cfn-supportauthz-supportpermit-condition-allowbefore
         */
        readonly allowBefore?: string;
    }
    /**
     * The signing key used by the permit.
     *
     * Exactly one key type must be provided.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-signingkeyinfo.html
     */
    interface SigningKeyInfoProperty {
        /**
         * The ARN of the KMS key used to sign permit grants.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-supportauthz-supportpermit-signingkeyinfo.html#cfn-supportauthz-supportpermit-signingkeyinfo-kmskey
         */
        readonly kmsKey?: string;
    }
}
/**
 * Properties for CfnSupportPermitPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html
 */
export interface CfnSupportPermitMixinProps {
    /**
     * An optional description of the support permit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html#cfn-supportauthz-supportpermit-description
     */
    readonly description?: string;
    /**
     * The name of the support permit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html#cfn-supportauthz-supportpermit-name
     */
    readonly name?: string;
    /**
     * The grant definition: which actions on which resources, optionally constrained by time conditions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html#cfn-supportauthz-supportpermit-permit
     */
    readonly permit?: cdk.IResolvable | CfnSupportPermitPropsMixin.PermitProperty;
    /**
     * The signing key used by the permit.
     *
     * Exactly one key type must be provided.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html#cfn-supportauthz-supportpermit-signingkeyinfo
     */
    readonly signingKeyInfo?: cdk.IResolvable | CfnSupportPermitPropsMixin.SigningKeyInfoProperty;
    /**
     * The support case display identifier associated with the permit.
     *
     * When provided, the permit is linked to the specified AWS Support case.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html#cfn-supportauthz-supportpermit-supportcasedisplayid
     */
    readonly supportCaseDisplayId?: string;
    /**
     * A list of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-supportauthz-supportpermit.html#cfn-supportauthz-supportpermit-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
