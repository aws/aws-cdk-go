import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-translate";
/**
 * A parallel data resource in Amazon Translate used to customize machine translation output.
 *
 * @cloudformationResource AWS::Translate::ParallelData
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html
 */
export declare class CfnParallelDataPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnParallelDataMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Translate::ParallelData`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnParallelDataMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnParallelData;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnParallelDataPropsMixin {
    /**
     * Specifies the format and S3 location of the parallel data input file.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-paralleldataconfig.html
     */
    interface ParallelDataConfigProperty {
        /**
         * The format of the parallel data input file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-paralleldataconfig.html#cfn-translate-paralleldata-paralleldataconfig-format
         */
        readonly format?: string;
        /**
         * The URI of the Amazon S3 folder that contains the parallel data input file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-paralleldataconfig.html#cfn-translate-paralleldata-paralleldataconfig-s3uri
         */
        readonly s3Uri?: string;
    }
    /**
     * The encryption key used to encrypt this object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-encryptionkey.html
     */
    interface EncryptionKeyProperty {
        /**
         * The Amazon Resource Name (ARN) of the encryption key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-encryptionkey.html#cfn-translate-paralleldata-encryptionkey-id
         */
        readonly id?: string;
        /**
         * The type of encryption key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-encryptionkey.html#cfn-translate-paralleldata-encryptionkey-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-tagsitems.html
     */
    interface TagsItemsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-tagsitems.html#cfn-translate-paralleldata-tagsitems-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-translate-paralleldata-tagsitems.html#cfn-translate-paralleldata-tagsitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnParallelDataPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html
 */
export interface CfnParallelDataMixinProps {
    /**
     * A custom description for the parallel data resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-description
     */
    readonly description?: string;
    /**
     * The encryption key used to encrypt this object.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-encryptionkey
     */
    readonly encryptionKey?: CfnParallelDataPropsMixin.EncryptionKeyProperty | cdk.IResolvable;
    /**
     * A custom name for the parallel data resource.
     *
     * Must be unique in the account and region.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-name
     */
    readonly name?: string;
    /**
     * Specifies the format and S3 location of the parallel data input file.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-paralleldataconfig
     */
    readonly parallelDataConfig?: cdk.IResolvable | CfnParallelDataPropsMixin.ParallelDataConfigProperty;
    /**
     * Tags associated with the parallel data resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-translate-paralleldata.html#cfn-translate-paralleldata-tags
     */
    readonly tags?: Array<CfnParallelDataPropsMixin.TagsItemsProperty>;
}
