import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-iotsecuretunneling";
/**
 * A connection between a source computer and a destination device using AWS IoT Secure Tunneling.
 *
 * @cloudformationResource AWS::IoTSecureTunneling::Tunnel
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iotsecuretunneling-tunnel.html
 */
export declare class CfnTunnelPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTunnelMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::IoTSecureTunneling::Tunnel`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTunnelMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTunnel;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTunnelPropsMixin {
    /**
     * The destination configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-iotsecuretunneling-tunnel-destinationconfig.html
     */
    interface DestinationConfigProperty {
        /**
         * A list of service names that identify the target application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-iotsecuretunneling-tunnel-destinationconfig.html#cfn-iotsecuretunneling-tunnel-destinationconfig-services
         */
        readonly services?: Array<string>;
        /**
         * The name of the IoT thing to which you want to connect.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-iotsecuretunneling-tunnel-destinationconfig.html#cfn-iotsecuretunneling-tunnel-destinationconfig-thingname
         */
        readonly thingName?: string;
    }
    /**
     * Tunnel timeout configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-iotsecuretunneling-tunnel-timeoutconfig.html
     */
    interface TimeoutConfigProperty {
        /**
         * The maximum amount of time (in minutes) a tunnel can remain open.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-iotsecuretunneling-tunnel-timeoutconfig.html#cfn-iotsecuretunneling-tunnel-timeoutconfig-maxlifetimetimeoutminutes
         */
        readonly maxLifetimeTimeoutMinutes?: number;
    }
}
/**
 * Properties for CfnTunnelPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iotsecuretunneling-tunnel.html
 */
export interface CfnTunnelMixinProps {
    /**
     * A short text description of the tunnel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iotsecuretunneling-tunnel.html#cfn-iotsecuretunneling-tunnel-description
     */
    readonly description?: string;
    /**
     * The destination configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iotsecuretunneling-tunnel.html#cfn-iotsecuretunneling-tunnel-destinationconfig
     */
    readonly destinationConfig?: CfnTunnelPropsMixin.DestinationConfigProperty | cdk.IResolvable;
    /**
     * A collection of tag metadata.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iotsecuretunneling-tunnel.html#cfn-iotsecuretunneling-tunnel-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Tunnel timeout configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-iotsecuretunneling-tunnel.html#cfn-iotsecuretunneling-tunnel-timeoutconfig
     */
    readonly timeoutConfig?: cdk.IResolvable | CfnTunnelPropsMixin.TimeoutConfigProperty;
}
