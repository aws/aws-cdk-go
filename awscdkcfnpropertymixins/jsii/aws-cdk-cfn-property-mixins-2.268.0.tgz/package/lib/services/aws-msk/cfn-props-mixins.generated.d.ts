import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-msk";
import { aws_acmpca as acmpcaRefs, aws_ec2 as ec2Refs, aws_kms as kmsRefs, aws_logs as logsRefs, aws_msk as mskRefs } from "aws-cdk-lib/interfaces";
/**
 * Represents a secret stored in the AWS Secrets Manager that can be used to authenticate with a cluster using a user name and a password.
 *
 * @cloudformationResource AWS::MSK::BatchScramSecret
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-batchscramsecret.html
 */
export declare class CfnBatchScramSecretPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnBatchScramSecretMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::BatchScramSecret`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnBatchScramSecretMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnBatchScramSecret;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnBatchScramSecretPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-batchscramsecret.html
 */
export interface CfnBatchScramSecretMixinProps {
    /**
     * The Amazon Resource Name (ARN) that uniquely identifies the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-batchscramsecret.html#cfn-msk-batchscramsecret-clusterarn
     */
    readonly clusterArn?: string;
    /**
     * List of Amazon Resource Name (ARN)s of Secrets Manager secrets.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-batchscramsecret.html#cfn-msk-batchscramsecret-secretarnlist
     */
    readonly secretArnList?: Array<string>;
}
/**
 * Creates a new MSK cluster.
 *
 * @cloudformationResource AWS::MSK::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html
 */
export declare class CfnClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::Cluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnClusterPropsMixin {
    /**
     * Includes encryption-related information, such as the Amazon KMS key used for encrypting data at rest and whether you want MSK to encrypt your data in transit.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptioninfo.html
     */
    interface EncryptionInfoProperty {
        /**
         * The data-volume encryption details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptioninfo.html#cfn-msk-cluster-encryptioninfo-encryptionatrest
         */
        readonly encryptionAtRest?: CfnClusterPropsMixin.EncryptionAtRestProperty | cdk.IResolvable;
        /**
         * The details for encryption in transit.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptioninfo.html#cfn-msk-cluster-encryptioninfo-encryptionintransit
         */
        readonly encryptionInTransit?: CfnClusterPropsMixin.EncryptionInTransitProperty | cdk.IResolvable;
    }
    /**
     * The data-volume encryption details.
     *
     * You can't update encryption at rest settings for existing clusters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptionatrest.html
     */
    interface EncryptionAtRestProperty {
        /**
         * The ARN of the Amazon KMS key for encrypting data at rest.
         *
         * If you don't specify a KMS key, MSK creates one for you and uses it.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptionatrest.html#cfn-msk-cluster-encryptionatrest-datavolumekmskeyid
         */
        readonly dataVolumeKmsKeyId?: kmsRefs.IKeyRef | string;
    }
    /**
     * The settings for encrypting data in transit.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptionintransit.html
     */
    interface EncryptionInTransitProperty {
        /**
         * Indicates the encryption setting for data in transit between clients and brokers.
         *
         * You must set it to one of the following values.
         *
         * - `TLS` : Indicates that client-broker communication is enabled with TLS only.
         * - `TLS_PLAINTEXT` : Indicates that client-broker communication is enabled for both TLS-encrypted, as well as plaintext data.
         * - `PLAINTEXT` : Indicates that client-broker communication is enabled in plaintext only.
         *
         * The default value is `TLS` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptionintransit.html#cfn-msk-cluster-encryptionintransit-clientbroker
         */
        readonly clientBroker?: string;
        /**
         * When set to true, it indicates that data communication among the broker nodes of the cluster is encrypted.
         *
         * When set to false, the communication happens in plaintext.
         *
         * The default value is true.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-encryptionintransit.html#cfn-msk-cluster-encryptionintransit-incluster
         */
        readonly inCluster?: boolean | cdk.IResolvable;
    }
    /**
     * JMX and Node monitoring for the MSK cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-openmonitoring.html
     */
    interface OpenMonitoringProperty {
        /**
         * Prometheus exporter settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-openmonitoring.html#cfn-msk-cluster-openmonitoring-prometheus
         */
        readonly prometheus?: cdk.IResolvable | CfnClusterPropsMixin.PrometheusProperty;
    }
    /**
     * Prometheus settings for open monitoring.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-prometheus.html
     */
    interface PrometheusProperty {
        /**
         * Indicates whether you want to enable or disable the JMX Exporter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-prometheus.html#cfn-msk-cluster-prometheus-jmxexporter
         */
        readonly jmxExporter?: cdk.IResolvable | CfnClusterPropsMixin.JmxExporterProperty;
        /**
         * Indicates whether you want to enable or disable the Node Exporter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-prometheus.html#cfn-msk-cluster-prometheus-nodeexporter
         */
        readonly nodeExporter?: cdk.IResolvable | CfnClusterPropsMixin.NodeExporterProperty;
    }
    /**
     * Indicates whether you want to enable or disable the JMX Exporter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-jmxexporter.html
     */
    interface JmxExporterProperty {
        /**
         * Indicates whether you want to enable or disable the JMX Exporter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-jmxexporter.html#cfn-msk-cluster-jmxexporter-enabledinbroker
         */
        readonly enabledInBroker?: boolean | cdk.IResolvable;
    }
    /**
     * Indicates whether you want to enable or disable the Node Exporter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-nodeexporter.html
     */
    interface NodeExporterProperty {
        /**
         * Indicates whether you want to enable or disable the Node Exporter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-nodeexporter.html#cfn-msk-cluster-nodeexporter-enabledinbroker
         */
        readonly enabledInBroker?: boolean | cdk.IResolvable;
    }
    /**
     * Specifies the configuration to use for the brokers.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-configurationinfo.html
     */
    interface ConfigurationInfoProperty {
        /**
         * ARN of the configuration to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-configurationinfo.html#cfn-msk-cluster-configurationinfo-arn
         */
        readonly arn?: mskRefs.IConfigurationRef | string;
        /**
         * The revision of the configuration to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-configurationinfo.html#cfn-msk-cluster-configurationinfo-revision
         */
        readonly revision?: number;
    }
    /**
     * Describes the setup to be used for the broker nodes in the cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html
     */
    interface BrokerNodeGroupInfoProperty {
        /**
         * This parameter is currently not in use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html#cfn-msk-cluster-brokernodegroupinfo-brokerazdistribution
         */
        readonly brokerAzDistribution?: string;
        /**
         * The list of subnets to connect to in the client virtual private cloud (VPC).
         *
         * Amazon creates elastic network interfaces (ENIs) inside these subnets. Client applications use ENIs to produce and consume data.
         *
         * If you use the US West (N. California) Region, specify exactly two subnets. For other Regions where Amazon MSK is available, you can specify either two or three subnets. The subnets that you specify must be in distinct Availability Zones. When you create a cluster, Amazon MSK distributes the broker nodes evenly across the subnets that you specify.
         *
         * Client subnets can't occupy the Availability Zone with ID `use1-az3` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html#cfn-msk-cluster-brokernodegroupinfo-clientsubnets
         */
        readonly clientSubnets?: Array<ec2Refs.ISubnetRef | string>;
        /**
         * Information about the cluster's connectivity setting.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html#cfn-msk-cluster-brokernodegroupinfo-connectivityinfo
         */
        readonly connectivityInfo?: CfnClusterPropsMixin.ConnectivityInfoProperty | cdk.IResolvable;
        /**
         * The type of Amazon EC2 instances to use for brokers.
         *
         * Depending on the [broker type](https://docs.aws.amazon.com/msk/latest/developerguide/broker-instance-types.html) , Amazon MSK supports the following broker sizes:
         *
         * *Standard broker sizes*
         *
         * - kafka.t3.small
         *
         * > You can't select the kafka.t3.small instance type when the metadata mode is KRaft.
         * - kafka.m5.large, kafka.m5.xlarge, kafka.m5.2xlarge, kafka.m5.4xlarge, kafka.m5.8xlarge, kafka.m5.12xlarge, kafka.m5.16xlarge, kafka.m5.24xlarge
         * - kafka.m7g.large, kafka.m7g.xlarge, kafka.m7g.2xlarge, kafka.m7g.4xlarge, kafka.m7g.8xlarge, kafka.m7g.12xlarge, kafka.m7g.16xlarge
         *
         * *Express broker sizes*
         *
         * - express.m7g.large, express.m7g.xlarge, express.m7g.2xlarge, express.m7g.4xlarge, express.m7g.8xlarge, express.m7g.12xlarge, express.m7g.16xlarge
         *
         * > Some broker sizes might not be available in certian AWS Regions. See the updated [Pricing tools](https://docs.aws.amazon.com/msk/pricing/) section on the Amazon MSK pricing page for the latest list of available instances by Region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html#cfn-msk-cluster-brokernodegroupinfo-instancetype
         */
        readonly instanceType?: string;
        /**
         * The security groups to associate with the ENIs in order to specify who can connect to and communicate with the Amazon MSK cluster.
         *
         * If you don't specify a security group, Amazon MSK uses the default security group associated with the VPC. If you specify security groups that were shared with you, you must ensure that you have permissions to them. Specifically, you need the `ec2:DescribeSecurityGroups` permission.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html#cfn-msk-cluster-brokernodegroupinfo-securitygroups
         */
        readonly securityGroups?: Array<ec2Refs.ISecurityGroupRef | string>;
        /**
         * Contains information about storage volumes attached to Amazon MSK broker nodes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokernodegroupinfo.html#cfn-msk-cluster-brokernodegroupinfo-storageinfo
         */
        readonly storageInfo?: cdk.IResolvable | CfnClusterPropsMixin.StorageInfoProperty;
    }
    /**
     * Broker access controls.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-connectivityinfo.html
     */
    interface ConnectivityInfoProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-connectivityinfo.html#cfn-msk-cluster-connectivityinfo-networktype
         */
        readonly networkType?: string;
        /**
         * Access control settings for the cluster's brokers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-connectivityinfo.html#cfn-msk-cluster-connectivityinfo-publicaccess
         */
        readonly publicAccess?: cdk.IResolvable | CfnClusterPropsMixin.PublicAccessProperty;
        /**
         * VPC connection control settings for brokers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-connectivityinfo.html#cfn-msk-cluster-connectivityinfo-vpcconnectivity
         */
        readonly vpcConnectivity?: cdk.IResolvable | CfnClusterPropsMixin.VpcConnectivityProperty;
    }
    /**
     * VPC connection control settings for brokers.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivity.html
     */
    interface VpcConnectivityProperty {
        /**
         * VPC connection control settings for brokers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivity.html#cfn-msk-cluster-vpcconnectivity-clientauthentication
         */
        readonly clientAuthentication?: cdk.IResolvable | CfnClusterPropsMixin.VpcConnectivityClientAuthenticationProperty;
    }
    /**
     * Includes all client authentication information for VpcConnectivity.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityclientauthentication.html
     */
    interface VpcConnectivityClientAuthenticationProperty {
        /**
         * Details for VpcConnectivity ClientAuthentication using SASL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityclientauthentication.html#cfn-msk-cluster-vpcconnectivityclientauthentication-sasl
         */
        readonly sasl?: cdk.IResolvable | CfnClusterPropsMixin.VpcConnectivitySaslProperty;
        /**
         * Details for VpcConnectivity ClientAuthentication using TLS.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityclientauthentication.html#cfn-msk-cluster-vpcconnectivityclientauthentication-tls
         */
        readonly tls?: cdk.IResolvable | CfnClusterPropsMixin.VpcConnectivityTlsProperty;
    }
    /**
     * Details for client authentication using SASL for VpcConnectivity.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivitysasl.html
     */
    interface VpcConnectivitySaslProperty {
        /**
         * Details for ClientAuthentication using IAM for VpcConnectivity.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivitysasl.html#cfn-msk-cluster-vpcconnectivitysasl-iam
         */
        readonly iam?: cdk.IResolvable | CfnClusterPropsMixin.VpcConnectivityIamProperty;
        /**
         * Details for SASL/SCRAM client authentication for VpcConnectivity.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivitysasl.html#cfn-msk-cluster-vpcconnectivitysasl-scram
         */
        readonly scram?: cdk.IResolvable | CfnClusterPropsMixin.VpcConnectivityScramProperty;
    }
    /**
     * Details for SASL/IAM client authentication for VpcConnectivity.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityiam.html
     */
    interface VpcConnectivityIamProperty {
        /**
         * SASL/IAM authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityiam.html#cfn-msk-cluster-vpcconnectivityiam-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details for SASL/SCRAM client authentication for VpcConnectivity.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityscram.html
     */
    interface VpcConnectivityScramProperty {
        /**
         * SASL/SCRAM authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivityscram.html#cfn-msk-cluster-vpcconnectivityscram-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details for client authentication using TLS for VpcConnectivity.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivitytls.html
     */
    interface VpcConnectivityTlsProperty {
        /**
         * TLS authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-vpcconnectivitytls.html#cfn-msk-cluster-vpcconnectivitytls-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Broker access controls.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-publicaccess.html
     */
    interface PublicAccessProperty {
        /**
         * DISABLED means that public access is turned off.
         *
         * SERVICE_PROVIDED_EIPS means that public access is turned on.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-publicaccess.html#cfn-msk-cluster-publicaccess-type
         */
        readonly type?: string;
    }
    /**
     * Contains information about storage volumes attached to Amazon MSK broker nodes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-storageinfo.html
     */
    interface StorageInfoProperty {
        /**
         * EBS volume information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-storageinfo.html#cfn-msk-cluster-storageinfo-ebsstorageinfo
         */
        readonly ebsStorageInfo?: CfnClusterPropsMixin.EBSStorageInfoProperty | cdk.IResolvable;
    }
    /**
     * Contains information about the EBS storage volumes attached to the broker nodes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-ebsstorageinfo.html
     */
    interface EBSStorageInfoProperty {
        /**
         * EBS volume provisioned throughput information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-ebsstorageinfo.html#cfn-msk-cluster-ebsstorageinfo-provisionedthroughput
         */
        readonly provisionedThroughput?: cdk.IResolvable | CfnClusterPropsMixin.ProvisionedThroughputProperty;
        /**
         * The size in GiB of the EBS volume for the data drive on each broker node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-ebsstorageinfo.html#cfn-msk-cluster-ebsstorageinfo-volumesize
         */
        readonly volumeSize?: number;
    }
    /**
     * Contains information about provisioned throughput for EBS storage volumes attached to kafka broker nodes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-provisionedthroughput.html
     */
    interface ProvisionedThroughputProperty {
        /**
         * Provisioned throughput is on or off.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-provisionedthroughput.html#cfn-msk-cluster-provisionedthroughput-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * Throughput value of the EBS volumes for the data drive on each kafka broker node in MiB per second.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-provisionedthroughput.html#cfn-msk-cluster-provisionedthroughput-volumethroughput
         */
        readonly volumeThroughput?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-clientauthentication.html
     */
    interface ClientAuthenticationProperty {
        /**
         * Details for client authentication using SASL.
         *
         * To turn on SASL, you must also turn on `EncryptionInTransit` by setting `inCluster` to true. You must set `clientBroker` to either `TLS` or `TLS_PLAINTEXT` . If you choose `TLS_PLAINTEXT` , then you must also set `unauthenticated` to true.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-clientauthentication.html#cfn-msk-cluster-clientauthentication-sasl
         */
        readonly sasl?: cdk.IResolvable | CfnClusterPropsMixin.SaslProperty;
        /**
         * Details for ClientAuthentication using TLS.
         *
         * To turn on TLS access control, you must also turn on `EncryptionInTransit` by setting `inCluster` to true and `clientBroker` to `TLS` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-clientauthentication.html#cfn-msk-cluster-clientauthentication-tls
         */
        readonly tls?: cdk.IResolvable | CfnClusterPropsMixin.TlsProperty;
        /**
         * Details for ClientAuthentication using no authentication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-clientauthentication.html#cfn-msk-cluster-clientauthentication-unauthenticated
         */
        readonly unauthenticated?: cdk.IResolvable | CfnClusterPropsMixin.UnauthenticatedProperty;
    }
    /**
     * Details for client authentication using SASL.
     *
     * To turn on SASL, you must also turn on `EncryptionInTransit` by setting `inCluster` to true. You must set `clientBroker` to either `TLS` or `TLS_PLAINTEXT` . If you choose `TLS_PLAINTEXT` , then you must also set `unauthenticated` to true.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-sasl.html
     */
    interface SaslProperty {
        /**
         * Details for ClientAuthentication using IAM.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-sasl.html#cfn-msk-cluster-sasl-iam
         */
        readonly iam?: CfnClusterPropsMixin.IamProperty | cdk.IResolvable;
        /**
         * Details for SASL/SCRAM client authentication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-sasl.html#cfn-msk-cluster-sasl-scram
         */
        readonly scram?: cdk.IResolvable | CfnClusterPropsMixin.ScramProperty;
    }
    /**
     * Details for SASL/IAM client authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-iam.html
     */
    interface IamProperty {
        /**
         * SASL/IAM authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-iam.html#cfn-msk-cluster-iam-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details for SASL/SCRAM client authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-scram.html
     */
    interface ScramProperty {
        /**
         * SASL/SCRAM authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-scram.html#cfn-msk-cluster-scram-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details for allowing no client authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-unauthenticated.html
     */
    interface UnauthenticatedProperty {
        /**
         * Unauthenticated is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-unauthenticated.html#cfn-msk-cluster-unauthenticated-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details for client authentication using TLS.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-tls.html
     */
    interface TlsProperty {
        /**
         * List of AWS Private CA ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-tls.html#cfn-msk-cluster-tls-certificateauthorityarnlist
         */
        readonly certificateAuthorityArnList?: Array<acmpcaRefs.ICertificateAuthorityRef | string>;
        /**
         * TLS authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-tls.html#cfn-msk-cluster-tls-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * You can configure your MSK cluster to send broker logs to different destination types.
     *
     * This is a container for the configuration details related to broker logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-logginginfo.html
     */
    interface LoggingInfoProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-logginginfo.html#cfn-msk-cluster-logginginfo-authorizerlogs
         */
        readonly authorizerLogs?: CfnClusterPropsMixin.AuthorizerLogsProperty | cdk.IResolvable;
        /**
         * You can configure your MSK cluster to send broker logs to different destination types.
         *
         * This configuration specifies the details of these destinations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-logginginfo.html#cfn-msk-cluster-logginginfo-brokerlogs
         */
        readonly brokerLogs?: CfnClusterPropsMixin.BrokerLogsProperty | cdk.IResolvable;
    }
    /**
     * The broker logs configuration for this MSK cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokerlogs.html
     */
    interface BrokerLogsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokerlogs.html#cfn-msk-cluster-brokerlogs-cloudwatchlogs
         */
        readonly cloudWatchLogs?: CfnClusterPropsMixin.CloudWatchLogsProperty | cdk.IResolvable;
        /**
         * Details of the Kinesis Data Firehose delivery stream that is the destination for broker logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokerlogs.html#cfn-msk-cluster-brokerlogs-firehose
         */
        readonly firehose?: CfnClusterPropsMixin.FirehoseProperty | cdk.IResolvable;
        /**
         * Details of the Amazon S3 destination for broker logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-brokerlogs.html#cfn-msk-cluster-brokerlogs-s3
         */
        readonly s3?: cdk.IResolvable | CfnClusterPropsMixin.S3Property;
    }
    /**
     * The details of the Amazon S3 destination for broker logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-s3.html
     */
    interface S3Property {
        /**
         * The name of the S3 bucket that is the destination for broker logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-s3.html#cfn-msk-cluster-s3-bucket
         */
        readonly bucket?: string;
        /**
         * Specifies whether broker logs get sent to the specified Amazon S3 destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-s3.html#cfn-msk-cluster-s3-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The S3 prefix that is the destination for broker logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-s3.html#cfn-msk-cluster-s3-prefix
         */
        readonly prefix?: string;
    }
    /**
     * Firehose details for BrokerLogs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-firehose.html
     */
    interface FirehoseProperty {
        /**
         * The Kinesis Data Firehose delivery stream that is the destination for broker logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-firehose.html#cfn-msk-cluster-firehose-deliverystream
         */
        readonly deliveryStream?: string;
        /**
         * Specifies whether broker logs get send to the specified Kinesis Data Firehose delivery stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-firehose.html#cfn-msk-cluster-firehose-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details of the CloudWatch Logs destination for broker logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-cloudwatchlogs.html
     */
    interface CloudWatchLogsProperty {
        /**
         * Specifies whether broker logs get sent to the specified CloudWatch Logs destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-cloudwatchlogs.html#cfn-msk-cluster-cloudwatchlogs-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The CloudWatch log group that is the destination for broker logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-cloudwatchlogs.html#cfn-msk-cluster-cloudwatchlogs-loggroup
         */
        readonly logGroup?: logsRefs.ILogGroupRef | string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-authorizerlogs.html
     */
    interface AuthorizerLogsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-authorizerlogs.html#cfn-msk-cluster-authorizerlogs-cloudwatchlogs
         */
        readonly cloudWatchLogs?: CfnClusterPropsMixin.CloudWatchLogsProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-authorizerlogs.html#cfn-msk-cluster-authorizerlogs-firehose
         */
        readonly firehose?: CfnClusterPropsMixin.FirehoseProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-authorizerlogs.html#cfn-msk-cluster-authorizerlogs-s3
         */
        readonly s3?: cdk.IResolvable | CfnClusterPropsMixin.S3Property;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-rebalancing.html
     */
    interface RebalancingProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-rebalancing.html#cfn-msk-cluster-rebalancing-status
         */
        readonly status?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-zookeeperaccess.html
     */
    interface ZookeeperAccessProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-cluster-zookeeperaccess.html#cfn-msk-cluster-zookeeperaccess-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html
 */
export interface CfnClusterMixinProps {
    /**
     * Information about the broker nodes in the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-brokernodegroupinfo
     */
    readonly brokerNodeGroupInfo?: CfnClusterPropsMixin.BrokerNodeGroupInfoProperty | cdk.IResolvable;
    /**
     * Includes all client authentication related information.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-clientauthentication
     */
    readonly clientAuthentication?: CfnClusterPropsMixin.ClientAuthenticationProperty | cdk.IResolvable;
    /**
     * The name of the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-clustername
     */
    readonly clusterName?: string;
    /**
     * Represents the configuration that you want MSK to use for the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-configurationinfo
     */
    readonly configurationInfo?: CfnClusterPropsMixin.ConfigurationInfoProperty | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-currentversion
     */
    readonly currentVersion?: string;
    /**
     * Includes all encryption-related information.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-encryptioninfo
     */
    readonly encryptionInfo?: CfnClusterPropsMixin.EncryptionInfoProperty | cdk.IResolvable;
    /**
     * Specifies the level of monitoring for the MSK cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-enhancedmonitoring
     */
    readonly enhancedMonitoring?: string;
    /**
     * The version of Apache Kafka.
     *
     * You can use Amazon MSK to create clusters that use [supported Apache Kafka versions](https://docs.aws.amazon.com/msk/latest/developerguide/supported-kafka-versions.html) .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-kafkaversion
     */
    readonly kafkaVersion?: string;
    /**
     * Logging info details for the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-logginginfo
     */
    readonly loggingInfo?: cdk.IResolvable | CfnClusterPropsMixin.LoggingInfoProperty;
    /**
     * The number of broker nodes in the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-numberofbrokernodes
     */
    readonly numberOfBrokerNodes?: number;
    /**
     * The settings for open monitoring.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-openmonitoring
     */
    readonly openMonitoring?: cdk.IResolvable | CfnClusterPropsMixin.OpenMonitoringProperty;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-rebalancing
     */
    readonly rebalancing?: cdk.IResolvable | CfnClusterPropsMixin.RebalancingProperty;
    /**
     * This controls storage mode for supported storage tiers.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-storagemode
     */
    readonly storageMode?: string;
    /**
     * An arbitrary set of tags (key-value pairs) for the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-tags
     */
    readonly tags?: Record<string, string>;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-cluster.html#cfn-msk-cluster-zookeeperaccess
     */
    readonly zookeeperAccess?: cdk.IResolvable | CfnClusterPropsMixin.ZookeeperAccessProperty;
}
/**
 * Create or update cluster policy.
 *
 * @cloudformationResource AWS::MSK::ClusterPolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-clusterpolicy.html
 */
export declare class CfnClusterPolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnClusterPolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::ClusterPolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnClusterPolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnClusterPolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnClusterPolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-clusterpolicy.html
 */
export interface CfnClusterPolicyMixinProps {
    /**
     * The Amazon Resource Name (ARN) that uniquely identifies the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-clusterpolicy.html#cfn-msk-clusterpolicy-clusterarn
     */
    readonly clusterArn?: string;
    /**
     * Resource policy for the cluster.
     *
     * The maximum size supported for a resource-based policy document is 20 KB.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-clusterpolicy.html#cfn-msk-clusterpolicy-policy
     */
    readonly policy?: any | cdk.IResolvable;
}
/**
 * Creates a new MSK configuration.
 *
 * To see an example of how to use this operation, first save the following text to a file and name the file `config-file.txt` .
 *
 * `auto.create.topics.enable = true zookeeper.connection.timeout.ms = 1000 log.roll.ms = 604800000`
 *
 * Now run the following Python 3.6 script in the folder where you saved `config-file.txt` . This script uses the properties specified in `config-file.txt` to create a configuration named `SalesClusterConfiguration` . This configuration can work with Apache Kafka versions 1.1.1 and 2.1.0.
 *
 * ```PYTHON
 * import boto3 client = boto3.client('kafka') config_file = open('config-file.txt', 'r') server_properties = config_file.read() response = client.create_configuration( Name='SalesClusterConfiguration', Description='The configuration to use on all sales clusters.', KafkaVersions=['1.1.1', '2.1.0'], ServerProperties=server_properties
 * ) print(response)
 * ```
 *
 * @cloudformationResource AWS::MSK::Configuration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html
 */
export declare class CfnConfigurationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConfigurationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::Configuration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConfigurationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConfiguration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConfigurationPropsMixin {
    /**
     * Describes a configuration revision.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-configuration-latestrevision.html
     */
    interface LatestRevisionProperty {
        /**
         * The time when the configuration revision was created.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-configuration-latestrevision.html#cfn-msk-configuration-latestrevision-creationtime
         */
        readonly creationTime?: string;
        /**
         * The description of the configuration revision.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-configuration-latestrevision.html#cfn-msk-configuration-latestrevision-description
         */
        readonly description?: string;
        /**
         * The revision number.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-configuration-latestrevision.html#cfn-msk-configuration-latestrevision-revision
         */
        readonly revision?: number;
    }
}
/**
 * Properties for CfnConfigurationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html
 */
export interface CfnConfigurationMixinProps {
    /**
     * The description of the configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html#cfn-msk-configuration-description
     */
    readonly description?: string;
    /**
     * The [versions of Apache Kafka](https://docs.aws.amazon.com/msk/latest/developerguide/supported-kafka-versions.html) with which you can use this MSK configuration.
     *
     * When you update the `KafkaVersionsList` property, CloudFormation recreates a new configuration with the updated property before deleting the old configuration. Such an update requires a [resource replacement](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks-update-behaviors.html#update-replacement) . To successfully update `KafkaVersionsList` , you must also update the `Name` property in the same operation.
     *
     * If your configuration is attached with any clusters created using the AWS Management Console or AWS CLI , you'll need to manually delete the old configuration from the console after the update completes.
     *
     * For more information, see [Can’t update KafkaVersionsList in MSK configuration](https://docs.aws.amazon.com/msk/latest/developerguide/troubleshooting.html#troubleshoot-kafkaversionslist-cfn-update-failure) in the *Amazon MSK Developer Guide* .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html#cfn-msk-configuration-kafkaversionslist
     */
    readonly kafkaVersionsList?: Array<string>;
    /**
     * Latest revision of the MSK configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html#cfn-msk-configuration-latestrevision
     */
    readonly latestRevision?: cdk.IResolvable | CfnConfigurationPropsMixin.LatestRevisionProperty;
    /**
     * The name of the configuration.
     *
     * Configuration names are strings that match the regex "^[0-9A-Za-z][0-9A-Za-z-]{0,}$".
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html#cfn-msk-configuration-name
     */
    readonly name?: string;
    /**
     * Contents of the `server.properties` file. When using the console, the SDK, or the AWS CLI , the contents of `server.properties` can be in plaintext.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-configuration.html#cfn-msk-configuration-serverproperties
     */
    readonly serverProperties?: string;
}
/**
 * Specifies the properties required for creating a serverless cluster.
 *
 * @cloudformationResource AWS::MSK::ServerlessCluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-serverlesscluster.html
 */
export declare class CfnServerlessClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnServerlessClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::ServerlessCluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnServerlessClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnServerlessCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnServerlessClusterPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-vpcconfig.html
     */
    interface VpcConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-vpcconfig.html#cfn-msk-serverlesscluster-vpcconfig-securitygroups
         */
        readonly securityGroups?: Array<ec2Refs.ISecurityGroupRef | string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-vpcconfig.html#cfn-msk-serverlesscluster-vpcconfig-subnetids
         */
        readonly subnetIds?: Array<ec2Refs.ISubnetRef | string>;
    }
    /**
     * Includes all client authentication information.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-clientauthentication.html
     */
    interface ClientAuthenticationProperty {
        /**
         * Details for client authentication using SASL.
         *
         * To turn on SASL, you must also turn on `EncryptionInTransit` by setting `inCluster` to true. You must set `clientBroker` to either `TLS` or `TLS_PLAINTEXT` . If you choose `TLS_PLAINTEXT` , then you must also set `unauthenticated` to true.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-clientauthentication.html#cfn-msk-serverlesscluster-clientauthentication-sasl
         */
        readonly sasl?: cdk.IResolvable | CfnServerlessClusterPropsMixin.SaslProperty;
    }
    /**
     * Details for client authentication using SASL.
     *
     * To turn on SASL, you must also turn on `EncryptionInTransit` by setting `inCluster` to true. You must set `clientBroker` to either `TLS` or `TLS_PLAINTEXT` . If you choose `TLS_PLAINTEXT` , then you must also set `unauthenticated` to true.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-sasl.html
     */
    interface SaslProperty {
        /**
         * Details for ClientAuthentication using IAM.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-sasl.html#cfn-msk-serverlesscluster-sasl-iam
         */
        readonly iam?: CfnServerlessClusterPropsMixin.IamProperty | cdk.IResolvable;
    }
    /**
     * Details for SASL/IAM client authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-iam.html
     */
    interface IamProperty {
        /**
         * SASL/IAM authentication is enabled or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-serverlesscluster-iam.html#cfn-msk-serverlesscluster-iam-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnServerlessClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-serverlesscluster.html
 */
export interface CfnServerlessClusterMixinProps {
    /**
     * Includes all client authentication related information.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-serverlesscluster.html#cfn-msk-serverlesscluster-clientauthentication
     */
    readonly clientAuthentication?: CfnServerlessClusterPropsMixin.ClientAuthenticationProperty | cdk.IResolvable;
    /**
     * The name of the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-serverlesscluster.html#cfn-msk-serverlesscluster-clustername
     */
    readonly clusterName?: string;
    /**
     * An arbitrary set of tags (key-value pairs) for the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-serverlesscluster.html#cfn-msk-serverlesscluster-tags
     */
    readonly tags?: Record<string, string>;
    /**
     * VPC configuration information for the serverless cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-serverlesscluster.html#cfn-msk-serverlesscluster-vpcconfigs
     */
    readonly vpcConfigs?: Array<cdk.IResolvable | CfnServerlessClusterPropsMixin.VpcConfigProperty> | cdk.IResolvable;
}
/**
 * Create remote VPC connection.
 *
 * @cloudformationResource AWS::MSK::VpcConnection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html
 */
export declare class CfnVpcConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVpcConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::VpcConnection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVpcConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVpcConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVpcConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html
 */
export interface CfnVpcConnectionMixinProps {
    /**
     * The type of private link authentication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html#cfn-msk-vpcconnection-authentication
     */
    readonly authentication?: string;
    /**
     * The list of subnets in the client VPC to connect to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html#cfn-msk-vpcconnection-clientsubnets
     */
    readonly clientSubnets?: Array<string>;
    /**
     * The security groups to attach to the ENIs for the broker nodes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html#cfn-msk-vpcconnection-securitygroups
     */
    readonly securityGroups?: Array<string>;
    /**
     * An arbitrary set of tags (key-value pairs) you specify while creating the VPC connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html#cfn-msk-vpcconnection-tags
     */
    readonly tags?: Record<string, string>;
    /**
     * The Amazon Resource Name (ARN) of the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html#cfn-msk-vpcconnection-targetclusterarn
     */
    readonly targetClusterArn?: string;
    /**
     * The VPC ID of the remote client.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-vpcconnection.html#cfn-msk-vpcconnection-vpcid
     */
    readonly vpcId?: string;
}
/**
 * Resource Type definition for AWS::MSK::Channel.
 *
 * @cloudformationResource AWS::MSK::Channel
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html
 */
export declare class CfnChannelPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnChannelMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::Channel`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnChannelMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnChannel;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnChannelPropsMixin {
    /**
     * Configuration of topic in a channel.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-topicconfiguration.html
     */
    interface TopicConfigurationProperty {
        /**
         * Record converter configuration for a topic.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-topicconfiguration.html#cfn-msk-channel-topicconfiguration-recordconverter
         */
        readonly recordConverter?: cdk.IResolvable | CfnChannelPropsMixin.RecordConverterProperty;
        /**
         * Record schema configuration for a topic.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-topicconfiguration.html#cfn-msk-channel-topicconfiguration-recordschema
         */
        readonly recordSchema?: cdk.IResolvable | CfnChannelPropsMixin.RecordSchemaProperty;
        /**
         * The Amazon Resource Name (ARN) that uniquely identifies the topic.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-topicconfiguration.html#cfn-msk-channel-topicconfiguration-topicarn
         */
        readonly topicArn?: string;
    }
    /**
     * Record converter configuration for a topic.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-recordconverter.html
     */
    interface RecordConverterProperty {
        /**
         * Value converter for topic data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-recordconverter.html#cfn-msk-channel-recordconverter-valueconverter
         */
        readonly valueConverter?: string;
    }
    /**
     * Record schema configuration for a topic.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-recordschema.html
     */
    interface RecordSchemaProperty {
        /**
         * ARN of Glue Schema Registry resource used for table schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-recordschema.html#cfn-msk-channel-recordschema-gsrarn
         */
        readonly gsrArn?: string;
    }
    /**
     * Encryption configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-encryptionconfiguration.html
     */
    interface EncryptionConfigurationProperty {
        /**
         * The ARN of the KMS key for encryption.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-encryptionconfiguration.html#cfn-msk-channel-encryptionconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
    }
    /**
     * Iceberg destination configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html
     */
    interface IcebergDestinationConfigurationProperty {
        /**
         * Append only mode.
         *
         * @default - true
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-appendonly
         */
        readonly appendOnly?: boolean | cdk.IResolvable;
        /**
         * Catalog configuration of the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-catalog
         */
        readonly catalog?: CfnChannelPropsMixin.CatalogProperty | cdk.IResolvable;
        /**
         * Compression codec for Iceberg table data files.
         *
         * Defaults to ZSTD.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-compressiontype
         */
        readonly compressionType?: string;
        /**
         * Data freshness in seconds.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-datafreshnessinseconds
         */
        readonly dataFreshnessInSeconds?: number;
        /**
         * Dead letter queue S3 configuration of the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-deadletterqueues3
         */
        readonly deadLetterQueueS3?: CfnChannelPropsMixin.DeadLetterQueueS3Property | cdk.IResolvable;
        /**
         * List of destination tables.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-destinationtablelist
         */
        readonly destinationTableList?: Array<CfnChannelPropsMixin.DestinationTableProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Schema evolution configuration of the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-schemaevolution
         */
        readonly schemaEvolution?: cdk.IResolvable | CfnChannelPropsMixin.SchemaEvolutionProperty;
        /**
         * The Amazon Resource Name (ARN) of an IAM role used by MSK to access the table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-serviceexecutionrolearn
         */
        readonly serviceExecutionRoleArn?: string;
        /**
         * Table creation configuration of the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-icebergdestinationconfiguration.html#cfn-msk-channel-icebergdestinationconfiguration-tablecreation
         */
        readonly tableCreation?: cdk.IResolvable | CfnChannelPropsMixin.TableCreationProperty;
    }
    /**
     * Catalog configuration of the destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-catalog.html
     */
    interface CatalogProperty {
        /**
         * The ARN of the catalog.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-catalog.html#cfn-msk-channel-catalog-catalogarn
         */
        readonly catalogArn?: string;
        /**
         * The warehouse location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-catalog.html#cfn-msk-channel-catalog-warehouselocation
         */
        readonly warehouseLocation?: string;
    }
    /**
     * Dead letter queue S3 configuration of the destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-deadletterqueues3.html
     */
    interface DeadLetterQueueS3Property {
        /**
         * The ARN of the S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-deadletterqueues3.html#cfn-msk-channel-deadletterqueues3-bucketarn
         */
        readonly bucketArn?: string;
        /**
         * The error output prefix.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-deadletterqueues3.html#cfn-msk-channel-deadletterqueues3-erroroutputprefix
         */
        readonly errorOutputPrefix?: string;
        /**
         * Optional 12-digit AWS account ID expected to own the dead-letter S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-deadletterqueues3.html#cfn-msk-channel-deadletterqueues3-expectedbucketowner
         */
        readonly expectedBucketOwner?: string;
    }
    /**
     * Schema evolution configuration of the destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-schemaevolution.html
     */
    interface SchemaEvolutionProperty {
        /**
         * Whether schema evolution is enabled.
         *
         * @default - false
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-schemaevolution.html#cfn-msk-channel-schemaevolution-enableschemaevolution
         */
        readonly enableSchemaEvolution?: boolean | cdk.IResolvable;
    }
    /**
     * Table creation configuration of the destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-tablecreation.html
     */
    interface TableCreationProperty {
        /**
         * Whether table creation is enabled.
         *
         * @default - true
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-tablecreation.html#cfn-msk-channel-tablecreation-enabletablecreation
         */
        readonly enableTableCreation?: boolean | cdk.IResolvable;
    }
    /**
     * Destination table configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-destinationtable.html
     */
    interface DestinationTableProperty {
        /**
         * The destination database name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-destinationtable.html#cfn-msk-channel-destinationtable-destinationdatabasename
         */
        readonly destinationDatabaseName?: string;
        /**
         * The destination table name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-destinationtable.html#cfn-msk-channel-destinationtable-destinationtablename
         */
        readonly destinationTableName?: string;
        /**
         * Partition specification.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-destinationtable.html#cfn-msk-channel-destinationtable-partitionspec
         */
        readonly partitionSpec?: cdk.IResolvable | CfnChannelPropsMixin.PartitionSpecProperty;
    }
    /**
     * Partition specification.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-partitionspec.html
     */
    interface PartitionSpecProperty {
        /**
         * Partition strategy for MSK channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-partitionspec.html#cfn-msk-channel-partitionspec-partitionstrategy
         */
        readonly partitionStrategy?: string;
        /**
         * Source list.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-partitionspec.html#cfn-msk-channel-partitionspec-sourcelist
         */
        readonly sourceList?: Array<cdk.IResolvable | CfnChannelPropsMixin.PartitionSourceProperty> | cdk.IResolvable;
    }
    /**
     * Partition source configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-partitionsource.html
     */
    interface PartitionSourceProperty {
        /**
         * Source name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-partitionsource.html#cfn-msk-channel-partitionsource-sourcename
         */
        readonly sourceName?: string;
    }
    /**
     * S3 destination configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3destinationconfiguration.html
     */
    interface S3DestinationConfigurationProperty {
        /**
         * Data freshness in seconds.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3destinationconfiguration.html#cfn-msk-channel-s3destinationconfiguration-datafreshnessinseconds
         */
        readonly dataFreshnessInSeconds?: number;
        /**
         * Dead letter queue S3 configuration of the destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3destinationconfiguration.html#cfn-msk-channel-s3destinationconfiguration-deadletterqueues3
         */
        readonly deadLetterQueueS3?: CfnChannelPropsMixin.DeadLetterQueueS3Property | cdk.IResolvable;
        /**
         * The Amazon Resource Name (ARN) of an IAM role used by MSK to access S3.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3destinationconfiguration.html#cfn-msk-channel-s3destinationconfiguration-serviceexecutionrolearn
         */
        readonly serviceExecutionRoleArn?: string;
        /**
         * S3 storage configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3destinationconfiguration.html#cfn-msk-channel-s3destinationconfiguration-storage
         */
        readonly storage?: cdk.IResolvable | CfnChannelPropsMixin.S3StorageProperty;
    }
    /**
     * S3 storage configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html
     */
    interface S3StorageProperty {
        /**
         * ARN of the S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html#cfn-msk-channel-s3storage-bucketarn
         */
        readonly bucketArn?: string;
        /**
         * S3 compression type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html#cfn-msk-channel-s3storage-compressiontype
         */
        readonly compressionType?: string;
        /**
         * Optional 12-digit AWS account ID expected to own the S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html#cfn-msk-channel-s3storage-expectedbucketowner
         */
        readonly expectedBucketOwner?: string;
        /**
         * Template for S3 key for output objects, used for partitioning.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html#cfn-msk-channel-s3storage-outputkeytemplate
         */
        readonly outputKeyTemplate?: string;
        /**
         * Optional prefix for output objects.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html#cfn-msk-channel-s3storage-outputprefix
         */
        readonly outputPrefix?: string;
        /**
         * S3 storage class.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3storage.html#cfn-msk-channel-s3storage-storageclass
         */
        readonly storageClass?: string;
    }
    /**
     * Log configuration details for Channel.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channellogginginfo.html
     */
    interface ChannelLoggingInfoProperty {
        /**
         * CloudWatch Logs log destination details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channellogginginfo.html#cfn-msk-channel-channellogginginfo-cloudwatchlogs
         */
        readonly cloudWatchLogs?: CfnChannelPropsMixin.CloudWatchLogsLogDestinationProperty | cdk.IResolvable;
        /**
         * Firehose log destination details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channellogginginfo.html#cfn-msk-channel-channellogginginfo-firehose
         */
        readonly firehose?: CfnChannelPropsMixin.FirehoseLogDestinationProperty | cdk.IResolvable;
        /**
         * S3 log destination details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channellogginginfo.html#cfn-msk-channel-channellogginginfo-s3
         */
        readonly s3?: cdk.IResolvable | CfnChannelPropsMixin.S3LogDestinationProperty;
    }
    /**
     * S3 log destination details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3logdestination.html
     */
    interface S3LogDestinationProperty {
        /**
         * The name of the S3 bucket for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3logdestination.html#cfn-msk-channel-s3logdestination-bucket
         */
        readonly bucket?: string;
        /**
         * Whether S3 logging is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3logdestination.html#cfn-msk-channel-s3logdestination-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The S3 prefix for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-s3logdestination.html#cfn-msk-channel-s3logdestination-prefix
         */
        readonly prefix?: string;
    }
    /**
     * CloudWatch Logs log destination details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-cloudwatchlogslogdestination.html
     */
    interface CloudWatchLogsLogDestinationProperty {
        /**
         * Whether CloudWatch Logs logging is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-cloudwatchlogslogdestination.html#cfn-msk-channel-cloudwatchlogslogdestination-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The CloudWatch log group for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-cloudwatchlogslogdestination.html#cfn-msk-channel-cloudwatchlogslogdestination-loggroup
         */
        readonly logGroup?: string;
    }
    /**
     * Firehose log destination details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-firehoselogdestination.html
     */
    interface FirehoseLogDestinationProperty {
        /**
         * The Firehose delivery stream for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-firehoselogdestination.html#cfn-msk-channel-firehoselogdestination-deliverystream
         */
        readonly deliveryStream?: string;
        /**
         * Whether Firehose logging is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-firehoselogdestination.html#cfn-msk-channel-firehoselogdestination-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Includes information about the channel state.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channelstateinfo.html
     */
    interface ChannelStateInfoProperty {
        /**
         * Code for channel state.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channelstateinfo.html#cfn-msk-channel-channelstateinfo-code
         */
        readonly code?: string;
        /**
         * Message for channel state.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-channel-channelstateinfo.html#cfn-msk-channel-channelstateinfo-message
         */
        readonly message?: string;
    }
}
/**
 * Properties for CfnChannelPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html
 */
export interface CfnChannelMixinProps {
    /**
     * Name of the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-channelname
     */
    readonly channelName?: string;
    /**
     * The Amazon Resource Name (ARN) of the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-clusterarn
     */
    readonly clusterArn?: string;
    /**
     * Encryption configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-encryptionconfiguration
     */
    readonly encryptionConfiguration?: CfnChannelPropsMixin.EncryptionConfigurationProperty | cdk.IResolvable;
    /**
     * Iceberg destination configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-icebergdestinationconfiguration
     */
    readonly icebergDestinationConfiguration?: CfnChannelPropsMixin.IcebergDestinationConfigurationProperty | cdk.IResolvable;
    /**
     * Log configuration details for Channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-logginginfo
     */
    readonly loggingInfo?: CfnChannelPropsMixin.ChannelLoggingInfoProperty | cdk.IResolvable;
    /**
     * S3 destination configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-s3destinationconfiguration
     */
    readonly s3DestinationConfiguration?: cdk.IResolvable | CfnChannelPropsMixin.S3DestinationConfigurationProperty;
    /**
     * Tags attached to the channel.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-tags
     */
    readonly tags?: Record<string, string>;
    /**
     * Topic configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-channel.html#cfn-msk-channel-topicconfigurationlist
     */
    readonly topicConfigurationList?: Array<cdk.IResolvable | CfnChannelPropsMixin.TopicConfigurationProperty> | cdk.IResolvable;
}
/**
 * Creates the replicator.
 *
 * @cloudformationResource AWS::MSK::Replicator
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html
 */
export declare class CfnReplicatorPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnReplicatorMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::Replicator`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnReplicatorMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnReplicator;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnReplicatorPropsMixin {
    /**
     * Information about Kafka Cluster to be used as source / target for replication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkacluster.html
     */
    interface KafkaClusterProperty {
        /**
         * Details of an Amazon MSK Cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkacluster.html#cfn-msk-replicator-kafkacluster-amazonmskcluster
         */
        readonly amazonMskCluster?: CfnReplicatorPropsMixin.AmazonMskClusterProperty | cdk.IResolvable;
        /**
         * Details of an Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkacluster.html#cfn-msk-replicator-kafkacluster-apachekafkacluster
         */
        readonly apacheKafkaCluster?: CfnReplicatorPropsMixin.ApacheKafkaClusterProperty | cdk.IResolvable;
        /**
         * Details of the client authentication used by the Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkacluster.html#cfn-msk-replicator-kafkacluster-clientauthentication
         */
        readonly clientAuthentication?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterClientAuthenticationProperty;
        /**
         * Details of encryption in transit to the Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkacluster.html#cfn-msk-replicator-kafkacluster-encryptionintransit
         */
        readonly encryptionInTransit?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterEncryptionInTransitProperty;
        /**
         * Details of an Amazon VPC which has network connectivity to the Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkacluster.html#cfn-msk-replicator-kafkacluster-vpcconfig
         */
        readonly vpcConfig?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterClientVpcConfigProperty;
    }
    /**
     * Details of an Amazon MSK Cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-amazonmskcluster.html
     */
    interface AmazonMskClusterProperty {
        /**
         * The Amazon Resource Name (ARN) of an Amazon MSK cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-amazonmskcluster.html#cfn-msk-replicator-amazonmskcluster-mskclusterarn
         */
        readonly mskClusterArn?: string;
    }
    /**
     * Details of an Apache Kafka cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-apachekafkacluster.html
     */
    interface ApacheKafkaClusterProperty {
        /**
         * The ID of the Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-apachekafkacluster.html#cfn-msk-replicator-apachekafkacluster-apachekafkaclusterid
         */
        readonly apacheKafkaClusterId?: string;
        /**
         * The bootstrap broker string of the Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-apachekafkacluster.html#cfn-msk-replicator-apachekafkacluster-bootstrapbrokerstring
         */
        readonly bootstrapBrokerString?: string;
    }
    /**
     * Details of an Amazon VPC which has network connectivity to the Apache Kafka cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientvpcconfig.html
     */
    interface KafkaClusterClientVpcConfigProperty {
        /**
         * The security groups to attach to the ENIs for the broker nodes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientvpcconfig.html#cfn-msk-replicator-kafkaclusterclientvpcconfig-securitygroupids
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * The list of subnets in the client VPC to connect to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientvpcconfig.html#cfn-msk-replicator-kafkaclusterclientvpcconfig-subnetids
         */
        readonly subnetIds?: Array<string>;
    }
    /**
     * Details of the client authentication used by the Apache Kafka cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientauthentication.html
     */
    interface KafkaClusterClientAuthenticationProperty {
        /**
         * Details for mTLS client authentication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientauthentication.html#cfn-msk-replicator-kafkaclusterclientauthentication-mtls
         */
        readonly mtls?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterMtlsAuthenticationProperty;
        /**
         * Details for client authentication using SASL/OAUTHBEARER.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientauthentication.html#cfn-msk-replicator-kafkaclusterclientauthentication-sasloauthbearer
         */
        readonly saslOAuthBearer?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterSaslOAuthBearerAuthenticationProperty;
        /**
         * Details for SASL/SCRAM client authentication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterclientauthentication.html#cfn-msk-replicator-kafkaclusterclientauthentication-saslscram
         */
        readonly saslScram?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterSaslScramAuthenticationProperty;
    }
    /**
     * Details for SASL/SCRAM client authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersaslscramauthentication.html
     */
    interface KafkaClusterSaslScramAuthenticationProperty {
        /**
         * The SASL/SCRAM authentication mechanism.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersaslscramauthentication.html#cfn-msk-replicator-kafkaclustersaslscramauthentication-mechanism
         */
        readonly mechanism?: string;
        /**
         * The Amazon Resource Name (ARN) of the Secrets Manager secret.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersaslscramauthentication.html#cfn-msk-replicator-kafkaclustersaslscramauthentication-secretarn
         */
        readonly secretArn?: string;
    }
    /**
     * Details for mTLS client authentication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustermtlsauthentication.html
     */
    interface KafkaClusterMtlsAuthenticationProperty {
        /**
         * The Amazon Resource Name (ARN) of the Secrets Manager secret.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustermtlsauthentication.html#cfn-msk-replicator-kafkaclustermtlsauthentication-secretarn
         */
        readonly secretArn?: string;
    }
    /**
     * Details for client authentication using SASL/OAUTHBEARER.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html
     */
    interface KafkaClusterSaslOAuthBearerAuthenticationProperty {
        /**
         * Details for SASL/OAUTHBEARER using the standard client_credentials grant.
         *
         * The referenced secret must contain client_id and client_secret.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-clientcredentials
         */
        readonly clientCredentials?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterOAuthClientCredentialsProperty;
        /**
         * Details for SASL/OAUTHBEARER using the client credentials grant with a JWT client assertion (RFC 7521/7523 Section 2.2). An STS-vended JWT is used as the client_assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-clientcredentialsassertion
         */
        readonly clientCredentialsAssertion?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterOAuthClientCredentialsAssertionProperty;
        /**
         * Details for SASL/OAUTHBEARER using the JWT Bearer assertion grant (RFC 7523).
         *
         * An STS-vended JWT is used as the assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-iamjwtbearer
         */
        readonly iamJwtBearer?: cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterOAuthIamJwtBearerProperty;
        /**
         * OAuth scope to request.
         *
         * Included in the token request if provided.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-scope
         */
        readonly scope?: string;
        /**
         * How client credentials are sent to the identity provider's token endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-tokenendpointauthenticationmethod
         */
        readonly tokenEndpointAuthenticationMethod?: string;
        /**
         * Secrets Manager ARN containing a custom CA certificate for the identity provider.
         *
         * Required only if the identity provider uses a private CA.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-tokenendpointtlscertificatearn
         */
        readonly tokenEndpointTlsCertificateArn?: string;
        /**
         * The HTTPS URL of the OAuth token endpoint that vends OAuth Bearer tokens per RFC 6749.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclustersasloauthbearerauthentication.html#cfn-msk-replicator-kafkaclustersasloauthbearerauthentication-tokenendpointurl
         */
        readonly tokenEndpointUrl?: string;
    }
    /**
     * Details for SASL/OAUTHBEARER using the standard client_credentials grant.
     *
     * The referenced secret must contain client_id and client_secret.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthclientcredentials.html
     */
    interface KafkaClusterOAuthClientCredentialsProperty {
        /**
         * Secrets Manager ARN of the secret containing the client_id and client_secret used to obtain an OAuth Bearer token via the client_credentials grant.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthclientcredentials.html#cfn-msk-replicator-kafkaclusteroauthclientcredentials-tokenrequestsecretarn
         */
        readonly tokenRequestSecretArn?: string;
    }
    /**
     * Details for SASL/OAUTHBEARER using the JWT Bearer assertion grant (RFC 7523).
     *
     * An STS-vended JWT is used as the assertion.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthiamjwtbearer.html
     */
    interface KafkaClusterOAuthIamJwtBearerProperty {
        /**
         * The audience (aud claim) set in the STS JWT assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthiamjwtbearer.html#cfn-msk-replicator-kafkaclusteroauthiamjwtbearer-audience
         */
        readonly audience?: string;
        /**
         * The algorithm used to sign the STS JWT assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthiamjwtbearer.html#cfn-msk-replicator-kafkaclusteroauthiamjwtbearer-signingalgorithm
         */
        readonly signingAlgorithm?: string;
        /**
         * Optional Secrets Manager ARN for identity providers that require client authentication alongside the JWT Bearer assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthiamjwtbearer.html#cfn-msk-replicator-kafkaclusteroauthiamjwtbearer-tokenrequestsecretarn
         */
        readonly tokenRequestSecretArn?: string;
    }
    /**
     * Details for SASL/OAUTHBEARER using the client credentials grant with a JWT client assertion (RFC 7521/7523 Section 2.2). An STS-vended JWT is used as the client_assertion.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthclientcredentialsassertion.html
     */
    interface KafkaClusterOAuthClientCredentialsAssertionProperty {
        /**
         * The audience (aud claim) set in the STS JWT client assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthclientcredentialsassertion.html#cfn-msk-replicator-kafkaclusteroauthclientcredentialsassertion-audience
         */
        readonly audience?: string;
        /**
         * The algorithm used to sign the STS JWT assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthclientcredentialsassertion.html#cfn-msk-replicator-kafkaclusteroauthclientcredentialsassertion-signingalgorithm
         */
        readonly signingAlgorithm?: string;
        /**
         * Optional Secrets Manager ARN for identity providers that require client_id as a form parameter alongside the JWT client assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusteroauthclientcredentialsassertion.html#cfn-msk-replicator-kafkaclusteroauthclientcredentialsassertion-tokenrequestsecretarn
         */
        readonly tokenRequestSecretArn?: string;
    }
    /**
     * Details of encryption in transit to the Apache Kafka cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterencryptionintransit.html
     */
    interface KafkaClusterEncryptionInTransitProperty {
        /**
         * The type of encryption in transit to the Apache Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterencryptionintransit.html#cfn-msk-replicator-kafkaclusterencryptionintransit-encryptiontype
         */
        readonly encryptionType?: string;
        /**
         * The root CA certificate.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-kafkaclusterencryptionintransit.html#cfn-msk-replicator-kafkaclusterencryptionintransit-rootcacertificate
         */
        readonly rootCaCertificate?: string;
    }
    /**
     * Specifies configuration for replication between a source and target Kafka cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html
     */
    interface ReplicationInfoProperty {
        /**
         * Configuration relating to consumer group replication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-consumergroupreplication
         */
        readonly consumerGroupReplication?: CfnReplicatorPropsMixin.ConsumerGroupReplicationProperty | cdk.IResolvable;
        /**
         * The ARN of the source Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-sourcekafkaclusterarn
         */
        readonly sourceKafkaClusterArn?: string;
        /**
         * The ID of the source Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-sourcekafkaclusterid
         */
        readonly sourceKafkaClusterId?: string;
        /**
         * The compression type to use when producing records to target cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-targetcompressiontype
         */
        readonly targetCompressionType?: string;
        /**
         * The ARN of the target Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-targetkafkaclusterarn
         */
        readonly targetKafkaClusterArn?: string;
        /**
         * The ID of the target Kafka cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-targetkafkaclusterid
         */
        readonly targetKafkaClusterId?: string;
        /**
         * Configuration relating to topic replication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationinfo.html#cfn-msk-replicator-replicationinfo-topicreplication
         */
        readonly topicReplication?: cdk.IResolvable | CfnReplicatorPropsMixin.TopicReplicationProperty;
    }
    /**
     * Details about topic replication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html
     */
    interface TopicReplicationProperty {
        /**
         * Whether to periodically configure remote topic ACLs to match their corresponding upstream topics.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-copyaccesscontrollistsfortopics
         */
        readonly copyAccessControlListsForTopics?: boolean | cdk.IResolvable;
        /**
         * Whether to periodically configure remote topics to match their corresponding upstream topics.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-copytopicconfigurations
         */
        readonly copyTopicConfigurations?: boolean | cdk.IResolvable;
        /**
         * Whether to periodically check for new topics and partitions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-detectandcopynewtopics
         */
        readonly detectAndCopyNewTopics?: boolean | cdk.IResolvable;
        /**
         * Specifies the position in the topics to start replicating from.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-startingposition
         */
        readonly startingPosition?: cdk.IResolvable | CfnReplicatorPropsMixin.ReplicationStartingPositionProperty;
        /**
         * Configuration for specifying replicated topic names will be the same as their corresponding upstream topics or prefixed with source cluster alias.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-topicnameconfiguration
         */
        readonly topicNameConfiguration?: cdk.IResolvable | CfnReplicatorPropsMixin.ReplicationTopicNameConfigurationProperty;
        /**
         * List of regular expression patterns indicating the topics that should not be replicated.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-topicstoexclude
         */
        readonly topicsToExclude?: Array<string>;
        /**
         * List of regular expression patterns indicating the topics to copy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-topicreplication.html#cfn-msk-replicator-topicreplication-topicstoreplicate
         */
        readonly topicsToReplicate?: Array<string>;
    }
    /**
     * Specifies the position in the topics to start replicating from.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationstartingposition.html
     */
    interface ReplicationStartingPositionProperty {
        /**
         * The type of replication starting position.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationstartingposition.html#cfn-msk-replicator-replicationstartingposition-type
         */
        readonly type?: string;
    }
    /**
     * Configuration for specifying replicated topic names will be the same as their corresponding upstream topics or prefixed with source cluster alias.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationtopicnameconfiguration.html
     */
    interface ReplicationTopicNameConfigurationProperty {
        /**
         * The type of replication topic name configuration, identical to upstream topic name or prefixed with source cluster alias.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicationtopicnameconfiguration.html#cfn-msk-replicator-replicationtopicnameconfiguration-type
         */
        readonly type?: string;
    }
    /**
     * Details about consumer group replication.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-consumergroupreplication.html
     */
    interface ConsumerGroupReplicationProperty {
        /**
         * The consumer group offset synchronization mode.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-consumergroupreplication.html#cfn-msk-replicator-consumergroupreplication-consumergroupoffsetsyncmode
         */
        readonly consumerGroupOffsetSyncMode?: string;
        /**
         * List of regular expression patterns indicating the consumer groups that should not be replicated.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-consumergroupreplication.html#cfn-msk-replicator-consumergroupreplication-consumergroupstoexclude
         */
        readonly consumerGroupsToExclude?: Array<string>;
        /**
         * List of regular expression patterns indicating the consumer groups to copy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-consumergroupreplication.html#cfn-msk-replicator-consumergroupreplication-consumergroupstoreplicate
         */
        readonly consumerGroupsToReplicate?: Array<string>;
        /**
         * Enables synchronization of consumer groups to target cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-consumergroupreplication.html#cfn-msk-replicator-consumergroupreplication-detectandcopynewconsumergroups
         */
        readonly detectAndCopyNewConsumerGroups?: boolean | cdk.IResolvable;
        /**
         * Enables synchronization of consumer group offsets to target cluster.
         *
         * The translated offsets will be written to topic __consumer_offsets.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-consumergroupreplication.html#cfn-msk-replicator-consumergroupreplication-synchroniseconsumergroupoffsets
         */
        readonly synchroniseConsumerGroupOffsets?: boolean | cdk.IResolvable;
    }
    /**
     * Configuration for log delivery for the replicator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-logdelivery.html
     */
    interface LogDeliveryProperty {
        /**
         * Details of the log delivery for the replicator.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-logdelivery.html#cfn-msk-replicator-logdelivery-replicatorlogdelivery
         */
        readonly replicatorLogDelivery?: cdk.IResolvable | CfnReplicatorPropsMixin.ReplicatorLogDeliveryProperty;
    }
    /**
     * Details of the log delivery for the replicator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicatorlogdelivery.html
     */
    interface ReplicatorLogDeliveryProperty {
        /**
         * Details about delivering logs to CloudWatch Logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicatorlogdelivery.html#cfn-msk-replicator-replicatorlogdelivery-cloudwatchlogs
         */
        readonly cloudWatchLogs?: CfnReplicatorPropsMixin.CloudWatchLogsProperty | cdk.IResolvable;
        /**
         * Details about delivering logs to Firehose.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicatorlogdelivery.html#cfn-msk-replicator-replicatorlogdelivery-firehose
         */
        readonly firehose?: CfnReplicatorPropsMixin.FirehoseProperty | cdk.IResolvable;
        /**
         * Details about delivering logs to S3.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-replicatorlogdelivery.html#cfn-msk-replicator-replicatorlogdelivery-s3
         */
        readonly s3?: cdk.IResolvable | CfnReplicatorPropsMixin.S3Property;
    }
    /**
     * Details about delivering logs to CloudWatch Logs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-cloudwatchlogs.html
     */
    interface CloudWatchLogsProperty {
        /**
         * Whether log delivery to CloudWatch Logs is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-cloudwatchlogs.html#cfn-msk-replicator-cloudwatchlogs-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The CloudWatch log group that is the destination for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-cloudwatchlogs.html#cfn-msk-replicator-cloudwatchlogs-loggroup
         */
        readonly logGroup?: string;
    }
    /**
     * Details about delivering logs to Firehose.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-firehose.html
     */
    interface FirehoseProperty {
        /**
         * The Firehose delivery stream that is the destination for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-firehose.html#cfn-msk-replicator-firehose-deliverystream
         */
        readonly deliveryStream?: string;
        /**
         * Whether log delivery to Firehose is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-firehose.html#cfn-msk-replicator-firehose-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
    /**
     * Details about delivering logs to S3.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-s3.html
     */
    interface S3Property {
        /**
         * The S3 bucket that is the destination for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-s3.html#cfn-msk-replicator-s3-bucket
         */
        readonly bucket?: string;
        /**
         * Whether log delivery to S3 is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-s3.html#cfn-msk-replicator-s3-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The S3 prefix that is the destination for log delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-msk-replicator-s3.html#cfn-msk-replicator-s3-prefix
         */
        readonly prefix?: string;
    }
}
/**
 * Properties for CfnReplicatorPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html
 */
export interface CfnReplicatorMixinProps {
    /**
     * A summary description of the replicator.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-description
     */
    readonly description?: string;
    /**
     * Kafka Clusters to use in setting up sources / targets for replication.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-kafkaclusters
     */
    readonly kafkaClusters?: Array<cdk.IResolvable | CfnReplicatorPropsMixin.KafkaClusterProperty> | cdk.IResolvable;
    /**
     * Configuration for log delivery for the replicator.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-logdelivery
     */
    readonly logDelivery?: cdk.IResolvable | CfnReplicatorPropsMixin.LogDeliveryProperty;
    /**
     * A list of replication configurations, where each configuration targets a given source cluster to target cluster replication flow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-replicationinfolist
     */
    readonly replicationInfoList?: Array<cdk.IResolvable | CfnReplicatorPropsMixin.ReplicationInfoProperty> | cdk.IResolvable;
    /**
     * The name of the replicator.
     *
     * Alpha-numeric characters with '-' are allowed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-replicatorname
     */
    readonly replicatorName?: string;
    /**
     * The ARN of the IAM role used by the replicator to access resources in the customer's account (e.g source and target clusters).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-serviceexecutionrolearn
     */
    readonly serviceExecutionRoleArn?: string;
    /**
     * List of tags to attach to created Replicator.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-replicator.html#cfn-msk-replicator-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::MSK::Topic.
 *
 * @cloudformationResource AWS::MSK::Topic
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html
 */
export declare class CfnTopicPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTopicMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MSK::Topic`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTopicMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTopic;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTopicPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html
 */
export interface CfnTopicMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the MSK cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html#cfn-msk-topic-clusterarn
     */
    readonly clusterArn?: string;
    /**
     * Base64 encoded configuration properties of the topic.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html#cfn-msk-topic-configs
     */
    readonly configs?: string;
    /**
     * The number of partitions for the topic.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html#cfn-msk-topic-partitioncount
     */
    readonly partitionCount?: number;
    /**
     * The replication factor for the topic.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html#cfn-msk-topic-replicationfactor
     */
    readonly replicationFactor?: number;
    /**
     * The name of the topic.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-msk-topic.html#cfn-msk-topic-topicname
     */
    readonly topicName?: string;
}
