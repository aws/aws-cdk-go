import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-accessanalyzer";
/**
 * The `AWS::AccessAnalyzer::Analyzer` resource specifies a new analyzer.
 *
 * The analyzer is an object that represents the IAM Access Analyzer feature. An analyzer is required for Access Analyzer to become operational.
 *
 * @cloudformationResource AWS::AccessAnalyzer::Analyzer
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html
 */
export declare class CfnAnalyzerPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAnalyzerMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AccessAnalyzer::Analyzer`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAnalyzerMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAnalyzer;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAnalyzerPropsMixin {
    /**
     * Contains information about an archive rule.
     *
     * Archive rules automatically archive new findings that meet the criteria you define when you create the rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-archiverule.html
     */
    interface ArchiveRuleProperty {
        /**
         * The criteria for the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-archiverule.html#cfn-accessanalyzer-analyzer-archiverule-filter
         */
        readonly filter?: Array<CfnAnalyzerPropsMixin.FilterProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The name of the rule to create.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-archiverule.html#cfn-accessanalyzer-analyzer-archiverule-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * The criteria that defines the archive rule.
     *
     * To learn about filter keys that you can use to create an archive rule, see [filter keys](https://docs.aws.amazon.com/IAM/latest/UserGuide/access-analyzer-reference-filter-keys.html) in the *User Guide* .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html
     */
    interface FilterProperty {
        /**
         * A "contains" condition to match for the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html#cfn-accessanalyzer-analyzer-filter-contains
         */
        readonly contains?: Array<string>;
        /**
         * An "equals" condition to match for the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html#cfn-accessanalyzer-analyzer-filter-eq
         */
        readonly eq?: Array<string>;
        /**
         * An "exists" condition to match for the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html#cfn-accessanalyzer-analyzer-filter-exists
         */
        readonly exists?: boolean | cdk.IResolvable;
        /**
         * A "not equal" condition to match for the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html#cfn-accessanalyzer-analyzer-filter-neq
         */
        readonly neq?: Array<string>;
        /**
         * The property used to define the criteria in the filter for the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-filter.html#cfn-accessanalyzer-analyzer-filter-property
         */
        readonly property?: string;
    }
    /**
     * Contains information about the configuration of an analyzer for an AWS organization or account.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analyzerconfiguration.html
     */
    interface AnalyzerConfigurationProperty {
        /**
         * Specifies the configuration of an internal access analyzer for an AWS organization or account.
         *
         * This configuration determines how the analyzer evaluates access within your AWS environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analyzerconfiguration.html#cfn-accessanalyzer-analyzer-analyzerconfiguration-internalaccessconfiguration
         */
        readonly internalAccessConfiguration?: CfnAnalyzerPropsMixin.InternalAccessConfigurationProperty | cdk.IResolvable;
        /**
         * Specifies the configuration of an unused access analyzer for an AWS organization or account.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analyzerconfiguration.html#cfn-accessanalyzer-analyzer-analyzerconfiguration-unusedaccessconfiguration
         */
        readonly unusedAccessConfiguration?: cdk.IResolvable | CfnAnalyzerPropsMixin.UnusedAccessConfigurationProperty;
    }
    /**
     * Contains information about an unused access analyzer.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-unusedaccessconfiguration.html
     */
    interface UnusedAccessConfigurationProperty {
        /**
         * Contains information about analysis rules for the analyzer.
         *
         * Analysis rules determine which entities will generate findings based on the criteria you define when you create the rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-unusedaccessconfiguration.html#cfn-accessanalyzer-analyzer-unusedaccessconfiguration-analysisrule
         */
        readonly analysisRule?: CfnAnalyzerPropsMixin.AnalysisRuleProperty | cdk.IResolvable;
        /**
         * The specified access age in days for which to generate findings for unused access.
         *
         * For example, if you specify 90 days, the analyzer will generate findings for IAM entities within the accounts of the selected organization for any access that hasn't been used in 90 or more days since the analyzer's last scan. You can choose a value between 1 and 365 days.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-unusedaccessconfiguration.html#cfn-accessanalyzer-analyzer-unusedaccessconfiguration-unusedaccessage
         */
        readonly unusedAccessAge?: number;
    }
    /**
     * Contains information about analysis rules for the analyzer.
     *
     * Analysis rules determine which entities will generate findings based on the criteria you define when you create the rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analysisrule.html
     */
    interface AnalysisRuleProperty {
        /**
         * A list of rules for the analyzer containing criteria to exclude from analysis.
         *
         * Entities that meet the rule criteria will not generate findings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analysisrule.html#cfn-accessanalyzer-analyzer-analysisrule-exclusions
         */
        readonly exclusions?: Array<CfnAnalyzerPropsMixin.AnalysisRuleCriteriaProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The criteria for an analysis rule for an analyzer.
     *
     * The criteria determine which entities will generate findings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analysisrulecriteria.html
     */
    interface AnalysisRuleCriteriaProperty {
        /**
         * A list of AWS account IDs to apply to the analysis rule criteria.
         *
         * The accounts cannot include the organization analyzer owner account. Account IDs can only be applied to the analysis rule criteria for organization-level analyzers. The list cannot include more than 2,000 account IDs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analysisrulecriteria.html#cfn-accessanalyzer-analyzer-analysisrulecriteria-accountids
         */
        readonly accountIds?: Array<string>;
        /**
         * An array of key-value pairs to match for your resources.
         *
         * You can use the set of Unicode letters, digits, whitespace, `_` , `.` , `/` , `=` , `+` , and `-` .
         *
         * For the tag key, you can specify a value that is 1 to 128 characters in length and cannot be prefixed with `aws:` .
         *
         * For the tag value, you can specify a value that is 0 to 256 characters in length. If the specified tag value is 0 characters, the rule is applied to all principals with the specified tag key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-analysisrulecriteria.html#cfn-accessanalyzer-analyzer-analysisrulecriteria-resourcetags
         */
        readonly resourceTags?: Array<Array<cdk.CfnTag | cdk.IResolvable> | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Specifies the configuration of an internal access analyzer for an AWS organization or account.
     *
     * This configuration determines how the analyzer evaluates internal access within your AWS environment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessconfiguration.html
     */
    interface InternalAccessConfigurationProperty {
        /**
         * Contains information about analysis rules for the internal access analyzer.
         *
         * These rules determine which resources and access patterns will be analyzed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessconfiguration.html#cfn-accessanalyzer-analyzer-internalaccessconfiguration-internalaccessanalysisrule
         */
        readonly internalAccessAnalysisRule?: CfnAnalyzerPropsMixin.InternalAccessAnalysisRuleProperty | cdk.IResolvable;
    }
    /**
     * Contains information about analysis rules for the internal access analyzer.
     *
     * Analysis rules determine which entities will generate findings based on the criteria you define when you create the rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessanalysisrule.html
     */
    interface InternalAccessAnalysisRuleProperty {
        /**
         * A list of rules for the internal access analyzer containing criteria to include in analysis.
         *
         * Only resources that meet the rule criteria will generate findings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessanalysisrule.html#cfn-accessanalyzer-analyzer-internalaccessanalysisrule-inclusions
         */
        readonly inclusions?: Array<CfnAnalyzerPropsMixin.InternalAccessAnalysisRuleCriteriaProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The criteria for an analysis rule for an internal access analyzer.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessanalysisrulecriteria.html
     */
    interface InternalAccessAnalysisRuleCriteriaProperty {
        /**
         * A list of AWS account IDs to apply to the internal access analysis rule criteria.
         *
         * Account IDs can only be applied to the analysis rule criteria for organization-level analyzers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessanalysisrulecriteria.html#cfn-accessanalyzer-analyzer-internalaccessanalysisrulecriteria-accountids
         */
        readonly accountIds?: Array<string>;
        /**
         * A list of resource ARNs to apply to the internal access analysis rule criteria.
         *
         * The analyzer will only generate findings for resources that match these ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessanalysisrulecriteria.html#cfn-accessanalyzer-analyzer-internalaccessanalysisrulecriteria-resourcearns
         */
        readonly resourceArns?: Array<string>;
        /**
         * A list of resource types to apply to the internal access analysis rule criteria.
         *
         * The analyzer will only generate findings for resources of these types. These resource types are currently supported for internal access analyzers:
         *
         * - `AWS::S3::Bucket`
         * - `AWS::RDS::DBSnapshot`
         * - `AWS::RDS::DBClusterSnapshot`
         * - `AWS::S3Express::DirectoryBucket`
         * - `AWS::DynamoDB::Table`
         * - `AWS::DynamoDB::Stream`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-analyzer-internalaccessanalysisrulecriteria.html#cfn-accessanalyzer-analyzer-internalaccessanalysisrulecriteria-resourcetypes
         */
        readonly resourceTypes?: Array<string>;
    }
}
/**
 * Properties for CfnAnalyzerPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html
 */
export interface CfnAnalyzerMixinProps {
    /**
     * Contains information about the configuration of an analyzer for an AWS organization or account.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html#cfn-accessanalyzer-analyzer-analyzerconfiguration
     */
    readonly analyzerConfiguration?: CfnAnalyzerPropsMixin.AnalyzerConfigurationProperty | cdk.IResolvable;
    /**
     * The name of the analyzer.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html#cfn-accessanalyzer-analyzer-analyzername
     */
    readonly analyzerName?: string;
    /**
     * Specifies the archive rules to add for the analyzer.
     *
     * Archive rules automatically archive findings that meet the criteria you define for the rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html#cfn-accessanalyzer-analyzer-archiverules
     */
    readonly archiveRules?: Array<CfnAnalyzerPropsMixin.ArchiveRuleProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * An array of key-value pairs to apply to the analyzer.
     *
     * You can use the set of Unicode letters, digits, whitespace, `_` , `.` , `/` , `=` , `+` , and `-` .
     *
     * For the tag key, you can specify a value that is 1 to 128 characters in length and cannot be prefixed with `aws:` .
     *
     * For the tag value, you can specify a value that is 0 to 256 characters in length.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html#cfn-accessanalyzer-analyzer-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The type represents the zone of trust for the analyzer.
     *
     * *Allowed Values* : ACCOUNT | ORGANIZATION | ACCOUNT_UNUSED_ACCESS | ACCOUNT_INTERNAL_ACCESS | ORGANIZATION_INTERNAL_ACCESS | ORGANIZATION_UNUSED_ACCESS
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-analyzer.html#cfn-accessanalyzer-analyzer-type
     */
    readonly type?: string;
}
/**
 * Creates an archive rule for the specified analyzer.
 *
 * Archive rules automatically archive new findings that meet the criteria you define when you create the rule.
 *
 * @cloudformationResource AWS::AccessAnalyzer::ArchiveRule
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-archiverule.html
 */
export declare class CfnArchiveRulePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnArchiveRuleMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AccessAnalyzer::ArchiveRule`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnArchiveRuleMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnArchiveRule;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnArchiveRulePropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-archiverule-filteritems.html
     */
    interface FilterItemsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-archiverule-filteritems.html#cfn-accessanalyzer-archiverule-filteritems-contains
         */
        readonly contains?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-archiverule-filteritems.html#cfn-accessanalyzer-archiverule-filteritems-eq
         */
        readonly eq?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-archiverule-filteritems.html#cfn-accessanalyzer-archiverule-filteritems-exists
         */
        readonly exists?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-accessanalyzer-archiverule-filteritems.html#cfn-accessanalyzer-archiverule-filteritems-neq
         */
        readonly neq?: Array<string>;
    }
}
/**
 * Properties for CfnArchiveRulePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-archiverule.html
 */
export interface CfnArchiveRuleMixinProps {
    /**
     * The name of the analyzer for the archive rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-archiverule.html#cfn-accessanalyzer-archiverule-analyzername
     */
    readonly analyzerName?: string;
    /**
     * The criteria for the archive rule.
     *
     * A map of filter criteria property names to their criterion values.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-archiverule.html#cfn-accessanalyzer-archiverule-filter
     */
    readonly filter?: cdk.IResolvable | Record<string, CfnArchiveRulePropsMixin.FilterItemsProperty | cdk.IResolvable>;
    /**
     * The name of the archive rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-accessanalyzer-archiverule.html#cfn-accessanalyzer-archiverule-rulename
     */
    readonly ruleName?: string;
}
