import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-dataexchange";
/**
 * Definition of AWS::DataExchange::DataSet Resource Type.
 *
 * @cloudformationResource AWS::DataExchange::DataSet
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-dataset.html
 */
export declare class CfnDataSetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDataSetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataExchange::DataSet`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDataSetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDataSet;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnDataSetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-dataset.html
 */
export interface CfnDataSetMixinProps {
    /**
     * The type of asset that is added to a data set.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-dataset.html#cfn-dataexchange-dataset-assettype
     */
    readonly assetType?: string;
    /**
     * A description for the data set.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-dataset.html#cfn-dataexchange-dataset-description
     */
    readonly description?: string;
    /**
     * The name of the data set.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-dataset.html#cfn-dataexchange-dataset-name
     */
    readonly name?: string;
    /**
     * Tags for the data set.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-dataset.html#cfn-dataexchange-dataset-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * An event action is an AWS Data Exchange resource that automatically exports data set revisions to Amazon S3 when a revision is published.
 *
 * @cloudformationResource AWS::DataExchange::EventAction
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-eventaction.html
 */
export declare class CfnEventActionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEventActionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataExchange::EventAction`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEventActionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEventAction;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEventActionPropsMixin {
    /**
     * What occurs after a certain event.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-action.html
     */
    interface ActionProperty {
        /**
         * Details of the operation to be performed by the job.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-action.html#cfn-dataexchange-eventaction-action-exportrevisiontos3
         */
        readonly exportRevisionToS3?: CfnEventActionPropsMixin.AutoExportRevisionToS3RequestDetailsProperty | cdk.IResolvable;
    }
    /**
     * Details of the operation to be performed by the job.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-autoexportrevisiontos3requestdetails.html
     */
    interface AutoExportRevisionToS3RequestDetailsProperty {
        /**
         * Encryption configuration of the export job.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-autoexportrevisiontos3requestdetails.html#cfn-dataexchange-eventaction-autoexportrevisiontos3requestdetails-encryption
         */
        readonly encryption?: CfnEventActionPropsMixin.ExportServerSideEncryptionProperty | cdk.IResolvable;
        /**
         * A revision destination is the Amazon S3 bucket folder destination to where the export will be sent.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-autoexportrevisiontos3requestdetails.html#cfn-dataexchange-eventaction-autoexportrevisiontos3requestdetails-revisiondestination
         */
        readonly revisionDestination?: CfnEventActionPropsMixin.AutoExportRevisionDestinationEntryProperty | cdk.IResolvable;
    }
    /**
     * Encryption configuration of the export job.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-exportserversideencryption.html
     */
    interface ExportServerSideEncryptionProperty {
        /**
         * The Amazon Resource Name (ARN) of the AWS KMS key you want to use to encrypt the Amazon S3 objects.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-exportserversideencryption.html#cfn-dataexchange-eventaction-exportserversideencryption-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * The type of server side encryption used for encrypting the objects in Amazon S3.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-exportserversideencryption.html#cfn-dataexchange-eventaction-exportserversideencryption-type
         */
        readonly type?: string;
    }
    /**
     * A revision destination is the Amazon S3 bucket folder destination to where the export will be sent.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-autoexportrevisiondestinationentry.html
     */
    interface AutoExportRevisionDestinationEntryProperty {
        /**
         * The Amazon S3 bucket that is the destination for the event action.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-autoexportrevisiondestinationentry.html#cfn-dataexchange-eventaction-autoexportrevisiondestinationentry-bucket
         */
        readonly bucket?: string;
        /**
         * A string representing the pattern for generated names of the individual assets in the revision.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-autoexportrevisiondestinationentry.html#cfn-dataexchange-eventaction-autoexportrevisiondestinationentry-keypattern
         */
        readonly keyPattern?: string;
    }
    /**
     * What occurs to start an action.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-event.html
     */
    interface EventProperty {
        /**
         * Information about the published revision.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-event.html#cfn-dataexchange-eventaction-event-revisionpublished
         */
        readonly revisionPublished?: cdk.IResolvable | CfnEventActionPropsMixin.RevisionPublishedProperty;
    }
    /**
     * Information about the published revision.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-revisionpublished.html
     */
    interface RevisionPublishedProperty {
        /**
         * The data set ID of the published revision.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dataexchange-eventaction-revisionpublished.html#cfn-dataexchange-eventaction-revisionpublished-datasetid
         */
        readonly dataSetId?: string;
    }
}
/**
 * Properties for CfnEventActionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-eventaction.html
 */
export interface CfnEventActionMixinProps {
    /**
     * What occurs after a certain event.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-eventaction.html#cfn-dataexchange-eventaction-action
     */
    readonly action?: CfnEventActionPropsMixin.ActionProperty | cdk.IResolvable;
    /**
     * What occurs to start an action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-eventaction.html#cfn-dataexchange-eventaction-event
     */
    readonly event?: CfnEventActionPropsMixin.EventProperty | cdk.IResolvable;
    /**
     * The tags for the event action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dataexchange-eventaction.html#cfn-dataexchange-eventaction-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
