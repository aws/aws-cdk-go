import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-arcregionswitch";
/**
 * Represents a Region switch plan.
 *
 * A plan defines the steps required to shift traffic from one AWS Region to another.
 *
 * @cloudformationResource AWS::ARCRegionSwitch::Plan
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html
 */
export declare class CfnPlanPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPlanMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ARCRegionSwitch::Plan`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPlanMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPlan;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPlanPropsMixin {
    /**
     * An Amazon CloudWatch alarm associated with a Region switch plan.
     *
     * These alarms can be used to trigger automatic execution of the plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-associatedalarm.html
     */
    interface AssociatedAlarmProperty {
        /**
         * The alarm type for an associated alarm.
         *
         * An associated CloudWatch alarm can be an application health alarm or a trigger alarm.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-associatedalarm.html#cfn-arcregionswitch-plan-associatedalarm-alarmtype
         */
        readonly alarmType?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-associatedalarm.html#cfn-arcregionswitch-plan-associatedalarm-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-associatedalarm.html#cfn-arcregionswitch-plan-associatedalarm-externalid
         */
        readonly externalId?: string;
        /**
         * The resource identifier for alarms that you associate with a plan.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-associatedalarm.html#cfn-arcregionswitch-plan-associatedalarm-resourceidentifier
         */
        readonly resourceIdentifier?: string;
    }
    /**
     * Configuration for automatic report generation for plan executions.
     *
     * When configured, Region switch automatically generates a report after each plan execution that includes execution events, plan configuration, and CloudWatch alarm states.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-reportconfiguration.html
     */
    interface ReportConfigurationProperty {
        /**
         * The output configuration for the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-reportconfiguration.html#cfn-arcregionswitch-plan-reportconfiguration-reportoutput
         */
        readonly reportOutput?: Array<cdk.IResolvable | CfnPlanPropsMixin.ReportOutputConfigurationProperty> | cdk.IResolvable;
    }
    /**
     * Configuration for report output destinations used in a Region switch plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-reportoutputconfiguration.html
     */
    interface ReportOutputConfigurationProperty {
        /**
         * Configuration for delivering reports to an Amazon S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-reportoutputconfiguration.html#cfn-arcregionswitch-plan-reportoutputconfiguration-s3configuration
         */
        readonly s3Configuration?: cdk.IResolvable | CfnPlanPropsMixin.S3ReportOutputConfigurationProperty;
    }
    /**
     * Configuration for delivering generated reports to an Amazon S3 bucket.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-s3reportoutputconfiguration.html
     */
    interface S3ReportOutputConfigurationProperty {
        /**
         * The AWS account ID that owns the S3 bucket.
         *
         * Required to ensure the bucket is still owned by the same expected owner at generation time.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-s3reportoutputconfiguration.html#cfn-arcregionswitch-plan-s3reportoutputconfiguration-bucketowner
         */
        readonly bucketOwner?: string;
        /**
         * The S3 bucket name and optional prefix where reports are stored.
         *
         * Format: bucket-name or bucket-name/prefix.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-s3reportoutputconfiguration.html#cfn-arcregionswitch-plan-s3reportoutputconfiguration-bucketpath
         */
        readonly bucketPath?: string;
    }
    /**
     * Defines a condition that can automatically trigger the execution of a Region switch plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-trigger.html
     */
    interface TriggerProperty {
        /**
         * The action to perform when the trigger fires.
         *
         * Valid values include ACTIVATE and DEACTIVATE.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-trigger.html#cfn-arcregionswitch-plan-trigger-action
         */
        readonly action?: string;
        /**
         * The conditions that must be met for the trigger to fire.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-trigger.html#cfn-arcregionswitch-plan-trigger-conditions
         */
        readonly conditions?: Array<cdk.IResolvable | CfnPlanPropsMixin.TriggerConditionProperty> | cdk.IResolvable;
        /**
         * The description for a trigger.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-trigger.html#cfn-arcregionswitch-plan-trigger-description
         */
        readonly description?: string;
        /**
         * The minimum time, in minutes, that must elapse between automatic executions of the plan.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-trigger.html#cfn-arcregionswitch-plan-trigger-mindelayminutesbetweenexecutions
         */
        readonly minDelayMinutesBetweenExecutions?: number;
        /**
         * The AWS Region for a trigger.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-trigger.html#cfn-arcregionswitch-plan-trigger-targetregion
         */
        readonly targetRegion?: string;
    }
    /**
     * Defines a condition that must be met for a trigger to fire.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-triggercondition.html
     */
    interface TriggerConditionProperty {
        /**
         * The name of the CloudWatch alarm associated with the condition.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-triggercondition.html#cfn-arcregionswitch-plan-triggercondition-associatedalarmname
         */
        readonly associatedAlarmName?: string;
        /**
         * The condition that must be met.
         *
         * Valid values include ALARM and OK.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-triggercondition.html#cfn-arcregionswitch-plan-triggercondition-condition
         */
        readonly condition?: string;
    }
    /**
     * Represents a workflow in a Region switch plan.
     *
     * A workflow defines a sequence of steps to execute during a Region switch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-workflow.html
     */
    interface WorkflowProperty {
        /**
         * The steps that make up the workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-workflow.html#cfn-arcregionswitch-plan-workflow-steps
         */
        readonly steps?: Array<cdk.IResolvable | CfnPlanPropsMixin.StepProperty> | cdk.IResolvable;
        /**
         * The description of the workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-workflow.html#cfn-arcregionswitch-plan-workflow-workflowdescription
         */
        readonly workflowDescription?: string;
        /**
         * The action that the workflow performs.
         *
         * Valid values include ACTIVATE and DEACTIVATE.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-workflow.html#cfn-arcregionswitch-plan-workflow-workflowtargetaction
         */
        readonly workflowTargetAction?: string;
        /**
         * The AWS Region that the workflow targets.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-workflow.html#cfn-arcregionswitch-plan-workflow-workflowtargetregion
         */
        readonly workflowTargetRegion?: string;
    }
    /**
     * Represents a step in a Region switch plan workflow.
     *
     * Each step performs a specific action during the Region switch process.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-step.html
     */
    interface StepProperty {
        /**
         * The description of a step in a workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-step.html#cfn-arcregionswitch-plan-step-description
         */
        readonly description?: string;
        /**
         * The configuration for an execution block in a workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-step.html#cfn-arcregionswitch-plan-step-executionblockconfiguration
         */
        readonly executionBlockConfiguration?: CfnPlanPropsMixin.ExecutionBlockConfigurationProperty | cdk.IResolvable;
        /**
         * The type of an execution block in a workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-step.html#cfn-arcregionswitch-plan-step-executionblocktype
         */
        readonly executionBlockType?: string;
        /**
         * The name of a step in a workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-step.html#cfn-arcregionswitch-plan-step-name
         */
        readonly name?: string;
    }
    /**
     * Execution block configurations for a workflow in a Region switch plan.
     *
     * An execution block represents a specific type of action to perform during a Region switch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html
     */
    interface ExecutionBlockConfigurationProperty {
        /**
         * An ARC routing control execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-arcroutingcontrolconfig
         */
        readonly arcRoutingControlConfig?: CfnPlanPropsMixin.ArcRoutingControlConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-auroraprovisionedscalingconfig
         */
        readonly auroraProvisionedScalingConfig?: CfnPlanPropsMixin.AuroraProvisionedScalingConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-auroraserverlessscalingconfig
         */
        readonly auroraServerlessScalingConfig?: CfnPlanPropsMixin.AuroraServerlessScalingConfigurationProperty | cdk.IResolvable;
        /**
         * An AWS Lambda execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-customactionlambdaconfig
         */
        readonly customActionLambdaConfig?: CfnPlanPropsMixin.CustomActionLambdaConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-documentdbconfig
         */
        readonly documentDbConfig?: CfnPlanPropsMixin.DocumentDbConfigurationProperty | cdk.IResolvable;
        /**
         * An EC2 Auto Scaling group execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-ec2asgcapacityincreaseconfig
         */
        readonly ec2AsgCapacityIncreaseConfig?: CfnPlanPropsMixin.Ec2AsgCapacityIncreaseConfigurationProperty | cdk.IResolvable;
        /**
         * The capacity increase specified for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-ecscapacityincreaseconfig
         */
        readonly ecsCapacityIncreaseConfig?: CfnPlanPropsMixin.EcsCapacityIncreaseConfigurationProperty | cdk.IResolvable;
        /**
         * An AWS EKS resource scaling execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-eksresourcescalingconfig
         */
        readonly eksResourceScalingConfig?: CfnPlanPropsMixin.EksResourceScalingConfigurationProperty | cdk.IResolvable;
        /**
         * A manual approval execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-executionapprovalconfig
         */
        readonly executionApprovalConfig?: CfnPlanPropsMixin.ExecutionApprovalConfigurationProperty | cdk.IResolvable;
        /**
         * An Aurora Global Database execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-globalauroraconfig
         */
        readonly globalAuroraConfig?: CfnPlanPropsMixin.GlobalAuroraConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-lambdaeventsourcemappingconfig
         */
        readonly lambdaEventSourceMappingConfig?: cdk.IResolvable | CfnPlanPropsMixin.LambdaEventSourceMappingConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-neptuneglobaldatabaseconfig
         */
        readonly neptuneGlobalDatabaseConfig?: cdk.IResolvable | CfnPlanPropsMixin.NeptuneGlobalDatabaseConfigurationProperty;
        /**
         * A parallel configuration execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-parallelconfig
         */
        readonly parallelConfig?: cdk.IResolvable | CfnPlanPropsMixin.ParallelExecutionBlockConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-rdscreatecrossregionreadreplicaconfig
         */
        readonly rdsCreateCrossRegionReadReplicaConfig?: cdk.IResolvable | CfnPlanPropsMixin.RdsCreateCrossRegionReplicaConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-rdspromotereadreplicaconfig
         */
        readonly rdsPromoteReadReplicaConfig?: cdk.IResolvable | CfnPlanPropsMixin.RdsPromoteReadReplicaConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-rdsswitchoverreadreplicaconfig
         */
        readonly rdsSwitchoverReadReplicaConfig?: cdk.IResolvable | CfnPlanPropsMixin.RdsSwitchoverReadReplicaConfigurationProperty;
        /**
         * A Region switch plan execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-regionswitchplanconfig
         */
        readonly regionSwitchPlanConfig?: cdk.IResolvable | CfnPlanPropsMixin.RegionSwitchPlanConfigurationProperty;
        /**
         * The Amazon Route 53 health check configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionblockconfiguration.html#cfn-arcregionswitch-plan-executionblockconfiguration-route53healthcheckconfig
         */
        readonly route53HealthCheckConfig?: cdk.IResolvable | CfnPlanPropsMixin.Route53HealthCheckConfigurationProperty;
    }
    /**
     * Configuration for AWS Lambda functions that perform custom actions during a Region switch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-customactionlambdaconfiguration.html
     */
    interface CustomActionLambdaConfigurationProperty {
        /**
         * The AWS Lambda functions for the execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-customactionlambdaconfiguration.html#cfn-arcregionswitch-plan-customactionlambdaconfiguration-lambdas
         */
        readonly lambdas?: Array<cdk.IResolvable | CfnPlanPropsMixin.LambdasProperty> | cdk.IResolvable;
        /**
         * The AWS Region for the function to run in.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-customactionlambdaconfiguration.html#cfn-arcregionswitch-plan-customactionlambdaconfiguration-regiontorun
         */
        readonly regionToRun?: string;
        /**
         * The retry interval specified.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-customactionlambdaconfiguration.html#cfn-arcregionswitch-plan-customactionlambdaconfiguration-retryintervalminutes
         */
        readonly retryIntervalMinutes?: number;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-customactionlambdaconfiguration.html#cfn-arcregionswitch-plan-customactionlambdaconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-customactionlambdaconfiguration.html#cfn-arcregionswitch-plan-customactionlambdaconfiguration-ungraceful
         */
        readonly ungraceful?: cdk.IResolvable | CfnPlanPropsMixin.LambdaUngracefulProperty;
    }
    /**
     * Configuration for AWS Lambda functions used in a Region switch plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdas.html
     */
    interface LambdasProperty {
        /**
         * The Amazon Resource Name (ARN) of the Lambda function.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdas.html#cfn-arcregionswitch-plan-lambdas-arn
         */
        readonly arn?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdas.html#cfn-arcregionswitch-plan-lambdas-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdas.html#cfn-arcregionswitch-plan-lambdas-externalid
         */
        readonly externalId?: string;
    }
    /**
     * Configuration for handling failures when invoking Lambda functions.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaungraceful.html
     */
    interface LambdaUngracefulProperty {
        /**
         * The ungraceful behavior for a Lambda function, which must be set to `skip` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaungraceful.html#cfn-arcregionswitch-plan-lambdaungraceful-behavior
         */
        readonly behavior?: string;
    }
    /**
     * Configuration for increasing the capacity of Amazon EC2 Auto Scaling groups during a Region switch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration.html
     */
    interface Ec2AsgCapacityIncreaseConfigurationProperty {
        /**
         * The EC2 Auto Scaling groups for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration-asgs
         */
        readonly asgs?: Array<CfnPlanPropsMixin.AsgProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The monitoring approach that you specify EC2 Auto Scaling groups for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration-capacitymonitoringapproach
         */
        readonly capacityMonitoringApproach?: string;
        /**
         * The target percentage that you specify for EC2 Auto Scaling groups.
         *
         * @default - 100
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration-targetpercent
         */
        readonly targetPercent?: number;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ec2asgcapacityincreaseconfiguration-ungraceful
         */
        readonly ungraceful?: CfnPlanPropsMixin.Ec2UngracefulProperty | cdk.IResolvable;
    }
    /**
     * Configuration for an Amazon EC2 Auto Scaling group used in a Region switch plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-asg.html
     */
    interface AsgProperty {
        /**
         * The Amazon Resource Name (ARN) of the EC2 Auto Scaling group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-asg.html#cfn-arcregionswitch-plan-asg-arn
         */
        readonly arn?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-asg.html#cfn-arcregionswitch-plan-asg-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-asg.html#cfn-arcregionswitch-plan-asg-externalid
         */
        readonly externalId?: string;
    }
    /**
     * Configuration for handling failures when performing operations on EC2 resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2ungraceful.html
     */
    interface Ec2UngracefulProperty {
        /**
         * The minimum success percentage that you specify for EC2 Auto Scaling groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ec2ungraceful.html#cfn-arcregionswitch-plan-ec2ungraceful-minimumsuccesspercentage
         */
        readonly minimumSuccessPercentage?: number;
    }
    /**
     * Configuration for approval steps in a Region switch plan execution.
     *
     * Approval steps require manual intervention before the execution can proceed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionapprovalconfiguration.html
     */
    interface ExecutionApprovalConfigurationProperty {
        /**
         * The IAM approval role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionapprovalconfiguration.html#cfn-arcregionswitch-plan-executionapprovalconfiguration-approvalrole
         */
        readonly approvalRole?: string;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-executionapprovalconfiguration.html#cfn-arcregionswitch-plan-executionapprovalconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * Configuration for ARC routing controls used in a Region switch plan.
     *
     * Routing controls are simple on/off switches that you can use to shift traffic away from an impaired Region.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolconfiguration.html
     */
    interface ArcRoutingControlConfigurationProperty {
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolconfiguration.html#cfn-arcregionswitch-plan-arcroutingcontrolconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolconfiguration.html#cfn-arcregionswitch-plan-arcroutingcontrolconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * The Region and ARC routing controls for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolconfiguration.html#cfn-arcregionswitch-plan-arcroutingcontrolconfiguration-regionandroutingcontrols
         */
        readonly regionAndRoutingControls?: cdk.IResolvable | Record<string, Array<CfnPlanPropsMixin.ArcRoutingControlStateProperty | cdk.IResolvable> | cdk.IResolvable>;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolconfiguration.html#cfn-arcregionswitch-plan-arcroutingcontrolconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolstate.html
     */
    interface ArcRoutingControlStateProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolstate.html#cfn-arcregionswitch-plan-arcroutingcontrolstate-routingcontrolarn
         */
        readonly routingControlArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-arcroutingcontrolstate.html#cfn-arcregionswitch-plan-arcroutingcontrolstate-state
         */
        readonly state?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html
     */
    interface AuroraProvisionedScalingConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html#cfn-arcregionswitch-plan-auroraprovisionedscalingconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html#cfn-arcregionswitch-plan-auroraprovisionedscalingconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html#cfn-arcregionswitch-plan-auroraprovisionedscalingconfiguration-globalclusteridentifier
         */
        readonly globalClusterIdentifier?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html#cfn-arcregionswitch-plan-auroraprovisionedscalingconfiguration-instancearns
         */
        readonly instanceArns?: cdk.IResolvable | Record<string, string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html#cfn-arcregionswitch-plan-auroraprovisionedscalingconfiguration-regiondatabaseclusterarns
         */
        readonly regionDatabaseClusterArns?: cdk.IResolvable | Record<string, string>;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraprovisionedscalingconfiguration.html#cfn-arcregionswitch-plan-auroraprovisionedscalingconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html
     */
    interface AuroraServerlessScalingConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html#cfn-arcregionswitch-plan-auroraserverlessscalingconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html#cfn-arcregionswitch-plan-auroraserverlessscalingconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html#cfn-arcregionswitch-plan-auroraserverlessscalingconfiguration-globalclusteridentifier
         */
        readonly globalClusterIdentifier?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html#cfn-arcregionswitch-plan-auroraserverlessscalingconfiguration-regiondatabaseclusterarns
         */
        readonly regionDatabaseClusterArns?: cdk.IResolvable | Record<string, string>;
        /**
         * @default - 100
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html#cfn-arcregionswitch-plan-auroraserverlessscalingconfiguration-targetpercent
         */
        readonly targetPercent?: number;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-auroraserverlessscalingconfiguration.html#cfn-arcregionswitch-plan-auroraserverlessscalingconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * Configuration for Amazon Aurora global databases used in a Region switch plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html
     */
    interface GlobalAuroraConfigurationProperty {
        /**
         * The behavior for a global database, that is, only allow switchover or also allow failover.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-behavior
         */
        readonly behavior?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The database cluster Amazon Resource Names (ARNs) for a global database.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-databaseclusterarns
         */
        readonly databaseClusterArns?: Array<string>;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * The global cluster identifier for a global database.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-globalclusteridentifier
         */
        readonly globalClusterIdentifier?: string;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraconfiguration.html#cfn-arcregionswitch-plan-globalauroraconfiguration-ungraceful
         */
        readonly ungraceful?: CfnPlanPropsMixin.GlobalAuroraUngracefulProperty | cdk.IResolvable;
    }
    /**
     * Configuration for handling failures when performing operations on Aurora global databases.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraungraceful.html
     */
    interface GlobalAuroraUngracefulProperty {
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-globalauroraungraceful.html#cfn-arcregionswitch-plan-globalauroraungraceful-ungraceful
         */
        readonly ungraceful?: string;
    }
    /**
     * Configuration for steps that should be executed in parallel during a Region switch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-parallelexecutionblockconfiguration.html
     */
    interface ParallelExecutionBlockConfigurationProperty {
        /**
         * The steps for a parallel execution block.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-parallelexecutionblockconfiguration.html#cfn-arcregionswitch-plan-parallelexecutionblockconfiguration-steps
         */
        readonly steps?: Array<cdk.IResolvable | CfnPlanPropsMixin.StepProperty> | cdk.IResolvable;
    }
    /**
     * Configuration for nested Region switch plans.
     *
     * This allows one Region switch plan to trigger another plan as part of its execution.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-regionswitchplanconfiguration.html
     */
    interface RegionSwitchPlanConfigurationProperty {
        /**
         * The Amazon Resource Name (ARN) of the plan configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-regionswitchplanconfiguration.html#cfn-arcregionswitch-plan-regionswitchplanconfiguration-arn
         */
        readonly arn?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-regionswitchplanconfiguration.html#cfn-arcregionswitch-plan-regionswitchplanconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-regionswitchplanconfiguration.html#cfn-arcregionswitch-plan-regionswitchplanconfiguration-externalid
         */
        readonly externalId?: string;
    }
    /**
     * The configuration for an AWS ECS capacity increase.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecscapacityincreaseconfiguration.html
     */
    interface EcsCapacityIncreaseConfigurationProperty {
        /**
         * The monitoring approach specified for the configuration, for example, `Most_Recent` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecscapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ecscapacityincreaseconfiguration-capacitymonitoringapproach
         */
        readonly capacityMonitoringApproach?: string;
        /**
         * The services specified for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecscapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ecscapacityincreaseconfiguration-services
         */
        readonly services?: Array<cdk.IResolvable | CfnPlanPropsMixin.ServiceProperty> | cdk.IResolvable;
        /**
         * The target percentage specified for the configuration.
         *
         * @default - 100
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecscapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ecscapacityincreaseconfiguration-targetpercent
         */
        readonly targetPercent?: number;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecscapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ecscapacityincreaseconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecscapacityincreaseconfiguration.html#cfn-arcregionswitch-plan-ecscapacityincreaseconfiguration-ungraceful
         */
        readonly ungraceful?: CfnPlanPropsMixin.EcsUngracefulProperty | cdk.IResolvable;
    }
    /**
     * The service for a cross account role.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-service.html
     */
    interface ServiceProperty {
        /**
         * The cluster Amazon Resource Name (ARN) for a service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-service.html#cfn-arcregionswitch-plan-service-clusterarn
         */
        readonly clusterArn?: string;
        /**
         * The cross account role for a service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-service.html#cfn-arcregionswitch-plan-service-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-service.html#cfn-arcregionswitch-plan-service-externalid
         */
        readonly externalId?: string;
        /**
         * The Amazon Resource Name (ARN) for a service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-service.html#cfn-arcregionswitch-plan-service-servicearn
         */
        readonly serviceArn?: string;
    }
    /**
     * The settings for ungraceful execution.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecsungraceful.html
     */
    interface EcsUngracefulProperty {
        /**
         * The minimum success percentage specified for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ecsungraceful.html#cfn-arcregionswitch-plan-ecsungraceful-minimumsuccesspercentage
         */
        readonly minimumSuccessPercentage?: number;
    }
    /**
     * The AWS EKS resource scaling configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html
     */
    interface EksResourceScalingConfigurationProperty {
        /**
         * The monitoring approach for the configuration, that is, whether it was sampled in the last 24 hours or autoscaled in the last 24 hours.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-capacitymonitoringapproach
         */
        readonly capacityMonitoringApproach?: string;
        /**
         * The clusters for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-eksclusters
         */
        readonly eksClusters?: Array<CfnPlanPropsMixin.EksClusterProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The Kubernetes resource type for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-kubernetesresourcetype
         */
        readonly kubernetesResourceType?: cdk.IResolvable | CfnPlanPropsMixin.KubernetesResourceTypeProperty;
        /**
         * The scaling resources for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-scalingresources
         */
        readonly scalingResources?: Array<cdk.IResolvable | Record<string, cdk.IResolvable | Record<string, cdk.IResolvable | CfnPlanPropsMixin.KubernetesScalingResourceProperty>>> | cdk.IResolvable;
        /**
         * The target percentage for the configuration.
         *
         * @default - 100
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-targetpercent
         */
        readonly targetPercent?: number;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingconfiguration.html#cfn-arcregionswitch-plan-eksresourcescalingconfiguration-ungraceful
         */
        readonly ungraceful?: CfnPlanPropsMixin.EksResourceScalingUngracefulProperty | cdk.IResolvable;
    }
    /**
     * Defines the type of Kubernetes resource to scale in an Amazon EKS cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesresourcetype.html
     */
    interface KubernetesResourceTypeProperty {
        /**
         * The API version type for the Kubernetes resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesresourcetype.html#cfn-arcregionswitch-plan-kubernetesresourcetype-apiversion
         */
        readonly apiVersion?: string;
        /**
         * The kind for the Kubernetes resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesresourcetype.html#cfn-arcregionswitch-plan-kubernetesresourcetype-kind
         */
        readonly kind?: string;
    }
    /**
     * The AWS EKS cluster execution block configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ekscluster.html
     */
    interface EksClusterProperty {
        /**
         * The Amazon Resource Name (ARN) of an AWS EKS cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ekscluster.html#cfn-arcregionswitch-plan-ekscluster-clusterarn
         */
        readonly clusterArn?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ekscluster.html#cfn-arcregionswitch-plan-ekscluster-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-ekscluster.html#cfn-arcregionswitch-plan-ekscluster-externalid
         */
        readonly externalId?: string;
    }
    /**
     * The ungraceful settings for AWS EKS resource scaling.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingungraceful.html
     */
    interface EksResourceScalingUngracefulProperty {
        /**
         * The minimum success percentage for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eksresourcescalingungraceful.html#cfn-arcregionswitch-plan-eksresourcescalingungraceful-minimumsuccesspercentage
         */
        readonly minimumSuccessPercentage?: number;
    }
    /**
     * Defines a Kubernetes resource to scale in an Amazon EKS cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesscalingresource.html
     */
    interface KubernetesScalingResourceProperty {
        /**
         * The hpaname for the Kubernetes resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesscalingresource.html#cfn-arcregionswitch-plan-kubernetesscalingresource-hpaname
         */
        readonly hpaName?: string;
        /**
         * The name for the Kubernetes resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesscalingresource.html#cfn-arcregionswitch-plan-kubernetesscalingresource-name
         */
        readonly name?: string;
        /**
         * The namespace for the Kubernetes resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-kubernetesscalingresource.html#cfn-arcregionswitch-plan-kubernetesscalingresource-namespace
         */
        readonly namespace?: string;
    }
    /**
     * The Amazon Route 53 health check configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html
     */
    interface Route53HealthCheckConfigurationProperty {
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html#cfn-arcregionswitch-plan-route53healthcheckconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html#cfn-arcregionswitch-plan-route53healthcheckconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * The Amazon Route 53 health check configuration hosted zone ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html#cfn-arcregionswitch-plan-route53healthcheckconfiguration-hostedzoneid
         */
        readonly hostedZoneId?: string;
        /**
         * The Amazon Route 53 health check configuration record name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html#cfn-arcregionswitch-plan-route53healthcheckconfiguration-recordname
         */
        readonly recordName?: string;
        /**
         * The Amazon Route 53 health check configuration record sets.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html#cfn-arcregionswitch-plan-route53healthcheckconfiguration-recordsets
         */
        readonly recordSets?: Array<cdk.IResolvable | CfnPlanPropsMixin.Route53ResourceRecordSetProperty> | cdk.IResolvable;
        /**
         * The Amazon Route 53 health check configuration time out (in minutes).
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthcheckconfiguration.html#cfn-arcregionswitch-plan-route53healthcheckconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * The Amazon Route 53 record set.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53resourcerecordset.html
     */
    interface Route53ResourceRecordSetProperty {
        /**
         * The Amazon Route 53 record set identifier.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53resourcerecordset.html#cfn-arcregionswitch-plan-route53resourcerecordset-recordsetidentifier
         */
        readonly recordSetIdentifier?: string;
        /**
         * The Amazon Route 53 record set Region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53resourcerecordset.html#cfn-arcregionswitch-plan-route53resourcerecordset-region
         */
        readonly region?: string;
    }
    /**
     * Configuration for Amazon DocumentDB global clusters used in a Region switch plan.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html
     */
    interface DocumentDbConfigurationProperty {
        /**
         * The behavior for a global cluster, that is, only allow switchover or also allow failover.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-behavior
         */
        readonly behavior?: string;
        /**
         * The cross account role for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * The database cluster Amazon Resource Names (ARNs) for a DocumentDB global cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-databaseclusterarns
         */
        readonly databaseClusterArns?: Array<string>;
        /**
         * The external ID (secret key) for the configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * The global cluster identifier for a DocumentDB global cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-globalclusteridentifier
         */
        readonly globalClusterIdentifier?: string;
        /**
         * The timeout value specified for the configuration.
         *
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbconfiguration.html#cfn-arcregionswitch-plan-documentdbconfiguration-ungraceful
         */
        readonly ungraceful?: CfnPlanPropsMixin.DocumentDbUngracefulProperty | cdk.IResolvable;
    }
    /**
     * Configuration for handling failures when performing operations on DocumentDB global clusters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbungraceful.html
     */
    interface DocumentDbUngracefulProperty {
        /**
         * The settings for ungraceful execution.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-documentdbungraceful.html#cfn-arcregionswitch-plan-documentdbungraceful-ungraceful
         */
        readonly ungraceful?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdspromotereadreplicaconfiguration.html
     */
    interface RdsPromoteReadReplicaConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdspromotereadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdspromotereadreplicaconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdspromotereadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdspromotereadreplicaconfiguration-dbinstancearnmap
         */
        readonly dbInstanceArnMap?: cdk.IResolvable | Record<string, string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdspromotereadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdspromotereadreplicaconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdspromotereadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdspromotereadreplicaconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration.html
     */
    interface RdsCreateCrossRegionReplicaConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration.html#cfn-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration.html#cfn-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration-dbinstancearnmap
         */
        readonly dbInstanceArnMap?: cdk.IResolvable | Record<string, string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration.html#cfn-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration.html#cfn-arcregionswitch-plan-rdscreatecrossregionreplicaconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingconfiguration.html
     */
    interface LambdaEventSourceMappingConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingconfiguration.html#cfn-arcregionswitch-plan-lambdaeventsourcemappingconfiguration-action
         */
        readonly action?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingconfiguration.html#cfn-arcregionswitch-plan-lambdaeventsourcemappingconfiguration-regioneventsourcemappings
         */
        readonly regionEventSourceMappings?: cdk.IResolvable | Record<string, CfnPlanPropsMixin.EventSourceMappingProperty | cdk.IResolvable>;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingconfiguration.html#cfn-arcregionswitch-plan-lambdaeventsourcemappingconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingconfiguration.html#cfn-arcregionswitch-plan-lambdaeventsourcemappingconfiguration-ungraceful
         */
        readonly ungraceful?: cdk.IResolvable | CfnPlanPropsMixin.LambdaEventSourceMappingUngracefulProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eventsourcemapping.html
     */
    interface EventSourceMappingProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eventsourcemapping.html#cfn-arcregionswitch-plan-eventsourcemapping-arn
         */
        readonly arn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eventsourcemapping.html#cfn-arcregionswitch-plan-eventsourcemapping-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-eventsourcemapping.html#cfn-arcregionswitch-plan-eventsourcemapping-externalid
         */
        readonly externalId?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingungraceful.html
     */
    interface LambdaEventSourceMappingUngracefulProperty {
        /**
         * @default - "skip"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-lambdaeventsourcemappingungraceful.html#cfn-arcregionswitch-plan-lambdaeventsourcemappingungraceful-behavior
         */
        readonly behavior?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html
     */
    interface NeptuneGlobalDatabaseConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-behavior
         */
        readonly behavior?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-globalclusteridentifier
         */
        readonly globalClusterIdentifier?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-regiondatabaseclusterarns
         */
        readonly regionDatabaseClusterArns?: cdk.IResolvable | Record<string, string>;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneglobaldatabaseconfiguration.html#cfn-arcregionswitch-plan-neptuneglobaldatabaseconfiguration-ungraceful
         */
        readonly ungraceful?: cdk.IResolvable | CfnPlanPropsMixin.NeptuneUngracefulProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneungraceful.html
     */
    interface NeptuneUngracefulProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-neptuneungraceful.html#cfn-arcregionswitch-plan-neptuneungraceful-ungraceful
         */
        readonly ungraceful?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration.html
     */
    interface RdsSwitchoverReadReplicaConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration-crossaccountrole
         */
        readonly crossAccountRole?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration-dbinstancearnmap
         */
        readonly dbInstanceArnMap?: cdk.IResolvable | Record<string, string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration-externalid
         */
        readonly externalId?: string;
        /**
         * @default - 60
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration-timeoutminutes
         */
        readonly timeoutMinutes?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration.html#cfn-arcregionswitch-plan-rdsswitchoverreadreplicaconfiguration-ungraceful
         */
        readonly ungraceful?: cdk.IResolvable | CfnPlanPropsMixin.RdsUngracefulProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsungraceful.html
     */
    interface RdsUngracefulProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-rdsungraceful.html#cfn-arcregionswitch-plan-rdsungraceful-ungraceful
         */
        readonly ungraceful?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-healthcheckstate.html
     */
    interface HealthCheckStateProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-healthcheckstate.html#cfn-arcregionswitch-plan-healthcheckstate-healthcheckid
         */
        readonly healthCheckId?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-healthcheckstate.html#cfn-arcregionswitch-plan-healthcheckstate-region
         */
        readonly region?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthchecks.html
     */
    interface Route53HealthChecksProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthchecks.html#cfn-arcregionswitch-plan-route53healthchecks-healthcheckids
         */
        readonly healthCheckIds?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthchecks.html#cfn-arcregionswitch-plan-route53healthchecks-hostedzoneids
         */
        readonly hostedZoneIds?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthchecks.html#cfn-arcregionswitch-plan-route53healthchecks-recordnames
         */
        readonly recordNames?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-arcregionswitch-plan-route53healthchecks.html#cfn-arcregionswitch-plan-route53healthchecks-regions
         */
        readonly regions?: Array<string>;
    }
}
/**
 * Properties for CfnPlanPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html
 */
export interface CfnPlanMixinProps {
    /**
     * The associated application health alarms for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-associatedalarms
     */
    readonly associatedAlarms?: cdk.IResolvable | Record<string, CfnPlanPropsMixin.AssociatedAlarmProperty | cdk.IResolvable>;
    /**
     * The description for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-description
     */
    readonly description?: string;
    /**
     * The execution role for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-executionrole
     */
    readonly executionRole?: string;
    /**
     * The name for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-name
     */
    readonly name?: string;
    /**
     * The primary Region for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-primaryregion
     */
    readonly primaryRegion?: string;
    /**
     * The recovery approach for a Region switch plan, which can be active/active (activeActive) or active/passive (activePassive).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-recoveryapproach
     */
    readonly recoveryApproach?: string;
    /**
     * The recovery time objective for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-recoverytimeobjectiveminutes
     */
    readonly recoveryTimeObjectiveMinutes?: number;
    /**
     * The AWS Regions for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-regions
     */
    readonly regions?: Array<string>;
    /**
     * The report configuration for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-reportconfiguration
     */
    readonly reportConfiguration?: cdk.IResolvable | CfnPlanPropsMixin.ReportConfigurationProperty;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-tags
     */
    readonly tags?: Record<string, string>;
    /**
     * The triggers for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-triggers
     */
    readonly triggers?: Array<cdk.IResolvable | CfnPlanPropsMixin.TriggerProperty> | cdk.IResolvable;
    /**
     * The workflows for a plan.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-arcregionswitch-plan.html#cfn-arcregionswitch-plan-workflows
     */
    readonly workflows?: Array<cdk.IResolvable | CfnPlanPropsMixin.WorkflowProperty> | cdk.IResolvable;
}
