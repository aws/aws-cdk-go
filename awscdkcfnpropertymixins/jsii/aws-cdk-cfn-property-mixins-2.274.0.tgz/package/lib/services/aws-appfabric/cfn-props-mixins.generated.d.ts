import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-appfabric";
/**
 * Creates an app authorization within an app bundle, which allows AppFabric to connect to an application.
 *
 * @cloudformationResource AWS::AppFabric::AppAuthorization
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html
 */
export declare class CfnAppAuthorizationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAppAuthorizationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AppFabric::AppAuthorization`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAppAuthorizationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAppAuthorization;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAppAuthorizationPropsMixin {
    /**
     * Contains credential information for the application.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-credential.html
     */
    interface CredentialProperty {
        /**
         * Contains API key credential information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-credential.html#cfn-appfabric-appauthorization-credential-apikeycredential
         */
        readonly apiKeyCredential?: CfnAppAuthorizationPropsMixin.ApiKeyCredentialProperty | cdk.IResolvable;
        /**
         * Contains OAuth2 client credential information.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-credential.html#cfn-appfabric-appauthorization-credential-oauth2credential
         */
        readonly oauth2Credential?: cdk.IResolvable | CfnAppAuthorizationPropsMixin.Oauth2CredentialProperty;
    }
    /**
     * Contains OAuth2 client credential information.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-oauth2credential.html
     */
    interface Oauth2CredentialProperty {
        /**
         * The client ID of the client application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-oauth2credential.html#cfn-appfabric-appauthorization-oauth2credential-clientid
         */
        readonly clientId?: string;
        /**
         * The client secret of the client application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-oauth2credential.html#cfn-appfabric-appauthorization-oauth2credential-clientsecret
         */
        readonly clientSecret?: string;
    }
    /**
     * Contains API key credential information.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-apikeycredential.html
     */
    interface ApiKeyCredentialProperty {
        /**
         * An API key for an application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-apikeycredential.html#cfn-appfabric-appauthorization-apikeycredential-apikey
         */
        readonly apiKey?: string;
    }
    /**
     * Contains information about an application tenant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-tenant.html
     */
    interface TenantProperty {
        /**
         * The display name of the tenant.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-tenant.html#cfn-appfabric-appauthorization-tenant-tenantdisplayname
         */
        readonly tenantDisplayName?: string;
        /**
         * The ID of the application tenant.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-appauthorization-tenant.html#cfn-appfabric-appauthorization-tenant-tenantidentifier
         */
        readonly tenantIdentifier?: string;
    }
}
/**
 * Properties for CfnAppAuthorizationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html
 */
export interface CfnAppAuthorizationMixinProps {
    /**
     * The name of the application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html#cfn-appfabric-appauthorization-app
     */
    readonly app?: string;
    /**
     * The Amazon Resource Name (ARN) or Universal Unique Identifier (UUID) of the app bundle to use for the request.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html#cfn-appfabric-appauthorization-appbundleidentifier
     */
    readonly appBundleIdentifier?: string;
    /**
     * The authorization type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html#cfn-appfabric-appauthorization-authtype
     */
    readonly authType?: string;
    /**
     * Contains credential information for the application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html#cfn-appfabric-appauthorization-credential
     */
    readonly credential?: CfnAppAuthorizationPropsMixin.CredentialProperty | cdk.IResolvable;
    /**
     * Tags to apply to the app authorization.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html#cfn-appfabric-appauthorization-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Contains information about an application tenant.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-appauthorization.html#cfn-appfabric-appauthorization-tenant
     */
    readonly tenant?: cdk.IResolvable | CfnAppAuthorizationPropsMixin.TenantProperty;
}
/**
 * Creates an ingestion destination, which specifies how an application's ingested data is processed by Amazon Web Services AppFabric and where it's delivered.
 *
 * @cloudformationResource AWS::AppFabric::IngestionDestination
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html
 */
export declare class CfnIngestionDestinationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIngestionDestinationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AppFabric::IngestionDestination`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIngestionDestinationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIngestionDestination;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIngestionDestinationPropsMixin {
    /**
     * Contains information about how ingested data is processed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-processingconfiguration.html
     */
    interface ProcessingConfigurationProperty {
        /**
         * Contains information about an audit log processing configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-processingconfiguration.html#cfn-appfabric-ingestiondestination-processingconfiguration-auditlog
         */
        readonly auditLog?: CfnIngestionDestinationPropsMixin.AuditLogProcessingConfigurationProperty | cdk.IResolvable;
    }
    /**
     * Contains information about an audit log processing configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-auditlogprocessingconfiguration.html
     */
    interface AuditLogProcessingConfigurationProperty {
        /**
         * The format in which the audit logs need to be formatted.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-auditlogprocessingconfiguration.html#cfn-appfabric-ingestiondestination-auditlogprocessingconfiguration-format
         */
        readonly format?: string;
        /**
         * The event schema in which the audit logs need to be formatted.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-auditlogprocessingconfiguration.html#cfn-appfabric-ingestiondestination-auditlogprocessingconfiguration-schema
         */
        readonly schema?: string;
    }
    /**
     * Contains information about the destination of ingested data.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-destinationconfiguration.html
     */
    interface DestinationConfigurationProperty {
        /**
         * Contains information about an audit log destination configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-destinationconfiguration.html#cfn-appfabric-ingestiondestination-destinationconfiguration-auditlog
         */
        readonly auditLog?: CfnIngestionDestinationPropsMixin.AuditLogDestinationConfigurationProperty | cdk.IResolvable;
    }
    /**
     * Contains information about an audit log destination configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-auditlogdestinationconfiguration.html
     */
    interface AuditLogDestinationConfigurationProperty {
        /**
         * Contains information about an audit log destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-auditlogdestinationconfiguration.html#cfn-appfabric-ingestiondestination-auditlogdestinationconfiguration-destination
         */
        readonly destination?: CfnIngestionDestinationPropsMixin.DestinationProperty | cdk.IResolvable;
    }
    /**
     * Contains information about an audit log destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-destination.html
     */
    interface DestinationProperty {
        /**
         * Contains information about an Amazon Kinesis Data Firehose delivery stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-destination.html#cfn-appfabric-ingestiondestination-destination-firehosestream
         */
        readonly firehoseStream?: CfnIngestionDestinationPropsMixin.FirehoseStreamProperty | cdk.IResolvable;
        /**
         * Contains information about an Amazon S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-destination.html#cfn-appfabric-ingestiondestination-destination-s3bucket
         */
        readonly s3Bucket?: cdk.IResolvable | CfnIngestionDestinationPropsMixin.S3BucketProperty;
    }
    /**
     * Contains information about an Amazon S3 bucket.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-s3bucket.html
     */
    interface S3BucketProperty {
        /**
         * The name of the Amazon S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-s3bucket.html#cfn-appfabric-ingestiondestination-s3bucket-bucketname
         */
        readonly bucketName?: string;
        /**
         * The object key to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-s3bucket.html#cfn-appfabric-ingestiondestination-s3bucket-prefix
         */
        readonly prefix?: string;
    }
    /**
     * Contains information about an Amazon Kinesis Data Firehose delivery stream.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-firehosestream.html
     */
    interface FirehoseStreamProperty {
        /**
         * The name of the Amazon Kinesis Data Firehose delivery stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-appfabric-ingestiondestination-firehosestream.html#cfn-appfabric-ingestiondestination-firehosestream-streamname
         */
        readonly streamName?: string;
    }
}
/**
 * Properties for CfnIngestionDestinationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html
 */
export interface CfnIngestionDestinationMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the app bundle.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html#cfn-appfabric-ingestiondestination-appbundlearn
     */
    readonly appBundleArn?: string;
    /**
     * Contains information about the destination of ingested data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html#cfn-appfabric-ingestiondestination-destinationconfiguration
     */
    readonly destinationConfiguration?: CfnIngestionDestinationPropsMixin.DestinationConfigurationProperty | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the ingestion.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html#cfn-appfabric-ingestiondestination-ingestionarn
     */
    readonly ingestionArn?: string;
    /**
     * Contains information about how ingested data is processed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html#cfn-appfabric-ingestiondestination-processingconfiguration
     */
    readonly processingConfiguration?: cdk.IResolvable | CfnIngestionDestinationPropsMixin.ProcessingConfigurationProperty;
    /**
     * A map of the key-value pairs of the tag or tags to assign to the resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-appfabric-ingestiondestination.html#cfn-appfabric-ingestiondestination-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
