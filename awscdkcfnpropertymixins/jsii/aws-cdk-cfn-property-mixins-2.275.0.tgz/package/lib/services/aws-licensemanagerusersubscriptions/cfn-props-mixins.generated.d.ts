import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-licensemanagerusersubscriptions";
/**
 * Resource Type definition for AWS::LicenseManagerUserSubscriptions::LicenseServerEndpoint.
 *
 * A license server endpoint that provides access to Remote Desktop Services Subscriber Access License servers for a registered identity provider.
 *
 * @cloudformationResource AWS::LicenseManagerUserSubscriptions::LicenseServerEndpoint
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-licensemanagerusersubscriptions-licenseserverendpoint.html
 */
export declare class CfnLicenseServerEndpointPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLicenseServerEndpointMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::LicenseManagerUserSubscriptions::LicenseServerEndpoint`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLicenseServerEndpointMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLicenseServerEndpoint;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnLicenseServerEndpointPropsMixin {
    /**
     * The settings of the RDS license server to create the endpoint for.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserversettings.html
     */
    interface LicenseServerSettingsProperty {
        /**
         * The settings of a license server, by server type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserversettings.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserversettings-serversettings
         */
        readonly serverSettings?: cdk.IResolvable | CfnLicenseServerEndpointPropsMixin.ServerSettingsProperty;
        /**
         * The type of license server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserversettings.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserversettings-servertype
         */
        readonly serverType?: string;
    }
    /**
     * The settings of a license server, by server type.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-serversettings.html
     */
    interface ServerSettingsProperty {
        /**
         * The settings of a Remote Desktop Services Subscriber Access License server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-serversettings.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-serversettings-rdssalsettings
         */
        readonly rdsSalSettings?: cdk.IResolvable | CfnLicenseServerEndpointPropsMixin.RdsSalSettingsProperty;
    }
    /**
     * The settings of a Remote Desktop Services Subscriber Access License server.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-rdssalsettings.html
     */
    interface RdsSalSettingsProperty {
        /**
         * The source of the credentials that License Manager uses to reach the license server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-rdssalsettings.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-rdssalsettings-rdssalcredentialsprovider
         */
        readonly rdsSalCredentialsProvider?: CfnLicenseServerEndpointPropsMixin.CredentialsProviderProperty | cdk.IResolvable;
    }
    /**
     * The source of the credentials that License Manager uses to reach the license server.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-credentialsprovider.html
     */
    interface CredentialsProviderProperty {
        /**
         * Credentials held in AWS Secrets Manager.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-credentialsprovider.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-credentialsprovider-secretsmanagercredentialsprovider
         */
        readonly secretsManagerCredentialsProvider?: cdk.IResolvable | CfnLicenseServerEndpointPropsMixin.SecretsManagerCredentialsProviderProperty;
    }
    /**
     * Credentials held in AWS Secrets Manager.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-secretsmanagercredentialsprovider.html
     */
    interface SecretsManagerCredentialsProviderProperty {
        /**
         * The identifier of the Secrets Manager secret that holds the license server administrator credentials.
         *
         * The name of the secret must begin with the prefix license-manager-user-.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-secretsmanagercredentialsprovider.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-secretsmanagercredentialsprovider-secretid
         */
        readonly secretId?: string;
    }
    /**
     * The network address of a license server endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-serverendpoint.html
     */
    interface ServerEndpointProperty {
        /**
         * The network address of the endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-serverendpoint.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-serverendpoint-endpoint
         */
        readonly endpoint?: string;
    }
    /**
     * A Remote Desktop Services license server that is accessed through the endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver.html
     */
    interface LicenseServerProperty {
        /**
         * The health status of the license server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver-healthstatus
         */
        readonly healthStatus?: string;
        /**
         * The domain IPv4 address of the license server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver-ipv4address
         */
        readonly ipv4Address?: string;
        /**
         * The domain IPv6 address of the license server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver-ipv6address
         */
        readonly ipv6Address?: string;
        /**
         * The current state of the provisioning process for the license server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserver-provisioningstatus
         */
        readonly provisioningStatus?: string;
    }
}
/**
 * Properties for CfnLicenseServerEndpointPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-licensemanagerusersubscriptions-licenseserverendpoint.html
 */
export interface CfnLicenseServerEndpointMixinProps {
    /**
     * The Amazon Resource Name (ARN) that identifies the registered identity provider the license server endpoint is created for.
     *
     * For Active Directory, that can be a self-managed Active Directory or an AWS Managed Microsoft AD.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-licensemanagerusersubscriptions-licenseserverendpoint.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-identityproviderarn
     */
    readonly identityProviderArn?: string;
    /**
     * The settings of the RDS license server to create the endpoint for.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-licensemanagerusersubscriptions-licenseserverendpoint.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-licenseserversettings
     */
    readonly licenseServerSettings?: cdk.IResolvable | CfnLicenseServerEndpointPropsMixin.LicenseServerSettingsProperty;
    /**
     * The tags that apply for the license server endpoint.
     *
     * A maximum of 50 tags.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-licensemanagerusersubscriptions-licenseserverendpoint.html#cfn-licensemanagerusersubscriptions-licenseserverendpoint-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
