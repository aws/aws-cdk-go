import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-storagegateway";
/**
 * Resource Type definition for AWS::StorageGateway::NFSFileShare.
 *
 * An NFS file share exposes an Amazon S3 bucket through a Storage Gateway file gateway, so clients read and write objects as files over NFS. The share's variant is fixed by its resource type rather than by a property: the service constructs the two variants with different APIs, and a property carrying the choice would belong to neither API's input.
 *
 * @cloudformationResource AWS::StorageGateway::NFSFileShare
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html
 */
export declare class CfnNFSFileSharePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNFSFileShareMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::NFSFileShare`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNFSFileShareMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNFSFileShare;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnNFSFileSharePropsMixin {
    /**
     * Refresh cache information for the file share.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-cacheattributes.html
     */
    interface CacheAttributesProperty {
        /**
         * How long the directory contents cached by the gateway are considered valid.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-cacheattributes.html#cfn-storagegateway-nfsfileshare-cacheattributes-cachestaletimeoutinseconds
         */
        readonly cacheStaleTimeoutInSeconds?: number;
    }
    /**
     * Default values for the file and directory permissions of an NFS share.
     *
     * Removing this property from a template leaves the live values unchanged rather than clearing them, because the service has no reset for it: a create that omits the object leaves it absent, but the update path merges member by member keyed on the same internal sentinel that reports absence, so no request can restore that state. Set the members you want rather than relying on removal.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-nfsfilesharedefaults.html
     */
    interface NFSFileShareDefaultsProperty {
        /**
         * The Unix directory mode in the form nnnn.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-nfsfilesharedefaults.html#cfn-storagegateway-nfsfileshare-nfsfilesharedefaults-directorymode
         */
        readonly directoryMode?: string;
        /**
         * The Unix file mode in the form nnnn.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-nfsfilesharedefaults.html#cfn-storagegateway-nfsfileshare-nfsfilesharedefaults-filemode
         */
        readonly fileMode?: string;
        /**
         * The default group ID for files in the file share.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-nfsfilesharedefaults.html#cfn-storagegateway-nfsfileshare-nfsfilesharedefaults-groupid
         */
        readonly groupId?: number;
        /**
         * The default owner ID for files in the file share.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-nfsfileshare-nfsfilesharedefaults.html#cfn-storagegateway-nfsfileshare-nfsfilesharedefaults-ownerid
         */
        readonly ownerId?: number;
    }
}
/**
 * Properties for CfnNFSFileSharePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html
 */
export interface CfnNFSFileShareMixinProps {
    /**
     * The ARN of the CloudWatch log group that receives the share's audit logs.
     *
     * Removing this property from a template detaches audit logging: the update sends the empty string, which the service treats as the reset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-auditdestinationarn
     */
    readonly auditDestinationArn?: string;
    /**
     * The Region of the S3 bucket, required when the bucket is reached through a VPC endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-bucketregion
     */
    readonly bucketRegion?: string;
    /**
     * Refresh cache information for the file share.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-cacheattributes
     */
    readonly cacheAttributes?: CfnNFSFileSharePropsMixin.CacheAttributesProperty | cdk.IResolvable;
    /**
     * The IPv4 or IPv6 addresses and CIDR blocks permitted to mount the NFS share.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-clientlist
     */
    readonly clientList?: Array<string>;
    /**
     * The S3 storage class for new objects.
     *
     * The service accepts S3_STANDARD, S3_INTELLIGENT_TIERING, S3_STANDARD_IA and S3_ONEZONE_IA; it is a length-bounded string in the API model rather than an enumeration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-defaultstorageclass
     */
    readonly defaultStorageClass?: string;
    /**
     * The server-side encryption the gateway applies to objects it writes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-encryptiontype
     */
    readonly encryptionType?: string;
    /**
     * The name of the file share, which defaults to the bucket name when omitted.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-filesharename
     */
    readonly fileShareName?: string;
    /**
     * The ARN of the S3 File Gateway that hosts the share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-gatewayarn
     */
    readonly gatewayArn?: string;
    /**
     * Whether the gateway infers the MIME type of uploaded objects from their extension.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-guessmimetypeenabled
     */
    readonly guessMimeTypeEnabled?: boolean | cdk.IResolvable;
    /**
     * Deprecated by the service in favour of EncryptionType;
     *
     * true selects KMS encryption. Retained because it remains readable and settable.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-kmsencrypted
     */
    readonly kmsEncrypted?: boolean | cdk.IResolvable;
    /**
     * The KMS key used for encryption, when EncryptionType selects KMS.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-kmskey
     */
    readonly kmsKey?: string;
    /**
     * The ARN of the S3 bucket, or bucket prefix, the share exposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-locationarn
     */
    readonly locationArn?: string;
    /**
     * Default values for the file and directory permissions of an NFS share.
     *
     * Removing this property from a template leaves the live values unchanged rather than clearing them, because the service has no reset for it: a create that omits the object leaves it absent, but the update path merges member by member keyed on the same internal sentinel that reports absence, so no request can restore that state. Set the members you want rather than relying on removal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-nfsfilesharedefaults
     */
    readonly nfsFileShareDefaults?: cdk.IResolvable | CfnNFSFileSharePropsMixin.NFSFileShareDefaultsProperty;
    /**
     * The upload-notification settling period, as a JSON document.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-notificationpolicy
     */
    readonly notificationPolicy?: string;
    /**
     * The canned S3 ACL applied to objects the gateway writes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-objectacl
     */
    readonly objectAcl?: string;
    /**
     * Whether clients may write to the share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-readonly
     */
    readonly readOnly?: boolean | cdk.IResolvable;
    /**
     * Whether the bucket is a Requester Pays bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-requesterpays
     */
    readonly requesterPays?: boolean | cdk.IResolvable;
    /**
     * The ARN of the IAM role the gateway assumes when it accesses the S3 location.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-role
     */
    readonly role?: string;
    /**
     * How the NFS share maps client user IDs.
     *
     * The service accepts RootSquash, NoSquash and AllSquash; it is a length-bounded string in the API model rather than an enumeration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-squash
     */
    readonly squash?: string;
    /**
     * Tags assigned to the file share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The DNS name of the S3 VPC endpoint the gateway uses to reach the bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-nfsfileshare.html#cfn-storagegateway-nfsfileshare-vpcendpointdnsname
     */
    readonly vpcEndpointDnsName?: string;
}
/**
 * Resource Type definition for AWS::StorageGateway::SMBFileShare.
 *
 * An SMB file share exposes an Amazon S3 bucket through a Storage Gateway file gateway, so clients read and write objects as files over SMB. The share's variant is fixed by its resource type rather than by a property: the service constructs the two variants with different APIs, and a property carrying the choice would belong to neither API's input.
 *
 * @cloudformationResource AWS::StorageGateway::SMBFileShare
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html
 */
export declare class CfnSMBFileSharePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSMBFileShareMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::SMBFileShare`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSMBFileShareMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSMBFileShare;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSMBFileSharePropsMixin {
    /**
     * Refresh cache information for the file share.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-smbfileshare-cacheattributes.html
     */
    interface CacheAttributesProperty {
        /**
         * How long the directory contents cached by the gateway are considered valid.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-storagegateway-smbfileshare-cacheattributes.html#cfn-storagegateway-smbfileshare-cacheattributes-cachestaletimeoutinseconds
         */
        readonly cacheStaleTimeoutInSeconds?: number;
    }
}
/**
 * Properties for CfnSMBFileSharePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html
 */
export interface CfnSMBFileShareMixinProps {
    /**
     * Whether clients see only the files and folders they may access.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-accessbasedenumeration
     */
    readonly accessBasedEnumeration?: boolean | cdk.IResolvable;
    /**
     * Users and groups granted administrative privileges on the SMB share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-adminuserlist
     */
    readonly adminUserList?: Array<string>;
    /**
     * The ARN of the CloudWatch log group that receives the share's audit logs.
     *
     * Removing this property from a template detaches audit logging: the update sends the empty string, which the service treats as the reset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-auditdestinationarn
     */
    readonly auditDestinationArn?: string;
    /**
     * The authentication the SMB share uses.
     *
     * The service accepts ActiveDirectory and GuestAccess; it is a length-bounded string in the API model rather than an enumeration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-authentication
     */
    readonly authentication?: string;
    /**
     * The Region of the S3 bucket, required when the bucket is reached through a VPC endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-bucketregion
     */
    readonly bucketRegion?: string;
    /**
     * Refresh cache information for the file share.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-cacheattributes
     */
    readonly cacheAttributes?: CfnSMBFileSharePropsMixin.CacheAttributesProperty | cdk.IResolvable;
    /**
     * Whether the SMB share is case sensitive or defers to the client.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-casesensitivity
     */
    readonly caseSensitivity?: string;
    /**
     * The S3 storage class for new objects.
     *
     * The service accepts S3_STANDARD, S3_INTELLIGENT_TIERING, S3_STANDARD_IA and S3_ONEZONE_IA; it is a length-bounded string in the API model rather than an enumeration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-defaultstorageclass
     */
    readonly defaultStorageClass?: string;
    /**
     * The server-side encryption the gateway applies to objects it writes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-encryptiontype
     */
    readonly encryptionType?: string;
    /**
     * The name of the file share, which defaults to the bucket name when omitted.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-filesharename
     */
    readonly fileShareName?: string;
    /**
     * The ARN of the S3 File Gateway that hosts the share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-gatewayarn
     */
    readonly gatewayArn?: string;
    /**
     * Whether the gateway infers the MIME type of uploaded objects from their extension.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-guessmimetypeenabled
     */
    readonly guessMimeTypeEnabled?: boolean | cdk.IResolvable;
    /**
     * Users and groups denied access to the SMB share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-invaliduserlist
     */
    readonly invalidUserList?: Array<string>;
    /**
     * Deprecated by the service in favour of EncryptionType;
     *
     * true selects KMS encryption. Retained because it remains readable and settable.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-kmsencrypted
     */
    readonly kmsEncrypted?: boolean | cdk.IResolvable;
    /**
     * The KMS key used for encryption, when EncryptionType selects KMS.
     *
     * Removing this property from a template leaves the share's current value: the service documents no value that resets it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-kmskey
     */
    readonly kmsKey?: string;
    /**
     * The ARN of the S3 bucket, or bucket prefix, the share exposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-locationarn
     */
    readonly locationArn?: string;
    /**
     * The upload-notification settling period, as a JSON document.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-notificationpolicy
     */
    readonly notificationPolicy?: string;
    /**
     * The canned S3 ACL applied to objects the gateway writes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-objectacl
     */
    readonly objectAcl?: string;
    /**
     * Whether the SMB share grants opportunistic locks.
     *
     * Removing this property from a template leaves the live value unchanged rather than restoring the created default, because that default depends on the gateway's software version -- opportunistic locking is enabled by default only on appliances at 1.19.0.0 or above -- and the version is not part of this resource. Set the value explicitly rather than relying on removal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-oplocksenabled
     */
    readonly oplocksEnabled?: boolean | cdk.IResolvable;
    /**
     * Whether clients may write to the share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-readonly
     */
    readonly readOnly?: boolean | cdk.IResolvable;
    /**
     * Whether the bucket is a Requester Pays bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-requesterpays
     */
    readonly requesterPays?: boolean | cdk.IResolvable;
    /**
     * The ARN of the IAM role the gateway assumes when it accesses the S3 location.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-role
     */
    readonly role?: string;
    /**
     * Whether the SMB share uses Windows ACLs rather than POSIX permissions.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-smbaclenabled
     */
    readonly smbaclEnabled?: boolean | cdk.IResolvable;
    /**
     * Tags assigned to the file share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Users and groups permitted to access the SMB share.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-validuserlist
     */
    readonly validUserList?: Array<string>;
    /**
     * The DNS name of the S3 VPC endpoint the gateway uses to reach the bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-smbfileshare.html#cfn-storagegateway-smbfileshare-vpcendpointdnsname
     */
    readonly vpcEndpointDnsName?: string;
}
/**
 * Creates a virtual tape with a user-defined barcode on a Tape Gateway (VTL).
 *
 * A virtual tape is stored in Amazon S3 and can be archived to S3 Glacier or S3 Glacier Deep Archive.
 *
 * @cloudformationResource AWS::StorageGateway::Tape
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html
 */
export declare class CfnTapePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTapeMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::Tape`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTapeMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTape;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTapePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html
 */
export interface CfnTapeMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the Tape Gateway that hosts the virtual tape.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-gatewayarn
     */
    readonly gatewayArn?: string;
    /**
     * Set to true to use Amazon S3 server-side encryption with your own KMS key, or false to use a key managed by Amazon S3.
     *
     * Optional.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-kmsencrypted
     */
    readonly kmsEncrypted?: boolean | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of a symmetric customer master key (CMK) used for Amazon S3 server-side encryption.
     *
     * This value must be set if KMSEncrypted is true.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-kmskey
     */
    readonly kmsKey?: string;
    /**
     * The ID of the pool that you want to add your tape to for archiving.
     *
     * Tapes in this pool are archived in the S3 storage class that is associated with the pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-poolid
     */
    readonly poolId?: string;
    /**
     * A list of up to 50 tags to assign to the virtual tape.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The barcode that you want to assign to the virtual tape.
     *
     * Barcodes cannot be reused, even after a tape is deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-tapebarcode
     */
    readonly tapeBarcode?: string;
    /**
     * The size, in bytes, of the virtual tape that you want to create.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-tapesizeinbytes
     */
    readonly tapeSizeInBytes?: number;
    /**
     * Set to true to create a write-once-read-many (WORM) virtual tape.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tape.html#cfn-storagegateway-tape-worm
     */
    readonly worm?: boolean | cdk.IResolvable;
}
/**
 * Creates a custom tape pool for archiving virtual tapes with optional retention lock.
 *
 * @cloudformationResource AWS::StorageGateway::TapePool
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html
 */
export declare class CfnTapePoolPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTapePoolMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::TapePool`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTapePoolMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTapePool;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTapePoolPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html
 */
export interface CfnTapePoolMixinProps {
    /**
     * The name of the custom tape pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-poolname
     */
    readonly poolName?: string;
    /**
     * Tape retention lock time in days (up to 36,500 days / 100 years).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-retentionlocktimeindays
     */
    readonly retentionLockTimeInDays?: number;
    /**
     * Tape retention lock type.
     *
     * Governance mode allows authorized removal; compliance mode prevents all removal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-retentionlocktype
     */
    readonly retentionLockType?: string;
    /**
     * The storage class associated with the custom pool (S3 Glacier or S3 Glacier Deep Archive).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-storageclass
     */
    readonly storageClass?: string;
    /**
     * A list of up to 50 tags for the tape pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-tapepool.html#cfn-storagegateway-tapepool-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a cached iSCSI volume on a Storage Gateway.
 *
 * A cached volume stores data in Amazon S3 and retains a copy of frequently accessed data subsets locally.
 *
 * @cloudformationResource AWS::StorageGateway::Volume
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html
 */
export declare class CfnVolumePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVolumeMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::StorageGateway::Volume`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVolumeMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVolume;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVolumePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html
 */
export interface CfnVolumeMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the gateway on which to create the volume.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-gatewayarn
     */
    readonly gatewayArn?: string;
    /**
     * Set to true to use Amazon S3 server-side encryption with your own KMS key, or false to use a key managed by Amazon S3.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-kmsencrypted
     */
    readonly kmsEncrypted?: boolean | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of a symmetric customer master key (CMK) used for Amazon S3 server-side encryption.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-kmskey
     */
    readonly kmsKey?: string;
    /**
     * The network interface of the gateway on which to expose the iSCSI target.
     *
     * Only IPv4 addresses are accepted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-networkinterfaceid
     */
    readonly networkInterfaceId?: string;
    /**
     * The snapshot ID of the snapshot to restore as the new cached volume (e.g., snap-1122aabb).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-snapshotid
     */
    readonly snapshotId?: string;
    /**
     * The ARN of an existing volume from which to create the new volume.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-sourcevolumearn
     */
    readonly sourceVolumeArn?: string;
    /**
     * A list of up to 50 tags to assign to the volume.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the iSCSI target used by an initiator to connect to a volume and used as a suffix for the target ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-targetname
     */
    readonly targetName?: string;
    /**
     * The size of the volume in bytes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-storagegateway-volume.html#cfn-storagegateway-volume-volumesizeinbytes
     */
    readonly volumeSizeInBytes?: number;
}
