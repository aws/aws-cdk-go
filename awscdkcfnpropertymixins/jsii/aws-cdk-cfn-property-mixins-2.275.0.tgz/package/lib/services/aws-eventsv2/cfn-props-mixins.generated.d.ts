import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-eventsv2";
/**
 * Resource type definition for AWS::EventsV2::EventBus, an Amazon EventBridge custom event bus that receives events and delivers them to matching subscribers.
 *
 * @cloudformationResource AWS::EventsV2::EventBus
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html
 */
export declare class CfnEventBusPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEventBusMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EventsV2::EventBus`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEventBusMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEventBus;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEventBusPropsMixin {
    /**
     * Storage (retention) configuration for the event bus.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventbus-storageconfiguration.html
     */
    interface StorageConfigurationProperty {
        /**
         * The number of days events are retained on the event bus for replay, 1-365.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventbus-storageconfiguration.html#cfn-eventsv2-eventbus-storageconfiguration-retentionperiodindays
         */
        readonly retentionPeriodInDays?: number;
    }
    /**
     * Encryption configuration for an event bus.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventbus-encryptionconfiguration.html
     */
    interface EncryptionConfigurationProperty {
        /**
         * The identifier of the AWS KMS customer managed key that the event bus uses to encrypt events.
         *
         * You can specify the key ARN, key ID, alias name, or alias ARN. If you do not specify a key, EventBridge uses an AWS owned key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventbus-encryptionconfiguration.html#cfn-eventsv2-eventbus-encryptionconfiguration-kmskeyidentifier
         */
        readonly kmsKeyIdentifier?: string;
    }
}
/**
 * Properties for CfnEventBusPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html
 */
export interface CfnEventBusMixinProps {
    /**
     * A description of the event bus.
     *
     * Control characters and Unicode line separators are not allowed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html#cfn-eventsv2-eventbus-description
     */
    readonly description?: string;
    /**
     * Encryption configuration for an event bus.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html#cfn-eventsv2-eventbus-encryptionconfiguration
     */
    readonly encryptionConfiguration?: CfnEventBusPropsMixin.EncryptionConfigurationProperty | cdk.IResolvable;
    /**
     * The name of the event bus.
     *
     * The first character must be alphanumeric; the remaining characters may also include '.', '-', and '_'.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html#cfn-eventsv2-eventbus-name
     */
    readonly name?: string;
    /**
     * Storage (retention) configuration for the event bus.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html#cfn-eventsv2-eventbus-storageconfiguration
     */
    readonly storageConfiguration?: cdk.IResolvable | CfnEventBusPropsMixin.StorageConfigurationProperty;
    /**
     * The tags assigned to the event bus.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventbus.html#cfn-eventsv2-eventbus-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource schema for AWS::EventsV2::EventSource.
 *
 * A managed event source that forwards AWS service events or partner events onto a custom event bus.
 *
 * @cloudformationResource AWS::EventsV2::EventSource
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html
 */
export declare class CfnEventSourcePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEventSourceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EventsV2::EventSource`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEventSourceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEventSource;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEventSourcePropsMixin {
    /**
     * Event source configuration.
     *
     * Exactly one of the two variants must be set.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-eventsourceconfiguration.html
     */
    interface EventSourceConfigurationProperty {
        /**
         * Forward a single AWS service's events from the account's default event bus.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-eventsourceconfiguration.html#cfn-eventsv2-eventsource-eventsourceconfiguration-awsserviceeventsconfiguration
         */
        readonly awsServiceEventsConfiguration?: CfnEventSourcePropsMixin.AwsServiceEventsConfigurationProperty | cdk.IResolvable;
        /**
         * Forward a partner event source's events through a managed partner event bus.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-eventsourceconfiguration.html#cfn-eventsv2-eventsource-eventsourceconfiguration-partnereventsconfiguration
         */
        readonly partnerEventsConfiguration?: cdk.IResolvable | CfnEventSourcePropsMixin.PartnerEventsConfigurationProperty;
    }
    /**
     * Forward a single AWS service's events from the account's default event bus.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-awsserviceeventsconfiguration.html
     */
    interface AwsServiceEventsConfigurationProperty {
        /**
         * A single AWS service source identifier, for example aws.s3. Wildcards and lists are not allowed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-awsserviceeventsconfiguration.html#cfn-eventsv2-eventsource-awsserviceeventsconfiguration-awsservice
         */
        readonly awsService?: string;
        /**
         * The destination for events that could not be forwarded by the managed forwarding target or, for partner event sources, the managed partner event bus.
         *
         * Arn is optional. An empty object removes a configured destination on update.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-awsserviceeventsconfiguration.html#cfn-eventsv2-eventsource-awsserviceeventsconfiguration-onfailureconfiguration
         */
        readonly onFailureConfiguration?: cdk.IResolvable | CfnEventSourcePropsMixin.OnFailureConfigurationProperty;
        /**
         * A filter pattern, as a JSON string, that defines which events from the specified AWS service are forwarded to the event bus.
         *
         * Do not include source, account, or region as top-level fields. If you do not specify a pattern, all events from the service are forwarded.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-awsserviceeventsconfiguration.html#cfn-eventsv2-eventsource-awsserviceeventsconfiguration-pattern
         */
        readonly pattern?: string;
    }
    /**
     * The destination for events that could not be forwarded by the managed forwarding target or, for partner event sources, the managed partner event bus.
     *
     * Arn is optional. An empty object removes a configured destination on update.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-onfailureconfiguration.html
     */
    interface OnFailureConfigurationProperty {
        /**
         * The ARN of the Amazon SQS standard queue that receives events that could not be forwarded.
         *
         * FIFO queues are not supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-onfailureconfiguration.html#cfn-eventsv2-eventsource-onfailureconfiguration-arn
         */
        readonly arn?: string;
    }
    /**
     * Forward a partner event source's events through a managed partner event bus.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-partnereventsconfiguration.html
     */
    interface PartnerEventsConfigurationProperty {
        /**
         * The destination for events that could not be forwarded by the managed forwarding target or, for partner event sources, the managed partner event bus.
         *
         * Arn is optional. An empty object removes a configured destination on update.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-partnereventsconfiguration.html#cfn-eventsv2-eventsource-partnereventsconfiguration-onfailureconfiguration
         */
        readonly onFailureConfiguration?: cdk.IResolvable | CfnEventSourcePropsMixin.OnFailureConfigurationProperty;
        /**
         * The identifier of the AWS KMS customer managed key for EventBridge to use, if you choose to use a customer managed key to encrypt events on the managed partner event bus.
         *
         * The identifier can be the key Amazon Resource Name (ARN), KeyId, key alias, or key alias ARN. If you do not specify a customer managed key identifier, EventBridge uses an AWS owned key to encrypt events on the event bus.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-partnereventsconfiguration.html#cfn-eventsv2-eventsource-partnereventsconfiguration-partnerbuskmskeyidentifier
         */
        readonly partnerBusKmsKeyIdentifier?: string;
        /**
         * The ARN of the partner event source to forward.
         *
         * The partner owns the event source, so the ARN's account segment is empty. Changing this property replaces the event source. Because Name and EventBusArn together identify an event source, and the replacement is created before the old resource is deleted, change Name in the same update.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-partnereventsconfiguration.html#cfn-eventsv2-eventsource-partnereventsconfiguration-partnereventsourcearn
         */
        readonly partnerEventSourceArn?: string;
        /**
         * A filter pattern, as a JSON string, that defines which events from the specified partner event source are forwarded to the event bus.
         *
         * If you do not specify a pattern, all events from the partner event source are forwarded.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-eventsource-partnereventsconfiguration.html#cfn-eventsv2-eventsource-partnereventsconfiguration-pattern
         */
        readonly pattern?: string;
    }
}
/**
 * Properties for CfnEventSourcePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html
 */
export interface CfnEventSourceMixinProps {
    /**
     * Event source configuration.
     *
     * Exactly one of the two variants must be set.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html#cfn-eventsv2-eventsource-configuration
     */
    readonly configuration?: CfnEventSourcePropsMixin.EventSourceConfigurationProperty | cdk.IResolvable;
    /**
     * A description of the event source.
     *
     * Control characters and Unicode line separators are not allowed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html#cfn-eventsv2-eventsource-description
     */
    readonly description?: string;
    /**
     * The ARN of the custom event bus the event source forwards onto.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html#cfn-eventsv2-eventsource-eventbusarn
     */
    readonly eventBusArn?: string;
    /**
     * The name of the event source.
     *
     * The first character must be alphanumeric; the remaining characters may also include '.', '-', and '_'. Names cannot begin with the reserved aws. prefix.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html#cfn-eventsv2-eventsource-name
     */
    readonly name?: string;
    /**
     * The tags assigned to the event source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-eventsource.html#cfn-eventsv2-eventsource-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource type definition for AWS::EventsV2::ResourcePolicy, the resource policy of an Amazon EventBridge event bus.
 *
 * This manages only the resource policy named "default", which the bus owner writes. It does not manage the policy named "AWS_RAM", which AWS Resource Access Manager owns on behalf of the bus owner. If the bus already has a default policy, creating this resource fails. Deleting this resource removes all permissions granted by it. An explicit Deny in this policy takes precedence over an Allow in the "AWS_RAM" policy, so deleting this resource can widen access. Set DeletionPolicy: Retain if the policy carries a Deny that you rely on. Required permissions: events:PutResourcePolicy, events:GetResourcePolicy, and events:DeleteResourcePolicy. Listing resources of this type also requires events:ListEventBuses and events:ListResourcePolicies.
 *
 * @cloudformationResource AWS::EventsV2::ResourcePolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-resourcepolicy.html
 */
export declare class CfnResourcePolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnResourcePolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EventsV2::ResourcePolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnResourcePolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnResourcePolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnResourcePolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-resourcepolicy.html
 */
export interface CfnResourcePolicyMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the event bus whose resource policy this is.
     *
     * The bus must already exist. This resource does not create it.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-resourcepolicy.html#cfn-eventsv2-resourcepolicy-eventbusarn
     */
    readonly eventBusArn?: string;
    /**
     * The resource policy document, as a JSON object.
     *
     * The document can be up to 20 KB. This quota is adjustable. An empty object is not a valid policy. To remove the policy, delete this resource. The principals in the document must exist and be visible to the service when the policy is written. When you create a new IAM role or user, that principal might not be immediately visible to the service. You might need to enforce a delay before you include it in the document. For more information, see "Changes that I make are not always immediately visible" in the IAM User Guide. Declare Version. Write AWS account and role principals as ARNs rather than as account IDs. Write a single Action, Resource, or principal value as a scalar rather than as a one-element list. The service returns these forms as you wrote them. It normalizes other forms, and a normalized value can appear as drift. A stack update replaces the whole policy with this document, including any change made outside CloudFormation. For more information about event bus resource policies, see the Amazon EventBridge User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-resourcepolicy.html#cfn-eventsv2-resourcepolicy-policydocument
     */
    readonly policyDocument?: any | cdk.IResolvable;
}
/**
 * Resource type definition for AWS::EventsV2::Subscriber, an Amazon EventBridge subscription that delivers events from an event bus to a target.
 *
 * Canonical identity is the combination of bus, name, and target. Replacement uses delete_then_create.
 *
 * @cloudformationResource AWS::EventsV2::Subscriber
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html
 */
export declare class CfnSubscriberPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSubscriberMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EventsV2::Subscriber`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSubscriberMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSubscriber;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSubscriberPropsMixin {
    /**
     * Configuration for how the subscriber invokes its target.
     *
     * Specify the target ARN, the IAM role, and, optionally, the target-specific parameters object that matches the target type.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html
     */
    interface InvokeConfigurationProperty {
        /**
         * Parameters for forwarding events to another EventBridge event bus, used when TargetArn is an event bus ARN of the form arn:{partition}:events:{region}:{account}:event-busv2/{name}/{id}.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-eventbusv2parameters
         */
        readonly eventBusV2Parameters?: CfnSubscriberPropsMixin.EventBusV2ParametersProperty | cdk.IResolvable;
        /**
         * Parameters for invoking an HTTP endpoint target, such as an Amazon API Gateway endpoint or an EventBridge API destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-httpparameters
         */
        readonly httpParameters?: CfnSubscriberPropsMixin.HttpParametersProperty | cdk.IResolvable;
        /**
         * Parameters for writing events to an Amazon Kinesis Data Streams target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-kinesisparameters
         */
        readonly kinesisParameters?: cdk.IResolvable | CfnSubscriberPropsMixin.KinesisParametersProperty;
        /**
         * Parameters for invoking an AWS Lambda function target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-lambdaparameters
         */
        readonly lambdaParameters?: cdk.IResolvable | CfnSubscriberPropsMixin.LambdaParametersProperty;
        /**
         * The ARN of the IAM role the service assumes to invoke the target.
         *
         * The role must belong to the same account as the subscriber.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-rolearn
         */
        readonly roleArn?: string;
        /**
         * Parameters for publishing events to an Amazon SNS topic target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-snsparameters
         */
        readonly snsParameters?: cdk.IResolvable | CfnSubscriberPropsMixin.SnsParametersProperty;
        /**
         * Parameters for sending events to an Amazon SQS queue target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-sqsparameters
         */
        readonly sqsParameters?: cdk.IResolvable | CfnSubscriberPropsMixin.SqsParametersProperty;
        /**
         * Parameters for starting an AWS Step Functions state machine execution target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-stepfunctionsparameters
         */
        readonly stepFunctionsParameters?: cdk.IResolvable | CfnSubscriberPropsMixin.StepFunctionsParametersProperty;
        /**
         * The Amazon Resource Name (ARN) of the target that the subscriber invokes.
         *
         * For universal service integration targets, use the form arn:{partition}:events:::aws-sdk:{service}:{apiAction}.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-targetarn
         */
        readonly targetArn?: string;
        /**
         * Parameters for invoking an AWS service API as a universal service integration target, used when TargetArn has the form arn:{partition}:events:::aws-sdk:{service}:{apiAction}.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-invokeconfiguration.html#cfn-eventsv2-subscriber-invokeconfiguration-universaltargetparameters
         */
        readonly universalTargetParameters?: cdk.IResolvable | CfnSubscriberPropsMixin.UniversalTargetParametersProperty;
    }
    /**
     * Parameters for invoking an AWS Lambda function target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-lambdaparameters.html
     */
    interface LambdaParametersProperty {
        /**
         * A unique name for a durable function execution.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-lambdaparameters.html#cfn-eventsv2-subscriber-lambdaparameters-durableexecutionname
         */
        readonly durableExecutionName?: string;
        /**
         * The timeout in seconds for each invocation of the target, written as a string.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-lambdaparameters.html#cfn-eventsv2-subscriber-lambdaparameters-invocationtimeoutseconds
         */
        readonly invocationTimeoutSeconds?: string;
        /**
         * How the function is invoked: EVENT (asynchronous) or REQUEST_RESPONSE (synchronous).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-lambdaparameters.html#cfn-eventsv2-subscriber-lambdaparameters-invocationtype
         */
        readonly invocationType?: string;
        /**
         * The version or alias of the Lambda function to invoke.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-lambdaparameters.html#cfn-eventsv2-subscriber-lambdaparameters-qualifier
         */
        readonly qualifier?: string;
        /**
         * The tenant identifier for multi-tenant Lambda functions.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-lambdaparameters.html#cfn-eventsv2-subscriber-lambdaparameters-tenantid
         */
        readonly tenantId?: string;
    }
    /**
     * Parameters for sending events to an Amazon SQS queue target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-sqsparameters.html
     */
    interface SqsParametersProperty {
        /**
         * The delay in seconds for the message, written as a string.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-sqsparameters.html#cfn-eventsv2-subscriber-sqsparameters-delayseconds
         */
        readonly delaySeconds?: string;
        /**
         * A map of message attribute names to values, with at most 50 attributes.
         *
         * Amazon SQS and Amazon SNS enforce their own per-message attribute limits on delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-sqsparameters.html#cfn-eventsv2-subscriber-sqsparameters-messageattributes
         */
        readonly messageAttributes?: cdk.IResolvable | Record<string, cdk.IResolvable | CfnSubscriberPropsMixin.MessageAttributeValueProperty>;
        /**
         * The message deduplication ID to use when the target is a FIFO queue.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-sqsparameters.html#cfn-eventsv2-subscriber-sqsparameters-messagededuplicationid
         */
        readonly messageDeduplicationId?: string;
        /**
         * The message group ID to use when the target is a FIFO queue.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-sqsparameters.html#cfn-eventsv2-subscriber-sqsparameters-messagegroupid
         */
        readonly messageGroupId?: string;
        /**
         * A map of message attribute names to values, with at most 50 attributes.
         *
         * Amazon SQS and Amazon SNS enforce their own per-message attribute limits on delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-sqsparameters.html#cfn-eventsv2-subscriber-sqsparameters-messagesystemattributes
         */
        readonly messageSystemAttributes?: cdk.IResolvable | Record<string, cdk.IResolvable | CfnSubscriberPropsMixin.MessageAttributeValueProperty>;
    }
    /**
     * A message attribute value and its data type, for Amazon SQS and Amazon SNS targets.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-messageattributevalue.html
     */
    interface MessageAttributeValueProperty {
        /**
         * The attribute value for the Binary data type, Base64-encoded.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-messageattributevalue.html#cfn-eventsv2-subscriber-messageattributevalue-binaryvalue
         */
        readonly binaryValue?: string;
        /**
         * The attribute data type.
         *
         * For Amazon SQS targets, specify String, Number, or Binary, optionally with a custom label suffix such as Number.float. For Amazon SNS targets, specify String, String.Array, Number, or Binary.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-messageattributevalue.html#cfn-eventsv2-subscriber-messageattributevalue-datatype
         */
        readonly dataType?: string;
        /**
         * The attribute value for the String and Number data types (and String.Array for Amazon SNS targets).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-messageattributevalue.html#cfn-eventsv2-subscriber-messageattributevalue-stringvalue
         */
        readonly stringValue?: string;
    }
    /**
     * Parameters for publishing events to an Amazon SNS topic target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-snsparameters.html
     */
    interface SnsParametersProperty {
        /**
         * A map of message attribute names to values, with at most 50 attributes.
         *
         * Amazon SQS and Amazon SNS enforce their own per-message attribute limits on delivery.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-snsparameters.html#cfn-eventsv2-subscriber-snsparameters-messageattributes
         */
        readonly messageAttributes?: cdk.IResolvable | Record<string, cdk.IResolvable | CfnSubscriberPropsMixin.MessageAttributeValueProperty>;
        /**
         * The message deduplication ID to use when the target is a FIFO topic.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-snsparameters.html#cfn-eventsv2-subscriber-snsparameters-messagededuplicationid
         */
        readonly messageDeduplicationId?: string;
        /**
         * The message group ID to use when the target is a FIFO topic.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-snsparameters.html#cfn-eventsv2-subscriber-snsparameters-messagegroupid
         */
        readonly messageGroupId?: string;
        /**
         * Set to json to send a different message per delivery protocol.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-snsparameters.html#cfn-eventsv2-subscriber-snsparameters-messagestructure
         */
        readonly messageStructure?: string;
        /**
         * The subject line to use for email-protocol subscriptions.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-snsparameters.html#cfn-eventsv2-subscriber-snsparameters-subject
         */
        readonly subject?: string;
    }
    /**
     * Parameters for writing events to an Amazon Kinesis Data Streams target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-kinesisparameters.html
     */
    interface KinesisParametersProperty {
        /**
         * An explicit hash key that overrides the partition key's shard assignment.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-kinesisparameters.html#cfn-eventsv2-subscriber-kinesisparameters-explicithashkey
         */
        readonly explicitHashKey?: string;
        /**
         * The partition key that determines which shard each record is written to.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-kinesisparameters.html#cfn-eventsv2-subscriber-kinesisparameters-partitionkey
         */
        readonly partitionKey?: string;
    }
    /**
     * Parameters for starting an AWS Step Functions state machine execution target.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-stepfunctionsparameters.html
     */
    interface StepFunctionsParametersProperty {
        /**
         * The timeout in seconds for each invocation of the target, written as a string.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-stepfunctionsparameters.html#cfn-eventsv2-subscriber-stepfunctionsparameters-invocationtimeoutseconds
         */
        readonly invocationTimeoutSeconds?: string;
        /**
         * How the execution is started: EVENT (StartExecution, asynchronous) or REQUEST_RESPONSE (StartSyncExecution, synchronous).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-stepfunctionsparameters.html#cfn-eventsv2-subscriber-stepfunctionsparameters-invocationtype
         */
        readonly invocationType?: string;
        /**
         * A name for the execution.
         *
         * Must be unique for the account, Region, and state machine. Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-stepfunctionsparameters.html#cfn-eventsv2-subscriber-stepfunctionsparameters-name
         */
        readonly name?: string;
        /**
         * The AWS X-Ray trace header for distributed tracing.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-stepfunctionsparameters.html#cfn-eventsv2-subscriber-stepfunctionsparameters-traceheader
         */
        readonly traceHeader?: string;
    }
    /**
     * Parameters for invoking an HTTP endpoint target, such as an Amazon API Gateway endpoint or an EventBridge API destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-httpparameters.html
     */
    interface HttpParametersProperty {
        /**
         * A map of HTTP header names to values.
         *
         * A header name or value may also be a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-httpparameters.html#cfn-eventsv2-subscriber-httpparameters-headerparameters
         */
        readonly headerParameters?: cdk.IResolvable | Record<string, string>;
        /**
         * The timeout in seconds for each invocation of the target, written as a string.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-httpparameters.html#cfn-eventsv2-subscriber-httpparameters-invocationtimeoutseconds
         */
        readonly invocationTimeoutSeconds?: string;
        /**
         * Values for the path parameters (wildcards) in the target URL, in order.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-httpparameters.html#cfn-eventsv2-subscriber-httpparameters-pathparametervalues
         */
        readonly pathParameterValues?: Array<string>;
        /**
         * A map of query string parameter names to values.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-httpparameters.html#cfn-eventsv2-subscriber-httpparameters-querystringparameters
         */
        readonly queryStringParameters?: cdk.IResolvable | Record<string, string>;
    }
    /**
     * Parameters for invoking an AWS service API as a universal service integration target, used when TargetArn has the form arn:{partition}:events:::aws-sdk:{service}:{apiAction}.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-universaltargetparameters.html
     */
    interface UniversalTargetParametersProperty {
        /**
         * JSON string or JSONata expression that produces the API request.
         *
         * Supports {% ... %} JSONata expressions for dynamic values from the event.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-universaltargetparameters.html#cfn-eventsv2-subscriber-universaltargetparameters-input
         */
        readonly input?: string;
        /**
         * Timeout in seconds for each invocation of the target (1-30, default 30).
         *
         * Must be a literal integer written as a string; JSONata expressions are not supported for this field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-universaltargetparameters.html#cfn-eventsv2-subscriber-universaltargetparameters-invocationtimeoutseconds
         */
        readonly invocationTimeoutSeconds?: string;
    }
    /**
     * Parameters for forwarding events to another EventBridge event bus, used when TargetArn is an event bus ARN of the form arn:{partition}:events:{region}:{account}:event-busv2/{name}/{id}.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2parameters.html
     */
    interface EventBusV2ParametersProperty {
        /**
         * Deduplication settings applied to the forwarded events on the downstream bus.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2parameters.html#cfn-eventsv2-subscriber-eventbusv2parameters-deduplicationconfiguration
         */
        readonly deduplicationConfiguration?: CfnSubscriberPropsMixin.DeduplicationConfigurationProperty | cdk.IResolvable;
        /**
         * Metadata forwarded with each event, as key-value string pairs, with at most 100 entries.
         *
         * A key or value may also be a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2parameters.html#cfn-eventsv2-subscriber-eventbusv2parameters-metadata
         */
        readonly metadata?: cdk.IResolvable | Record<string, string>;
        /**
         * Customer-controllable system metadata attached to each forwarded event.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2parameters.html#cfn-eventsv2-subscriber-eventbusv2parameters-systemmetadata
         */
        readonly systemMetadata?: CfnSubscriberPropsMixin.EventBusV2SystemMetadataProperty | cdk.IResolvable;
    }
    /**
     * Customer-controllable system metadata attached to each forwarded event.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2systemmetadata.html
     */
    interface EventBusV2SystemMetadataProperty {
        /**
         * The deduplication ID for FIFO deduplication on the downstream event bus.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2systemmetadata.html#cfn-eventsv2-subscriber-eventbusv2systemmetadata-deduplicationid
         */
        readonly deduplicationId?: string;
        /**
         * The event group ID for FIFO ordering on the downstream event bus.
         *
         * Accepts a literal value or a JSONata expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-eventbusv2systemmetadata.html#cfn-eventsv2-subscriber-eventbusv2systemmetadata-eventgroupid
         */
        readonly eventGroupId?: string;
    }
    /**
     * Deduplication settings applied to the forwarded events on the downstream bus.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-deduplicationconfiguration.html
     */
    interface DeduplicationConfigurationProperty {
        /**
         * How duplicate events are detected: CONTENT_BASED deduplicates by a hash of the event content.
         *
         * To deduplicate by a caller-supplied token instead, omit DeduplicationConfiguration and set SystemMetadata.DeduplicationId.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-deduplicationconfiguration.html#cfn-eventsv2-subscriber-deduplicationconfiguration-deduplicationtype
         */
        readonly deduplicationType?: string;
    }
    /**
     * Configuration for filtering which events are delivered to the target.
     *
     * An event must match every filter to be delivered.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-filterconfiguration.html
     */
    interface FilterConfigurationProperty {
        /**
         * The list of filters, 1-50 entries.
         *
         * An event must match every filter to be delivered.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-filterconfiguration.html#cfn-eventsv2-subscriber-filterconfiguration-filters
         */
        readonly filters?: Array<CfnSubscriberPropsMixin.FilterProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The filter language.
         *
         * The default is EVENT_BRIDGE_PATTERN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-filterconfiguration.html#cfn-eventsv2-subscriber-filterconfiguration-language
         */
        readonly language?: string;
    }
    /**
     * A single filter entry: an event pattern and the scope of the event it is evaluated against.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-filter.html
     */
    interface FilterProperty {
        /**
         * The event pattern, as a JSON string.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-filter.html#cfn-eventsv2-subscriber-filter-pattern
         */
        readonly pattern?: string;
        /**
         * Which part of the event the pattern is evaluated against: DATA (the event payload), METADATA (event metadata), or SYSTEM_METADATA (service-generated metadata).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-filter.html#cfn-eventsv2-subscriber-filter-scope
         */
        readonly scope?: string;
    }
    /**
     * The point in time to start delivering events from, used when StartingPosition is POINT_IN_TIME.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-pointintimeconfiguration.html
     */
    interface PointInTimeConfigurationProperty {
        /**
         * An optional time to stop delivering events at, in seconds since the Unix epoch.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-pointintimeconfiguration.html#cfn-eventsv2-subscriber-pointintimeconfiguration-endpoint
         */
        readonly endPoint?: number;
        /**
         * Where to start: HORIZON starts from the earliest available event;
         *
         * TIMESTAMP starts from the StartingPoint timestamp.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-pointintimeconfiguration.html#cfn-eventsv2-subscriber-pointintimeconfiguration-pointtype
         */
        readonly pointType?: string;
        /**
         * The time to start delivering events from, in seconds since the Unix epoch.
         *
         * Required when PointType is TIMESTAMP.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-pointintimeconfiguration.html#cfn-eventsv2-subscriber-pointintimeconfiguration-startingpoint
         */
        readonly startingPoint?: number;
    }
    /**
     * Configuration for batching events into a single delivery.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-batchconfiguration.html
     */
    interface BatchConfigurationProperty {
        /**
         * The maximum number of events in a single batch delivered to the target.
         *
         * The maximum depends on the target: 500 for Kinesis Data Streams and Amazon Data Firehose, 100 for Lambda, Step Functions, and AWS::EventsV2::EventBus targets, 10 for Amazon SQS, Amazon SNS, and AWS::Events::EventBus targets, and 1 for API Gateway, API destinations, and universal service integration targets. The service rejects a value above the target's maximum. Fewer events may be delivered when the batch window elapses. When omitted, the default is 10 for Lambda and Step Functions targets and the target's maximum for other targets. The resolved value applied by the service is returned on read.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-batchconfiguration.html#cfn-eventsv2-subscriber-batchconfiguration-maxbatchsize
         */
        readonly maxBatchSize?: number;
        /**
         * The maximum time in seconds to wait for a batch to fill before delivering it, 0-300.
         *
         * The default is 0 (no wait). The resolved value applied by the service is returned on read.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-batchconfiguration.html#cfn-eventsv2-subscriber-batchconfiguration-maxbatchwindowinseconds
         */
        readonly maxBatchWindowInSeconds?: number;
    }
    /**
     * Configuration for transforming events before delivery: the raw payload, the payload with its metadata envelope, or the output of a JSONata expression.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-transformer.html
     */
    interface TransformerProperty {
        /**
         * JSONata transform settings.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-transformer.html#cfn-eventsv2-subscriber-transformer-jsonataconfiguration
         */
        readonly jsonataConfiguration?: cdk.IResolvable | CfnSubscriberPropsMixin.JsonataConfigurationProperty;
        /**
         * The transform type: RAW delivers the event payload only;
         *
         * WITH_METADATA delivers the event with its metadata envelope; JSONATA delivers the output of the JSONata expression in JsonataConfiguration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-transformer.html#cfn-eventsv2-subscriber-transformer-type
         */
        readonly type?: string;
    }
    /**
     * JSONata transform settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-jsonataconfiguration.html
     */
    interface JsonataConfigurationProperty {
        /**
         * The JSONata expression that transforms the event, enclosed in {% %} delimiters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-jsonataconfiguration.html#cfn-eventsv2-subscriber-jsonataconfiguration-expression
         */
        readonly expression?: string;
    }
    /**
     * The retry policy for failed deliveries.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-retrypolicy.html
     */
    interface RetryPolicyProperty {
        /**
         * The maximum age of an event in seconds, 60-86400 (24 hours).
         *
         * When an event reaches this age, retries stop; if OnFailureConfiguration is set, the event is delivered to that destination, otherwise it is dropped. The default is 300.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-retrypolicy.html#cfn-eventsv2-subscriber-retrypolicy-maxeventageinseconds
         */
        readonly maxEventAgeInSeconds?: number;
        /**
         * The maximum number of retry attempts, 0-185.
         *
         * When the attempts are exhausted, retries stop; if OnFailureConfiguration is set, the event is delivered to that destination, otherwise it is dropped. The default is 5.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-retrypolicy.html#cfn-eventsv2-subscriber-retrypolicy-maxretryattempts
         */
        readonly maxRetryAttempts?: number;
        /**
         * Which errors are retried.
         *
         * ALL retries all errors. The default is ALL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-retrypolicy.html#cfn-eventsv2-subscriber-retrypolicy-retrystrategy
         */
        readonly retryStrategy?: string;
    }
    /**
     * The destination for events that could not be delivered.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-onfailureconfiguration.html
     */
    interface OnFailureConfigurationProperty {
        /**
         * The ARN of the destination that receives events that could not be delivered.
         *
         * An Amazon SQS queue is the supported destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-onfailureconfiguration.html#cfn-eventsv2-subscriber-onfailureconfiguration-arn
         */
        readonly arn?: string;
    }
    /**
     * Delivery logging configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-logconfiguration.html
     */
    interface LogConfigurationProperty {
        /**
         * Whether the event payload is included in emitted log records: FULL includes it in every emitted record, and ON_ERROR_ONLY includes it only in error records.
         *
         * The default is ON_ERROR_ONLY.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-logconfiguration.html#cfn-eventsv2-subscriber-logconfiguration-includepayload
         */
        readonly includePayload?: string;
        /**
         * The minimum log level: OFF (no logging), ERROR, or INFO.
         *
         * Records below this level are not emitted. The default is OFF.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-eventsv2-subscriber-logconfiguration.html#cfn-eventsv2-subscriber-logconfiguration-level
         */
        readonly level?: string;
    }
}
/**
 * Properties for CfnSubscriberPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html
 */
export interface CfnSubscriberMixinProps {
    /**
     * Configuration for batching events into a single delivery.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-batchconfiguration
     */
    readonly batchConfiguration?: CfnSubscriberPropsMixin.BatchConfigurationProperty | cdk.IResolvable;
    /**
     * A description of the subscriber.
     *
     * Control characters and Unicode line separators are not allowed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-description
     */
    readonly description?: string;
    /**
     * The ARN of the event bus this subscriber belongs to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-eventbusarn
     */
    readonly eventBusArn?: string;
    /**
     * Configuration for filtering which events are delivered to the target.
     *
     * An event must match every filter to be delivered.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-filterconfiguration
     */
    readonly filterConfiguration?: CfnSubscriberPropsMixin.FilterConfigurationProperty | cdk.IResolvable;
    /**
     * Configuration for how the subscriber invokes its target.
     *
     * Specify the target ARN, the IAM role, and, optionally, the target-specific parameters object that matches the target type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-invokeconfiguration
     */
    readonly invokeConfiguration?: CfnSubscriberPropsMixin.InvokeConfigurationProperty | cdk.IResolvable;
    /**
     * Delivery logging configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-logconfiguration
     */
    readonly logConfiguration?: cdk.IResolvable | CfnSubscriberPropsMixin.LogConfigurationProperty;
    /**
     * The name of the subscriber.
     *
     * The first character must be alphanumeric; the remaining characters may also include '.', '-', and '_'.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-name
     */
    readonly name?: string;
    /**
     * The destination for events that could not be delivered.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-onfailureconfiguration
     */
    readonly onFailureConfiguration?: cdk.IResolvable | CfnSubscriberPropsMixin.OnFailureConfigurationProperty;
    /**
     * The point in time to start delivering events from, used when StartingPosition is POINT_IN_TIME.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-pointintimeconfiguration
     */
    readonly pointInTimeConfiguration?: cdk.IResolvable | CfnSubscriberPropsMixin.PointInTimeConfigurationProperty;
    /**
     * Resume-time control, never returned by the service.
     *
     * Applied only when an update transitions State from STOPPED to RUNNING: LAST_PROCESSED (default) resumes from the last processed event, LATEST skips to the newest. Ignored on create and on any update that does not perform that transition.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-resumeposition
     */
    readonly resumePosition?: string;
    /**
     * The retry policy for failed deliveries.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-retrypolicy
     */
    readonly retryPolicy?: cdk.IResolvable | CfnSubscriberPropsMixin.RetryPolicyProperty;
    /**
     * Where the subscriber starts reading events: LATEST starts from the newest events;
     *
     * POINT_IN_TIME starts from the point specified in PointInTimeConfiguration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-startingposition
     */
    readonly startingPosition?: string;
    /**
     * The run state of the subscriber.
     *
     * Events are delivered only while the state is RUNNING. Setting the state to STOPPED pauses delivery. When an update sets a stopped subscriber back to RUNNING, ResumePosition controls where delivery resumes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-state
     */
    readonly state?: string;
    /**
     * The tags assigned to the subscriber.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Configuration for transforming events before delivery: the raw payload, the payload with its metadata envelope, or the output of a JSONata expression.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-transformer
     */
    readonly transformer?: cdk.IResolvable | CfnSubscriberPropsMixin.TransformerProperty;
    /**
     * The delivery ordering mode of the subscriber.
     *
     * FIFO delivers events in order within an event group; UNORDERED delivers without an ordering guarantee.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-eventsv2-subscriber.html#cfn-eventsv2-subscriber-type
     */
    readonly type?: string;
}
