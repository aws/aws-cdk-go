import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-devopsagent";
/**
 * The `AWS::DevOpsAgent::AgentSpace` resource specifies an Agent Space for the AWS DevOps Agent Service.
 *
 * @cloudformationResource AWS::DevOpsAgent::AgentSpace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html
 */
export declare class CfnAgentSpacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAgentSpaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DevOpsAgent::AgentSpace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAgentSpaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgentSpace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAgentSpacePropsMixin {
    /**
     * Preferences that configure behavior of this AgentSpace.
     *
     * This container fully owns the AgentSpace preferences: the properties supplied here replace the stored preferences in their entirety, and omitting the Preferences container reverts all preferences to their service defaults.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-preferences.html
     */
    interface PreferencesProperty {
        /**
         * Indicates whether elevated directed actions are permitted in this AgentSpace.
         *
         * Defaults to false when not set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-preferences.html#cfn-devopsagent-agentspace-preferences-elevatedactionsenabled
         */
        readonly elevatedActionsEnabled?: boolean | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-operatorapp.html
     */
    interface OperatorAppProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-operatorapp.html#cfn-devopsagent-agentspace-operatorapp-iam
         */
        readonly iam?: CfnAgentSpacePropsMixin.IamAuthConfigurationProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-operatorapp.html#cfn-devopsagent-agentspace-operatorapp-idc
         */
        readonly idc?: CfnAgentSpacePropsMixin.IdcAuthConfigurationProperty | cdk.IResolvable;
        /**
         * External identity provider configuration for the Operator App.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-operatorapp.html#cfn-devopsagent-agentspace-operatorapp-idp
         */
        readonly idp?: CfnAgentSpacePropsMixin.IdpAuthConfigurationProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-iamauthconfiguration.html
     */
    interface IamAuthConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-iamauthconfiguration.html#cfn-devopsagent-agentspace-iamauthconfiguration-createdat
         */
        readonly createdAt?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-iamauthconfiguration.html#cfn-devopsagent-agentspace-iamauthconfiguration-operatorapprolearn
         */
        readonly operatorAppRoleArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-iamauthconfiguration.html#cfn-devopsagent-agentspace-iamauthconfiguration-updatedat
         */
        readonly updatedAt?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idcauthconfiguration.html
     */
    interface IdcAuthConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idcauthconfiguration.html#cfn-devopsagent-agentspace-idcauthconfiguration-createdat
         */
        readonly createdAt?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idcauthconfiguration.html#cfn-devopsagent-agentspace-idcauthconfiguration-idcapplicationarn
         */
        readonly idcApplicationArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idcauthconfiguration.html#cfn-devopsagent-agentspace-idcauthconfiguration-idcinstancearn
         */
        readonly idcInstanceArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idcauthconfiguration.html#cfn-devopsagent-agentspace-idcauthconfiguration-operatorapprolearn
         */
        readonly operatorAppRoleArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idcauthconfiguration.html#cfn-devopsagent-agentspace-idcauthconfiguration-updatedat
         */
        readonly updatedAt?: string;
    }
    /**
     * External identity provider configuration for the Operator App.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html
     */
    interface IdpAuthConfigurationProperty {
        /**
         * The OIDC client identifier for the external identity provider application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-clientid
         */
        readonly clientId?: string;
        /**
         * The OIDC client secret for the external identity provider application.
         *
         * Use a Secrets Manager dynamic reference to avoid storing the secret in the template.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-clientsecret
         */
        readonly clientSecret?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-createdat
         */
        readonly createdAt?: string;
        /**
         * The OIDC issuer URL for the external identity provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-issuerurl
         */
        readonly issuerUrl?: string;
        /**
         * The IAM role that Operator App users assume to access DevOps Agent APIs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-operatorapprolearn
         */
        readonly operatorAppRoleArn?: string;
        /**
         * The external identity provider type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-provider
         */
        readonly provider?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-updatedat
         */
        readonly updatedAt?: string;
        /**
         * The identity claim used to identify users.
         *
         * This value is selected by the service for the configured provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-agentspace-idpauthconfiguration.html#cfn-devopsagent-agentspace-idpauthconfiguration-useridclaim
         */
        readonly userIdClaim?: string;
    }
}
/**
 * Properties for CfnAgentSpacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html
 */
export interface CfnAgentSpaceMixinProps {
    /**
     * The description of the Agent Space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-description
     */
    readonly description?: string;
    /**
     * The ARN of the KMS key to use for encryption.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-kmskeyarn
     */
    readonly kmsKeyArn?: string;
    /**
     * The locale for the AgentSpace, which determines the language used in agent responses.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-locale
     */
    readonly locale?: string;
    /**
     * The name of the Agent Space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-operatorapp
     */
    readonly operatorApp?: cdk.IResolvable | CfnAgentSpacePropsMixin.OperatorAppProperty;
    /**
     * Preferences that configure behavior of this AgentSpace.
     *
     * This container fully owns the AgentSpace preferences: the properties supplied here replace the stored preferences in their entirety, and omitting the Preferences container reverts all preferences to their service defaults.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-preferences
     */
    readonly preferences?: cdk.IResolvable | CfnAgentSpacePropsMixin.PreferencesProperty;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-agentspace.html#cfn-devopsagent-agentspace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::DevOpsAgent::Asset.
 *
 * An asset attached to an existing AWS DevOps Agent Space. Customer-creatable types include skill, agents_md, and attachment; call ListAssetTypes for the current authoritative set.
 *
 * @cloudformationResource AWS::DevOpsAgent::Asset
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html
 */
export declare class CfnAssetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAssetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DevOpsAgent::Asset`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAssetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAsset;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAssetPropsMixin {
    /**
     * A single file inside an Asset's bundle.
     *
     * Path is the diff key on update; Content is write-only and not repopulated by Read.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-asset-assetfile.html
     */
    interface AssetFileProperty {
        /**
         * Base64-encoded binary contents of the file.
         *
         * Mutually exclusive with ContentText (max 6 MiB).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-asset-assetfile.html#cfn-devopsagent-asset-assetfile-contentbytes
         */
        readonly contentBytes?: string;
        /**
         * UTF-8 text contents of the file.
         *
         * Mutually exclusive with ContentBytes (max 1.5 MiB).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-asset-assetfile.html#cfn-devopsagent-asset-assetfile-contenttext
         */
        readonly contentText?: string;
        /**
         * Per-file metadata document.
         *
         * Values may be strings, numbers, booleans, or lists of any of those (validated server-side).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-asset-assetfile.html#cfn-devopsagent-asset-assetfile-metadata
         */
        readonly metadata?: any | cdk.IResolvable;
        /**
         * Path of this file within the asset bundle.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-asset-assetfile.html#cfn-devopsagent-asset-assetfile-path
         */
        readonly path?: string;
    }
}
/**
 * Properties for CfnAssetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html
 */
export interface CfnAssetMixinProps {
    /**
     * The unique identifier of the parent Agent Space.
     *
     * The asset is created as a child of this agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html#cfn-devopsagent-asset-agentspaceid
     */
    readonly agentSpaceId?: string;
    /**
     * The type of asset.
     *
     * The Asset API treats this as an open string; call ListAssetTypes for the current authoritative set of supported types. As of launch, customer-creatable types include skill, agents_md, and attachment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html#cfn-devopsagent-asset-assettype
     */
    readonly assetType?: string;
    /**
     * Inline file list.
     *
     * Mutually exclusive with Zip; enforced by the handler at Create/Update time. Write-only: not repopulated by Read.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html#cfn-devopsagent-asset-files
     */
    readonly files?: Array<CfnAssetPropsMixin.AssetFileProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Asset metadata document.
     *
     * Required and optional keys depend on AssetType. Values may be strings, numbers, booleans, or lists of any of those - validated server-side; see the public Asset API docs for the per-type metadata schema.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html#cfn-devopsagent-asset-metadata
     */
    readonly metadata?: any | cdk.IResolvable;
    /**
     * Base64-encoded zip bundle containing all files for the asset.
     *
     * Mutually exclusive with Files; enforced by the handler at Create/Update time. Write-only: not repopulated by Read. Server treats a zip as 'replace all files' (max 6 MiB).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-asset.html#cfn-devopsagent-asset-zip
     */
    readonly zip?: string;
}
/**
 * The `AWS::DevOpsAgent::Association` resource specifies an association between an Agent Space and a service, defining how the Agent Space interacts with external services like GitHub, Slack, AWS accounts, and others.
 *
 * @cloudformationResource AWS::DevOpsAgent::Association
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html
 */
export declare class CfnAssociationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAssociationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DevOpsAgent::Association`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAssociationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAssociation;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAssociationPropsMixin {
    /**
     * The configuration that directs how Agent Space interacts with the given service.
     *
     * You can specify only one configuration type per association.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html
     */
    interface ServiceConfigurationProperty {
        /**
         * Configuration for AWS monitor account integration.
         *
         * Specifies the account ID, assumable role ARN, and resources to be monitored in the primary monitoring account.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-aws
         */
        readonly aws?: CfnAssociationPropsMixin.AWSConfigurationProperty | cdk.IResolvable;
        /**
         * Azure subscription integration configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-azure
         */
        readonly azure?: CfnAssociationPropsMixin.AzureConfigurationProperty | cdk.IResolvable;
        /**
         * Configuration for Dynatrace monitoring integration.
         *
         * Specifies the environment ID, resources to monitor, and webhook settings to enable the Agent Space to access Dynatrace metrics, traces, and logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-dynatrace
         */
        readonly dynatrace?: CfnAssociationPropsMixin.DynatraceConfigurationProperty | cdk.IResolvable;
        /**
         * Configuration for Event Channel integration.
         *
         * Specifies webhook settings to enable the Agent Space to receive and process real-time events from external systems.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-eventchannel
         */
        readonly eventChannel?: CfnAssociationPropsMixin.EventChannelConfigurationProperty | cdk.IResolvable;
        /**
         * Configuration for GitHub repository integration.
         *
         * Specifies the repository name, repository ID, owner, and owner type to enable the Agent Space to access code, pull requests, and issues.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-github
         */
        readonly gitHub?: CfnAssociationPropsMixin.GitHubConfigurationProperty | cdk.IResolvable;
        /**
         * Configuration for GitLab project integration.
         *
         * Specifies the project ID, project path, instance identifier, and webhook settings to enable the Agent Space to access code, merge requests, and issues.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-gitlab
         */
        readonly gitLab?: CfnAssociationPropsMixin.GitLabConfigurationProperty | cdk.IResolvable;
        /**
         * Configuration for custom MCP (Model Context Protocol) server integration.
         *
         * Specifies the server name, endpoint URL, available tools, description, and webhook settings to enable the Agent Space to interact with custom MCP servers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-mcpserver
         */
        readonly mcpServer?: cdk.IResolvable | CfnAssociationPropsMixin.MCPServerConfigurationProperty;
        /**
         * Configuration for Datadog MCP server integration.
         *
         * Specifies the server name, endpoint URL, optional description, and webhook settings to enable the Agent Space to query metrics, traces, and logs from Datadog.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-mcpserverdatadog
         */
        readonly mcpServerDatadog?: cdk.IResolvable | CfnAssociationPropsMixin.MCPServerDatadogConfigurationProperty;
        /**
         * Grafana MCP server configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-mcpservergrafana
         */
        readonly mcpServerGrafana?: cdk.IResolvable | CfnAssociationPropsMixin.MCPServerGrafanaConfigurationProperty;
        /**
         * Configuration for New Relic MCP server integration.
         *
         * Specifies the New Relic account ID and MCP endpoint URL to enable the Agent Space to query metrics, traces, and logs from New Relic.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-mcpservernewrelic
         */
        readonly mcpServerNewRelic?: cdk.IResolvable | CfnAssociationPropsMixin.MCPServerNewRelicConfigurationProperty;
        /**
         * SigV4-authenticated MCP server configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-mcpserversigv4
         */
        readonly mcpServerSigV4?: cdk.IResolvable | CfnAssociationPropsMixin.MCPServerSigV4ConfigurationProperty;
        /**
         * Configuration for Splunk MCP server integration.
         *
         * Specifies the server name, endpoint URL, optional description, and webhook settings to enable the Agent Space to query logs, metrics, and events from Splunk.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-mcpserversplunk
         */
        readonly mcpServerSplunk?: cdk.IResolvable | CfnAssociationPropsMixin.MCPServerSplunkConfigurationProperty;
        /**
         * PagerDuty integration configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-pagerduty
         */
        readonly pagerDuty?: cdk.IResolvable | CfnAssociationPropsMixin.PagerDutyConfigurationProperty;
        /**
         * Configuration for a release management environment.
         *
         * A release management environment defines how AWS DevOps Agent reaches your application, and other associations reference it to run automatic verification testing against that application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-releasemanagement
         */
        readonly releaseManagement?: cdk.IResolvable | CfnAssociationPropsMixin.ReleaseManagementConfigurationProperty;
        /**
         * Configuration for ServiceNow instance integration.
         *
         * Specifies the instance URL, instance ID, and webhook settings to enable the Agent Space to create, update, and manage ServiceNow incidents and change requests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-servicenow
         */
        readonly serviceNow?: cdk.IResolvable | CfnAssociationPropsMixin.ServiceNowConfigurationProperty;
        /**
         * Configuration for Slack workspace integration.
         *
         * Specifies the workspace ID, workspace name, and transmission targets to enable the Agent Space to send notifications to designated Slack channels.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-slack
         */
        readonly slack?: cdk.IResolvable | CfnAssociationPropsMixin.SlackConfigurationProperty;
        /**
         * Configuration for AWS source account integration.
         *
         * Specifies the account ID, assumable role ARN, and resources to be monitored in the source account.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-serviceconfiguration.html#cfn-devopsagent-association-serviceconfiguration-sourceaws
         */
        readonly sourceAws?: cdk.IResolvable | CfnAssociationPropsMixin.SourceAwsConfigurationProperty;
    }
    /**
     * Configuration for AWS source account integration.
     *
     * Specifies the account ID, assumable role ARN, and resources to be monitored in the source account.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html
     */
    interface SourceAwsConfigurationProperty {
        /**
         * Account ID corresponding to the provided resources.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html#cfn-devopsagent-association-sourceawsconfiguration-accountid
         */
        readonly accountId?: string;
        /**
         * Account Type 'source' for AWS DevOps Agent monitoring.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html#cfn-devopsagent-association-sourceawsconfiguration-accounttype
         */
        readonly accountType?: string;
        /**
         * The IAM role that AWS DevOps Agent assumes to perform elevated directed actions in this AWS account.
         *
         * Elevated actions also require ElevatedActionsEnabled to be set in the Preferences of the AgentSpace. When not provided, only non-elevated directed actions are available. Removing this property from the template clears the role on update. Setting this role is subject to the same iam:PassRole requirement as AssumableRoleArn.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html#cfn-devopsagent-association-sourceawsconfiguration-agentelevatedrolearn
         */
        readonly agentElevatedRoleArn?: string;
        /**
         * Role ARN to be assumed by AWS DevOps Agent to operate on behalf of customer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html#cfn-devopsagent-association-sourceawsconfiguration-assumablerolearn
         */
        readonly assumableRoleArn?: string;
        /**
         * List of resources to monitor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html#cfn-devopsagent-association-sourceawsconfiguration-resources
         */
        readonly resources?: Array<CfnAssociationPropsMixin.AWSResourceProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of tags as key-value pairs, used to identify resources for topology crawl.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-sourceawsconfiguration.html#cfn-devopsagent-association-sourceawsconfiguration-tags
         */
        readonly tags?: Array<CfnAssociationPropsMixin.KeyValuePairProperty>;
    }
    /**
     * Defines an AWS resource to be monitored, including its type, ARN, and optional metadata.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsresource.html
     */
    interface AWSResourceProperty {
        /**
         * The Amazon Resource Name (ARN) of the resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsresource.html#cfn-devopsagent-association-awsresource-resourcearn
         */
        readonly resourceArn?: string;
        /**
         * Additional metadata specific to the resource.
         *
         * This is an optional JSON object that can include resource-specific information to provide additional context for monitoring and management.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsresource.html#cfn-devopsagent-association-awsresource-resourcemetadata
         */
        readonly resourceMetadata?: any | cdk.IResolvable;
        /**
         * Resource type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsresource.html#cfn-devopsagent-association-awsresource-resourcetype
         */
        readonly resourceType?: string;
    }
    /**
     * A key-value pair for tags.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-keyvaluepair.html
     */
    interface KeyValuePairProperty {
        /**
         * The key name of the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-keyvaluepair.html#cfn-devopsagent-association-keyvaluepair-key
         */
        readonly key?: string;
        /**
         * The value for the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-keyvaluepair.html#cfn-devopsagent-association-keyvaluepair-value
         */
        readonly value?: string;
    }
    /**
     * Configuration for AWS monitor account integration.
     *
     * Specifies the account ID, assumable role ARN, and resources to be monitored in the primary monitoring account.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html
     */
    interface AWSConfigurationProperty {
        /**
         * Account ID corresponding to the provided resources.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html#cfn-devopsagent-association-awsconfiguration-accountid
         */
        readonly accountId?: string;
        /**
         * Account Type 'monitor' for AWS DevOps Agent monitoring.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html#cfn-devopsagent-association-awsconfiguration-accounttype
         */
        readonly accountType?: string;
        /**
         * The IAM role that AWS DevOps Agent assumes to perform elevated directed actions in this AWS account.
         *
         * Elevated actions also require ElevatedActionsEnabled to be set in the Preferences of the AgentSpace. When not provided, only non-elevated directed actions are available. Removing this property from the template clears the role on update. Setting this role is subject to the same iam:PassRole requirement as AssumableRoleArn.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html#cfn-devopsagent-association-awsconfiguration-agentelevatedrolearn
         */
        readonly agentElevatedRoleArn?: string;
        /**
         * Role ARN used by AWS DevOps Agent to access resources in the primary account.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html#cfn-devopsagent-association-awsconfiguration-assumablerolearn
         */
        readonly assumableRoleArn?: string;
        /**
         * List of resources to monitor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html#cfn-devopsagent-association-awsconfiguration-resources
         */
        readonly resources?: Array<CfnAssociationPropsMixin.AWSResourceProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of tags as key-value pairs, used to identify resources for topology crawl.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-awsconfiguration.html#cfn-devopsagent-association-awsconfiguration-tags
         */
        readonly tags?: Array<CfnAssociationPropsMixin.KeyValuePairProperty>;
    }
    /**
     * Configuration for GitHub repository integration.
     *
     * Defines the repository name, numeric repository ID, owner name, and owner type (user or organization) required for the Agent Space to access and interact with the GitHub repository.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-githubconfiguration.html
     */
    interface GitHubConfigurationProperty {
        /**
         * Repository owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-githubconfiguration.html#cfn-devopsagent-association-githubconfiguration-owner
         */
        readonly owner?: string;
        /**
         * Type of repository owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-githubconfiguration.html#cfn-devopsagent-association-githubconfiguration-ownertype
         */
        readonly ownerType?: string;
        /**
         * Associated Github repo ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-githubconfiguration.html#cfn-devopsagent-association-githubconfiguration-repoid
         */
        readonly repoId?: string;
        /**
         * Associated Github repo name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-githubconfiguration.html#cfn-devopsagent-association-githubconfiguration-reponame
         */
        readonly repoName?: string;
    }
    /**
     * Configuration for Slack workspace integration.
     *
     * Defines the workspace ID, workspace name, and transmission targets that specify which Slack channels receive notifications.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackconfiguration.html
     */
    interface SlackConfigurationProperty {
        /**
         * Optional bidirectional communication configuration.
         *
         * Supply this configuration and set Enabled to true so you can interact with the agent directly from Slack
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackconfiguration.html#cfn-devopsagent-association-slackconfiguration-bidirectional
         */
        readonly bidirectional?: cdk.IResolvable | CfnAssociationPropsMixin.SlackBidirectionalConfigurationProperty;
        /**
         * Transmission targets for agent notifications.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackconfiguration.html#cfn-devopsagent-association-slackconfiguration-transmissiontarget
         */
        readonly transmissionTarget?: cdk.IResolvable | CfnAssociationPropsMixin.SlackTransmissionTargetProperty;
        /**
         * Associated Slack workspace ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackconfiguration.html#cfn-devopsagent-association-slackconfiguration-workspaceid
         */
        readonly workspaceId?: string;
        /**
         * Associated Slack workspace name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackconfiguration.html#cfn-devopsagent-association-slackconfiguration-workspacename
         */
        readonly workspaceName?: string;
    }
    /**
     * Defines the Slack channels where different types of agent notifications will be sent.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slacktransmissiontarget.html
     */
    interface SlackTransmissionTargetProperty {
        /**
         * Destination for AWS DevOps Agent Incident Response.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slacktransmissiontarget.html#cfn-devopsagent-association-slacktransmissiontarget-incidentresponsetarget
         */
        readonly incidentResponseTarget?: cdk.IResolvable | CfnAssociationPropsMixin.SlackChannelProperty;
    }
    /**
     * Represents a Slack channel with its unique identifier and optional display name.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackchannel.html
     */
    interface SlackChannelProperty {
        /**
         * Slack channel ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackchannel.html#cfn-devopsagent-association-slackchannel-channelid
         */
        readonly channelId?: string;
        /**
         * Slack channel name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackchannel.html#cfn-devopsagent-association-slackchannel-channelname
         */
        readonly channelName?: string;
    }
    /**
     * Optional bidirectional communication configuration.
     *
     * Supply this configuration and set Enabled to true so you can interact with the agent directly from Slack
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackbidirectionalconfiguration.html
     */
    interface SlackBidirectionalConfigurationProperty {
        /**
         * Whether bidirectional communication is enabled for this association.
         *
         * When set to true, you can mention the agent in a configured Slack channel and it responds in that channel. When omitted or set to false, the agent ignores mentions and only sends notifications
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackbidirectionalconfiguration.html#cfn-devopsagent-association-slackbidirectionalconfiguration-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * IAM role ARN that AWS DevOps Agent assumes to exchange messages with your Slack workspace on behalf of this association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-slackbidirectionalconfiguration.html#cfn-devopsagent-association-slackbidirectionalconfiguration-rolearn
         */
        readonly roleArn?: string;
    }
    /**
     * Configuration for Dynatrace monitoring integration.
     *
     * Defines the Dynatrace environment ID, list of resources to monitor, and webhook update settings required for the Agent Space to access metrics, traces, and logs from Dynatrace.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-dynatraceconfiguration.html
     */
    interface DynatraceConfigurationProperty {
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-dynatraceconfiguration.html#cfn-devopsagent-association-dynatraceconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * Dynatrace environment id.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-dynatraceconfiguration.html#cfn-devopsagent-association-dynatraceconfiguration-envid
         */
        readonly envId?: string;
        /**
         * List of Dynatrace resources to monitor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-dynatraceconfiguration.html#cfn-devopsagent-association-dynatraceconfiguration-resources
         */
        readonly resources?: Array<string>;
    }
    /**
     * Configuration for ServiceNow integration.
     *
     * Defines the ServiceNow instance URL, instance ID, and webhook update settings required for the Agent Space to create, update, and manage incidents and change requests.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-servicenowconfiguration.html
     */
    interface ServiceNowConfigurationProperty {
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-servicenowconfiguration.html#cfn-devopsagent-association-servicenowconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * ServiceNow instance ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-servicenowconfiguration.html#cfn-devopsagent-association-servicenowconfiguration-instanceid
         */
        readonly instanceId?: string;
    }
    /**
     * Configuration for MCP (Model Context Protocol) server integration.
     *
     * Defines the server name, endpoint URL, available tools, optional description, and webhook update settings for custom MCP servers.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverconfiguration.html
     */
    interface MCPServerConfigurationProperty {
        /**
         * The description of the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverconfiguration.html#cfn-devopsagent-association-mcpserverconfiguration-description
         */
        readonly description?: string;
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverconfiguration.html#cfn-devopsagent-association-mcpserverconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverconfiguration.html#cfn-devopsagent-association-mcpserverconfiguration-endpoint
         */
        readonly endpoint?: string;
        /**
         * The name of the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverconfiguration.html#cfn-devopsagent-association-mcpserverconfiguration-name
         */
        readonly name?: string;
        /**
         * List of MCP tools that can be used with the association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverconfiguration.html#cfn-devopsagent-association-mcpserverconfiguration-tools
         */
        readonly tools?: Array<string>;
    }
    /**
     * Configuration for GitLab project integration.
     *
     * Defines the numeric project ID, full project path (namespace/project-name), GitLab instance identifier, and webhook update settings required for the Agent Space to access and interact with the GitLab project.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-gitlabconfiguration.html
     */
    interface GitLabConfigurationProperty {
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-gitlabconfiguration.html#cfn-devopsagent-association-gitlabconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * GitLab instance identifier (e.g., gitlab.com).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-gitlabconfiguration.html#cfn-devopsagent-association-gitlabconfiguration-instanceidentifier
         */
        readonly instanceIdentifier?: string;
        /**
         * GitLab numeric project ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-gitlabconfiguration.html#cfn-devopsagent-association-gitlabconfiguration-projectid
         */
        readonly projectId?: string;
        /**
         * Full GitLab project path (e.g., namespace/project-name).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-gitlabconfiguration.html#cfn-devopsagent-association-gitlabconfiguration-projectpath
         */
        readonly projectPath?: string;
    }
    /**
     * Configuration for Datadog MCP server integration.
     *
     * Defines the server name, endpoint URL, optional description, and webhook update settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverdatadogconfiguration.html
     */
    interface MCPServerDatadogConfigurationProperty {
        /**
         * The description of the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverdatadogconfiguration.html#cfn-devopsagent-association-mcpserverdatadogconfiguration-description
         */
        readonly description?: string;
        /**
         * The mutative MCP tools enabled for this integration, by tool name.
         *
         * Only tools the service classifies as MUTATIVE may be listed; other names are rejected. Tool names can be found in the console or from the association's current configuration. The list fully replaces the stored value on update: removing a name disables that tool, and removing the property disables all elevated tools.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverdatadogconfiguration.html#cfn-devopsagent-association-mcpserverdatadogconfiguration-enabledelevatedtools
         */
        readonly enabledElevatedTools?: Array<string>;
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverdatadogconfiguration.html#cfn-devopsagent-association-mcpserverdatadogconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverdatadogconfiguration.html#cfn-devopsagent-association-mcpserverdatadogconfiguration-endpoint
         */
        readonly endpoint?: string;
        /**
         * The name of the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserverdatadogconfiguration.html#cfn-devopsagent-association-mcpserverdatadogconfiguration-name
         */
        readonly name?: string;
    }
    /**
     * Configuration for Splunk MCP server integration.
     *
     * Defines the server name, endpoint URL, optional description, and webhook update settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversplunkconfiguration.html
     */
    interface MCPServerSplunkConfigurationProperty {
        /**
         * The description of the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversplunkconfiguration.html#cfn-devopsagent-association-mcpserversplunkconfiguration-description
         */
        readonly description?: string;
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversplunkconfiguration.html#cfn-devopsagent-association-mcpserversplunkconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversplunkconfiguration.html#cfn-devopsagent-association-mcpserversplunkconfiguration-endpoint
         */
        readonly endpoint?: string;
        /**
         * The name of the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversplunkconfiguration.html#cfn-devopsagent-association-mcpserversplunkconfiguration-name
         */
        readonly name?: string;
    }
    /**
     * Configuration for New Relic MCP server integration.
     *
     * Defines the New Relic account ID and MCP server endpoint URL required for the Agent Space to authenticate and query observability data from New Relic.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservernewrelicconfiguration.html
     */
    interface MCPServerNewRelicConfigurationProperty {
        /**
         * New Relic Account ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservernewrelicconfiguration.html#cfn-devopsagent-association-mcpservernewrelicconfiguration-accountid
         */
        readonly accountId?: string;
        /**
         * MCP server endpoint URL (e.g., https://mcp.newrelic.com/mcp/).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservernewrelicconfiguration.html#cfn-devopsagent-association-mcpservernewrelicconfiguration-endpoint
         */
        readonly endpoint?: string;
    }
    /**
     * Grafana MCP server configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservergrafanaconfiguration.html
     */
    interface MCPServerGrafanaConfigurationProperty {
        /**
         * The mutative MCP tools enabled for this integration, by tool name.
         *
         * Only tools the service classifies as MUTATIVE may be listed; other names are rejected. Tool names can be found in the console or from the association's current configuration. The list fully replaces the stored value on update: removing a name disables that tool, and removing the property disables all elevated tools. Independent of Tools, which selects the toolsets available to the agent.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservergrafanaconfiguration.html#cfn-devopsagent-association-mcpservergrafanaconfiguration-enabledelevatedtools
         */
        readonly enabledElevatedTools?: Array<string>;
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservergrafanaconfiguration.html#cfn-devopsagent-association-mcpservergrafanaconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservergrafanaconfiguration.html#cfn-devopsagent-association-mcpservergrafanaconfiguration-endpoint
         */
        readonly endpoint?: string;
        /**
         * List of tool categories to enable for the Grafana MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpservergrafanaconfiguration.html#cfn-devopsagent-association-mcpservergrafanaconfiguration-tools
         */
        readonly tools?: Array<string>;
    }
    /**
     * PagerDuty integration configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-pagerdutyconfiguration.html
     */
    interface PagerDutyConfigurationProperty {
        /**
         * Email to be used in PagerDuty API header.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-pagerdutyconfiguration.html#cfn-devopsagent-association-pagerdutyconfiguration-customeremail
         */
        readonly customerEmail?: string;
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-pagerdutyconfiguration.html#cfn-devopsagent-association-pagerdutyconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
        /**
         * List of PagerDuty service IDs available for the association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-pagerdutyconfiguration.html#cfn-devopsagent-association-pagerdutyconfiguration-services
         */
        readonly services?: Array<string>;
    }
    /**
     * Configuration for Event Channel integration.
     *
     * Defines webhook update settings to enable the Agent Space to receive real-time event notifications from event channel integrations.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-eventchannelconfiguration.html
     */
    interface EventChannelConfigurationProperty {
        /**
         * When set to true, enables the Agent Space to create and update webhooks for receiving notifications and events from the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-eventchannelconfiguration.html#cfn-devopsagent-association-eventchannelconfiguration-enablewebhookupdates
         */
        readonly enableWebhookUpdates?: boolean | cdk.IResolvable;
    }
    /**
     * Azure subscription integration configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-azureconfiguration.html
     */
    interface AzureConfigurationProperty {
        /**
         * Azure subscription ID corresponding to provided resources.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-azureconfiguration.html#cfn-devopsagent-association-azureconfiguration-subscriptionid
         */
        readonly subscriptionId?: string;
    }
    /**
     * SigV4-authenticated MCP server configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversigv4configuration.html
     */
    interface MCPServerSigV4ConfigurationProperty {
        /**
         * List of MCP tools available for the association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-mcpserversigv4configuration.html#cfn-devopsagent-association-mcpserversigv4configuration-tools
         */
        readonly tools?: Array<string>;
    }
    /**
     * Configuration for a release management environment.
     *
     * A release management environment defines how AWS DevOps Agent reaches your application, and other associations reference it to run automatic verification testing against that application.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-releasemanagementconfiguration.html
     */
    interface ReleaseManagementConfigurationProperty {
        /**
         * The name for this release management environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-releasemanagementconfiguration.html#cfn-devopsagent-association-releasemanagementconfiguration-name
         */
        readonly name?: string;
        /**
         * Specifies how AWS DevOps Agent reaches your application using a release management environment.
         *
         * Exactly one access type must be specified.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-releasemanagementconfiguration.html#cfn-devopsagent-association-releasemanagementconfiguration-networkaccess
         */
        readonly networkAccess?: cdk.IResolvable | CfnAssociationPropsMixin.NetworkAccessConfigurationProperty;
    }
    /**
     * Specifies how AWS DevOps Agent reaches your application using a release management environment.
     *
     * Exactly one access type must be specified.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-networkaccessconfiguration.html
     */
    interface NetworkAccessConfigurationProperty {
        /**
         * Private network access to your application inside a VPC, reached through a private connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-networkaccessconfiguration.html#cfn-devopsagent-association-networkaccessconfiguration-privateaccess
         */
        readonly privateAccess?: cdk.IResolvable | CfnAssociationPropsMixin.PrivateNetworkAccessProperty;
    }
    /**
     * Private network access to your application inside a VPC, reached through a private connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-privatenetworkaccess.html
     */
    interface PrivateNetworkAccessProperty {
        /**
         * Name of the private connection that supplies the VPC configuration for this release management environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-privatenetworkaccess.html#cfn-devopsagent-association-privatenetworkaccess-privateconnectionname
         */
        readonly privateConnectionName?: string;
        /**
         * Role ARN that AWS DevOps Agent assumes at runtime to connect to your VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-privatenetworkaccess.html#cfn-devopsagent-association-privatenetworkaccess-runtimerolearn
         */
        readonly runtimeRoleArn?: string;
    }
    /**
     * Automated AWS DevOps Agent capabilities for the repository in this association.
     *
     * Code change risk analysis analyzes pull requests and merge requests for deployment risk, and automated testing extends that analysis by running tests against the change. Capabilities are supported for GitHub and GitLab associations. When this property is set, it fully defines both capabilities below: a capability omitted here is removed from the association. Removing this property from a template that previously set it disables both capabilities. Capabilities configured outside CloudFormation are left unchanged only while this property has never been set. On rollback, both capabilities are restored to the previous template's values, not to settings made outside CloudFormation. Other capabilities on the association are not affected. Updates read and rewrite the association's full capability set, so a capability change made outside CloudFormation while a stack update is in progress may be overwritten.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-capabilities.html
     */
    interface CapabilitiesProperty {
        /**
         * Configuration of a single capability.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-capabilities.html#cfn-devopsagent-association-capabilities-codechangeriskanalysis
         */
        readonly codeChangeRiskAnalysis?: CfnAssociationPropsMixin.CapabilityConfigurationProperty | cdk.IResolvable;
        /**
         * Configuration of the code change risk analysis automated testing capability.
         *
         * This capability does not support trigger filter groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-capabilities.html#cfn-devopsagent-association-capabilities-codechangeriskanalysisautomatedtesting
         */
        readonly codeChangeRiskAnalysisAutomatedTesting?: CfnAssociationPropsMixin.AutomatedTestingCapabilityConfigurationProperty | cdk.IResolvable;
    }
    /**
     * Configuration of a single capability.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-capabilityconfiguration.html
     */
    interface CapabilityConfigurationProperty {
        /**
         * Whether the capability is enabled for this association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-capabilityconfiguration.html#cfn-devopsagent-association-capabilityconfiguration-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * Filter groups controlling when the capability triggers automatically.
         *
         * The capability triggers when any group matches. When omitted, all applicable events trigger the capability. Retained while the capability is disabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-capabilityconfiguration.html#cfn-devopsagent-association-capabilityconfiguration-triggerfiltergroups
         */
        readonly triggerFilterGroups?: Array<cdk.IResolvable | CfnAssociationPropsMixin.TriggerFilterGroupProperty> | cdk.IResolvable;
    }
    /**
     * A group of trigger conditions.
     *
     * The group matches when all present conditions pass. At least one condition must be present.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-triggerfiltergroup.html
     */
    interface TriggerFilterGroupProperty {
        /**
         * Passes when the webhook event is one of the listed events.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-triggerfiltergroup.html#cfn-devopsagent-association-triggerfiltergroup-events
         */
        readonly events?: Array<string>;
        /**
         * A regex-based match condition.
         *
         * Passes when the value matches any pattern.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-triggerfiltergroup.html#cfn-devopsagent-association-triggerfiltergroup-targetbranches
         */
        readonly targetBranches?: cdk.IResolvable | CfnAssociationPropsMixin.PatternFilterProperty;
    }
    /**
     * A regex-based match condition.
     *
     * Passes when the value matches any pattern.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-patternfilter.html
     */
    interface PatternFilterProperty {
        /**
         * Anchored full-match regex patterns, for example 'main' or 'release/.*'.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-patternfilter.html#cfn-devopsagent-association-patternfilter-patterns
         */
        readonly patterns?: Array<string>;
    }
    /**
     * Configuration of the code change risk analysis automated testing capability.
     *
     * This capability does not support trigger filter groups.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-automatedtestingcapabilityconfiguration.html
     */
    interface AutomatedTestingCapabilityConfigurationProperty {
        /**
         * Whether the capability is enabled for this association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-association-automatedtestingcapabilityconfiguration.html#cfn-devopsagent-association-automatedtestingcapabilityconfiguration-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnAssociationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html
 */
export interface CfnAssociationMixinProps {
    /**
     * The unique identifier of the Agent Space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html#cfn-devopsagent-association-agentspaceid
     */
    readonly agentSpaceId?: string;
    /**
     * Automated AWS DevOps Agent capabilities for the repository in this association.
     *
     * Code change risk analysis analyzes pull requests and merge requests for deployment risk, and automated testing extends that analysis by running tests against the change. Capabilities are supported for GitHub and GitLab associations. When this property is set, it fully defines both capabilities below: a capability omitted here is removed from the association. Removing this property from a template that previously set it disables both capabilities. Capabilities configured outside CloudFormation are left unchanged only while this property has never been set. On rollback, both capabilities are restored to the previous template's values, not to settings made outside CloudFormation. Other capabilities on the association are not affected. Updates read and rewrite the association's full capability set, so a capability change made outside CloudFormation while a stack update is in progress may be overwritten.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html#cfn-devopsagent-association-capabilities
     */
    readonly capabilities?: CfnAssociationPropsMixin.CapabilitiesProperty | cdk.IResolvable;
    /**
     * The configuration that directs how the Agent Space interacts with the given service.
     *
     * You can specify only one configuration type per association.
     *
     * *Allowed Values* : `SourceAws` | `Aws` | `GitHub` | `GitLab` | `Slack` | `Dynatrace` | `ServiceNow` | `MCPServer` | `MCPServerNewRelic` | `MCPServerDatadog` | `MCPServerSplunk` | `EventChannel`
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html#cfn-devopsagent-association-configuration
     */
    readonly configuration?: cdk.IResolvable | CfnAssociationPropsMixin.ServiceConfigurationProperty;
    /**
     * Set of linked association IDs for parent-child relationships.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html#cfn-devopsagent-association-linkedassociationids
     */
    readonly linkedAssociationIds?: Array<string>;
    /**
     * The identifier for the associated service.
     *
     * For `SourceAws` and `Aws` configurations, this must be `aws` . For all other service types, this is a UUID generated from the RegisterService command.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-association.html#cfn-devopsagent-association-serviceid
     */
    readonly serviceId?: string;
}
/**
 * Resource Type definition for AWS::DevOpsAgent::PrivateConnection.
 *
 * @cloudformationResource AWS::DevOpsAgent::PrivateConnection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-privateconnection.html
 */
export declare class CfnPrivateConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPrivateConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DevOpsAgent::PrivateConnection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPrivateConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPrivateConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPrivateConnectionPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-connectionconfiguration.html
     */
    interface ConnectionConfigurationProperty {
        /**
         * Configuration for a self-managed Private Connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-connectionconfiguration.html#cfn-devopsagent-privateconnection-connectionconfiguration-selfmanaged
         */
        readonly selfManaged?: cdk.IResolvable | CfnPrivateConnectionPropsMixin.SelfManagedModeProperty;
        /**
         * Configuration for a service-managed Private Connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-connectionconfiguration.html#cfn-devopsagent-privateconnection-connectionconfiguration-servicemanaged
         */
        readonly serviceManaged?: cdk.IResolvable | CfnPrivateConnectionPropsMixin.ServiceManagedModeProperty;
    }
    /**
     * Configuration for a self-managed Private Connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-selfmanagedmode.html
     */
    interface SelfManagedModeProperty {
        /**
         * The ARN of the Resource Configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-selfmanagedmode.html#cfn-devopsagent-privateconnection-selfmanagedmode-resourceconfigurationid
         */
        readonly resourceConfigurationId?: string;
    }
    /**
     * Configuration for a service-managed Private Connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html
     */
    interface ServiceManagedModeProperty {
        /**
         * DNS resolution mode for the resource gateway.
         *
         * Defaults to PUBLIC when not set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-dnsresolution
         */
        readonly dnsResolution?: string;
        /**
         * IP address or DNS name of the target resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-hostaddress
         */
        readonly hostAddress?: string;
        /**
         * IP address type of the service-managed Resource Gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-ipaddresstype
         */
        readonly ipAddressType?: string;
        /**
         * Number of IPv4 addresses in each ENI for the service-managed Resource Gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-ipv4addressespereni
         */
        readonly ipv4AddressesPerEni?: number;
        /**
         * TCP port ranges that a consumer can use to access the resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-portranges
         */
        readonly portRanges?: Array<string>;
        /**
         * Security groups to attach to the service-managed Resource Gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-securitygroupids
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * Subnets that the service-managed Resource Gateway will span.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-subnetids
         */
        readonly subnetIds?: Array<string>;
        /**
         * VPC to create the service-managed Resource Gateway in.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-privateconnection-servicemanagedmode.html#cfn-devopsagent-privateconnection-servicemanagedmode-vpcid
         */
        readonly vpcId?: string;
    }
}
/**
 * Properties for CfnPrivateConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-privateconnection.html
 */
export interface CfnPrivateConnectionMixinProps {
    /**
     * Certificate for the Private Connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-privateconnection.html#cfn-devopsagent-privateconnection-certificate
     */
    readonly certificate?: string;
    /**
     * The connection configuration, either SelfManaged or ServiceManaged.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-privateconnection.html#cfn-devopsagent-privateconnection-connectionconfiguration
     */
    readonly connectionConfiguration?: CfnPrivateConnectionPropsMixin.ConnectionConfigurationProperty | cdk.IResolvable;
    /**
     * Unique name for this Private Connection within the account.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-privateconnection.html#cfn-devopsagent-privateconnection-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-privateconnection.html#cfn-devopsagent-privateconnection-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * The AWS::DevOpsAgent::Service resource registers external services (like Dynatrace, MCP servers, GitLab) for integration with DevOpsAgent.
 *
 * @cloudformationResource AWS::DevOpsAgent::Service
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html
 */
export declare class CfnServicePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnServiceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DevOpsAgent::Service`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnServiceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnService;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnServicePropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html
     */
    interface ServiceDetailsProperty {
        /**
         * Azure Identity service configuration for federated identity.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-azureidentity
         */
        readonly azureIdentity?: CfnServicePropsMixin.AzureIdentityServiceDetailsProperty | cdk.IResolvable;
        /**
         * Dynatrace service configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-dynatrace
         */
        readonly dynatrace?: CfnServicePropsMixin.DynatraceServiceDetailsProperty | cdk.IResolvable;
        /**
         * GitHub personal access token (PAT) service configuration.
         *
         * Exactly one of AppVerification or DirectAccess selects how the token is used
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-github
         */
        readonly gitHub?: CfnServicePropsMixin.GitHubDetailsProperty | cdk.IResolvable;
        /**
         * GitLab service configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-gitlab
         */
        readonly gitLab?: CfnServicePropsMixin.GitLabDetailsProperty | cdk.IResolvable;
        /**
         * MCP server configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-mcpserver
         */
        readonly mcpServer?: cdk.IResolvable | CfnServicePropsMixin.MCPServerDetailsProperty;
        /**
         * Grafana MCP server configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-mcpservergrafana
         */
        readonly mcpServerGrafana?: cdk.IResolvable | CfnServicePropsMixin.MCPServerGrafanaDetailsProperty;
        /**
         * New Relic service configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-mcpservernewrelic
         */
        readonly mcpServerNewRelic?: cdk.IResolvable | CfnServicePropsMixin.NewRelicServiceDetailsProperty;
        /**
         * SigV4-authenticated MCP server configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-mcpserversigv4
         */
        readonly mcpServerSigV4?: cdk.IResolvable | CfnServicePropsMixin.MCPServerSigV4DetailsProperty;
        /**
         * Splunk MCP server configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-mcpserversplunk
         */
        readonly mcpServerSplunk?: cdk.IResolvable | CfnServicePropsMixin.MCPServerSplunkDetailsProperty;
        /**
         * PagerDuty service configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-pagerduty
         */
        readonly pagerDuty?: cdk.IResolvable | CfnServicePropsMixin.PagerDutyDetailsProperty;
        /**
         * ServiceNow service configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicedetails.html#cfn-devopsagent-service-servicedetails-servicenow
         */
        readonly serviceNow?: cdk.IResolvable | CfnServicePropsMixin.ServiceNowServiceDetailsProperty;
    }
    /**
     * Dynatrace service configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-dynatraceservicedetails.html
     */
    interface DynatraceServiceDetailsProperty {
        /**
         * Dynatrace resource account URN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-dynatraceservicedetails.html#cfn-devopsagent-service-dynatraceservicedetails-accounturn
         */
        readonly accountUrn?: string;
        /**
         * Dynatrace OAuth authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-dynatraceservicedetails.html#cfn-devopsagent-service-dynatraceservicedetails-authorizationconfig
         */
        readonly authorizationConfig?: CfnServicePropsMixin.DynatraceAuthorizationConfigProperty | cdk.IResolvable;
    }
    /**
     * Dynatrace OAuth authorization configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-dynatraceauthorizationconfig.html
     */
    interface DynatraceAuthorizationConfigProperty {
        /**
         * OAuth client credentials.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-dynatraceauthorizationconfig.html#cfn-devopsagent-service-dynatraceauthorizationconfig-oauthclientcredentials
         */
        readonly oAuthClientCredentials?: cdk.IResolvable | CfnServicePropsMixin.OAuthClientDetailsProperty;
    }
    /**
     * OAuth client credentials.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-oauthclientdetails.html
     */
    interface OAuthClientDetailsProperty {
        /**
         * OAuth client ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-oauthclientdetails.html#cfn-devopsagent-service-oauthclientdetails-clientid
         */
        readonly clientId?: string;
        /**
         * User friendly OAuth client name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-oauthclientdetails.html#cfn-devopsagent-service-oauthclientdetails-clientname
         */
        readonly clientName?: string;
        /**
         * OAuth client secret.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-oauthclientdetails.html#cfn-devopsagent-service-oauthclientdetails-clientsecret
         */
        readonly clientSecret?: string;
        /**
         * OAuth token exchange parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-oauthclientdetails.html#cfn-devopsagent-service-oauthclientdetails-exchangeparameters
         */
        readonly exchangeParameters?: any | cdk.IResolvable;
    }
    /**
     * MCP server configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverdetails.html
     */
    interface MCPServerDetailsProperty {
        /**
         * MCP server authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverdetails.html#cfn-devopsagent-service-mcpserverdetails-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.MCPServerAuthorizationConfigProperty;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverdetails.html#cfn-devopsagent-service-mcpserverdetails-description
         */
        readonly description?: string;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverdetails.html#cfn-devopsagent-service-mcpserverdetails-endpoint
         */
        readonly endpoint?: string;
        /**
         * MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverdetails.html#cfn-devopsagent-service-mcpserverdetails-name
         */
        readonly name?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverauthorizationconfig.html
     */
    interface MCPServerAuthorizationConfigProperty {
        /**
         * API key authentication details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverauthorizationconfig.html#cfn-devopsagent-service-mcpserverauthorizationconfig-apikey
         */
        readonly apiKey?: CfnServicePropsMixin.ApiKeyDetailsProperty | cdk.IResolvable;
        /**
         * Bearer token authentication details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverauthorizationconfig.html#cfn-devopsagent-service-mcpserverauthorizationconfig-bearertoken
         */
        readonly bearerToken?: CfnServicePropsMixin.BearerTokenDetailsProperty | cdk.IResolvable;
        /**
         * MCP server OAuth client credentials configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserverauthorizationconfig.html#cfn-devopsagent-service-mcpserverauthorizationconfig-oauthclientcredentials
         */
        readonly oAuthClientCredentials?: cdk.IResolvable | CfnServicePropsMixin.MCPServerOAuthClientCredentialsConfigProperty;
    }
    /**
     * MCP server OAuth client credentials configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html
     */
    interface MCPServerOAuthClientCredentialsConfigProperty {
        /**
         * OAuth client ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html#cfn-devopsagent-service-mcpserveroauthclientcredentialsconfig-clientid
         */
        readonly clientId?: string;
        /**
         * User friendly OAuth client name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html#cfn-devopsagent-service-mcpserveroauthclientcredentialsconfig-clientname
         */
        readonly clientName?: string;
        /**
         * OAuth client secret.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html#cfn-devopsagent-service-mcpserveroauthclientcredentialsconfig-clientsecret
         */
        readonly clientSecret?: string;
        /**
         * OAuth token exchange parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html#cfn-devopsagent-service-mcpserveroauthclientcredentialsconfig-exchangeparameters
         */
        readonly exchangeParameters?: any | cdk.IResolvable;
        /**
         * OAuth token exchange URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html#cfn-devopsagent-service-mcpserveroauthclientcredentialsconfig-exchangeurl
         */
        readonly exchangeUrl?: string;
        /**
         * OAuth scopes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserveroauthclientcredentialsconfig.html#cfn-devopsagent-service-mcpserveroauthclientcredentialsconfig-scopes
         */
        readonly scopes?: Array<string>;
    }
    /**
     * API key authentication details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-apikeydetails.html
     */
    interface ApiKeyDetailsProperty {
        /**
         * HTTP header name to send the API key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-apikeydetails.html#cfn-devopsagent-service-apikeydetails-apikeyheader
         */
        readonly apiKeyHeader?: string;
        /**
         * User friendly API key name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-apikeydetails.html#cfn-devopsagent-service-apikeydetails-apikeyname
         */
        readonly apiKeyName?: string;
        /**
         * API key value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-apikeydetails.html#cfn-devopsagent-service-apikeydetails-apikeyvalue
         */
        readonly apiKeyValue?: string;
    }
    /**
     * Bearer token authentication details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-bearertokendetails.html
     */
    interface BearerTokenDetailsProperty {
        /**
         * HTTP header name to send the bearer token.
         *
         * @default - "Authorization"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-bearertokendetails.html#cfn-devopsagent-service-bearertokendetails-authorizationheader
         */
        readonly authorizationHeader?: string;
        /**
         * User friendly bearer token name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-bearertokendetails.html#cfn-devopsagent-service-bearertokendetails-tokenname
         */
        readonly tokenName?: string;
        /**
         * Bearer token value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-bearertokendetails.html#cfn-devopsagent-service-bearertokendetails-tokenvalue
         */
        readonly tokenValue?: string;
    }
    /**
     * Splunk MCP server configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkdetails.html
     */
    interface MCPServerSplunkDetailsProperty {
        /**
         * MCP server splunk authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkdetails.html#cfn-devopsagent-service-mcpserversplunkdetails-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.MCPServerSplunkAuthorizationConfigProperty;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkdetails.html#cfn-devopsagent-service-mcpserversplunkdetails-description
         */
        readonly description?: string;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkdetails.html#cfn-devopsagent-service-mcpserversplunkdetails-endpoint
         */
        readonly endpoint?: string;
        /**
         * MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkdetails.html#cfn-devopsagent-service-mcpserversplunkdetails-name
         */
        readonly name?: string;
    }
    /**
     * MCP server splunk authorization configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkauthorizationconfig.html
     */
    interface MCPServerSplunkAuthorizationConfigProperty {
        /**
         * Bearer token authentication details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversplunkauthorizationconfig.html#cfn-devopsagent-service-mcpserversplunkauthorizationconfig-bearertoken
         */
        readonly bearerToken?: CfnServicePropsMixin.BearerTokenDetailsProperty | cdk.IResolvable;
    }
    /**
     * New Relic service configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicservicedetails.html
     */
    interface NewRelicServiceDetailsProperty {
        /**
         * New Relic authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicservicedetails.html#cfn-devopsagent-service-newrelicservicedetails-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.NewRelicAuthorizationConfigProperty;
    }
    /**
     * New Relic authorization configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicauthorizationconfig.html
     */
    interface NewRelicAuthorizationConfigProperty {
        /**
         * New Relic API key configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicauthorizationconfig.html#cfn-devopsagent-service-newrelicauthorizationconfig-apikey
         */
        readonly apiKey?: cdk.IResolvable | CfnServicePropsMixin.NewRelicApiKeyConfigProperty;
    }
    /**
     * New Relic API key configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html
     */
    interface NewRelicApiKeyConfigProperty {
        /**
         * New Relic Account ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html#cfn-devopsagent-service-newrelicapikeyconfig-accountid
         */
        readonly accountId?: string;
        /**
         * List of alert policy IDs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html#cfn-devopsagent-service-newrelicapikeyconfig-alertpolicyids
         */
        readonly alertPolicyIds?: Array<string>;
        /**
         * New Relic User API Key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html#cfn-devopsagent-service-newrelicapikeyconfig-apikey
         */
        readonly apiKey?: string;
        /**
         * List of monitored APM application IDs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html#cfn-devopsagent-service-newrelicapikeyconfig-applicationids
         */
        readonly applicationIds?: Array<string>;
        /**
         * List of globally unique IDs for New Relic resources.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html#cfn-devopsagent-service-newrelicapikeyconfig-entityguids
         */
        readonly entityGuids?: Array<string>;
        /**
         * New Relic region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-newrelicapikeyconfig.html#cfn-devopsagent-service-newrelicapikeyconfig-region
         */
        readonly region?: string;
    }
    /**
     * GitLab service configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-gitlabdetails.html
     */
    interface GitLabDetailsProperty {
        /**
         * Optional GitLab group ID for group-level access tokens.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-gitlabdetails.html#cfn-devopsagent-service-gitlabdetails-groupid
         */
        readonly groupId?: string;
        /**
         * GitLab instance URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-gitlabdetails.html#cfn-devopsagent-service-gitlabdetails-targeturl
         */
        readonly targetUrl?: string;
        /**
         * Type of GitLab access token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-gitlabdetails.html#cfn-devopsagent-service-gitlabdetails-tokentype
         */
        readonly tokenType?: string;
        /**
         * GitLab access token value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-gitlabdetails.html#cfn-devopsagent-service-gitlabdetails-tokenvalue
         */
        readonly tokenValue?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubdetails.html
     */
    interface GitHubDetailsProperty {
        /**
         * The token verifies an existing DevOps Agent GitHub App installation on github.com and is then discarded. Not supported for GitHub Enterprise Server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubdetails.html#cfn-devopsagent-service-githubdetails-appverification
         */
        readonly appVerification?: CfnServicePropsMixin.GitHubAppVerificationDetailsProperty | cdk.IResolvable;
        /**
         * The token is stored and used as the long-lived credential for GitHub API access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubdetails.html#cfn-devopsagent-service-githubdetails-directaccess
         */
        readonly directAccess?: CfnServicePropsMixin.GitHubPatDetailsProperty | cdk.IResolvable;
    }
    /**
     * The token verifies an existing DevOps Agent GitHub App installation on github.com and is then discarded. Not supported for GitHub Enterprise Server.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubappverificationdetails.html
     */
    interface GitHubAppVerificationDetailsProperty {
        /**
         * Permission variant of the DevOps Agent GitHub App that must already be installed on the organization or account.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubappverificationdetails.html#cfn-devopsagent-service-githubappverificationdetails-appvariant
         */
        readonly appVariant?: string;
        /**
         * GitHub organization to scope the service to.
         *
         * The token must be an active member of the organization and only that organization's repositories are accessible. Omit to register the token's own user account
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubappverificationdetails.html#cfn-devopsagent-service-githubappverificationdetails-organizationname
         */
        readonly organizationName?: string;
        /**
         * GitHub instance URL.
         *
         * Omit for github.com. Provide the instance host for GitHub Enterprise Server or GitHub Enterprise Cloud with data residency (e.g. https://github.example.com)
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubappverificationdetails.html#cfn-devopsagent-service-githubappverificationdetails-targeturl
         */
        readonly targetUrl?: string;
        /**
         * GitHub personal access token (PAT) value.
         *
         * Accepts classic PATs (ghp_...), fine-grained PATs (github_pat_...), and GitHub Enterprise Server token formats
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubappverificationdetails.html#cfn-devopsagent-service-githubappverificationdetails-tokenvalue
         */
        readonly tokenValue?: string;
    }
    /**
     * The token is stored and used as the long-lived credential for GitHub API access.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubpatdetails.html
     */
    interface GitHubPatDetailsProperty {
        /**
         * GitHub organization to scope the service to.
         *
         * The token must be an active member of the organization and only that organization's repositories are accessible. Omit to register the token's own user account
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubpatdetails.html#cfn-devopsagent-service-githubpatdetails-organizationname
         */
        readonly organizationName?: string;
        /**
         * GitHub instance URL.
         *
         * Omit for github.com. Provide the instance host for GitHub Enterprise Server or GitHub Enterprise Cloud with data residency (e.g. https://github.example.com)
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubpatdetails.html#cfn-devopsagent-service-githubpatdetails-targeturl
         */
        readonly targetUrl?: string;
        /**
         * GitHub personal access token (PAT) value.
         *
         * Accepts classic PATs (ghp_...), fine-grained PATs (github_pat_...), and GitHub Enterprise Server token formats
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-githubpatdetails.html#cfn-devopsagent-service-githubpatdetails-tokenvalue
         */
        readonly tokenValue?: string;
    }
    /**
     * ServiceNow service configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicenowservicedetails.html
     */
    interface ServiceNowServiceDetailsProperty {
        /**
         * ServiceNow OAuth authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicenowservicedetails.html#cfn-devopsagent-service-servicenowservicedetails-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.ServiceNowAuthorizationConfigProperty;
        /**
         * ServiceNow instance URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicenowservicedetails.html#cfn-devopsagent-service-servicenowservicedetails-instanceurl
         */
        readonly instanceUrl?: string;
    }
    /**
     * ServiceNow OAuth authorization configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicenowauthorizationconfig.html
     */
    interface ServiceNowAuthorizationConfigProperty {
        /**
         * OAuth client credentials.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-servicenowauthorizationconfig.html#cfn-devopsagent-service-servicenowauthorizationconfig-oauthclientcredentials
         */
        readonly oAuthClientCredentials?: cdk.IResolvable | CfnServicePropsMixin.OAuthClientDetailsProperty;
    }
    /**
     * PagerDuty service configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-pagerdutydetails.html
     */
    interface PagerDutyDetailsProperty {
        /**
         * PagerDuty OAuth authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-pagerdutydetails.html#cfn-devopsagent-service-pagerdutydetails-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.PagerDutyAuthorizationConfigProperty;
        /**
         * PagerDuty scopes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-pagerdutydetails.html#cfn-devopsagent-service-pagerdutydetails-scopes
         */
        readonly scopes?: Array<string>;
    }
    /**
     * PagerDuty OAuth authorization configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-pagerdutyauthorizationconfig.html
     */
    interface PagerDutyAuthorizationConfigProperty {
        /**
         * OAuth client credentials.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-pagerdutyauthorizationconfig.html#cfn-devopsagent-service-pagerdutyauthorizationconfig-oauthclientcredentials
         */
        readonly oAuthClientCredentials?: cdk.IResolvable | CfnServicePropsMixin.OAuthClientDetailsProperty;
    }
    /**
     * Azure Identity service configuration for federated identity.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-azureidentityservicedetails.html
     */
    interface AzureIdentityServiceDetailsProperty {
        /**
         * Azure AD application client ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-azureidentityservicedetails.html#cfn-devopsagent-service-azureidentityservicedetails-clientid
         */
        readonly clientId?: string;
        /**
         * Azure AD tenant ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-azureidentityservicedetails.html#cfn-devopsagent-service-azureidentityservicedetails-tenantid
         */
        readonly tenantId?: string;
        /**
         * ARN of the IAM role for web identity token exchange.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-azureidentityservicedetails.html#cfn-devopsagent-service-azureidentityservicedetails-webidentityrolearn
         */
        readonly webIdentityRoleArn?: string;
        /**
         * List of audiences for the web identity token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-azureidentityservicedetails.html#cfn-devopsagent-service-azureidentityservicedetails-webidentitytokenaudiences
         */
        readonly webIdentityTokenAudiences?: Array<string>;
    }
    /**
     * SigV4-authenticated MCP server configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4details.html
     */
    interface MCPServerSigV4DetailsProperty {
        /**
         * SigV4 authorization configuration for MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4details.html#cfn-devopsagent-service-mcpserversigv4details-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.MCPServerSigV4AuthorizationConfigProperty;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4details.html#cfn-devopsagent-service-mcpserversigv4details-description
         */
        readonly description?: string;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4details.html#cfn-devopsagent-service-mcpserversigv4details-endpoint
         */
        readonly endpoint?: string;
        /**
         * MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4details.html#cfn-devopsagent-service-mcpserversigv4details-name
         */
        readonly name?: string;
    }
    /**
     * SigV4 authorization configuration for MCP server.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4authorizationconfig.html
     */
    interface MCPServerSigV4AuthorizationConfigProperty {
        /**
         * Custom headers for the SigV4 MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4authorizationconfig.html#cfn-devopsagent-service-mcpserversigv4authorizationconfig-customheaders
         */
        readonly customHeaders?: cdk.IResolvable | Record<string, string>;
        /**
         * IAM role ARN to assume for SigV4 signing.
         *
         * Optional - when omitted, credentials are resolved at runtime via a monitor account association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4authorizationconfig.html#cfn-devopsagent-service-mcpserversigv4authorizationconfig-mcprolearn
         */
        readonly mcpRoleArn?: string;
        /**
         * AWS region for SigV4 signing.
         *
         * Use '*' for SigV4a multi-region signing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4authorizationconfig.html#cfn-devopsagent-service-mcpserversigv4authorizationconfig-region
         */
        readonly region?: string;
        /**
         * Deprecated - use McpRoleArn instead.
         *
         * IAM role ARN to assume for SigV4 signing. Set to an empty string to remove a previously configured role and make the server role-less (cross-account).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4authorizationconfig.html#cfn-devopsagent-service-mcpserversigv4authorizationconfig-rolearn
         */
        readonly roleArn?: string;
        /**
         * AWS service name for SigV4 signing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpserversigv4authorizationconfig.html#cfn-devopsagent-service-mcpserversigv4authorizationconfig-service
         */
        readonly service?: string;
    }
    /**
     * Grafana MCP server configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanadetails.html
     */
    interface MCPServerGrafanaDetailsProperty {
        /**
         * Grafana MCP server authorization configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanadetails.html#cfn-devopsagent-service-mcpservergrafanadetails-authorizationconfig
         */
        readonly authorizationConfig?: cdk.IResolvable | CfnServicePropsMixin.MCPServerGrafanaAuthorizationConfigProperty;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanadetails.html#cfn-devopsagent-service-mcpservergrafanadetails-description
         */
        readonly description?: string;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanadetails.html#cfn-devopsagent-service-mcpservergrafanadetails-endpoint
         */
        readonly endpoint?: string;
        /**
         * MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanadetails.html#cfn-devopsagent-service-mcpservergrafanadetails-name
         */
        readonly name?: string;
    }
    /**
     * Grafana MCP server authorization configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanaauthorizationconfig.html
     */
    interface MCPServerGrafanaAuthorizationConfigProperty {
        /**
         * Bearer token authentication details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-mcpservergrafanaauthorizationconfig.html#cfn-devopsagent-service-mcpservergrafanaauthorizationconfig-bearertoken
         */
        readonly bearerToken?: CfnServicePropsMixin.BearerTokenDetailsProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html
     */
    interface AdditionalServiceDetailsProperty {
        /**
         * Azure Identity service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-azureidentity
         */
        readonly azureIdentity?: cdk.IResolvable | CfnServicePropsMixin.RegisteredAzureIdentityDetailsProperty;
        /**
         * Dynatrace service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-dynatrace
         */
        readonly dynatrace?: cdk.IResolvable | CfnServicePropsMixin.RegisteredDynatraceDetailsProperty;
        /**
         * GitHub service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-github
         */
        readonly gitHub?: cdk.IResolvable | CfnServicePropsMixin.RegisteredGitHubServiceDetailsProperty;
        /**
         * GitLab service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-gitlab
         */
        readonly gitLab?: cdk.IResolvable | CfnServicePropsMixin.RegisteredGitLabServiceDetailsProperty;
        /**
         * MCP server details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-mcpserver
         */
        readonly mcpServer?: cdk.IResolvable | CfnServicePropsMixin.RegisteredMCPServerDetailsProperty;
        /**
         * Grafana MCP server details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-mcpservergrafana
         */
        readonly mcpServerGrafana?: cdk.IResolvable | CfnServicePropsMixin.RegisteredMCPServerGrafanaDetailsProperty;
        /**
         * New Relic service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-mcpservernewrelic
         */
        readonly mcpServerNewRelic?: cdk.IResolvable | CfnServicePropsMixin.RegisteredNewRelicDetailsProperty;
        /**
         * SigV4-authenticated MCP server details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-mcpserversigv4
         */
        readonly mcpServerSigV4?: cdk.IResolvable | CfnServicePropsMixin.RegisteredMCPServerSigV4DetailsProperty;
        /**
         * MCP server details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-mcpserversplunk
         */
        readonly mcpServerSplunk?: cdk.IResolvable | CfnServicePropsMixin.RegisteredMCPServerDetailsProperty;
        /**
         * PagerDuty service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-pagerduty
         */
        readonly pagerDuty?: cdk.IResolvable | CfnServicePropsMixin.RegisteredPagerDutyDetailsProperty;
        /**
         * ServiceNow service details returned after registration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-additionalservicedetails.html#cfn-devopsagent-service-additionalservicedetails-servicenow
         */
        readonly serviceNow?: cdk.IResolvable | CfnServicePropsMixin.RegisteredServiceNowDetailsProperty;
    }
    /**
     * MCP server details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserverdetails.html
     */
    interface RegisteredMCPServerDetailsProperty {
        /**
         * API key header name if using API key authentication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserverdetails.html#cfn-devopsagent-service-registeredmcpserverdetails-apikeyheader
         */
        readonly apiKeyHeader?: string;
        /**
         * MCP server authorization method.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserverdetails.html#cfn-devopsagent-service-registeredmcpserverdetails-authorizationmethod
         */
        readonly authorizationMethod?: string;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserverdetails.html#cfn-devopsagent-service-registeredmcpserverdetails-description
         */
        readonly description?: string;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserverdetails.html#cfn-devopsagent-service-registeredmcpserverdetails-endpoint
         */
        readonly endpoint?: string;
        /**
         * MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserverdetails.html#cfn-devopsagent-service-registeredmcpserverdetails-name
         */
        readonly name?: string;
    }
    /**
     * GitLab service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgitlabservicedetails.html
     */
    interface RegisteredGitLabServiceDetailsProperty {
        /**
         * Optional GitLab group ID for group-level access tokens.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgitlabservicedetails.html#cfn-devopsagent-service-registeredgitlabservicedetails-groupid
         */
        readonly groupId?: string;
        /**
         * GitLab instance URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgitlabservicedetails.html#cfn-devopsagent-service-registeredgitlabservicedetails-targeturl
         */
        readonly targetUrl?: string;
        /**
         * Type of GitLab access token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgitlabservicedetails.html#cfn-devopsagent-service-registeredgitlabservicedetails-tokentype
         */
        readonly tokenType?: string;
    }
    /**
     * GitHub service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html
     */
    interface RegisteredGitHubServiceDetailsProperty {
        /**
         * The GitHub App variant the service was registered with.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html#cfn-devopsagent-service-registeredgithubservicedetails-appvariant
         */
        readonly appVariant?: string;
        /**
         * How the service authenticates against the GitHub API: app after AppVerification, pat after DirectAccess.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html#cfn-devopsagent-service-registeredgithubservicedetails-authmode
         */
        readonly authMode?: string;
        /**
         * The GitHub hosting type the service was registered with.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html#cfn-devopsagent-service-registeredgithubservicedetails-hostingtype
         */
        readonly hostingType?: string;
        /**
         * The GitHub repository owner name derived from the token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html#cfn-devopsagent-service-registeredgithubservicedetails-owner
         */
        readonly owner?: string;
        /**
         * Type of repository owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html#cfn-devopsagent-service-registeredgithubservicedetails-ownertype
         */
        readonly ownerType?: string;
        /**
         * GitHub instance URL (absent for github.com).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredgithubservicedetails.html#cfn-devopsagent-service-registeredgithubservicedetails-targeturl
         */
        readonly targetUrl?: string;
    }
    /**
     * New Relic service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registerednewrelicdetails.html
     */
    interface RegisteredNewRelicDetailsProperty {
        /**
         * New Relic account ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registerednewrelicdetails.html#cfn-devopsagent-service-registerednewrelicdetails-accountid
         */
        readonly accountId?: string;
        /**
         * Optional user description.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registerednewrelicdetails.html#cfn-devopsagent-service-registerednewrelicdetails-description
         */
        readonly description?: string;
        /**
         * New Relic region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registerednewrelicdetails.html#cfn-devopsagent-service-registerednewrelicdetails-region
         */
        readonly region?: string;
    }
    /**
     * Dynatrace service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registereddynatracedetails.html
     */
    interface RegisteredDynatraceDetailsProperty {
        /**
         * Dynatrace resource account URN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registereddynatracedetails.html#cfn-devopsagent-service-registereddynatracedetails-accounturn
         */
        readonly accountUrn?: string;
    }
    /**
     * ServiceNow service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredservicenowdetails.html
     */
    interface RegisteredServiceNowDetailsProperty {
        /**
         * ServiceNow instance URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredservicenowdetails.html#cfn-devopsagent-service-registeredservicenowdetails-instanceurl
         */
        readonly instanceUrl?: string;
    }
    /**
     * PagerDuty service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredpagerdutydetails.html
     */
    interface RegisteredPagerDutyDetailsProperty {
        /**
         * The scopes assigned to the service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredpagerdutydetails.html#cfn-devopsagent-service-registeredpagerdutydetails-scopes
         */
        readonly scopes?: Array<string>;
    }
    /**
     * Azure Identity service details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredazureidentitydetails.html
     */
    interface RegisteredAzureIdentityDetailsProperty {
        /**
         * Azure AD application client ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredazureidentitydetails.html#cfn-devopsagent-service-registeredazureidentitydetails-clientid
         */
        readonly clientId?: string;
        /**
         * Azure AD tenant ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredazureidentitydetails.html#cfn-devopsagent-service-registeredazureidentitydetails-tenantid
         */
        readonly tenantId?: string;
        /**
         * ARN of the IAM role for web identity token exchange.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredazureidentitydetails.html#cfn-devopsagent-service-registeredazureidentitydetails-webidentityrolearn
         */
        readonly webIdentityRoleArn?: string;
        /**
         * List of audiences for the web identity token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredazureidentitydetails.html#cfn-devopsagent-service-registeredazureidentitydetails-webidentitytokenaudiences
         */
        readonly webIdentityTokenAudiences?: Array<string>;
    }
    /**
     * SigV4-authenticated MCP server details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html
     */
    interface RegisteredMCPServerSigV4DetailsProperty {
        /**
         * Custom headers for the SigV4 MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-customheaders
         */
        readonly customHeaders?: cdk.IResolvable | Record<string, string>;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-description
         */
        readonly description?: string;
        /**
         * The MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-endpoint
         */
        readonly endpoint?: string;
        /**
         * IAM role ARN for SigV4 signing.
         *
         * Absent when no dedicated role is configured.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-mcprolearn
         */
        readonly mcpRoleArn?: string;
        /**
         * The MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-name
         */
        readonly name?: string;
        /**
         * AWS region for SigV4 signing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-region
         */
        readonly region?: string;
        /**
         * Deprecated - use McpRoleArn instead.
         *
         * IAM role ARN for SigV4 signing
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-rolearn
         */
        readonly roleArn?: string;
        /**
         * AWS service name for SigV4 signing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpserversigv4details.html#cfn-devopsagent-service-registeredmcpserversigv4details-service
         */
        readonly service?: string;
    }
    /**
     * Grafana MCP server details returned after registration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpservergrafanadetails.html
     */
    interface RegisteredMCPServerGrafanaDetailsProperty {
        /**
         * MCP server authorization method.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpservergrafanadetails.html#cfn-devopsagent-service-registeredmcpservergrafanadetails-authorizationmethod
         */
        readonly authorizationMethod?: string;
        /**
         * Optional description for the MCP server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpservergrafanadetails.html#cfn-devopsagent-service-registeredmcpservergrafanadetails-description
         */
        readonly description?: string;
        /**
         * MCP server endpoint URL.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpservergrafanadetails.html#cfn-devopsagent-service-registeredmcpservergrafanadetails-endpoint
         */
        readonly endpoint?: string;
        /**
         * MCP server name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-service-registeredmcpservergrafanadetails.html#cfn-devopsagent-service-registeredmcpservergrafanadetails-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnServicePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html
 */
export interface CfnServiceMixinProps {
    /**
     * The name of the private connection to use for OAuth token exchange requests only.
     *
     * Cannot be specified when PrivateConnectionName is provided.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-exchangeurlprivateconnectionname
     */
    readonly exchangeUrlPrivateConnectionName?: string;
    /**
     * The ARN of the KMS key to use for encryption.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-kmskeyarn
     */
    readonly kmsKeyArn?: string;
    /**
     * The display name for the service registration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-name
     */
    readonly name?: string;
    /**
     * The name of the private connection to use for VPC connectivity.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-privateconnectionname
     */
    readonly privateConnectionName?: string;
    /**
     * Service-specific configuration details - MCPServerSigV4 supports in-place updates;
     *
     * GitLab (TokenValue), MCPServer (ApiKey or BearerToken credential rotation), MCPServerNewRelic (ApiKey rotation), and MCPServerGrafana (BearerToken rotation) support in-place credential rotation; all other service types and fields, including GitHub, require replacement when modified
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-servicedetails
     */
    readonly serviceDetails?: cdk.IResolvable | CfnServicePropsMixin.ServiceDetailsProperty;
    /**
     * The type of service being registered.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-servicetype
     */
    readonly serviceType?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the private connection to use for API calls (target URL) only.
     *
     * Cannot be specified when PrivateConnectionName is provided.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-service.html#cfn-devopsagent-service-targeturlprivateconnectionname
     */
    readonly targetUrlPrivateConnectionName?: string;
}
/**
 * Resource Type definition for AWS::DevOpsAgent::Trigger.
 *
 * A trigger defines an automated action that fires on a schedule within an Agent Space.
 *
 * @cloudformationResource AWS::DevOpsAgent::Trigger
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html
 */
export declare class CfnTriggerPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTriggerMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DevOpsAgent::Trigger`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTriggerMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTrigger;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTriggerPropsMixin {
    /**
     * The condition that causes the trigger to fire.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-trigger-condition.html
     */
    interface ConditionProperty {
        /**
         * Schedule configuration for a time-based trigger.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-trigger-condition.html#cfn-devopsagent-trigger-condition-schedule
         */
        readonly schedule?: cdk.IResolvable | CfnTriggerPropsMixin.ScheduleProperty;
    }
    /**
     * Schedule configuration for a time-based trigger.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-trigger-schedule.html
     */
    interface ScheduleProperty {
        /**
         * A cron or rate expression that defines when the trigger fires.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-devopsagent-trigger-schedule.html#cfn-devopsagent-trigger-schedule-expression
         */
        readonly expression?: string;
    }
}
/**
 * Properties for CfnTriggerPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html
 */
export interface CfnTriggerMixinProps {
    /**
     * The action to perform when the trigger fires.
     *
     * A JSON object containing actionType and task.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html#cfn-devopsagent-trigger-action
     */
    readonly action?: any | cdk.IResolvable;
    /**
     * The unique identifier of the parent Agent Space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html#cfn-devopsagent-trigger-agentspaceid
     */
    readonly agentSpaceId?: string;
    /**
     * The condition that causes the trigger to fire.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html#cfn-devopsagent-trigger-condition
     */
    readonly condition?: CfnTriggerPropsMixin.ConditionProperty | cdk.IResolvable;
    /**
     * The status of the trigger.
     *
     * Active triggers fire on schedule; Inactive triggers are paused.
     *
     * @default - "Active"
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html#cfn-devopsagent-trigger-status
     */
    readonly status?: string;
    /**
     * The type of trigger.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-devopsagent-trigger.html#cfn-devopsagent-trigger-type
     */
    readonly type?: string;
}
