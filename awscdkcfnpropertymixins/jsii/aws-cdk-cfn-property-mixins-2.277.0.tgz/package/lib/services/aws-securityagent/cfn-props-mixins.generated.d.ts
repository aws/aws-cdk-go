import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-securityagent";
/**
 * Resource Type definition for AWS::SecurityAgent::AgentSpace.
 *
 * @cloudformationResource AWS::SecurityAgent::AgentSpace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html
 */
export declare class CfnAgentSpacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAgentSpaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::AgentSpace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAgentSpaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgentSpace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAgentSpacePropsMixin {
    /**
     * AWS resource configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html
     */
    interface AWSResourcesProperty {
        /**
         * IAM role ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-iamroles
         */
        readonly iamRoles?: Array<string>;
        /**
         * Lambda function ARNs used to retrieve tester credentials for pentests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-lambdafunctionarns
         */
        readonly lambdaFunctionArns?: Array<string>;
        /**
         * CloudWatch log group ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-loggroups
         */
        readonly logGroups?: Array<string>;
        /**
         * S3 bucket ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-s3buckets
         */
        readonly s3Buckets?: Array<string>;
        /**
         * SecretsManager secret ARNs used to store tester credentials for pentests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-secretarns
         */
        readonly secretArns?: Array<string>;
        /**
         * VPC configurations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-vpcs
         */
        readonly vpcs?: Array<cdk.IResolvable | CfnAgentSpacePropsMixin.VpcConfigProperty> | cdk.IResolvable;
    }
    /**
     * Customer VPC configuration that the security testing environment accesses.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html
     */
    interface VpcConfigProperty {
        /**
         * List of security group ARNs in the customer VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html#cfn-securityagent-agentspace-vpcconfig-securitygrouparns
         */
        readonly securityGroupArns?: Array<string>;
        /**
         * List of subnet ARNs in the customer VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html#cfn-securityagent-agentspace-vpcconfig-subnetarns
         */
        readonly subnetArns?: Array<string>;
        /**
         * ARN of the customer VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html#cfn-securityagent-agentspace-vpcconfig-vpcarn
         */
        readonly vpcArn?: string;
    }
    /**
     * Details of code review settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-codereviewsettings.html
     */
    interface CodeReviewSettingsProperty {
        /**
         * Whether Controls are utilized for code review analysis.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-codereviewsettings.html#cfn-securityagent-agentspace-codereviewsettings-controlsscanning
         */
        readonly controlsScanning?: boolean | cdk.IResolvable;
        /**
         * Whether general purpose analysis is performed for code review.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-codereviewsettings.html#cfn-securityagent-agentspace-codereviewsettings-generalpurposescanning
         */
        readonly generalPurposeScanning?: boolean | cdk.IResolvable;
    }
    /**
     * Integrated Resource details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-integratedresource.html
     */
    interface IntegratedResourceProperty {
        /**
         * Unique identifier of the Provider Integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-integratedresource.html#cfn-securityagent-agentspace-integratedresource-integration
         */
        readonly integration?: string;
    }
}
/**
 * Properties for CfnAgentSpacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html
 */
export interface CfnAgentSpaceMixinProps {
    /**
     * AWS resource configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-awsresources
     */
    readonly awsResources?: CfnAgentSpacePropsMixin.AWSResourcesProperty | cdk.IResolvable;
    /**
     * Details of code review settings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-codereviewsettings
     */
    readonly codeReviewSettings?: CfnAgentSpacePropsMixin.CodeReviewSettingsProperty | cdk.IResolvable;
    /**
     * Description of the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-description
     */
    readonly description?: string;
    /**
     * Integrated Resources configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-integratedresources
     */
    readonly integratedResources?: Array<CfnAgentSpacePropsMixin.IntegratedResourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Identifier of the KMS key used to encrypt data.
     *
     * Can be a key ID, key ARN, alias name, or alias ARN. If not specified, an AWS managed key is used.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * Name of the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-name
     */
    readonly name?: string;
    /**
     * Tags for the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * List of target domain identifiers registered with the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-targetdomainids
     */
    readonly targetDomainIds?: Array<string>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::Application.
 *
 * @cloudformationResource AWS::SecurityAgent::Application
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html
 */
export declare class CfnApplicationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnApplicationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::Application`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnApplicationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnApplication;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnApplicationPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-application-idcconfiguration.html
     */
    interface IdCConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-application-idcconfiguration.html#cfn-securityagent-application-idcconfiguration-idcapplicationarn
         */
        readonly idCApplicationArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-application-idcconfiguration.html#cfn-securityagent-application-idcconfiguration-idcinstancearn
         */
        readonly idCInstanceArn?: string;
    }
}
/**
 * Properties for CfnApplicationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html
 */
export interface CfnApplicationMixinProps {
    /**
     * Identifier of a KMS key.
     *
     * Can be a key ID, key ARN, alias name, or alias ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-defaultkmskeyid
     */
    readonly defaultKmsKeyId?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-idcconfiguration
     */
    readonly idCConfiguration?: CfnApplicationPropsMixin.IdCConfigurationProperty | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-rolearn
     */
    readonly roleArn?: string;
    /**
     * Tags for the application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Uploads an artifact to an agent space.
 *
 * Artifacts provide additional context for security testing, such as architecture diagrams, API specifications, or configuration files.
 *
 * @cloudformationResource AWS::SecurityAgent::Artifact
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-artifact.html
 */
export declare class CfnArtifactPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnArtifactMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::Artifact`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnArtifactMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnArtifact;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnArtifactPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-artifact.html
 */
export interface CfnArtifactMixinProps {
    /**
     * The unique identifier of the agent space to add the artifact to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-artifact.html#cfn-securityagent-artifact-agentspaceid
     */
    readonly agentSpaceId?: string;
    /**
     * The binary content of the artifact to upload, encoded as a Base64 string.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-artifact.html#cfn-securityagent-artifact-artifactcontent
     */
    readonly artifactContent?: string;
    /**
     * The file type of the artifact.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-artifact.html#cfn-securityagent-artifact-artifacttype
     */
    readonly artifactType?: string;
    /**
     * The file name of the artifact.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-artifact.html#cfn-securityagent-artifact-filename
     */
    readonly fileName?: string;
}
/**
 * Resource Type definition for AWS::SecurityAgent::Integration.
 *
 * Creates a connection between Security Agent and a third-party provider for code review and remediation.
 *
 * @cloudformationResource AWS::SecurityAgent::Integration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html
 */
export declare class CfnIntegrationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIntegrationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::Integration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIntegrationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIntegration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIntegrationPropsMixin {
    /**
     * The provider-specific input required to create the integration.
     *
     * Exactly one of the provider input objects must be specified.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-providerinput.html
     */
    interface ProviderInputProperty {
        /**
         * The input required to create a Bitbucket integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-providerinput.html#cfn-securityagent-integration-providerinput-bitbucket
         */
        readonly bitbucket?: CfnIntegrationPropsMixin.BitbucketInputProperty | cdk.IResolvable;
        /**
         * The input required to create a Confluence integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-providerinput.html#cfn-securityagent-integration-providerinput-confluence
         */
        readonly confluence?: CfnIntegrationPropsMixin.ConfluenceInputProperty | cdk.IResolvable;
        /**
         * The input required to create a GitHub integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-providerinput.html#cfn-securityagent-integration-providerinput-github
         */
        readonly github?: CfnIntegrationPropsMixin.GitHubInputProperty | cdk.IResolvable;
        /**
         * The input required to create a GitLab integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-providerinput.html#cfn-securityagent-integration-providerinput-gitlab
         */
        readonly gitlab?: CfnIntegrationPropsMixin.GitLabInputProperty | cdk.IResolvable;
    }
    /**
     * The input required to create a GitHub integration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-githubinput.html
     */
    interface GitHubInputProperty {
        /**
         * The OAuth authorization code received from GitHub.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-githubinput.html#cfn-securityagent-integration-githubinput-code
         */
        readonly code?: string;
        /**
         * The installation identifier provided by GitHub Enterprise Server on the install callback.
         *
         * Required for GitHub Enterprise Server integrations and ignored for GitHub.com.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-githubinput.html#cfn-securityagent-integration-githubinput-installationid
         */
        readonly installationId?: string;
        /**
         * The name of the GitHub organization to integrate with.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-githubinput.html#cfn-securityagent-integration-githubinput-organizationname
         */
        readonly organizationName?: string;
        /**
         * The CSRF state token for validating the OAuth flow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-githubinput.html#cfn-securityagent-integration-githubinput-state
         */
        readonly state?: string;
        /**
         * The HTTPS URL of a self-hosted GitHub Enterprise Server instance.
         *
         * Omit this value for GitHub.com.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-githubinput.html#cfn-securityagent-integration-githubinput-targeturl
         */
        readonly targetUrl?: string;
    }
    /**
     * The input required to create a GitLab integration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-gitlabinput.html
     */
    interface GitLabInputProperty {
        /**
         * The GitLab access token used to authenticate.
         *
         * This can be a personal access token or a group access token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-gitlabinput.html#cfn-securityagent-integration-gitlabinput-accesstoken
         */
        readonly accessToken?: string;
        /**
         * The identifier of the GitLab group.
         *
         * Required when TokenType is GROUP and ignored for personal tokens.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-gitlabinput.html#cfn-securityagent-integration-gitlabinput-groupid
         */
        readonly groupId?: string;
        /**
         * The HTTPS URL of a self-managed GitLab instance.
         *
         * Omit this value for GitLab SaaS (gitlab.com).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-gitlabinput.html#cfn-securityagent-integration-gitlabinput-targeturl
         */
        readonly targetUrl?: string;
        /**
         * The type of GitLab access token.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-gitlabinput.html#cfn-securityagent-integration-gitlabinput-tokentype
         */
        readonly tokenType?: string;
    }
    /**
     * The input required to create a Bitbucket integration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-bitbucketinput.html
     */
    interface BitbucketInputProperty {
        /**
         * The OAuth 2.0 authorization code returned from the consent redirect.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-bitbucketinput.html#cfn-securityagent-integration-bitbucketinput-code
         */
        readonly code?: string;
        /**
         * The Atlassian installation identifier, available from the Atlassian administration console.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-bitbucketinput.html#cfn-securityagent-integration-bitbucketinput-installationid
         */
        readonly installationId?: string;
        /**
         * The CSRF state token echoed back from the OAuth redirect.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-bitbucketinput.html#cfn-securityagent-integration-bitbucketinput-state
         */
        readonly state?: string;
        /**
         * The Bitbucket workspace slug that identifies the workspace to integrate.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-bitbucketinput.html#cfn-securityagent-integration-bitbucketinput-workspace
         */
        readonly workspace?: string;
    }
    /**
     * The input required to create a Confluence integration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-confluenceinput.html
     */
    interface ConfluenceInputProperty {
        /**
         * The OAuth 2.0 authorization code returned from the consent redirect.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-confluenceinput.html#cfn-securityagent-integration-confluenceinput-code
         */
        readonly code?: string;
        /**
         * The Atlassian installation identifier, available from the Atlassian administration console.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-confluenceinput.html#cfn-securityagent-integration-confluenceinput-installationid
         */
        readonly installationId?: string;
        /**
         * The Confluence Cloud site URL, for example https://mysite.atlassian.net.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-confluenceinput.html#cfn-securityagent-integration-confluenceinput-siteurl
         */
        readonly siteUrl?: string;
        /**
         * The CSRF state token echoed back from the OAuth redirect.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-integration-confluenceinput.html#cfn-securityagent-integration-confluenceinput-state
         */
        readonly state?: string;
    }
}
/**
 * Properties for CfnIntegrationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html
 */
export interface CfnIntegrationMixinProps {
    /**
     * The display name for the integration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html#cfn-securityagent-integration-displayname
     */
    readonly displayName?: string;
    /**
     * The identifier of the AWS KMS key to use for encrypting data associated with the integration.
     *
     * Can be a key ID, key ARN, alias name, or alias ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html#cfn-securityagent-integration-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * The name of an active private connection used to reach a self-hosted provider instance over private networking.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html#cfn-securityagent-integration-privateconnectionname
     */
    readonly privateConnectionName?: string;
    /**
     * The integration provider.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html#cfn-securityagent-integration-provider
     */
    readonly provider?: string;
    /**
     * The provider-specific input required to create the integration.
     *
     * Exactly one of the provider input objects must be specified.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html#cfn-securityagent-integration-providerinput
     */
    readonly providerInput?: cdk.IResolvable | CfnIntegrationPropsMixin.ProviderInputProperty;
    /**
     * The tags to associate with the integration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-integration.html#cfn-securityagent-integration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::Pentest.
 *
 * @cloudformationResource AWS::SecurityAgent::Pentest
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html
 */
export declare class CfnPentestPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPentestMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::Pentest`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPentestMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPentest;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPentestPropsMixin {
    /**
     * Collection of assets to be tested during the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html
     */
    interface AssetsProperty {
        /**
         * List of actors used during testing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-actors
         */
        readonly actors?: Array<CfnPentestPropsMixin.ActorProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Client certificates that AWS Security Agent presents to target hosts that require mutual TLS (mTLS).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-clientcertificates
         */
        readonly clientCertificates?: Array<CfnPentestPropsMixin.ClientCertificateProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of documents providing additional context for the pentest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-documents
         */
        readonly documents?: Array<CfnPentestPropsMixin.DocumentInfoProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of endpoints to test.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-endpoints
         */
        readonly endpoints?: Array<CfnPentestPropsMixin.EndpointProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of repositories connected via provider integrations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-integratedrepositories
         */
        readonly integratedRepositories?: Array<CfnPentestPropsMixin.IntegratedRepositoryProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of source code repositories to analyze.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-sourcecode
         */
        readonly sourceCode?: Array<cdk.IResolvable | CfnPentestPropsMixin.SourceCodeRepositoryProperty> | cdk.IResolvable;
        /**
         * Trust anchors for validating target endpoint TLS certificates, for endpoints served by a private or internal CA, an intermediate CA, or a self-signed certificate.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-trustedcacertificates
         */
        readonly trustedCaCertificates?: Array<cdk.IResolvable | CfnPentestPropsMixin.TrustedCaCertificateProperty> | cdk.IResolvable;
    }
    /**
     * An endpoint to be tested during the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-endpoint.html
     */
    interface EndpointProperty {
        /**
         * URI of the endpoint to test.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-endpoint.html#cfn-securityagent-pentest-endpoint-uri
         */
        readonly uri?: string;
    }
    /**
     * An authenticated actor to be used during pentest execution.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html
     */
    interface ActorProperty {
        /**
         * Authentication configuration for a pentest actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-authentication
         */
        readonly authentication?: CfnPentestPropsMixin.AuthenticationProperty | cdk.IResolvable;
        /**
         * Description of the actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-description
         */
        readonly description?: string;
        /**
         * Whether email-based MFA is enabled for this actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-enableemailmfa
         */
        readonly enableEmailMfa?: boolean | cdk.IResolvable;
        /**
         * Identifier for the actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-identifier
         */
        readonly identifier?: string;
        /**
         * Server-generated email forwarding address for receiving MFA codes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-mfaforwardingaddress
         */
        readonly mfaForwardingAddress?: string;
        /**
         * List of URIs this actor is authorized to access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-uris
         */
        readonly uris?: Array<string>;
    }
    /**
     * Authentication configuration for a pentest actor.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-authentication.html
     */
    interface AuthenticationProperty {
        /**
         * Type of authentication provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-authentication.html#cfn-securityagent-pentest-authentication-providertype
         */
        readonly providerType?: string;
        /**
         * Reference value for the authentication provider, such as a secret ARN or Lambda ARN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-authentication.html#cfn-securityagent-pentest-authentication-value
         */
        readonly value?: string;
    }
    /**
     * A document attached to the pentest, uploaded to S3.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-documentinfo.html
     */
    interface DocumentInfoProperty {
        /**
         * Artifact identifier.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-documentinfo.html#cfn-securityagent-pentest-documentinfo-artifactid
         */
        readonly artifactId?: string;
        /**
         * S3 document location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-documentinfo.html#cfn-securityagent-pentest-documentinfo-s3location
         */
        readonly s3Location?: string;
    }
    /**
     * A source code archive stored in S3 for analysis during the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-sourcecoderepository.html
     */
    interface SourceCodeRepositoryProperty {
        /**
         * S3 source code location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-sourcecoderepository.html#cfn-securityagent-pentest-sourcecoderepository-s3location
         */
        readonly s3Location?: string;
    }
    /**
     * A repository connected via a provider integration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html
     */
    interface IntegratedRepositoryProperty {
        /**
         * An optional override for the repository branch.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html#cfn-securityagent-pentest-integratedrepository-branch
         */
        readonly branch?: string;
        /**
         * Unique identifier of the provider integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html#cfn-securityagent-pentest-integratedrepository-integrationid
         */
        readonly integrationId?: string;
        /**
         * Identifier of the resource within the provider integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html#cfn-securityagent-pentest-integratedrepository-providerresourceid
         */
        readonly providerResourceId?: string;
    }
    /**
     * Trust anchor used when validating a target endpoint's TLS certificate.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-trustedcacertificate.html
     */
    interface TrustedCaCertificateProperty {
        /**
         * Source of a trusted CA certificate.
         *
         * Exactly one member must be set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-trustedcacertificate.html#cfn-securityagent-pentest-trustedcacertificate-source
         */
        readonly source?: CfnPentestPropsMixin.CaCertificateSourceProperty | cdk.IResolvable;
    }
    /**
     * Source of a trusted CA certificate.
     *
     * Exactly one member must be set.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cacertificatesource.html
     */
    interface CaCertificateSourceProperty {
        /**
         * Artifact ID of an uploaded certificate file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cacertificatesource.html#cfn-securityagent-pentest-cacertificatesource-artifactid
         */
        readonly artifactId?: string;
        /**
         * PEM-encoded X.509 certificate supplied inline.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cacertificatesource.html#cfn-securityagent-pentest-cacertificatesource-inlinepem
         */
        readonly inlinePem?: string;
        /**
         * Amazon S3 location URI of a customer-staged certificate.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cacertificatesource.html#cfn-securityagent-pentest-cacertificatesource-s3location
         */
        readonly s3Location?: string;
    }
    /**
     * Client certificate presented during the TLS handshake to the hosts it applies to.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-clientcertificate.html
     */
    interface ClientCertificateProperty {
        /**
         * Name of the client certificate, unique within the pentest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-clientcertificate.html#cfn-securityagent-pentest-clientcertificate-name
         */
        readonly name?: string;
        /**
         * Target hosts the certificate applies to, as https://host[:port] origins.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-clientcertificate.html#cfn-securityagent-pentest-clientcertificate-origins
         */
        readonly origins?: Array<string>;
        /**
         * ARN of the Secrets Manager secret that holds the certificate and private key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-clientcertificate.html#cfn-securityagent-pentest-clientcertificate-secretarn
         */
        readonly secretArn?: string;
    }
    /**
     * CloudWatch Logs configuration for pentest output.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cloudwatchlog.html
     */
    interface CloudWatchLogProperty {
        /**
         * CloudWatch log group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cloudwatchlog.html#cfn-securityagent-pentest-cloudwatchlog-loggroup
         */
        readonly logGroup?: string;
        /**
         * CloudWatch log stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cloudwatchlog.html#cfn-securityagent-pentest-cloudwatchlog-logstream
         */
        readonly logStream?: string;
    }
    /**
     * VPC configuration that the pentest agent accesses.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html
     */
    interface VpcConfigProperty {
        /**
         * List of security groups in the VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html#cfn-securityagent-pentest-vpcconfig-securitygrouparns
         */
        readonly securityGroupArns?: Array<string>;
        /**
         * List of subnets in the VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html#cfn-securityagent-pentest-vpcconfig-subnetarns
         */
        readonly subnetArns?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html#cfn-securityagent-pentest-vpcconfig-vpcarn
         */
        readonly vpcArn?: string;
    }
    /**
     * Network traffic configuration for the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficconfig.html
     */
    interface NetworkTrafficConfigProperty {
        /**
         * Custom headers to include in outbound requests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficconfig.html#cfn-securityagent-pentest-networktrafficconfig-customheaders
         */
        readonly customHeaders?: Array<CfnPentestPropsMixin.CustomHeaderProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Ordered list of network traffic rules.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficconfig.html#cfn-securityagent-pentest-networktrafficconfig-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnPentestPropsMixin.NetworkTrafficRuleProperty> | cdk.IResolvable;
    }
    /**
     * Network traffic rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html
     */
    interface NetworkTrafficRuleProperty {
        /**
         * Whether to allow or deny traffic matching this rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html#cfn-securityagent-pentest-networktrafficrule-effect
         */
        readonly effect?: string;
        /**
         * Type of pattern matching for this rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html#cfn-securityagent-pentest-networktrafficrule-networktrafficruletype
         */
        readonly networkTrafficRuleType?: string;
        /**
         * URL pattern this rule applies to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html#cfn-securityagent-pentest-networktrafficrule-pattern
         */
        readonly pattern?: string;
    }
    /**
     * A custom header to include in outbound requests.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-customheader.html
     */
    interface CustomHeaderProperty {
        /**
         * Name of the header.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-customheader.html#cfn-securityagent-pentest-customheader-name
         */
        readonly name?: string;
        /**
         * Value of the header.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-customheader.html#cfn-securityagent-pentest-customheader-value
         */
        readonly value?: string;
    }
    /**
     * Destination for publishing a scan report to Confluence.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportdestination.html
     */
    interface ReportDestinationProperty {
        /**
         * Identifier of the container, such as a space, within the integration to publish the report to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportdestination.html#cfn-securityagent-pentest-reportdestination-containerid
         */
        readonly containerId?: string;
        /**
         * Identifier of an existing document to update with the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportdestination.html#cfn-securityagent-pentest-reportdestination-documentid
         */
        readonly documentId?: string;
        /**
         * Unique identifier of the provider integration to publish the report to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportdestination.html#cfn-securityagent-pentest-reportdestination-integrationid
         */
        readonly integrationId?: string;
        /**
         * Identifier of the parent under which the report document is created.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportdestination.html#cfn-securityagent-pentest-reportdestination-parentid
         */
        readonly parentId?: string;
    }
    /**
     * Filters applied when a scan report is published to Confluence.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html
     */
    interface ReportFiltersProperty {
        /**
         * Whether to include reviewer annotation notes under each finding.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-annotationnotes
         */
        readonly annotationNotes?: boolean | cdk.IResolvable;
        /**
         * Whether to include the compliance-ready report additions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-compliancereport
         */
        readonly complianceReport?: boolean | cdk.IResolvable;
        /**
         * Confidence levels to include in the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-confidencelevels
         */
        readonly confidenceLevels?: Array<string>;
        /**
         * Finding types to include in the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-findingtypes
         */
        readonly findingTypes?: Array<string>;
        /**
         * Severity levels to include in the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-risklevels
         */
        readonly riskLevels?: Array<string>;
        /**
         * Risk types to include in the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-risktypes
         */
        readonly riskTypes?: Array<string>;
        /**
         * Finding statuses to include in the report.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-statuses
         */
        readonly statuses?: Array<string>;
        /**
         * Task execution statuses to include in the report's task table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-reportfilters.html#cfn-securityagent-pentest-reportfilters-taskstatuses
         */
        readonly taskStatuses?: Array<string>;
    }
    /**
     * Scope of the target under test, determining which classes of risk are assessed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-testscope.html
     */
    interface TestScopeProperty {
        /**
         * The kind of application a pentest target is tested as.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-testscope.html#cfn-securityagent-pentest-testscope-type
         */
        readonly type?: string;
    }
    /**
     * Configuration for running pentests automatically from a CI/CD pipeline.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cicdconfiguration.html
     */
    interface CiCdConfigurationProperty {
        /**
         * Whether CI/CD pentesting is enabled.
         *
         * When enabled, the pentest must have at least one entry in Assets.IntegratedRepositories
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cicdconfiguration.html#cfn-securityagent-pentest-cicdconfiguration-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnPentestPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html
 */
export interface CfnPentestMixinProps {
    /**
     * Identifier of agent space where the pentest should be created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-agentspaceid
     */
    readonly agentSpaceId?: string;
    /**
     * Collection of assets to be tested during the pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-assets
     */
    readonly assets?: CfnPentestPropsMixin.AssetsProperty | cdk.IResolvable;
    /**
     * Configuration for running pentests automatically from a CI/CD pipeline.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-cicdconfiguration
     */
    readonly ciCdConfiguration?: CfnPentestPropsMixin.CiCdConfigurationProperty | cdk.IResolvable;
    /**
     * Strategy for cleaning up resources after pentest job completion.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-cleanupstrategy
     */
    readonly cleanUpStrategy?: string;
    /**
     * Strategy for remediating code vulnerabilities discovered during the pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-coderemediationstrategy
     */
    readonly codeRemediationStrategy?: string;
    /**
     * A list of managed skills to disable for this pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-disablemanagedskills
     */
    readonly disableManagedSkills?: Array<string>;
    /**
     * A list of risk types excluded from the pentest execution.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-excluderisktypes
     */
    readonly excludeRiskTypes?: Array<string>;
    /**
     * CloudWatch Logs configuration for pentest output.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-logconfig
     */
    readonly logConfig?: CfnPentestPropsMixin.CloudWatchLogProperty | cdk.IResolvable;
    /**
     * The maximum number of billable task hours allowed for jobs started from this pentest.
     *
     * If not set, jobs run to completion with no budget cap.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-maxtaskhours
     */
    readonly maxTaskHours?: number;
    /**
     * Network traffic configuration for the pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-networktrafficconfig
     */
    readonly networkTrafficConfig?: cdk.IResolvable | CfnPentestPropsMixin.NetworkTrafficConfigProperty;
    /**
     * Destination for publishing a scan report to Confluence.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-reportdestination
     */
    readonly reportDestination?: cdk.IResolvable | CfnPentestPropsMixin.ReportDestinationProperty;
    /**
     * Filters applied when a scan report is published to Confluence.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-reportfilters
     */
    readonly reportFilters?: cdk.IResolvable | CfnPentestPropsMixin.ReportFiltersProperty;
    /**
     * Service role for accessing resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-servicerole
     */
    readonly serviceRole?: string;
    /**
     * Scope of the target under test, determining which classes of risk are assessed.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-testscope
     */
    readonly testScope?: cdk.IResolvable | CfnPentestPropsMixin.TestScopeProperty;
    /**
     * Title of the penetration test.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-title
     */
    readonly title?: string;
    /**
     * VPC configuration that the pentest agent accesses.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-vpcconfig
     */
    readonly vpcConfig?: cdk.IResolvable | CfnPentestPropsMixin.VpcConfigProperty;
}
/**
 * Resource Type definition for AWS::SecurityAgent::PrivateConnection.
 *
 * A private connection allows Security Agent to reach a target resource privately via a VPC Lattice resource gateway.
 *
 * @cloudformationResource AWS::SecurityAgent::PrivateConnection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-privateconnection.html
 */
export declare class CfnPrivateConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPrivateConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::PrivateConnection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPrivateConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPrivateConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPrivateConnectionPropsMixin {
    /**
     * The configuration for the private connection.
     *
     * Specify either a service-managed or a self-managed mode.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-mode.html
     */
    interface ModeProperty {
        /**
         * The configuration for a self-managed private connection, where you manage your own resource configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-mode.html#cfn-securityagent-privateconnection-mode-selfmanaged
         */
        readonly selfManaged?: cdk.IResolvable | CfnPrivateConnectionPropsMixin.SelfManagedProperty;
        /**
         * The configuration for a service-managed private connection, where the service manages the resource gateway lifecycle.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-mode.html#cfn-securityagent-privateconnection-mode-servicemanaged
         */
        readonly serviceManaged?: cdk.IResolvable | CfnPrivateConnectionPropsMixin.ServiceManagedProperty;
    }
    /**
     * The configuration for a service-managed private connection, where the service manages the resource gateway lifecycle.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html
     */
    interface ServiceManagedProperty {
        /**
         * The DNS resolution mode for the resource gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-dnsresolution
         */
        readonly dnsResolution?: string;
        /**
         * The IP address or DNS name of the target resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-hostaddress
         */
        readonly hostAddress?: string;
        /**
         * The IP address type of the service-managed resource gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-ipaddresstype
         */
        readonly ipAddressType?: string;
        /**
         * The number of IPv4 addresses in each elastic network interface for the service-managed resource gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-ipv4addressespereni
         */
        readonly ipv4AddressesPerEni?: number;
        /**
         * The TCP port ranges that a consumer can use to access the resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-portranges
         */
        readonly portRanges?: Array<string>;
        /**
         * The security groups to attach to the service-managed resource gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-securitygroupids
         */
        readonly securityGroupIds?: Array<string>;
        /**
         * The subnets that the service-managed resource gateway spans.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-subnetids
         */
        readonly subnetIds?: Array<string>;
        /**
         * The VPC to create the service-managed resource gateway in.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-servicemanaged.html#cfn-securityagent-privateconnection-servicemanaged-vpcid
         */
        readonly vpcId?: string;
    }
    /**
     * The configuration for a self-managed private connection, where you manage your own resource configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-selfmanaged.html
     */
    interface SelfManagedProperty {
        /**
         * The identifier or ARN of the resource configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-privateconnection-selfmanaged.html#cfn-securityagent-privateconnection-selfmanaged-resourceconfigurationid
         */
        readonly resourceConfigurationId?: string;
    }
}
/**
 * Properties for CfnPrivateConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-privateconnection.html
 */
export interface CfnPrivateConnectionMixinProps {
    /**
     * The PEM-encoded certificate chain for the private connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-privateconnection.html#cfn-securityagent-privateconnection-certificate
     */
    readonly certificate?: string;
    /**
     * The configuration for the private connection.
     *
     * Specify either a service-managed or a self-managed mode.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-privateconnection.html#cfn-securityagent-privateconnection-mode
     */
    readonly mode?: cdk.IResolvable | CfnPrivateConnectionPropsMixin.ModeProperty;
    /**
     * A unique name for the private connection within your account.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-privateconnection.html#cfn-securityagent-privateconnection-privateconnectionname
     */
    readonly privateConnectionName?: string;
    /**
     * The tags attached to the private connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-privateconnection.html#cfn-securityagent-privateconnection-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::SecurityRequirementPack.
 *
 * @cloudformationResource AWS::SecurityAgent::SecurityRequirementPack
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html
 */
export declare class CfnSecurityRequirementPackPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSecurityRequirementPackMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::SecurityRequirementPack`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSecurityRequirementPackMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSecurityRequirementPack;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSecurityRequirementPackPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html
     */
    interface SecurityRequirementProperty {
        /**
         * Description of the security requirement.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-description
         */
        readonly description?: string;
        /**
         * Security domain this requirement belongs to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-domain
         */
        readonly domain?: string;
        /**
         * How to evaluate compliance with this requirement.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-evaluation
         */
        readonly evaluation?: string;
        /**
         * Name of the security requirement.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-name
         */
        readonly name?: string;
        /**
         * How to remediate non-compliance.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-remediation
         */
        readonly remediation?: string;
    }
}
/**
 * Properties for CfnSecurityRequirementPackPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html
 */
export interface CfnSecurityRequirementPackMixinProps {
    /**
     * Description of the pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-description
     */
    readonly description?: string;
    /**
     * KMS key for client-side encryption of pack contents.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * Name of the security requirement pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-name
     */
    readonly name?: string;
    /**
     * Security requirements within this pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-securityrequirements
     */
    readonly securityRequirements?: Array<cdk.IResolvable | CfnSecurityRequirementPackPropsMixin.SecurityRequirementProperty> | cdk.IResolvable;
    /**
     * Whether the pack is enabled or disabled.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-status
     */
    readonly status?: string;
    /**
     * Tags for the security requirement pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::TargetDomain.
 *
 * @cloudformationResource AWS::SecurityAgent::TargetDomain
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html
 */
export declare class CfnTargetDomainPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTargetDomainMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::TargetDomain`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTargetDomainMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTargetDomain;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTargetDomainPropsMixin {
    /**
     * Verification details to verify registered target domain.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html
     */
    interface VerificationDetailsProperty {
        /**
         * Represents DNS TXT verification details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html#cfn-securityagent-targetdomain-verificationdetails-dnstxt
         */
        readonly dnsTxt?: CfnTargetDomainPropsMixin.DnsVerificationProperty | cdk.IResolvable;
        /**
         * Represents HTTP route verification details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html#cfn-securityagent-targetdomain-verificationdetails-httproute
         */
        readonly httpRoute?: CfnTargetDomainPropsMixin.HttpVerificationProperty | cdk.IResolvable;
        /**
         * Type of domain ownership verification method.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html#cfn-securityagent-targetdomain-verificationdetails-method
         */
        readonly method?: string;
    }
    /**
     * Represents DNS TXT verification details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html
     */
    interface DnsVerificationProperty {
        /**
         * Record name to be added in DNS for target domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html#cfn-securityagent-targetdomain-dnsverification-dnsrecordname
         */
        readonly dnsRecordName?: string;
        /**
         * Type of record to be added in DNS for target domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html#cfn-securityagent-targetdomain-dnsverification-dnsrecordtype
         */
        readonly dnsRecordType?: string;
        /**
         * Token used to verify domain ownership.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html#cfn-securityagent-targetdomain-dnsverification-token
         */
        readonly token?: string;
    }
    /**
     * Represents HTTP route verification details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-httpverification.html
     */
    interface HttpVerificationProperty {
        /**
         * Route path where verification token should be placed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-httpverification.html#cfn-securityagent-targetdomain-httpverification-routepath
         */
        readonly routePath?: string;
        /**
         * Token used to verify domain ownership.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-httpverification.html#cfn-securityagent-targetdomain-httpverification-token
         */
        readonly token?: string;
    }
}
/**
 * Properties for CfnTargetDomainPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html
 */
export interface CfnTargetDomainMixinProps {
    /**
     * Tags for the target domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html#cfn-securityagent-targetdomain-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Domain name of the target domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html#cfn-securityagent-targetdomain-targetdomainname
     */
    readonly targetDomainName?: string;
    /**
     * Verification method for the target domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html#cfn-securityagent-targetdomain-verificationmethod
     */
    readonly verificationMethod?: string;
}
