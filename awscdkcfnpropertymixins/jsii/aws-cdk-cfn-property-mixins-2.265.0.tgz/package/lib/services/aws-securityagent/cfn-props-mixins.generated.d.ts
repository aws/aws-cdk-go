import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-securityagent";
/**
 * Resource Type definition for AWS::SecurityAgent::AgentSpace.
 *
 * @cloudformationResource AWS::SecurityAgent::AgentSpace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html
 */
export declare class CfnAgentSpacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAgentSpaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::AgentSpace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAgentSpaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAgentSpace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAgentSpacePropsMixin {
    /**
     * AWS resource configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html
     */
    interface AWSResourcesProperty {
        /**
         * IAM role ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-iamroles
         */
        readonly iamRoles?: Array<string>;
        /**
         * Lambda function ARNs used to retrieve tester credentials for pentests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-lambdafunctionarns
         */
        readonly lambdaFunctionArns?: Array<string>;
        /**
         * CloudWatch log group ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-loggroups
         */
        readonly logGroups?: Array<string>;
        /**
         * S3 bucket ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-s3buckets
         */
        readonly s3Buckets?: Array<string>;
        /**
         * SecretsManager secret ARNs used to store tester credentials for pentests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-secretarns
         */
        readonly secretArns?: Array<string>;
        /**
         * VPC configurations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-awsresources.html#cfn-securityagent-agentspace-awsresources-vpcs
         */
        readonly vpcs?: Array<cdk.IResolvable | CfnAgentSpacePropsMixin.VpcConfigProperty> | cdk.IResolvable;
    }
    /**
     * Customer VPC configuration that the security testing environment accesses.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html
     */
    interface VpcConfigProperty {
        /**
         * List of security group ARNs in the customer VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html#cfn-securityagent-agentspace-vpcconfig-securitygrouparns
         */
        readonly securityGroupArns?: Array<string>;
        /**
         * List of subnet ARNs in the customer VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html#cfn-securityagent-agentspace-vpcconfig-subnetarns
         */
        readonly subnetArns?: Array<string>;
        /**
         * ARN of the customer VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-vpcconfig.html#cfn-securityagent-agentspace-vpcconfig-vpcarn
         */
        readonly vpcArn?: string;
    }
    /**
     * Details of code review settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-codereviewsettings.html
     */
    interface CodeReviewSettingsProperty {
        /**
         * Whether Controls are utilized for code review analysis.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-codereviewsettings.html#cfn-securityagent-agentspace-codereviewsettings-controlsscanning
         */
        readonly controlsScanning?: boolean | cdk.IResolvable;
        /**
         * Whether general purpose analysis is performed for code review.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-codereviewsettings.html#cfn-securityagent-agentspace-codereviewsettings-generalpurposescanning
         */
        readonly generalPurposeScanning?: boolean | cdk.IResolvable;
    }
    /**
     * Integrated Resource details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-integratedresource.html
     */
    interface IntegratedResourceProperty {
        /**
         * Unique identifier of the Provider Integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-agentspace-integratedresource.html#cfn-securityagent-agentspace-integratedresource-integration
         */
        readonly integration?: string;
    }
}
/**
 * Properties for CfnAgentSpacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html
 */
export interface CfnAgentSpaceMixinProps {
    /**
     * AWS resource configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-awsresources
     */
    readonly awsResources?: CfnAgentSpacePropsMixin.AWSResourcesProperty | cdk.IResolvable;
    /**
     * Details of code review settings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-codereviewsettings
     */
    readonly codeReviewSettings?: CfnAgentSpacePropsMixin.CodeReviewSettingsProperty | cdk.IResolvable;
    /**
     * Description of the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-description
     */
    readonly description?: string;
    /**
     * Integrated Resources configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-integratedresources
     */
    readonly integratedResources?: Array<CfnAgentSpacePropsMixin.IntegratedResourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Identifier of the KMS key used to encrypt data.
     *
     * Can be a key ID, key ARN, alias name, or alias ARN. If not specified, an AWS managed key is used.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * Name of the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-name
     */
    readonly name?: string;
    /**
     * Tags for the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * List of target domain identifiers registered with the agent space.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-agentspace.html#cfn-securityagent-agentspace-targetdomainids
     */
    readonly targetDomainIds?: Array<string>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::Application.
 *
 * @cloudformationResource AWS::SecurityAgent::Application
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html
 */
export declare class CfnApplicationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnApplicationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::Application`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnApplicationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnApplication;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnApplicationPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-application-idcconfiguration.html
     */
    interface IdCConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-application-idcconfiguration.html#cfn-securityagent-application-idcconfiguration-idcapplicationarn
         */
        readonly idCApplicationArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-application-idcconfiguration.html#cfn-securityagent-application-idcconfiguration-idcinstancearn
         */
        readonly idCInstanceArn?: string;
    }
}
/**
 * Properties for CfnApplicationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html
 */
export interface CfnApplicationMixinProps {
    /**
     * Identifier of a KMS key.
     *
     * Can be a key ID, key ARN, alias name, or alias ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-defaultkmskeyid
     */
    readonly defaultKmsKeyId?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-idcconfiguration
     */
    readonly idCConfiguration?: CfnApplicationPropsMixin.IdCConfigurationProperty | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-rolearn
     */
    readonly roleArn?: string;
    /**
     * Tags for the application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-application.html#cfn-securityagent-application-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::Pentest.
 *
 * @cloudformationResource AWS::SecurityAgent::Pentest
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html
 */
export declare class CfnPentestPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPentestMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::Pentest`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPentestMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPentest;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPentestPropsMixin {
    /**
     * Collection of assets to be tested during the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html
     */
    interface AssetsProperty {
        /**
         * List of actors used during testing.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-actors
         */
        readonly actors?: Array<CfnPentestPropsMixin.ActorProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of documents providing additional context for the pentest.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-documents
         */
        readonly documents?: Array<CfnPentestPropsMixin.DocumentInfoProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of endpoints to test.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-endpoints
         */
        readonly endpoints?: Array<CfnPentestPropsMixin.EndpointProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of repositories connected via provider integrations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-integratedrepositories
         */
        readonly integratedRepositories?: Array<CfnPentestPropsMixin.IntegratedRepositoryProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * List of source code repositories to analyze.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-assets.html#cfn-securityagent-pentest-assets-sourcecode
         */
        readonly sourceCode?: Array<cdk.IResolvable | CfnPentestPropsMixin.SourceCodeRepositoryProperty> | cdk.IResolvable;
    }
    /**
     * An endpoint to be tested during the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-endpoint.html
     */
    interface EndpointProperty {
        /**
         * URI of the endpoint to test.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-endpoint.html#cfn-securityagent-pentest-endpoint-uri
         */
        readonly uri?: string;
    }
    /**
     * An authenticated actor to be used during pentest execution.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html
     */
    interface ActorProperty {
        /**
         * Authentication configuration for a pentest actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-authentication
         */
        readonly authentication?: CfnPentestPropsMixin.AuthenticationProperty | cdk.IResolvable;
        /**
         * Description of the actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-description
         */
        readonly description?: string;
        /**
         * Identifier for the actor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-identifier
         */
        readonly identifier?: string;
        /**
         * List of URIs this actor is authorized to access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-actor.html#cfn-securityagent-pentest-actor-uris
         */
        readonly uris?: Array<string>;
    }
    /**
     * Authentication configuration for a pentest actor.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-authentication.html
     */
    interface AuthenticationProperty {
        /**
         * Type of authentication provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-authentication.html#cfn-securityagent-pentest-authentication-providertype
         */
        readonly providerType?: string;
        /**
         * Reference value for the authentication provider, such as a secret ARN or Lambda ARN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-authentication.html#cfn-securityagent-pentest-authentication-value
         */
        readonly value?: string;
    }
    /**
     * A document attached to the pentest, uploaded to S3.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-documentinfo.html
     */
    interface DocumentInfoProperty {
        /**
         * Artifact identifier.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-documentinfo.html#cfn-securityagent-pentest-documentinfo-artifactid
         */
        readonly artifactId?: string;
        /**
         * S3 document location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-documentinfo.html#cfn-securityagent-pentest-documentinfo-s3location
         */
        readonly s3Location?: string;
    }
    /**
     * A source code archive stored in S3 for analysis during the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-sourcecoderepository.html
     */
    interface SourceCodeRepositoryProperty {
        /**
         * S3 source code location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-sourcecoderepository.html#cfn-securityagent-pentest-sourcecoderepository-s3location
         */
        readonly s3Location?: string;
    }
    /**
     * A repository connected via a provider integration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html
     */
    interface IntegratedRepositoryProperty {
        /**
         * Unique identifier of the provider integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html#cfn-securityagent-pentest-integratedrepository-integrationid
         */
        readonly integrationId?: string;
        /**
         * Identifier of the resource within the provider integration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-integratedrepository.html#cfn-securityagent-pentest-integratedrepository-providerresourceid
         */
        readonly providerResourceId?: string;
    }
    /**
     * CloudWatch Logs configuration for pentest output.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cloudwatchlog.html
     */
    interface CloudWatchLogProperty {
        /**
         * CloudWatch log group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cloudwatchlog.html#cfn-securityagent-pentest-cloudwatchlog-loggroup
         */
        readonly logGroup?: string;
        /**
         * CloudWatch log stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-cloudwatchlog.html#cfn-securityagent-pentest-cloudwatchlog-logstream
         */
        readonly logStream?: string;
    }
    /**
     * VPC configuration that the pentest agent accesses.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html
     */
    interface VpcConfigProperty {
        /**
         * List of security groups in the VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html#cfn-securityagent-pentest-vpcconfig-securitygrouparns
         */
        readonly securityGroupArns?: Array<string>;
        /**
         * List of subnets in the VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html#cfn-securityagent-pentest-vpcconfig-subnetarns
         */
        readonly subnetArns?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-vpcconfig.html#cfn-securityagent-pentest-vpcconfig-vpcarn
         */
        readonly vpcArn?: string;
    }
    /**
     * Network traffic configuration for the pentest.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficconfig.html
     */
    interface NetworkTrafficConfigProperty {
        /**
         * Custom headers to include in outbound requests.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficconfig.html#cfn-securityagent-pentest-networktrafficconfig-customheaders
         */
        readonly customHeaders?: Array<CfnPentestPropsMixin.CustomHeaderProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Ordered list of network traffic rules.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficconfig.html#cfn-securityagent-pentest-networktrafficconfig-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnPentestPropsMixin.NetworkTrafficRuleProperty> | cdk.IResolvable;
    }
    /**
     * Network traffic rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html
     */
    interface NetworkTrafficRuleProperty {
        /**
         * Whether to allow or deny traffic matching this rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html#cfn-securityagent-pentest-networktrafficrule-effect
         */
        readonly effect?: string;
        /**
         * Type of pattern matching for this rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html#cfn-securityagent-pentest-networktrafficrule-networktrafficruletype
         */
        readonly networkTrafficRuleType?: string;
        /**
         * URL pattern this rule applies to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-networktrafficrule.html#cfn-securityagent-pentest-networktrafficrule-pattern
         */
        readonly pattern?: string;
    }
    /**
     * A custom header to include in outbound requests.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-customheader.html
     */
    interface CustomHeaderProperty {
        /**
         * Name of the header.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-customheader.html#cfn-securityagent-pentest-customheader-name
         */
        readonly name?: string;
        /**
         * Value of the header.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-pentest-customheader.html#cfn-securityagent-pentest-customheader-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnPentestPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html
 */
export interface CfnPentestMixinProps {
    /**
     * Identifier of agent space where the pentest should be created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-agentspaceid
     */
    readonly agentSpaceId?: string;
    /**
     * Collection of assets to be tested during the pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-assets
     */
    readonly assets?: CfnPentestPropsMixin.AssetsProperty | cdk.IResolvable;
    /**
     * Strategy for cleaning up resources after pentest job completion.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-cleanupstrategy
     */
    readonly cleanUpStrategy?: string;
    /**
     * Strategy for remediating code vulnerabilities discovered during the pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-coderemediationstrategy
     */
    readonly codeRemediationStrategy?: string;
    /**
     * A list of managed skills to disable for this pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-disablemanagedskills
     */
    readonly disableManagedSkills?: Array<string>;
    /**
     * A list of risk types excluded from the pentest execution.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-excluderisktypes
     */
    readonly excludeRiskTypes?: Array<string>;
    /**
     * CloudWatch Logs configuration for pentest output.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-logconfig
     */
    readonly logConfig?: CfnPentestPropsMixin.CloudWatchLogProperty | cdk.IResolvable;
    /**
     * Network traffic configuration for the pentest.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-networktrafficconfig
     */
    readonly networkTrafficConfig?: cdk.IResolvable | CfnPentestPropsMixin.NetworkTrafficConfigProperty;
    /**
     * Service role for accessing resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-servicerole
     */
    readonly serviceRole?: string;
    /**
     * Title of the penetration test.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-title
     */
    readonly title?: string;
    /**
     * VPC configuration that the pentest agent accesses.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-pentest.html#cfn-securityagent-pentest-vpcconfig
     */
    readonly vpcConfig?: cdk.IResolvable | CfnPentestPropsMixin.VpcConfigProperty;
}
/**
 * Resource Type definition for AWS::SecurityAgent::SecurityRequirementPack.
 *
 * @cloudformationResource AWS::SecurityAgent::SecurityRequirementPack
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html
 */
export declare class CfnSecurityRequirementPackPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSecurityRequirementPackMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::SecurityRequirementPack`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSecurityRequirementPackMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSecurityRequirementPack;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSecurityRequirementPackPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html
     */
    interface SecurityRequirementProperty {
        /**
         * Description of the security requirement.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-description
         */
        readonly description?: string;
        /**
         * Security domain this requirement belongs to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-domain
         */
        readonly domain?: string;
        /**
         * How to evaluate compliance with this requirement.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-evaluation
         */
        readonly evaluation?: string;
        /**
         * Name of the security requirement.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-name
         */
        readonly name?: string;
        /**
         * How to remediate non-compliance.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-securityrequirementpack-securityrequirement.html#cfn-securityagent-securityrequirementpack-securityrequirement-remediation
         */
        readonly remediation?: string;
    }
}
/**
 * Properties for CfnSecurityRequirementPackPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html
 */
export interface CfnSecurityRequirementPackMixinProps {
    /**
     * Description of the pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-description
     */
    readonly description?: string;
    /**
     * KMS key for client-side encryption of pack contents.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * Name of the security requirement pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-name
     */
    readonly name?: string;
    /**
     * Security requirements within this pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-securityrequirements
     */
    readonly securityRequirements?: Array<cdk.IResolvable | CfnSecurityRequirementPackPropsMixin.SecurityRequirementProperty> | cdk.IResolvable;
    /**
     * Whether the pack is enabled or disabled.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-status
     */
    readonly status?: string;
    /**
     * Tags for the security requirement pack.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-securityrequirementpack.html#cfn-securityagent-securityrequirementpack-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Resource Type definition for AWS::SecurityAgent::TargetDomain.
 *
 * @cloudformationResource AWS::SecurityAgent::TargetDomain
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html
 */
export declare class CfnTargetDomainPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTargetDomainMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SecurityAgent::TargetDomain`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTargetDomainMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTargetDomain;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTargetDomainPropsMixin {
    /**
     * Verification details to verify registered target domain.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html
     */
    interface VerificationDetailsProperty {
        /**
         * Represents DNS TXT verification details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html#cfn-securityagent-targetdomain-verificationdetails-dnstxt
         */
        readonly dnsTxt?: CfnTargetDomainPropsMixin.DnsVerificationProperty | cdk.IResolvable;
        /**
         * Represents HTTP route verification details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html#cfn-securityagent-targetdomain-verificationdetails-httproute
         */
        readonly httpRoute?: CfnTargetDomainPropsMixin.HttpVerificationProperty | cdk.IResolvable;
        /**
         * Type of domain ownership verification method.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-verificationdetails.html#cfn-securityagent-targetdomain-verificationdetails-method
         */
        readonly method?: string;
    }
    /**
     * Represents DNS TXT verification details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html
     */
    interface DnsVerificationProperty {
        /**
         * Record name to be added in DNS for target domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html#cfn-securityagent-targetdomain-dnsverification-dnsrecordname
         */
        readonly dnsRecordName?: string;
        /**
         * Type of record to be added in DNS for target domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html#cfn-securityagent-targetdomain-dnsverification-dnsrecordtype
         */
        readonly dnsRecordType?: string;
        /**
         * Token used to verify domain ownership.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-dnsverification.html#cfn-securityagent-targetdomain-dnsverification-token
         */
        readonly token?: string;
    }
    /**
     * Represents HTTP route verification details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-httpverification.html
     */
    interface HttpVerificationProperty {
        /**
         * Route path where verification token should be placed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-httpverification.html#cfn-securityagent-targetdomain-httpverification-routepath
         */
        readonly routePath?: string;
        /**
         * Token used to verify domain ownership.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-securityagent-targetdomain-httpverification.html#cfn-securityagent-targetdomain-httpverification-token
         */
        readonly token?: string;
    }
}
/**
 * Properties for CfnTargetDomainPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html
 */
export interface CfnTargetDomainMixinProps {
    /**
     * Tags for the target domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html#cfn-securityagent-targetdomain-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Domain name of the target domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html#cfn-securityagent-targetdomain-targetdomainname
     */
    readonly targetDomainName?: string;
    /**
     * Verification method for the target domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-securityagent-targetdomain.html#cfn-securityagent-targetdomain-verificationmethod
     */
    readonly verificationMethod?: string;
}
