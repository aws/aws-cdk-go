import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-s3tables";
/**
 * Creates a namespace.
 *
 * A namespace is a logical grouping of tables within your table bucket, which you can use to organize tables. For more information, see [Create a namespace](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables-namespace-create.html) in the *Amazon Simple Storage Service User Guide* .
 *
 * - **Permissions** - You must have the `s3tables:CreateNamespace` permission to use this operation.
 * - **Cloud Development Kit** - To use S3 Tables AWS CDK constructs, add the `@aws-cdk/aws-s3tables-alpha` dependency with one of the following options:
 *
 * - NPM: `npm i @aws-cdk/aws-s3tables-alpha`
 * - Yarn: `yarn add @aws-cdk/aws-s3tables-alpha`
 *
 * @cloudformationResource AWS::S3Tables::Namespace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-namespace.html
 */
export declare class CfnNamespacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNamespaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Tables::Namespace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNamespaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNamespace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnNamespacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-namespace.html
 */
export interface CfnNamespaceMixinProps {
    /**
     * The name of the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-namespace.html#cfn-s3tables-namespace-namespace
     */
    readonly namespace?: string;
    /**
     * The Amazon Resource Name (ARN) of the table bucket to create the namespace in.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-namespace.html#cfn-s3tables-namespace-tablebucketarn
     */
    readonly tableBucketArn?: string;
}
/**
 * Creates a new table associated with the given namespace in a table bucket.
 *
 * For more information, see [Creating an Amazon S3 table](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables-create.html) in the *Amazon Simple Storage Service User Guide* .
 *
 * - **Permissions** - - You must have the `s3tables:CreateTable` permission to use this operation.
 * - If you use this operation with the optional `metadata` request parameter you must have the `s3tables:PutTableData` permission.
 * - If you use this operation with the optional `encryptionConfiguration` request parameter you must have the `s3tables:PutTableEncryption` permission.
 *
 * > Additionally, If you choose SSE-KMS encryption you must grant the S3 Tables maintenance principal access to your KMS key. For more information, see [Permissions requirements for S3 Tables SSE-KMS encryption](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables-kms-permissions.html) .
 * - **Cloud Development Kit** - To use S3 Tables AWS CDK constructs, add the `@aws-cdk/aws-s3tables-alpha` dependency with one of the following options:
 *
 * - NPM: `npm i @aws-cdk/aws-s3tables-alpha`
 * - Yarn: `yarn add @aws-cdk/aws-s3tables-alpha`
 *
 * @cloudformationResource AWS::S3Tables::Table
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html
 */
export declare class CfnTablePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTableMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Tables::Table`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTableMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTable;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTablePropsMixin {
    /**
     * The configuration details for the storage class of tables or table buckets.
     *
     * This allows you to optimize storage costs by selecting the appropriate storage class based on your access patterns and performance requirements.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-storageclassconfiguration.html
     */
    interface StorageClassConfigurationProperty {
        /**
         * The storage class for the table or table bucket.
         *
         * Valid values include storage classes optimized for different access patterns and cost profiles.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-storageclassconfiguration.html#cfn-s3tables-table-storageclassconfiguration-storageclass
         */
        readonly storageClass?: string;
    }
    /**
     * Contains details about the compaction settings for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-compaction.html
     */
    interface CompactionProperty {
        /**
         * The status of the maintenance configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-compaction.html#cfn-s3tables-table-compaction-status
         */
        readonly status?: string;
        /**
         * The target file size for the table in MB.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-compaction.html#cfn-s3tables-table-compaction-targetfilesizemb
         */
        readonly targetFileSizeMb?: number;
    }
    /**
     * Contains details about the metadata for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergmetadata.html
     */
    interface IcebergMetadataProperty {
        /**
         * Partition specification for an Iceberg table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergmetadata.html#cfn-s3tables-table-icebergmetadata-icebergpartitionspec
         */
        readonly icebergPartitionSpec?: CfnTablePropsMixin.IcebergPartitionSpecProperty | cdk.IResolvable;
        /**
         * The schema for an Iceberg table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergmetadata.html#cfn-s3tables-table-icebergmetadata-icebergschema
         */
        readonly icebergSchema?: CfnTablePropsMixin.IcebergSchemaProperty | cdk.IResolvable;
        /**
         * Contains details about the schema version 2 (V2) for an Iceberg table that supports Apache Iceberg Nested Types (struct, list, map).
         *
         * Primitive types are also supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergmetadata.html#cfn-s3tables-table-icebergmetadata-icebergschemav2
         */
        readonly icebergSchemaV2?: CfnTablePropsMixin.IcebergSchemaV2Property | cdk.IResolvable;
        /**
         * Sort order specification for an Iceberg table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergmetadata.html#cfn-s3tables-table-icebergmetadata-icebergsortorder
         */
        readonly icebergSortOrder?: CfnTablePropsMixin.IcebergSortOrderProperty | cdk.IResolvable;
        /**
         * Iceberg table properties (e.g., format-version, write.parquet.compression-codec).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergmetadata.html#cfn-s3tables-table-icebergmetadata-tableproperties
         */
        readonly tableProperties?: cdk.IResolvable | Record<string, string>;
    }
    /**
     * Contains details about the schema for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschema.html
     */
    interface IcebergSchemaProperty {
        /**
         * The schema fields for the table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschema.html#cfn-s3tables-table-icebergschema-schemafieldlist
         */
        readonly schemaFieldList?: Array<cdk.IResolvable | CfnTablePropsMixin.SchemaFieldProperty> | cdk.IResolvable;
    }
    /**
     * Contains details about a schema field.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemafield.html
     */
    interface SchemaFieldProperty {
        /**
         * The unique identifier for the field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemafield.html#cfn-s3tables-table-schemafield-id
         */
        readonly id?: number;
        /**
         * The name of the field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemafield.html#cfn-s3tables-table-schemafield-name
         */
        readonly name?: string;
        /**
         * A Boolean value that specifies whether values are required for each row in this field.
         *
         * By default, this is `false` and null values are allowed in the field. If this is `true` the field does not allow null values.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemafield.html#cfn-s3tables-table-schemafield-required
         */
        readonly required?: boolean | cdk.IResolvable;
        /**
         * The field type.
         *
         * S3 Tables supports all Apache Iceberg primitive types. For more information, see the [Apache Iceberg documentation](https://docs.aws.amazon.com/https://iceberg.apache.org/spec/#primitive-types) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemafield.html#cfn-s3tables-table-schemafield-type
         */
        readonly type?: string;
    }
    /**
     * Sort order specification for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortorder.html
     */
    interface IcebergSortOrderProperty {
        /**
         * List of sort fields for an Iceberg table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortorder.html#cfn-s3tables-table-icebergsortorder-fields
         */
        readonly fields?: Array<CfnTablePropsMixin.IcebergSortFieldProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The sort order ID (defaults to 1 if not specified, 0 is reserved for unsorted).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortorder.html#cfn-s3tables-table-icebergsortorder-orderid
         */
        readonly orderId?: number;
    }
    /**
     * A sort field specification for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortfield.html
     */
    interface IcebergSortFieldProperty {
        /**
         * Sort direction (asc or desc).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortfield.html#cfn-s3tables-table-icebergsortfield-direction
         */
        readonly direction?: string;
        /**
         * Null value ordering (nulls-first or nulls-last).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortfield.html#cfn-s3tables-table-icebergsortfield-nullorder
         */
        readonly nullOrder?: string;
        /**
         * The source column ID to sort on.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortfield.html#cfn-s3tables-table-icebergsortfield-sourceid
         */
        readonly sourceId?: number;
        /**
         * The sort transform function.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergsortfield.html#cfn-s3tables-table-icebergsortfield-transform
         */
        readonly transform?: string;
    }
    /**
     * Contains details about the schema version 2 (V2) for an Iceberg table that supports Apache Iceberg Nested Types (struct, list, map).
     *
     * Primitive types are also supported.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschemav2.html
     */
    interface IcebergSchemaV2Property {
        /**
         * A list of field IDs that are used as the identifier fields for the table.
         *
         * Identifier fields uniquely identify a row in the table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschemav2.html#cfn-s3tables-table-icebergschemav2-identifierfieldids
         */
        readonly identifierFieldIds?: Array<number> | cdk.IResolvable;
        /**
         * An optional unique identifier for the schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschemav2.html#cfn-s3tables-table-icebergschemav2-schemaid
         */
        readonly schemaId?: number;
        /**
         * List of schema fields that support nested types.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschemav2.html#cfn-s3tables-table-icebergschemav2-schemav2fieldlist
         */
        readonly schemaV2FieldList?: Array<cdk.IResolvable | CfnTablePropsMixin.SchemaV2FieldProperty> | cdk.IResolvable;
        /**
         * The type of the top-level schema, which is always 'struct'.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergschemav2.html#cfn-s3tables-table-icebergschemav2-schemav2fieldtype
         */
        readonly schemaV2FieldType?: string;
    }
    /**
     * Contains details about a schema field for an Iceberg table that supports nested types (struct, list, map).
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemav2field.html
     */
    interface SchemaV2FieldProperty {
        /**
         * Optional documentation for the field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemav2field.html#cfn-s3tables-table-schemav2field-doc
         */
        readonly doc?: string;
        /**
         * The unique identifier for the field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemav2field.html#cfn-s3tables-table-schemav2field-id
         */
        readonly id?: number;
        /**
         * The name of the field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemav2field.html#cfn-s3tables-table-schemav2field-name
         */
        readonly name?: string;
        /**
         * A Boolean value that specifies whether values are required for each row in this field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemav2field.html#cfn-s3tables-table-schemav2field-required
         */
        readonly required?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-schemav2field.html#cfn-s3tables-table-schemav2field-type
         */
        readonly type?: any | cdk.IResolvable | string;
    }
    /**
     * Partition specification for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionspec.html
     */
    interface IcebergPartitionSpecProperty {
        /**
         * List of partition fields for an Iceberg table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionspec.html#cfn-s3tables-table-icebergpartitionspec-fields
         */
        readonly fields?: Array<CfnTablePropsMixin.IcebergPartitionFieldProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The partition spec ID (defaults to 0 if not specified).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionspec.html#cfn-s3tables-table-icebergpartitionspec-specid
         */
        readonly specId?: number;
    }
    /**
     * A partition field specification for an Iceberg table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionfield.html
     */
    interface IcebergPartitionFieldProperty {
        /**
         * The partition field ID (auto-assigned starting from 1000 if not specified).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionfield.html#cfn-s3tables-table-icebergpartitionfield-fieldid
         */
        readonly fieldId?: number;
        /**
         * The name of the partition field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionfield.html#cfn-s3tables-table-icebergpartitionfield-name
         */
        readonly name?: string;
        /**
         * The source column ID to partition on.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionfield.html#cfn-s3tables-table-icebergpartitionfield-sourceid
         */
        readonly sourceId?: number;
        /**
         * The partition transform function (identity, bucket[N], truncate[N], year, month, day, hour).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-icebergpartitionfield.html#cfn-s3tables-table-icebergpartitionfield-transform
         */
        readonly transform?: string;
    }
    /**
     * Contains details about the snapshot management settings for an Iceberg table.
     *
     * The oldest snapshot expires when its age exceeds the `maxSnapshotAgeHours` and the total number of snapshots exceeds the value for the minimum number of snapshots to keep `minSnapshotsToKeep` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-snapshotmanagement.html
     */
    interface SnapshotManagementProperty {
        /**
         * The maximum age of a snapshot before it can be expired.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-snapshotmanagement.html#cfn-s3tables-table-snapshotmanagement-maxsnapshotagehours
         */
        readonly maxSnapshotAgeHours?: number;
        /**
         * The minimum number of snapshots to keep.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-snapshotmanagement.html#cfn-s3tables-table-snapshotmanagement-minsnapshotstokeep
         */
        readonly minSnapshotsToKeep?: number;
        /**
         * The status of the maintenance configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-table-snapshotmanagement.html#cfn-s3tables-table-snapshotmanagement-status
         */
        readonly status?: string;
    }
}
/**
 * Properties for CfnTablePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html
 */
export interface CfnTableMixinProps {
    /**
     * Contains details about the compaction settings for an Iceberg table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-compaction
     */
    readonly compaction?: CfnTablePropsMixin.CompactionProperty | cdk.IResolvable;
    /**
     * Contains details about the metadata for an Iceberg table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-icebergmetadata
     */
    readonly icebergMetadata?: CfnTablePropsMixin.IcebergMetadataProperty | cdk.IResolvable;
    /**
     * The name of the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-namespace
     */
    readonly namespace?: string;
    /**
     * The format of the table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-opentableformat
     */
    readonly openTableFormat?: string;
    /**
     * Contains details about the Iceberg snapshot management settings for the table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-snapshotmanagement
     */
    readonly snapshotManagement?: cdk.IResolvable | CfnTablePropsMixin.SnapshotManagementProperty;
    /**
     * The configuration details for the storage class of tables or table buckets.
     *
     * This allows you to optimize storage costs by selecting the appropriate storage class based on your access patterns and performance requirements.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-storageclassconfiguration
     */
    readonly storageClassConfiguration?: cdk.IResolvable | CfnTablePropsMixin.StorageClassConfigurationProperty;
    /**
     * The Amazon Resource Name (ARN) of the table bucket to create the table in.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-tablebucketarn
     */
    readonly tableBucketArn?: string;
    /**
     * The name for the table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-tablename
     */
    readonly tableName?: string;
    /**
     * User tags (key-value pairs) to associate with the table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Indicates that you don't want to specify a schema for the table.
     *
     * This property is mutually exclusive to `IcebergMetadata` , and its only possible value is `Yes` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-table.html#cfn-s3tables-table-withoutmetadata
     */
    readonly withoutMetadata?: string;
}
/**
 * Creates a table bucket.
 *
 * For more information, see [Creating a table bucket](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables-buckets-create.html) in the *Amazon Simple Storage Service User Guide* .
 *
 * - **Permissions** - - You must have the `s3tables:CreateTableBucket` permission to use this operation.
 * - If you use this operation with the optional `encryptionConfiguration` parameter you must have the `s3tables:PutTableBucketEncryption` permission.
 * - **Cloud Development Kit** - To use S3 Tables AWS CDK constructs, add the `@aws-cdk/aws-s3tables-alpha` dependency with one of the following options:
 *
 * - NPM: `npm i @aws-cdk/aws-s3tables-alpha`
 * - Yarn: `yarn add @aws-cdk/aws-s3tables-alpha`
 *
 * @cloudformationResource AWS::S3Tables::TableBucket
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html
 */
export declare class CfnTableBucketPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTableBucketMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Tables::TableBucket`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTableBucketMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTableBucket;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTableBucketPropsMixin {
    /**
     * The unreferenced file removal settings for your table bucket.
     *
     * Unreferenced file removal identifies and deletes all objects that are not referenced by any table snapshots. For more information, see the [*Amazon S3 User Guide*](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-table-buckets-maintenance.html) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-unreferencedfileremoval.html
     */
    interface UnreferencedFileRemovalProperty {
        /**
         * The number of days an object can be noncurrent before Amazon S3 deletes it.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-unreferencedfileremoval.html#cfn-s3tables-tablebucket-unreferencedfileremoval-noncurrentdays
         */
        readonly noncurrentDays?: number;
        /**
         * The status of the unreferenced file removal configuration for your table bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-unreferencedfileremoval.html#cfn-s3tables-tablebucket-unreferencedfileremoval-status
         */
        readonly status?: string;
        /**
         * The number of days an object must be unreferenced by your table before Amazon S3 marks the object as noncurrent.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-unreferencedfileremoval.html#cfn-s3tables-tablebucket-unreferencedfileremoval-unreferenceddays
         */
        readonly unreferencedDays?: number;
    }
    /**
     * Configuration specifying how data should be encrypted.
     *
     * This structure defines the encryption algorithm and optional KMS key to be used for server-side encryption.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-encryptionconfiguration.html
     */
    interface EncryptionConfigurationProperty {
        /**
         * The Amazon Resource Name (ARN) of the KMS key to use for encryption.
         *
         * This field is required only when `sseAlgorithm` is set to `aws:kms` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-encryptionconfiguration.html#cfn-s3tables-tablebucket-encryptionconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * The server-side encryption algorithm to use.
         *
         * Valid values are `AES256` for S3-managed encryption keys, or `aws:kms` for AWS KMS-managed encryption keys. If you choose SSE-KMS encryption you must grant the S3 Tables maintenance principal access to your KMS key. For more information, see [Permissions requirements for S3 Tables SSE-KMS encryption](https://docs.aws.amazon.com//AmazonS3/latest/userguide/s3-tables-kms-permissions.html) .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-encryptionconfiguration.html#cfn-s3tables-tablebucket-encryptionconfiguration-ssealgorithm
         */
        readonly sseAlgorithm?: string;
    }
    /**
     * Settings governing the Metric configuration for the table bucket.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-metricsconfiguration.html
     */
    interface MetricsConfigurationProperty {
        /**
         * Indicates whether Metrics are enabled.
         *
         * @default - "Disabled"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-metricsconfiguration.html#cfn-s3tables-tablebucket-metricsconfiguration-status
         */
        readonly status?: string;
    }
    /**
     * The configuration details for the storage class of tables or table buckets.
     *
     * This allows you to optimize storage costs by selecting the appropriate storage class based on your access patterns and performance requirements.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-storageclassconfiguration.html
     */
    interface StorageClassConfigurationProperty {
        /**
         * The storage class for the table or table bucket.
         *
         * Valid values include storage classes optimized for different access patterns and cost profiles.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-storageclassconfiguration.html#cfn-s3tables-tablebucket-storageclassconfiguration-storageclass
         */
        readonly storageClass?: string;
    }
    /**
     * Specifies replication configuration for the table bucket.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationconfiguration.html
     */
    interface ReplicationConfigurationProperty {
        /**
         * The ARN of the IAM role to use for replication.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationconfiguration.html#cfn-s3tables-tablebucket-replicationconfiguration-role
         */
        readonly role?: string;
        /**
         * List of replication rules.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationconfiguration.html#cfn-s3tables-tablebucket-replicationconfiguration-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnTableBucketPropsMixin.ReplicationRuleProperty> | cdk.IResolvable;
    }
    /**
     * A replication rule for the table bucket.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationrule.html
     */
    interface ReplicationRuleProperty {
        /**
         * List of replication destinations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationrule.html#cfn-s3tables-tablebucket-replicationrule-destinations
         */
        readonly destinations?: Array<cdk.IResolvable | CfnTableBucketPropsMixin.ReplicationDestinationProperty> | cdk.IResolvable;
    }
    /**
     * A replication destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationdestination.html
     */
    interface ReplicationDestinationProperty {
        /**
         * The ARN of the destination table bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3tables-tablebucket-replicationdestination.html#cfn-s3tables-tablebucket-replicationdestination-destinationtablebucketarn
         */
        readonly destinationTableBucketArn?: string;
    }
}
/**
 * Properties for CfnTableBucketPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html
 */
export interface CfnTableBucketMixinProps {
    /**
     * Configuration specifying how data should be encrypted.
     *
     * This structure defines the encryption algorithm and optional KMS key to be used for server-side encryption.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-encryptionconfiguration
     */
    readonly encryptionConfiguration?: CfnTableBucketPropsMixin.EncryptionConfigurationProperty | cdk.IResolvable;
    /**
     * Settings governing the Metric configuration for the table bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-metricsconfiguration
     */
    readonly metricsConfiguration?: cdk.IResolvable | CfnTableBucketPropsMixin.MetricsConfigurationProperty;
    /**
     * Specifies replication configuration for the table bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-replicationconfiguration
     */
    readonly replicationConfiguration?: cdk.IResolvable | CfnTableBucketPropsMixin.ReplicationConfigurationProperty;
    /**
     * The configuration details for the storage class of tables or table buckets.
     *
     * This allows you to optimize storage costs by selecting the appropriate storage class based on your access patterns and performance requirements.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-storageclassconfiguration
     */
    readonly storageClassConfiguration?: cdk.IResolvable | CfnTableBucketPropsMixin.StorageClassConfigurationProperty;
    /**
     * The name for the table bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-tablebucketname
     */
    readonly tableBucketName?: string;
    /**
     * User tags (key-value pairs) to associate with the table bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The unreferenced file removal settings for your table bucket.
     *
     * Unreferenced file removal identifies and deletes all objects that are not referenced by any table snapshots. For more information, see the [*Amazon S3 User Guide*](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-table-buckets-maintenance.html) .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucket.html#cfn-s3tables-tablebucket-unreferencedfileremoval
     */
    readonly unreferencedFileRemoval?: cdk.IResolvable | CfnTableBucketPropsMixin.UnreferencedFileRemovalProperty;
}
/**
 * Creates a new maintenance configuration or replaces an existing table bucket policy for a table bucket.
 *
 * For more information, see [Adding a table bucket policy](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables-bucket-policy.html#table-bucket-policy-add) in the *Amazon Simple Storage Service User Guide* .
 *
 * - **Permissions** - You must have the `s3tables:PutTableBucketPolicy` permission to use this operation.
 * - **Cloud Development Kit** - To use S3 Tables AWS CDK constructs, add the `@aws-cdk/aws-s3tables-alpha` dependency with one of the following options:
 *
 * - NPM: `npm i @aws-cdk/aws-s3tables-alpha`
 * - Yarn: `yarn add @aws-cdk/aws-s3tables-alpha`
 *
 * @cloudformationResource AWS::S3Tables::TableBucketPolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucketpolicy.html
 */
export declare class CfnTableBucketPolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTableBucketPolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Tables::TableBucketPolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTableBucketPolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTableBucketPolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTableBucketPolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucketpolicy.html
 */
export interface CfnTableBucketPolicyMixinProps {
    /**
     * The bucket policy JSON for the table bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucketpolicy.html#cfn-s3tables-tablebucketpolicy-resourcepolicy
     */
    readonly resourcePolicy?: any | cdk.IResolvable | string;
    /**
     * The Amazon Resource Name (ARN) of the table bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablebucketpolicy.html#cfn-s3tables-tablebucketpolicy-tablebucketarn
     */
    readonly tableBucketArn?: string;
}
/**
 * Creates a new maintenance configuration or replaces an existing table policy for a table.
 *
 * For more information, see [Adding a table policy](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-tables-table-policy.html#table-policy-add) in the *Amazon Simple Storage Service User Guide* .
 *
 * - **Permissions** - You must have the `s3tables:PutTablePolicy` permission to use this operation.
 * - **Cloud Development Kit** - To use S3 Tables AWS CDK constructs, add the `@aws-cdk/aws-s3tables-alpha` dependency with one of the following options:
 *
 * - NPM: `npm i @aws-cdk/aws-s3tables-alpha`
 * - Yarn: `yarn add @aws-cdk/aws-s3tables-alpha`
 *
 * @cloudformationResource AWS::S3Tables::TablePolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablepolicy.html
 */
export declare class CfnTablePolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTablePolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Tables::TablePolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTablePolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTablePolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnTablePolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablepolicy.html
 */
export interface CfnTablePolicyMixinProps {
    /**
     * The `JSON` that defines the policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablepolicy.html#cfn-s3tables-tablepolicy-resourcepolicy
     */
    readonly resourcePolicy?: any | cdk.IResolvable | string;
    /**
     * The Amazon Resource Name (ARN) of the table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3tables-tablepolicy.html#cfn-s3tables-tablepolicy-tablearn
     */
    readonly tableArn?: string;
}
