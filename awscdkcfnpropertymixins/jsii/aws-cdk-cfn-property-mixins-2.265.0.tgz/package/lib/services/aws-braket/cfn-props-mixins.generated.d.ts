import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-braket";
/**
 * Creates a spending limit for a specified quantum device.
 *
 * Spending limits help you control costs by setting maximum amounts that can be spent on quantum computing tasks within a specified time period.
 *
 * @cloudformationResource AWS::Braket::SpendingLimit
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-braket-spendinglimit.html
 */
export declare class CfnSpendingLimitPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSpendingLimitMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Braket::SpendingLimit`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSpendingLimitMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSpendingLimit;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSpendingLimitPropsMixin {
    /**
     * Defines a time range for spending limits, specifying when the limit is active.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-braket-spendinglimit-timeperiod.html
     */
    interface TimePeriodProperty {
        /**
         * The end date and time for the spending limit period, in ISO 8601 format.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-braket-spendinglimit-timeperiod.html#cfn-braket-spendinglimit-timeperiod-endat
         */
        readonly endAt?: string;
        /**
         * The start date and time for the spending limit period, in ISO 8601 format.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-braket-spendinglimit-timeperiod.html#cfn-braket-spendinglimit-timeperiod-startat
         */
        readonly startAt?: string;
    }
}
/**
 * Properties for CfnSpendingLimitPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-braket-spendinglimit.html
 */
export interface CfnSpendingLimitMixinProps {
    /**
     * The Amazon Resource Name (ARN) of the quantum device to apply the spending limit to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-braket-spendinglimit.html#cfn-braket-spendinglimit-devicearn
     */
    readonly deviceArn?: string;
    /**
     * The maximum amount that can be spent on the specified device, in USD.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-braket-spendinglimit.html#cfn-braket-spendinglimit-spendinglimit
     */
    readonly spendingLimit?: string;
    /**
     * The tags to apply to the spending limit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-braket-spendinglimit.html#cfn-braket-spendinglimit-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Defines a time range for spending limits, specifying when the limit is active.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-braket-spendinglimit.html#cfn-braket-spendinglimit-timeperiod
     */
    readonly timePeriod?: cdk.IResolvable | CfnSpendingLimitPropsMixin.TimePeriodProperty;
}
