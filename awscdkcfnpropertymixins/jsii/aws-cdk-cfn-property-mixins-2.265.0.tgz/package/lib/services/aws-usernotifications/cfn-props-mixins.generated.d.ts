import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-usernotifications";
/**
 * Resource type definition for AWS User Notifications ManagedNotificationConfiguration.
 *
 * This is a read-only resource representing AWS-managed notification configurations.
 *
 * @cloudformationResource AWS::UserNotifications::ManagedNotificationConfiguration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-usernotifications-managednotificationconfiguration.html
 */
export declare class CfnManagedNotificationConfigurationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnManagedNotificationConfigurationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::UserNotifications::ManagedNotificationConfiguration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnManagedNotificationConfigurationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnManagedNotificationConfiguration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnManagedNotificationConfigurationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-usernotifications-managednotificationconfiguration.html
 */
export interface CfnManagedNotificationConfigurationMixinProps {
    /**
     * The category of the ManagedNotificationConfiguration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-usernotifications-managednotificationconfiguration.html#cfn-usernotifications-managednotificationconfiguration-category
     */
    readonly category?: string;
    /**
     * The subCategory of the ManagedNotificationConfiguration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-usernotifications-managednotificationconfiguration.html#cfn-usernotifications-managednotificationconfiguration-subcategory
     */
    readonly subCategory?: string;
}
