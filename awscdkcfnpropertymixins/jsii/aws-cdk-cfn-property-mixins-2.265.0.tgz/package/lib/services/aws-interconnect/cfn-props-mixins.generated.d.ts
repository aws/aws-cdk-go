import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-interconnect";
/**
 * Resource Type definition for AWS::Interconnect::Connection.
 *
 * Creates a managed network connection between AWS and a partner cloud service provider.
 *
 * @cloudformationResource AWS::Interconnect::Connection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html
 */
export declare class CfnConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Interconnect::Connection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConnectionPropsMixin {
    /**
     * The logical attachment point in your AWS network where the managed connection will be connected.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-attachpoint.html
     */
    interface AttachPointProperty {
        /**
         * The ARN of the resource to attach to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-attachpoint.html#cfn-interconnect-connection-attachpoint-arn
         */
        readonly arn?: string;
        /**
         * The ID of the Direct Connect Gateway to attach to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-attachpoint.html#cfn-interconnect-connection-attachpoint-directconnectgateway
         */
        readonly directConnectGateway?: string;
    }
    /**
     * The remote account identifier for the connection.
     *
     * Required when creating a connection through AWS. Replaces RemoteOwnerAccount.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-remoteaccount.html
     */
    interface RemoteAccountProperty {
        /**
         * The identifier of the remote account.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-remoteaccount.html#cfn-interconnect-connection-remoteaccount-identifier
         */
        readonly identifier?: string;
    }
    /**
     * The partner cloud service provider.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-provider.html
     */
    interface ProviderProperty {
        /**
         * The name of the cloud service provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-provider.html#cfn-interconnect-connection-provider-cloudserviceprovider
         */
        readonly cloudServiceProvider?: string;
        /**
         * The name of the last mile provider.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-interconnect-connection-provider.html#cfn-interconnect-connection-provider-lastmileprovider
         */
        readonly lastMileProvider?: string;
    }
}
/**
 * Properties for CfnConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html
 */
export interface CfnConnectionMixinProps {
    /**
     * The activation key for accepting a connection proposal from a partner CSP.
     *
     * Mutually exclusive with EnvironmentId.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-activationkey
     */
    readonly activationKey?: string;
    /**
     * The logical attachment point in your AWS network where the managed connection will be connected.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-attachpoint
     */
    readonly attachPoint?: CfnConnectionPropsMixin.AttachPointProperty | cdk.IResolvable;
    /**
     * The bandwidth of the connection (e.g., 50Mbps, 1Gbps). Required when creating a connection through AWS.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-bandwidth
     */
    readonly bandwidth?: string;
    /**
     * A description of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-description
     */
    readonly description?: string;
    /**
     * The ID of the environment for the connection.
     *
     * Required when creating a connection through AWS. Mutually exclusive with ActivationKey.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-environmentid
     */
    readonly environmentId?: string;
    /**
     * The remote account identifier for the connection.
     *
     * Required when creating a connection through AWS. Replaces RemoteOwnerAccount.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-remoteaccount
     */
    readonly remoteAccount?: cdk.IResolvable | CfnConnectionPropsMixin.RemoteAccountProperty;
    /**
     * Deprecated.
     *
     * Use RemoteAccount instead. The account ID of the remote owner. Required when creating a connection through AWS.
     *
     * @deprecated this property has been deprecated
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-remoteowneraccount
     */
    readonly remoteOwnerAccount?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-interconnect-connection.html#cfn-interconnect-connection-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
