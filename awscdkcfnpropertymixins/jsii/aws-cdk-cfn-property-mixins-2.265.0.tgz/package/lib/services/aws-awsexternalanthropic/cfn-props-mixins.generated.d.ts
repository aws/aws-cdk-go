import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-awsexternalanthropic";
/**
 * Resource type definition for AWS::AWSExternalAnthropic::Workspace.
 *
 * @cloudformationResource AWS::AWSExternalAnthropic::Workspace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-awsexternalanthropic-workspace.html
 */
export declare class CfnWorkspacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnWorkspaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::AWSExternalAnthropic::Workspace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnWorkspaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnWorkspace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnWorkspacePropsMixin {
    /**
     * Data residency configuration for the workspace.
     *
     * WorkspaceGeo is immutable after creation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-awsexternalanthropic-workspace-dataresidency.html
     */
    interface DataResidencyProperty {
        /**
         * Permitted inference geo values.
         *
         * Omit to allow all geos (the service default of 'unrestricted'); otherwise list specific geos.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-awsexternalanthropic-workspace-dataresidency.html#cfn-awsexternalanthropic-workspace-dataresidency-allowedinferencegeos
         */
        readonly allowedInferenceGeos?: Array<string>;
        /**
         * Default inference geo applied when requests omit the parameter.
         *
         * Defaults to 'global' if omitted. Must be a member of AllowedInferenceGeos unless AllowedInferenceGeos is omitted.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-awsexternalanthropic-workspace-dataresidency.html#cfn-awsexternalanthropic-workspace-dataresidency-defaultinferencegeo
         */
        readonly defaultInferenceGeo?: string;
        /**
         * Geographic region for workspace data storage.
         *
         * Immutable after creation. Defaults to 'us' if omitted.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-awsexternalanthropic-workspace-dataresidency.html#cfn-awsexternalanthropic-workspace-dataresidency-workspacegeo
         */
        readonly workspaceGeo?: string;
    }
}
/**
 * Properties for CfnWorkspacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-awsexternalanthropic-workspace.html
 */
export interface CfnWorkspaceMixinProps {
    /**
     * Data residency configuration for the workspace.
     *
     * WorkspaceGeo is immutable after creation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-awsexternalanthropic-workspace.html#cfn-awsexternalanthropic-workspace-dataresidency
     */
    readonly dataResidency?: CfnWorkspacePropsMixin.DataResidencyProperty | cdk.IResolvable;
    /**
     * The name of the workspace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-awsexternalanthropic-workspace.html#cfn-awsexternalanthropic-workspace-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-awsexternalanthropic-workspace.html#cfn-awsexternalanthropic-workspace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
