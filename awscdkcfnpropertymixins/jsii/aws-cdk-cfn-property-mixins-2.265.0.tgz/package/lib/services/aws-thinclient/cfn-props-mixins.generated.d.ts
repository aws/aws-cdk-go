import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-thinclient";
/**
 * Describes a software set for Amazon WorkSpaces Thin Client.
 *
 * @cloudformationResource AWS::ThinClient::SoftwareSet
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-thinclient-softwareset.html
 */
export declare class CfnSoftwareSetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSoftwareSetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ThinClient::SoftwareSet`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSoftwareSetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSoftwareSet;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSoftwareSetPropsMixin {
    /**
     * Describes software.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-thinclient-softwareset-software.html
     */
    interface SoftwareProperty {
        /**
         * The name of the software component.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-thinclient-softwareset-software.html#cfn-thinclient-softwareset-software-name
         */
        readonly name?: string;
        /**
         * The version of the software component.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-thinclient-softwareset-software.html#cfn-thinclient-softwareset-software-version
         */
        readonly version?: string;
    }
}
/**
 * Properties for CfnSoftwareSetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-thinclient-softwareset.html
 */
export interface CfnSoftwareSetMixinProps {
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-thinclient-softwareset.html#cfn-thinclient-softwareset-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
