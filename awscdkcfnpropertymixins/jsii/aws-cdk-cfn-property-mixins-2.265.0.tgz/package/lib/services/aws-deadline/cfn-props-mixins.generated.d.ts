import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-deadline";
/**
 * Creates a farm to allow space for queues and fleets.
 *
 * Farms are the space where the components of your renders gather and are pieced together in the cloud. Farms contain budgets and allow you to enforce permissions. Deadline Cloud farms are a useful container for large projects.
 *
 * @cloudformationResource AWS::Deadline::Farm
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html
 */
export declare class CfnFarmPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnFarmMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::Farm`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnFarmMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFarm;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnFarmPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html
 */
export interface CfnFarmMixinProps {
    /**
     * @default - 1
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html#cfn-deadline-farm-costscalefactor
     */
    readonly costScaleFactor?: number;
    /**
     * A description of the farm that helps identify what the farm is used for.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @default - ""
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html#cfn-deadline-farm-description
     */
    readonly description?: string;
    /**
     * The display name of the farm.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html#cfn-deadline-farm-displayname
     */
    readonly displayName?: string;
    /**
     * The ARN for the KMS key.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html#cfn-deadline-farm-kmskeyarn
     */
    readonly kmsKeyArn?: string;
    /**
     * The tags to add to your farm.
     *
     * Each tag consists of a tag key and a tag value. Tag keys and values are both required, but tag values can be empty strings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-farm.html#cfn-deadline-farm-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a fleet.
 *
 * Fleets gather information relating to compute, or capacity, for renders within your farms. You can choose to manage your own capacity or opt to have fleets fully managed by Deadline Cloud.
 *
 * @cloudformationResource AWS::Deadline::Fleet
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html
 */
export declare class CfnFleetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnFleetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::Fleet`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnFleetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFleet;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnFleetPropsMixin {
    /**
     * Fleet configuration details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetconfiguration.html
     */
    interface FleetConfigurationProperty {
        /**
         * The customer managed fleets within a fleet configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetconfiguration.html#cfn-deadline-fleet-fleetconfiguration-customermanaged
         */
        readonly customerManaged?: CfnFleetPropsMixin.CustomerManagedFleetConfigurationProperty | cdk.IResolvable;
        /**
         * The service managed Amazon EC2 instances for a fleet configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetconfiguration.html#cfn-deadline-fleet-fleetconfiguration-servicemanagedec2
         */
        readonly serviceManagedEc2?: cdk.IResolvable | CfnFleetPropsMixin.ServiceManagedEc2FleetConfigurationProperty;
    }
    /**
     * The configuration details for a customer managed fleet.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedfleetconfiguration.html
     */
    interface CustomerManagedFleetConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedfleetconfiguration.html#cfn-deadline-fleet-customermanagedfleetconfiguration-autoscalingconfiguration
         */
        readonly autoScalingConfiguration?: CfnFleetPropsMixin.CustomerManagedAutoScalingConfigurationProperty | cdk.IResolvable;
        /**
         * The Auto Scaling mode for the customer managed fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedfleetconfiguration.html#cfn-deadline-fleet-customermanagedfleetconfiguration-mode
         */
        readonly mode?: string;
        /**
         * The storage profile ID for the customer managed fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedfleetconfiguration.html#cfn-deadline-fleet-customermanagedfleetconfiguration-storageprofileid
         */
        readonly storageProfileId?: string;
        /**
         * The tag propagation mode for the customer managed fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedfleetconfiguration.html#cfn-deadline-fleet-customermanagedfleetconfiguration-tagpropagationmode
         */
        readonly tagPropagationMode?: string;
        /**
         * The worker capabilities for the customer managed fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedfleetconfiguration.html#cfn-deadline-fleet-customermanagedfleetconfiguration-workercapabilities
         */
        readonly workerCapabilities?: CfnFleetPropsMixin.CustomerManagedWorkerCapabilitiesProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedautoscalingconfiguration.html
     */
    interface CustomerManagedAutoScalingConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedautoscalingconfiguration.html#cfn-deadline-fleet-customermanagedautoscalingconfiguration-scaleoutworkersperminute
         */
        readonly scaleOutWorkersPerMinute?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedautoscalingconfiguration.html#cfn-deadline-fleet-customermanagedautoscalingconfiguration-standbyworkercount
         */
        readonly standbyWorkerCount?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedautoscalingconfiguration.html#cfn-deadline-fleet-customermanagedautoscalingconfiguration-workeridledurationseconds
         */
        readonly workerIdleDurationSeconds?: number;
    }
    /**
     * The worker capabilities for a customer managed workflow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html
     */
    interface CustomerManagedWorkerCapabilitiesProperty {
        /**
         * The range of the accelerator.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-acceleratorcount
         */
        readonly acceleratorCount?: CfnFleetPropsMixin.AcceleratorCountRangeProperty | cdk.IResolvable;
        /**
         * The total memory (MiB) for the customer managed worker capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-acceleratortotalmemorymib
         */
        readonly acceleratorTotalMemoryMiB?: CfnFleetPropsMixin.AcceleratorTotalMemoryMiBRangeProperty | cdk.IResolvable;
        /**
         * The accelerator types for the customer managed worker capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-acceleratortypes
         */
        readonly acceleratorTypes?: Array<string>;
        /**
         * The CPU architecture type for the customer managed worker capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-cpuarchitecturetype
         */
        readonly cpuArchitectureType?: string;
        /**
         * Custom requirement ranges for customer managed worker capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-customamounts
         */
        readonly customAmounts?: Array<CfnFleetPropsMixin.FleetAmountCapabilityProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Custom attributes for the customer manged worker capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-customattributes
         */
        readonly customAttributes?: Array<CfnFleetPropsMixin.FleetAttributeCapabilityProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The memory (MiB).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-memorymib
         */
        readonly memoryMiB?: cdk.IResolvable | CfnFleetPropsMixin.MemoryMiBRangeProperty;
        /**
         * The operating system (OS) family.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-osfamily
         */
        readonly osFamily?: string;
        /**
         * The vCPU count for the customer manged worker capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-customermanagedworkercapabilities.html#cfn-deadline-fleet-customermanagedworkercapabilities-vcpucount
         */
        readonly vCpuCount?: cdk.IResolvable | CfnFleetPropsMixin.VCpuCountRangeProperty;
    }
    /**
     * The allowable range of vCPU processing power for the fleet.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-vcpucountrange.html
     */
    interface VCpuCountRangeProperty {
        /**
         * The maximum amount of vCPU.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-vcpucountrange.html#cfn-deadline-fleet-vcpucountrange-max
         */
        readonly max?: number;
        /**
         * The minimum amount of vCPU.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-vcpucountrange.html#cfn-deadline-fleet-vcpucountrange-min
         */
        readonly min?: number;
    }
    /**
     * The range of memory in MiB.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-memorymibrange.html
     */
    interface MemoryMiBRangeProperty {
        /**
         * The maximum amount of memory (in MiB).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-memorymibrange.html#cfn-deadline-fleet-memorymibrange-max
         */
        readonly max?: number;
        /**
         * The minimum amount of memory (in MiB).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-memorymibrange.html#cfn-deadline-fleet-memorymibrange-min
         */
        readonly min?: number;
    }
    /**
     * Defines the maximum and minimum number of GPU accelerators required for a worker instance..
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorcountrange.html
     */
    interface AcceleratorCountRangeProperty {
        /**
         * The maximum number of GPU accelerators in the worker host.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorcountrange.html#cfn-deadline-fleet-acceleratorcountrange-max
         */
        readonly max?: number;
        /**
         * The minimum number of GPU accelerators in the worker host.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorcountrange.html#cfn-deadline-fleet-acceleratorcountrange-min
         */
        readonly min?: number;
    }
    /**
     * Defines the maximum and minimum amount of memory, in MiB, to use for the accelerator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratortotalmemorymibrange.html
     */
    interface AcceleratorTotalMemoryMiBRangeProperty {
        /**
         * The maximum amount of memory to use for the accelerator, measured in MiB.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratortotalmemorymibrange.html#cfn-deadline-fleet-acceleratortotalmemorymibrange-max
         */
        readonly max?: number;
        /**
         * The minimum amount of memory to use for the accelerator, measured in MiB.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratortotalmemorymibrange.html#cfn-deadline-fleet-acceleratortotalmemorymibrange-min
         */
        readonly min?: number;
    }
    /**
     * The fleet amount and attribute capabilities.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetamountcapability.html
     */
    interface FleetAmountCapabilityProperty {
        /**
         * The maximum amount of the fleet worker capability.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetamountcapability.html#cfn-deadline-fleet-fleetamountcapability-max
         */
        readonly max?: number;
        /**
         * The minimum amount of fleet worker capability.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetamountcapability.html#cfn-deadline-fleet-fleetamountcapability-min
         */
        readonly min?: number;
        /**
         * The name of the fleet capability.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetamountcapability.html#cfn-deadline-fleet-fleetamountcapability-name
         */
        readonly name?: string;
    }
    /**
     * Defines the fleet's capability name, minimum, and maximum.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetattributecapability.html
     */
    interface FleetAttributeCapabilityProperty {
        /**
         * The name of the fleet attribute capability for the worker.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetattributecapability.html#cfn-deadline-fleet-fleetattributecapability-name
         */
        readonly name?: string;
        /**
         * The number of fleet attribute capabilities.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetattributecapability.html#cfn-deadline-fleet-fleetattributecapability-values
         */
        readonly values?: Array<string>;
    }
    /**
     * The configuration details for a service managed EC2 fleet.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html
     */
    interface ServiceManagedEc2FleetConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html#cfn-deadline-fleet-servicemanagedec2fleetconfiguration-autoscalingconfiguration
         */
        readonly autoScalingConfiguration?: cdk.IResolvable | CfnFleetPropsMixin.ServiceManagedEc2AutoScalingConfigurationProperty;
        /**
         * The instance capabilities for the service managed EC2 fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html#cfn-deadline-fleet-servicemanagedec2fleetconfiguration-instancecapabilities
         */
        readonly instanceCapabilities?: cdk.IResolvable | CfnFleetPropsMixin.ServiceManagedEc2InstanceCapabilitiesProperty;
        /**
         * The instance market options for the service managed EC2 fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html#cfn-deadline-fleet-servicemanagedec2fleetconfiguration-instancemarketoptions
         */
        readonly instanceMarketOptions?: cdk.IResolvable | CfnFleetPropsMixin.ServiceManagedEc2InstanceMarketOptionsProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html#cfn-deadline-fleet-servicemanagedec2fleetconfiguration-persistentvolumeconfiguration
         */
        readonly persistentVolumeConfiguration?: cdk.IResolvable | CfnFleetPropsMixin.PersistentVolumeConfigurationProperty;
        /**
         * The storage profile ID for the service managed EC2 fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html#cfn-deadline-fleet-servicemanagedec2fleetconfiguration-storageprofileid
         */
        readonly storageProfileId?: string;
        /**
         * The VPC configuration for the service managed EC2 fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2fleetconfiguration.html#cfn-deadline-fleet-servicemanagedec2fleetconfiguration-vpcconfiguration
         */
        readonly vpcConfiguration?: cdk.IResolvable | CfnFleetPropsMixin.VpcConfigurationProperty;
    }
    /**
     * The Amazon EC2 instance capabilities.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html
     */
    interface ServiceManagedEc2InstanceCapabilitiesProperty {
        /**
         * Describes the GPU accelerator capabilities required for worker host instances in this fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-acceleratorcapabilities
         */
        readonly acceleratorCapabilities?: CfnFleetPropsMixin.AcceleratorCapabilitiesProperty | cdk.IResolvable;
        /**
         * The allowable Amazon EC2 instance types.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-allowedinstancetypes
         */
        readonly allowedInstanceTypes?: Array<string>;
        /**
         * The CPU architecture type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-cpuarchitecturetype
         */
        readonly cpuArchitectureType?: string;
        /**
         * The custom capability amounts to require for instances in this fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-customamounts
         */
        readonly customAmounts?: Array<CfnFleetPropsMixin.FleetAmountCapabilityProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The custom capability attributes to require for instances in this fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-customattributes
         */
        readonly customAttributes?: Array<CfnFleetPropsMixin.FleetAttributeCapabilityProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The instance types to exclude from the fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-excludedinstancetypes
         */
        readonly excludedInstanceTypes?: Array<string>;
        /**
         * The memory, as MiB, for the Amazon EC2 instance type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-memorymib
         */
        readonly memoryMiB?: cdk.IResolvable | CfnFleetPropsMixin.MemoryMiBRangeProperty;
        /**
         * The operating system (OS) family.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-osfamily
         */
        readonly osFamily?: string;
        /**
         * The root EBS volume.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-rootebsvolume
         */
        readonly rootEbsVolume?: CfnFleetPropsMixin.Ec2EbsVolumeProperty | cdk.IResolvable;
        /**
         * The amount of vCPU to require for instances in this fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancecapabilities.html#cfn-deadline-fleet-servicemanagedec2instancecapabilities-vcpucount
         */
        readonly vCpuCount?: cdk.IResolvable | CfnFleetPropsMixin.VCpuCountRangeProperty;
    }
    /**
     * Specifies the EBS volume.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-ec2ebsvolume.html
     */
    interface Ec2EbsVolumeProperty {
        /**
         * The IOPS per volume.
         *
         * @default - 3000
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-ec2ebsvolume.html#cfn-deadline-fleet-ec2ebsvolume-iops
         */
        readonly iops?: number;
        /**
         * The EBS volume size in GiB.
         *
         * @default - 250
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-ec2ebsvolume.html#cfn-deadline-fleet-ec2ebsvolume-sizegib
         */
        readonly sizeGiB?: number;
        /**
         * The throughput per volume in MiB.
         *
         * @default - 125
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-ec2ebsvolume.html#cfn-deadline-fleet-ec2ebsvolume-throughputmib
         */
        readonly throughputMiB?: number;
    }
    /**
     * Provides information about the GPU accelerators used for jobs processed by a fleet.
     *
     * > Accelerator capabilities cannot be used with wait-and-save fleets. If you specify accelerator capabilities, you must use either spot or on-demand instance market options. > Each accelerator type maps to specific EC2 instance families:
     * >
     * > - `t4` : Uses G4dn instance family
     * > - `a10g` : Uses G5 instance family
     * > - `l4` : Uses G6 and Gr6 instance families
     * > - `l40s` : Uses G6e instance family
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorcapabilities.html
     */
    interface AcceleratorCapabilitiesProperty {
        /**
         * The number of GPU accelerators specified for worker hosts in this fleet.
         *
         * > You must specify either `acceleratorCapabilities.count.max` or `allowedInstanceTypes` when using accelerator capabilities. If you don't specify a maximum count, AWS Deadline Cloud uses the instance types you specify in `allowedInstanceTypes` to determine the maximum number of accelerators.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorcapabilities.html#cfn-deadline-fleet-acceleratorcapabilities-count
         */
        readonly count?: CfnFleetPropsMixin.AcceleratorCountRangeProperty | cdk.IResolvable;
        /**
         * A list of accelerator capabilities requested for this fleet.
         *
         * Only Amazon Elastic Compute Cloud instances that provide these capabilities will be used. For example, if you specify both L4 and T4 chips, AWS Deadline Cloud will use Amazon EC2 instances that have either the L4 or the T4 chip installed.
         *
         * > - You must specify at least one accelerator selection.
         * > - You cannot specify the same accelerator name multiple times in the selections list.
         * > - All accelerators in the selections must use the same runtime version.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorcapabilities.html#cfn-deadline-fleet-acceleratorcapabilities-selections
         */
        readonly selections?: Array<CfnFleetPropsMixin.AcceleratorSelectionProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Describes a specific GPU accelerator required for an Amazon Elastic Compute Cloud worker host.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorselection.html
     */
    interface AcceleratorSelectionProperty {
        /**
         * The name of the chip used by the GPU accelerator.
         *
         * The available GPU accelerators are:
         *
         * - `t4` - NVIDIA T4 Tensor Core GPU (16 GiB memory)
         * - `a10g` - NVIDIA A10G Tensor Core GPU (24 GiB memory)
         * - `l4` - NVIDIA L4 Tensor Core GPU (24 GiB memory)
         * - `l40s` - NVIDIA L40S Tensor Core GPU (48 GiB memory)
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorselection.html#cfn-deadline-fleet-acceleratorselection-name
         */
        readonly name?: string;
        /**
         * Specifies the runtime driver to use for the GPU accelerator.
         *
         * You must use the same runtime for all GPUs in a fleet.
         *
         * You can choose from the following runtimes:
         *
         * - `latest` - Use the latest runtime available for the chip. If you specify `latest` and a new version of the runtime is released, the new version of the runtime is used.
         * - `grid:r570` - [NVIDIA vGPU software 18](https://docs.aws.amazon.com/https://docs.nvidia.com/vgpu/18.0/index.html)
         * - `grid:r535` - [NVIDIA vGPU software 16](https://docs.aws.amazon.com/https://docs.nvidia.com/vgpu/16.0/index.html)
         *
         * If you don't specify a runtime, AWS Deadline Cloud uses `latest` as the default. However, if you have multiple accelerators and specify `latest` for some and leave others blank, AWS Deadline Cloud raises an exception.
         *
         * > Not all runtimes are compatible with all accelerator types:
         * >
         * > - `t4` and `a10g` : Support all runtimes ( `grid:r570` , `grid:r535` )
         * > - `l4` and `l40s` : Only support `grid:r570` and newer
         * >
         * > All accelerators in a fleet must use the same runtime version. You cannot mix different runtime versions within a single fleet. > When you specify `latest` , it resolves to `grid:r570` for all currently supported accelerators.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-acceleratorselection.html#cfn-deadline-fleet-acceleratorselection-runtime
         */
        readonly runtime?: string;
    }
    /**
     * The details of the Amazon EC2 instance market options for a service managed fleet.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancemarketoptions.html
     */
    interface ServiceManagedEc2InstanceMarketOptionsProperty {
        /**
         * The Amazon EC2 instance type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2instancemarketoptions.html#cfn-deadline-fleet-servicemanagedec2instancemarketoptions-type
         */
        readonly type?: string;
    }
    /**
     * The configuration options for a service managed fleet's VPC.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-vpcconfiguration.html
     */
    interface VpcConfigurationProperty {
        /**
         * The ARNs of the VPC Lattice resource configurations attached to the fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-vpcconfiguration.html#cfn-deadline-fleet-vpcconfiguration-resourceconfigurationarns
         */
        readonly resourceConfigurationArns?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-persistentvolumeconfiguration.html
     */
    interface PersistentVolumeConfigurationProperty {
        /**
         * @default - 3000
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-persistentvolumeconfiguration.html#cfn-deadline-fleet-persistentvolumeconfiguration-iops
         */
        readonly iops?: number;
        /**
         * @default - 168
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-persistentvolumeconfiguration.html#cfn-deadline-fleet-persistentvolumeconfiguration-lastusedttlhours
         */
        readonly lastUsedTtlHours?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-persistentvolumeconfiguration.html#cfn-deadline-fleet-persistentvolumeconfiguration-mountpath
         */
        readonly mountPath?: string;
        /**
         * @default - 250
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-persistentvolumeconfiguration.html#cfn-deadline-fleet-persistentvolumeconfiguration-sizegib
         */
        readonly sizeGiB?: number;
        /**
         * @default - 125
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-persistentvolumeconfiguration.html#cfn-deadline-fleet-persistentvolumeconfiguration-throughputmib
         */
        readonly throughputMiB?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2autoscalingconfiguration.html
     */
    interface ServiceManagedEc2AutoScalingConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2autoscalingconfiguration.html#cfn-deadline-fleet-servicemanagedec2autoscalingconfiguration-scaleoutworkersperminute
         */
        readonly scaleOutWorkersPerMinute?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2autoscalingconfiguration.html#cfn-deadline-fleet-servicemanagedec2autoscalingconfiguration-standbyworkercount
         */
        readonly standbyWorkerCount?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-servicemanagedec2autoscalingconfiguration.html#cfn-deadline-fleet-servicemanagedec2autoscalingconfiguration-workeridledurationseconds
         */
        readonly workerIdleDurationSeconds?: number;
    }
    /**
     * Provides a script that runs as a worker is starting up that you can use to provide additional configuration for workers in your fleet.
     *
     * To remove a script from a fleet, use the [UpdateFleet](https://docs.aws.amazon.com/deadline-cloud/latest/APIReference/API_UpdateFleet.html) operation with the `hostConfiguration` `scriptBody` parameter set to an empty string ("").
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-hostconfiguration.html
     */
    interface HostConfigurationProperty {
        /**
         * The text of the script that runs as a worker is starting up that you can use to provide additional configuration for workers in your fleet.
         *
         * The script runs after a worker enters the `STARTING` state and before the worker processes tasks.
         *
         * For more information about using the script, see [Run scripts as an administrator to configure workers](https://docs.aws.amazon.com/deadline-cloud/latest/developerguide/smf-admin.html) in the *Deadline Cloud Developer Guide* .
         *
         * > The script runs as an administrative user ( `sudo root` on Linux, as an Administrator on Windows).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-hostconfiguration.html#cfn-deadline-fleet-hostconfiguration-scriptbody
         */
        readonly scriptBody?: string;
        /**
         * The maximum time that the host configuration can run.
         *
         * If the timeout expires, the worker enters the `NOT RESPONDING` state and shuts down. You are charged for the time that the worker is running the host configuration script.
         *
         * > You should configure your fleet for a maximum of one worker while testing your host configuration script to avoid starting additional workers.
         *
         * The default is 300 seconds (5 minutes).
         *
         * @default - 300
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-hostconfiguration.html#cfn-deadline-fleet-hostconfiguration-scripttimeoutseconds
         */
        readonly scriptTimeoutSeconds?: number;
    }
    /**
     * The amounts and attributes of fleets.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetcapabilities.html
     */
    interface FleetCapabilitiesProperty {
        /**
         * Amount capabilities of the fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetcapabilities.html#cfn-deadline-fleet-fleetcapabilities-amounts
         */
        readonly amounts?: Array<CfnFleetPropsMixin.FleetAmountCapabilityProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Attribute capabilities of the fleet.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-fleet-fleetcapabilities.html#cfn-deadline-fleet-fleetcapabilities-attributes
         */
        readonly attributes?: Array<CfnFleetPropsMixin.FleetAttributeCapabilityProperty | cdk.IResolvable> | cdk.IResolvable;
    }
}
/**
 * Properties for CfnFleetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html
 */
export interface CfnFleetMixinProps {
    /**
     * The configuration details for the fleet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-configuration
     */
    readonly configuration?: CfnFleetPropsMixin.FleetConfigurationProperty | cdk.IResolvable;
    /**
     * A description that helps identify what the fleet is used for.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @default - ""
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-description
     */
    readonly description?: string;
    /**
     * The display name of the fleet summary to update.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-displayname
     */
    readonly displayName?: string;
    /**
     * The farm ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-farmid
     */
    readonly farmId?: string;
    /**
     * Provides a script that runs as a worker is starting up that you can use to provide additional configuration for workers in your fleet.
     *
     * To remove a script from a fleet, use the [UpdateFleet](https://docs.aws.amazon.com/deadline-cloud/latest/APIReference/API_UpdateFleet.html) operation with the `hostConfiguration` `scriptBody` parameter set to an empty string ("").
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-hostconfiguration
     */
    readonly hostConfiguration?: CfnFleetPropsMixin.HostConfigurationProperty | cdk.IResolvable;
    /**
     * The maximum number of workers specified in the fleet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-maxworkercount
     */
    readonly maxWorkerCount?: number;
    /**
     * The minimum number of workers in the fleet.
     *
     * @default - 0
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-minworkercount
     */
    readonly minWorkerCount?: number;
    /**
     * The IAM role that workers in the fleet use when processing jobs.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-rolearn
     */
    readonly roleArn?: string;
    /**
     * The tags to add to your fleet.
     *
     * Each tag consists of a tag key and a tag value. Tag keys and values are both required, but tag values can be empty strings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-fleet.html#cfn-deadline-fleet-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a license endpoint to integrate your various licensed software used for rendering on Deadline Cloud.
 *
 * @cloudformationResource AWS::Deadline::LicenseEndpoint
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-licenseendpoint.html
 */
export declare class CfnLicenseEndpointPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLicenseEndpointMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::LicenseEndpoint`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLicenseEndpointMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLicenseEndpoint;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnLicenseEndpointPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-licenseendpoint.html
 */
export interface CfnLicenseEndpointMixinProps {
    /**
     * The identifier of the Amazon EC2 security group that controls access to the license endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-licenseendpoint.html#cfn-deadline-licenseendpoint-securitygroupids
     */
    readonly securityGroupIds?: Array<string>;
    /**
     * Identifies the VPC subnets that can connect to a license endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-licenseendpoint.html#cfn-deadline-licenseendpoint-subnetids
     */
    readonly subnetIds?: Array<string>;
    /**
     * The tags to add to your license endpoint.
     *
     * Each tag consists of a tag key and a tag value. Tag keys and values are both required, but tag values can be empty strings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-licenseendpoint.html#cfn-deadline-licenseendpoint-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The VPC (virtual private cloud) ID associated with the license endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-licenseendpoint.html#cfn-deadline-licenseendpoint-vpcid
     */
    readonly vpcId?: string;
}
/**
 * Creates a limit that manages the distribution of shared resources, such as floating licenses.
 *
 * A limit can throttle work assignments, help manage workloads, and track current usage. Before you use a limit, you must associate the limit with one or more queues.
 *
 * You must add the `amountRequirementName` to a step in a job template to declare the limit requirement.
 *
 * @cloudformationResource AWS::Deadline::Limit
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html
 */
export declare class CfnLimitPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLimitMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::Limit`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLimitMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLimit;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnLimitPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html
 */
export interface CfnLimitMixinProps {
    /**
     * The value that you specify as the `name` in the `amounts` field of the `hostRequirements` in a step of a job template to declare the limit requirement.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html#cfn-deadline-limit-amountrequirementname
     */
    readonly amountRequirementName?: string;
    /**
     * A description of the limit. A clear description helps you identify the purpose of the limit.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @default - ""
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html#cfn-deadline-limit-description
     */
    readonly description?: string;
    /**
     * The name of the limit used in lists to identify the limit.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html#cfn-deadline-limit-displayname
     */
    readonly displayName?: string;
    /**
     * The unique identifier of the farm that contains the limit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html#cfn-deadline-limit-farmid
     */
    readonly farmId?: string;
    /**
     * The maximum number of resources constrained by this limit.
     *
     * When all of the resources are in use, steps that require the limit won't be scheduled until the resource is available.
     *
     * The `maxValue` must not be 0. If the value is -1, there is no restriction on the number of resources that can be acquired for this limit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-limit.html#cfn-deadline-limit-maxcount
     */
    readonly maxCount?: number;
}
/**
 * Adds a metered product.
 *
 * @cloudformationResource AWS::Deadline::MeteredProduct
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-meteredproduct.html
 */
export declare class CfnMeteredProductPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMeteredProductMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::MeteredProduct`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMeteredProductMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMeteredProduct;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnMeteredProductPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-meteredproduct.html
 */
export interface CfnMeteredProductMixinProps {
    /**
     * The Amazon EC2 identifier of the license endpoint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-meteredproduct.html#cfn-deadline-meteredproduct-licenseendpointid
     */
    readonly licenseEndpointId?: string;
    /**
     * The product ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-meteredproduct.html#cfn-deadline-meteredproduct-productid
     */
    readonly productId?: string;
}
/**
 * Creates an AWS Deadline Cloud monitor that you can use to view your farms, queues, and fleets.
 *
 * After you submit a job, you can track the progress of the tasks and steps that make up the job, and then download the job's results.
 *
 * @cloudformationResource AWS::Deadline::Monitor
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html
 */
export declare class CfnMonitorPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMonitorMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::Monitor`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMonitorMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMonitor;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnMonitorPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html
 */
export interface CfnMonitorMixinProps {
    /**
     * The name of the monitor that displays on the Deadline Cloud console.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html#cfn-deadline-monitor-displayname
     */
    readonly displayName?: string;
    /**
     * The Amazon Resource Name of the IAM Identity Center instance responsible for authenticating monitor users.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html#cfn-deadline-monitor-identitycenterinstancearn
     */
    readonly identityCenterInstanceArn?: string;
    /**
     * The AWS region where IAM Identity Center is enabled.
     *
     * Required when Identity Center is in a different region than the monitor.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html#cfn-deadline-monitor-identitycenterregion
     */
    readonly identityCenterRegion?: string;
    /**
     * The Amazon Resource Name of the IAM role for the monitor.
     *
     * Users of the monitor use this role to access Deadline Cloud resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html#cfn-deadline-monitor-rolearn
     */
    readonly roleArn?: string;
    /**
     * The subdomain used for the monitor URL.
     *
     * The full URL of the monitor is subdomain.Region.deadlinecloud.amazonaws.com.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html#cfn-deadline-monitor-subdomain
     */
    readonly subdomain?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-monitor.html#cfn-deadline-monitor-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a queue to coordinate the order in which jobs run on a farm.
 *
 * A queue can also specify where to pull resources and indicate where to output completed jobs.
 *
 * @cloudformationResource AWS::Deadline::Queue
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html
 */
export declare class CfnQueuePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnQueueMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::Queue`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnQueueMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnQueue;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnQueuePropsMixin {
    /**
     * The job attachment settings.
     *
     * These are the Amazon S3 bucket name and the Amazon S3 prefix.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobattachmentsettings.html
     */
    interface JobAttachmentSettingsProperty {
        /**
         * The root prefix.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobattachmentsettings.html#cfn-deadline-queue-jobattachmentsettings-rootprefix
         */
        readonly rootPrefix?: string;
        /**
         * The Amazon S3 bucket name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobattachmentsettings.html#cfn-deadline-queue-jobattachmentsettings-s3bucketname
         */
        readonly s3BucketName?: string;
    }
    /**
     * Identifies the user for a job.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobrunasuser.html
     */
    interface JobRunAsUserProperty {
        /**
         * The user and group that the jobs in the queue run as.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobrunasuser.html#cfn-deadline-queue-jobrunasuser-posix
         */
        readonly posix?: cdk.IResolvable | CfnQueuePropsMixin.PosixUserProperty;
        /**
         * Specifies whether the job should run using the queue's system user or if the job should run using the worker agent system user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobrunasuser.html#cfn-deadline-queue-jobrunasuser-runas
         */
        readonly runAs?: string;
        /**
         * Identifies a Microsoft Windows user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-jobrunasuser.html#cfn-deadline-queue-jobrunasuser-windows
         */
        readonly windows?: cdk.IResolvable | CfnQueuePropsMixin.WindowsUserProperty;
    }
    /**
     * The POSIX user.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-posixuser.html
     */
    interface PosixUserProperty {
        /**
         * The name of the POSIX user's group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-posixuser.html#cfn-deadline-queue-posixuser-group
         */
        readonly group?: string;
        /**
         * The name of the POSIX user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-posixuser.html#cfn-deadline-queue-posixuser-user
         */
        readonly user?: string;
    }
    /**
     * The Windows user details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-windowsuser.html
     */
    interface WindowsUserProperty {
        /**
         * The password ARN for the Windows user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-windowsuser.html#cfn-deadline-queue-windowsuser-passwordarn
         */
        readonly passwordArn?: string;
        /**
         * The user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-windowsuser.html#cfn-deadline-queue-windowsuser-user
         */
        readonly user?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingconfiguration.html
     */
    interface SchedulingConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingconfiguration.html#cfn-deadline-queue-schedulingconfiguration-prioritybalanced
         */
        readonly priorityBalanced?: cdk.IResolvable | CfnQueuePropsMixin.PriorityBalancedSchedulingConfigurationProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingconfiguration.html#cfn-deadline-queue-schedulingconfiguration-priorityfifo
         */
        readonly priorityFifo?: any | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingconfiguration.html#cfn-deadline-queue-schedulingconfiguration-weightedbalanced
         */
        readonly weightedBalanced?: cdk.IResolvable | CfnQueuePropsMixin.WeightedBalancedSchedulingConfigurationProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-prioritybalancedschedulingconfiguration.html
     */
    interface PriorityBalancedSchedulingConfigurationProperty {
        /**
         * @default - 1
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-prioritybalancedschedulingconfiguration.html#cfn-deadline-queue-prioritybalancedschedulingconfiguration-renderingtaskbuffer
         */
        readonly renderingTaskBuffer?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html
     */
    interface WeightedBalancedSchedulingConfigurationProperty {
        /**
         * @default - -10
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-errorweight
         */
        readonly errorWeight?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-maxpriorityoverride
         */
        readonly maxPriorityOverride?: cdk.IResolvable | CfnQueuePropsMixin.SchedulingMaxPriorityOverrideProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-minpriorityoverride
         */
        readonly minPriorityOverride?: cdk.IResolvable | CfnQueuePropsMixin.SchedulingMinPriorityOverrideProperty;
        /**
         * @default - 100
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-priorityweight
         */
        readonly priorityWeight?: number;
        /**
         * @default - 1
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-renderingtaskbuffer
         */
        readonly renderingTaskBuffer?: number;
        /**
         * @default - -100
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-renderingtaskweight
         */
        readonly renderingTaskWeight?: number;
        /**
         * @default - 3
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-weightedbalancedschedulingconfiguration.html#cfn-deadline-queue-weightedbalancedschedulingconfiguration-submissiontimeweight
         */
        readonly submissionTimeWeight?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingmaxpriorityoverride.html
     */
    interface SchedulingMaxPriorityOverrideProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingmaxpriorityoverride.html#cfn-deadline-queue-schedulingmaxpriorityoverride-alwaysschedulefirst
         */
        readonly alwaysScheduleFirst?: any | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingminpriorityoverride.html
     */
    interface SchedulingMinPriorityOverrideProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-queue-schedulingminpriorityoverride.html#cfn-deadline-queue-schedulingminpriorityoverride-alwaysschedulelast
         */
        readonly alwaysScheduleLast?: any | cdk.IResolvable;
    }
}
/**
 * Properties for CfnQueuePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html
 */
export interface CfnQueueMixinProps {
    /**
     * The identifiers of the storage profiles that this queue can use to share assets between workers using different operating systems.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-allowedstorageprofileids
     */
    readonly allowedStorageProfileIds?: Array<string>;
    /**
     * The default action taken on a queue summary if a budget wasn't configured.
     *
     * @default - "NONE"
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-defaultbudgetaction
     */
    readonly defaultBudgetAction?: string;
    /**
     * A description of the queue that helps identify what the queue is used for.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @default - ""
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-description
     */
    readonly description?: string;
    /**
     * The display name of the queue summary to update.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-displayname
     */
    readonly displayName?: string;
    /**
     * The farm ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-farmid
     */
    readonly farmId?: string;
    /**
     * The job attachment settings.
     *
     * These are the Amazon S3 bucket name and the Amazon S3 prefix.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-jobattachmentsettings
     */
    readonly jobAttachmentSettings?: cdk.IResolvable | CfnQueuePropsMixin.JobAttachmentSettingsProperty;
    /**
     * Identifies the user for a job.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-jobrunasuser
     */
    readonly jobRunAsUser?: cdk.IResolvable | CfnQueuePropsMixin.JobRunAsUserProperty;
    /**
     * The file system location that the queue uses.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-requiredfilesystemlocationnames
     */
    readonly requiredFileSystemLocationNames?: Array<string>;
    /**
     * The Amazon Resource Name (ARN) of the IAM role that workers use when running jobs in this queue.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-rolearn
     */
    readonly roleArn?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-schedulingconfiguration
     */
    readonly schedulingConfiguration?: cdk.IResolvable | CfnQueuePropsMixin.SchedulingConfigurationProperty;
    /**
     * The tags to add to your queue.
     *
     * Each tag consists of a tag key and a tag value. Tag keys and values are both required, but tag values can be empty strings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queue.html#cfn-deadline-queue-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates an environment for a queue that defines how jobs in the queue run.
 *
 * @cloudformationResource AWS::Deadline::QueueEnvironment
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html
 */
export declare class CfnQueueEnvironmentPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnQueueEnvironmentMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::QueueEnvironment`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnQueueEnvironmentMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnQueueEnvironment;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnQueueEnvironmentPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html
 */
export interface CfnQueueEnvironmentMixinProps {
    /**
     * The identifier assigned to the farm that contains the queue.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html#cfn-deadline-queueenvironment-farmid
     */
    readonly farmId?: string;
    /**
     * The queue environment's priority.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html#cfn-deadline-queueenvironment-priority
     */
    readonly priority?: number;
    /**
     * The unique identifier of the queue that contains the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html#cfn-deadline-queueenvironment-queueid
     */
    readonly queueId?: string;
    /**
     * A JSON or YAML template that describes the processing environment for the queue.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html#cfn-deadline-queueenvironment-template
     */
    readonly template?: string;
    /**
     * Specifies whether the template for the queue environment is JSON or YAML.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queueenvironment.html#cfn-deadline-queueenvironment-templatetype
     */
    readonly templateType?: string;
}
/**
 * Creates an association between a queue and a fleet.
 *
 * @cloudformationResource AWS::Deadline::QueueFleetAssociation
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuefleetassociation.html
 */
export declare class CfnQueueFleetAssociationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnQueueFleetAssociationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::QueueFleetAssociation`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnQueueFleetAssociationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnQueueFleetAssociation;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnQueueFleetAssociationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuefleetassociation.html
 */
export interface CfnQueueFleetAssociationMixinProps {
    /**
     * The identifier of the farm that contains the queue and the fleet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuefleetassociation.html#cfn-deadline-queuefleetassociation-farmid
     */
    readonly farmId?: string;
    /**
     * The fleet ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuefleetassociation.html#cfn-deadline-queuefleetassociation-fleetid
     */
    readonly fleetId?: string;
    /**
     * The queue ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuefleetassociation.html#cfn-deadline-queuefleetassociation-queueid
     */
    readonly queueId?: string;
}
/**
 * Associates a limit with a particular queue.
 *
 * After the limit is associated, all workers for jobs that specify the limit associated with the queue are subject to the limit. You can't associate two limits with the same `amountRequirementName` to the same queue.
 *
 * @cloudformationResource AWS::Deadline::QueueLimitAssociation
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuelimitassociation.html
 */
export declare class CfnQueueLimitAssociationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnQueueLimitAssociationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::QueueLimitAssociation`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnQueueLimitAssociationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnQueueLimitAssociation;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnQueueLimitAssociationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuelimitassociation.html
 */
export interface CfnQueueLimitAssociationMixinProps {
    /**
     * The unique identifier of the farm that contains the queue-limit association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuelimitassociation.html#cfn-deadline-queuelimitassociation-farmid
     */
    readonly farmId?: string;
    /**
     * The unique identifier of the limit in the association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuelimitassociation.html#cfn-deadline-queuelimitassociation-limitid
     */
    readonly limitId?: string;
    /**
     * The unique identifier of the queue in the association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-queuelimitassociation.html#cfn-deadline-queuelimitassociation-queueid
     */
    readonly queueId?: string;
}
/**
 * Creates a storage profile that specifies the operating system, file type, and file location of resources used on a farm.
 *
 * @cloudformationResource AWS::Deadline::StorageProfile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-storageprofile.html
 */
export declare class CfnStorageProfilePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnStorageProfileMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Deadline::StorageProfile`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnStorageProfileMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnStorageProfile;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnStorageProfilePropsMixin {
    /**
     * The details of the file system location for the resource.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-storageprofile-filesystemlocation.html
     */
    interface FileSystemLocationProperty {
        /**
         * The location name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-storageprofile-filesystemlocation.html#cfn-deadline-storageprofile-filesystemlocation-name
         */
        readonly name?: string;
        /**
         * The file path.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-storageprofile-filesystemlocation.html#cfn-deadline-storageprofile-filesystemlocation-path
         */
        readonly path?: string;
        /**
         * The type of file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-deadline-storageprofile-filesystemlocation.html#cfn-deadline-storageprofile-filesystemlocation-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnStorageProfilePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-storageprofile.html
 */
export interface CfnStorageProfileMixinProps {
    /**
     * The display name of the storage profile summary to update.
     *
     * > This field can store any content. Escape or encode this content before displaying it on a webpage or any other system that might interpret the content of this field.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-storageprofile.html#cfn-deadline-storageprofile-displayname
     */
    readonly displayName?: string;
    /**
     * The unique identifier of the farm that contains the storage profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-storageprofile.html#cfn-deadline-storageprofile-farmid
     */
    readonly farmId?: string;
    /**
     * Operating system specific file system path to the storage location.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-storageprofile.html#cfn-deadline-storageprofile-filesystemlocations
     */
    readonly fileSystemLocations?: Array<CfnStorageProfilePropsMixin.FileSystemLocationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The operating system (OS) family.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-deadline-storageprofile.html#cfn-deadline-storageprofile-osfamily
     */
    readonly osFamily?: string;
}
