import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-mpa";
/**
 * Creates a new approval team.
 *
 * For more information, see [Approval team](https://docs.aws.amazon.com/mpa/latest/userguide/mpa-concepts.html) in the *Multi-party approval User Guide* .
 *
 * @cloudformationResource AWS::MPA::ApprovalTeam
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html
 */
export declare class CfnApprovalTeamPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnApprovalTeamMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MPA::ApprovalTeam`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnApprovalTeamMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnApprovalTeam;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnApprovalTeamPropsMixin {
    /**
     * Strategy for how an approval team grants approval.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approvalstrategy.html
     */
    interface ApprovalStrategyProperty {
        /**
         * Minimum number of approvals (M) required for a total number of approvers (N).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approvalstrategy.html#cfn-mpa-approvalteam-approvalstrategy-mofn
         */
        readonly mofN?: cdk.IResolvable | CfnApprovalTeamPropsMixin.MofNApprovalStrategyProperty;
    }
    /**
     * Strategy for how an approval team grants approval.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-mofnapprovalstrategy.html
     */
    interface MofNApprovalStrategyProperty {
        /**
         * Minimum number of approvals (M) required for a total number of approvers (N).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-mofnapprovalstrategy.html#cfn-mpa-approvalteam-mofnapprovalstrategy-minapprovalsrequired
         */
        readonly minApprovalsRequired?: number;
    }
    /**
     * Contains details for an approver.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approver.html
     */
    interface ApproverProperty {
        /**
         * ID for the approver.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approver.html#cfn-mpa-approvalteam-approver-approverid
         */
        readonly approverId?: string;
        /**
         * ID for the user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approver.html#cfn-mpa-approvalteam-approver-primaryidentityid
         */
        readonly primaryIdentityId?: string;
        /**
         * Amazon Resource Name (ARN) for the identity source.
         *
         * The identity source manages the user authentication for approvers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approver.html#cfn-mpa-approvalteam-approver-primaryidentitysourcearn
         */
        readonly primaryIdentitySourceArn?: string;
        /**
         * Status for the identity source.
         *
         * For example, if an approver has accepted a team invitation with a user authentication method managed by the identity source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approver.html#cfn-mpa-approvalteam-approver-primaryidentitystatus
         */
        readonly primaryIdentityStatus?: string;
        /**
         * Timestamp when the approver responded to an approval team invitation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-approver.html#cfn-mpa-approvalteam-approver-responsetime
         */
        readonly responseTime?: string;
    }
    /**
     * Contains details for a policy.
     *
     * Policies define what operations a team that define the permissions for team resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-policy.html
     */
    interface PolicyProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-approvalteam-policy.html#cfn-mpa-approvalteam-policy-policyarn
         */
        readonly policyArn?: string;
    }
}
/**
 * Properties for CfnApprovalTeamPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html
 */
export interface CfnApprovalTeamMixinProps {
    /**
     * Contains details for how an approval team grants approval.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html#cfn-mpa-approvalteam-approvalstrategy
     */
    readonly approvalStrategy?: CfnApprovalTeamPropsMixin.ApprovalStrategyProperty | cdk.IResolvable;
    /**
     * Contains details for an approver.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html#cfn-mpa-approvalteam-approvers
     */
    readonly approvers?: Array<CfnApprovalTeamPropsMixin.ApproverProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Description for the team.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html#cfn-mpa-approvalteam-description
     */
    readonly description?: string;
    /**
     * Name of the team.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html#cfn-mpa-approvalteam-name
     */
    readonly name?: string;
    /**
     * Contains details for a policy.
     *
     * Policies define what operations a team that define the permissions for team resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html#cfn-mpa-approvalteam-policies
     */
    readonly policies?: Array<cdk.IResolvable | CfnApprovalTeamPropsMixin.PolicyProperty> | cdk.IResolvable;
    /**
     * Tags that you have added to the specified resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-approvalteam.html#cfn-mpa-approvalteam-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a new identity source.
 *
 * For more information, see [Identity Source](https://docs.aws.amazon.com/mpa/latest/userguide/mpa-concepts.html) in the *Multi-party approval User Guide* .
 *
 * @cloudformationResource AWS::MPA::IdentitySource
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-identitysource.html
 */
export declare class CfnIdentitySourcePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIdentitySourceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::MPA::IdentitySource`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIdentitySourceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIdentitySource;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIdentitySourcePropsMixin {
    /**
     * Contains details for the resource that provides identities to the identity source.
     *
     * For example, an IAM Identity Center instance.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-identitysource-identitysourceparameters.html
     */
    interface IdentitySourceParametersProperty {
        /**
         * SSOlong credentials.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-identitysource-identitysourceparameters.html#cfn-mpa-identitysource-identitysourceparameters-iamidentitycenter
         */
        readonly iamIdentityCenter?: CfnIdentitySourcePropsMixin.IamIdentityCenterProperty | cdk.IResolvable;
    }
    /**
     * SSOlong credentials.
     *
     * For more information see, [SSOlong](https://docs.aws.amazon.com/identity-center/) .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-identitysource-iamidentitycenter.html
     */
    interface IamIdentityCenterProperty {
        /**
         * URL for the approval portal associated with the IAM Identity Center instance.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-identitysource-iamidentitycenter.html#cfn-mpa-identitysource-iamidentitycenter-approvalportalurl
         */
        readonly approvalPortalUrl?: string;
        /**
         * Amazon Resource Name (ARN) for the IAM Identity Center instance.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-identitysource-iamidentitycenter.html#cfn-mpa-identitysource-iamidentitycenter-instancearn
         */
        readonly instanceArn?: string;
        /**
         * AWS Region where the IAM Identity Center instance is located.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-mpa-identitysource-iamidentitycenter.html#cfn-mpa-identitysource-iamidentitycenter-region
         */
        readonly region?: string;
    }
}
/**
 * Properties for CfnIdentitySourcePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-identitysource.html
 */
export interface CfnIdentitySourceMixinProps {
    /**
     * A `IdentitySourceParameters` object.
     *
     * Contains details for the resource that provides identities to the identity source. For example, an IAM Identity Center instance.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-identitysource.html#cfn-mpa-identitysource-identitysourceparameters
     */
    readonly identitySourceParameters?: CfnIdentitySourcePropsMixin.IdentitySourceParametersProperty | cdk.IResolvable;
    /**
     * Tags that you have added to the specified resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-mpa-identitysource.html#cfn-mpa-identitysource-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
