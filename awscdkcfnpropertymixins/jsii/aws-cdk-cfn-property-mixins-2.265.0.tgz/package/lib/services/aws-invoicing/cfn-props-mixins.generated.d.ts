import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-invoicing";
/**
 * An invoice unit is a set of mutually exclusive account that correspond to your business entity.
 *
 * Invoice units allow you separate AWS account costs and configures your invoice for each business entity going forward.
 *
 * @cloudformationResource AWS::Invoicing::InvoiceUnit
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html
 */
export declare class CfnInvoiceUnitPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnInvoiceUnitMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Invoicing::InvoiceUnit`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnInvoiceUnitMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnInvoiceUnit;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnInvoiceUnitPropsMixin {
    /**
     * The `InvoiceUnitRule` object used to update invoice units.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-rule.html
     */
    interface RuleProperty {
        /**
         * The list of `LINKED_ACCOUNT` IDs where charges are included within the invoice unit.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-rule.html#cfn-invoicing-invoiceunit-rule-linkedaccounts
         */
        readonly linkedAccounts?: Array<string>;
    }
    /**
     * The tag structure that contains a tag key and value.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-resourcetag.html
     */
    interface ResourceTagProperty {
        /**
         * The object key of your of your resource tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-resourcetag.html#cfn-invoicing-invoiceunit-resourcetag-key
         */
        readonly key?: string;
        /**
         * The specific value of the resource tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-invoicing-invoiceunit-resourcetag.html#cfn-invoicing-invoiceunit-resourcetag-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnInvoiceUnitPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html
 */
export interface CfnInvoiceUnitMixinProps {
    /**
     * The assigned description for an invoice unit.
     *
     * This information can't be modified or deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-description
     */
    readonly description?: string;
    /**
     * The account that receives invoices related to the invoice unit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-invoicereceiver
     */
    readonly invoiceReceiver?: string;
    /**
     * A unique name that is distinctive within your AWS .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-name
     */
    readonly name?: string;
    /**
     * The tag structure that contains a tag key and value.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-resourcetags
     */
    readonly resourceTags?: Array<CfnInvoiceUnitPropsMixin.ResourceTagProperty>;
    /**
     * An `InvoiceUnitRule` object used the categorize invoice units.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-rule
     */
    readonly rule?: cdk.IResolvable | CfnInvoiceUnitPropsMixin.RuleProperty;
    /**
     * Whether the invoice unit based tax inheritance is/ should be enabled or disabled.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-invoicing-invoiceunit.html#cfn-invoicing-invoiceunit-taxinheritancedisabled
     */
    readonly taxInheritanceDisabled?: boolean | cdk.IResolvable;
}
