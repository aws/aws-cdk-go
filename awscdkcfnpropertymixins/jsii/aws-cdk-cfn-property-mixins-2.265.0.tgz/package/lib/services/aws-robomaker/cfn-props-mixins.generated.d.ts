import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-robomaker";
import { aws_robomaker as roboMakerRefs } from "aws-cdk-lib/interfaces";
/**
 * > The following resource is now deprecated.
 *
 * This resource can no longer be provisioned via stack create or update operations, and should not be included in your stack templates.
 * >
 * > We recommend migrating to AWS IoT Greengrass Version 2. For more information, see [Support Changes: May 2, 2022](https://docs.aws.amazon.com/robomaker/latest/dg/chapter-support-policy.html#software-support-policy-may2022) in the *AWS RoboMaker Developer Guide* .
 *
 * The `AWS::RoboMaker::Fleet` resource creates an AWS RoboMaker fleet. Fleets contain robots and can receive deployments.
 *
 * @cloudformationResource AWS::RoboMaker::Fleet
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-fleet.html
 */
export declare class CfnFleetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnFleetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::RoboMaker::Fleet`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnFleetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFleet;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnFleetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-fleet.html
 */
export interface CfnFleetMixinProps {
    /**
     * The name of the fleet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-fleet.html#cfn-robomaker-fleet-name
     */
    readonly name?: string;
    /**
     * The list of all tags added to the fleet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-fleet.html#cfn-robomaker-fleet-tags
     */
    readonly tags?: Record<string, string>;
}
/**
 * > The following resource is now deprecated.
 *
 * This resource can no longer be provisioned via stack create or update operations, and should not be included in your stack templates.
 * >
 * > We recommend migrating to AWS IoT Greengrass Version 2. For more information, see [Support Changes: May 2, 2022](https://docs.aws.amazon.com/robomaker/latest/dg/chapter-support-policy.html#software-support-policy-may2022) in the *AWS RoboMaker Developer Guide* .
 *
 * The `AWS::RoboMaker::RobotApplication` resource creates an AWS RoboMaker robot.
 *
 * @cloudformationResource AWS::RoboMaker::Robot
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html
 */
export declare class CfnRobotPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRobotMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::RoboMaker::Robot`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRobotMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRobot;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnRobotPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html
 */
export interface CfnRobotMixinProps {
    /**
     * The architecture of the robot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html#cfn-robomaker-robot-architecture
     */
    readonly architecture?: string;
    /**
     * The Amazon Resource Name (ARN) of the fleet to which the robot will be registered.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html#cfn-robomaker-robot-fleet
     */
    readonly fleet?: roboMakerRefs.IFleetRef | string;
    /**
     * The Greengrass group associated with the robot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html#cfn-robomaker-robot-greengrassgroupid
     */
    readonly greengrassGroupId?: string;
    /**
     * The name of the robot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html#cfn-robomaker-robot-name
     */
    readonly name?: string;
    /**
     * A map that contains tag keys and tag values that are attached to the robot.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robot.html#cfn-robomaker-robot-tags
     */
    readonly tags?: Record<string, string>;
}
/**
 * The `AWS::RoboMaker::RobotApplication` resource creates an AWS RoboMaker robot application.
 *
 * @cloudformationResource AWS::RoboMaker::RobotApplication
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html
 */
export declare class CfnRobotApplicationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRobotApplicationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::RoboMaker::RobotApplication`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRobotApplicationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRobotApplication;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnRobotApplicationPropsMixin {
    /**
     * Information about a robot software suite.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-robotsoftwaresuite.html
     */
    interface RobotSoftwareSuiteProperty {
        /**
         * The name of the robot software suite.
         *
         * `General` is the only supported value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-robotsoftwaresuite.html#cfn-robomaker-robotapplication-robotsoftwaresuite-name
         */
        readonly name?: string;
        /**
         * The version of the robot software suite.
         *
         * Not applicable for General software suite.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-robotsoftwaresuite.html#cfn-robomaker-robotapplication-robotsoftwaresuite-version
         */
        readonly version?: string;
    }
    /**
     * Information about a source configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-sourceconfig.html
     */
    interface SourceConfigProperty {
        /**
         * The target processor architecture for the application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-sourceconfig.html#cfn-robomaker-robotapplication-sourceconfig-architecture
         */
        readonly architecture?: string;
        /**
         * The Amazon S3 bucket name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-sourceconfig.html#cfn-robomaker-robotapplication-sourceconfig-s3bucket
         */
        readonly s3Bucket?: string;
        /**
         * The s3 object key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-robotapplication-sourceconfig.html#cfn-robomaker-robotapplication-sourceconfig-s3key
         */
        readonly s3Key?: string;
    }
}
/**
 * Properties for CfnRobotApplicationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html
 */
export interface CfnRobotApplicationMixinProps {
    /**
     * The current revision id.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html#cfn-robomaker-robotapplication-currentrevisionid
     */
    readonly currentRevisionId?: string;
    /**
     * The environment of the robot application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html#cfn-robomaker-robotapplication-environment
     */
    readonly environment?: string;
    /**
     * The name of the robot application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html#cfn-robomaker-robotapplication-name
     */
    readonly name?: string;
    /**
     * The robot software suite used by the robot application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html#cfn-robomaker-robotapplication-robotsoftwaresuite
     */
    readonly robotSoftwareSuite?: cdk.IResolvable | CfnRobotApplicationPropsMixin.RobotSoftwareSuiteProperty;
    /**
     * The sources of the robot application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html#cfn-robomaker-robotapplication-sources
     */
    readonly sources?: Array<cdk.IResolvable | CfnRobotApplicationPropsMixin.SourceConfigProperty> | cdk.IResolvable;
    /**
     * A map that contains tag keys and tag values that are attached to the robot application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplication.html#cfn-robomaker-robotapplication-tags
     */
    readonly tags?: Record<string, string>;
}
/**
 * The `AWS::RoboMaker::RobotApplicationVersion` resource creates an AWS RoboMaker robot version.
 *
 * @cloudformationResource AWS::RoboMaker::RobotApplicationVersion
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplicationversion.html
 */
export declare class CfnRobotApplicationVersionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRobotApplicationVersionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::RoboMaker::RobotApplicationVersion`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRobotApplicationVersionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRobotApplicationVersion;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnRobotApplicationVersionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplicationversion.html
 */
export interface CfnRobotApplicationVersionMixinProps {
    /**
     * The application information for the robot application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplicationversion.html#cfn-robomaker-robotapplicationversion-application
     */
    readonly application?: roboMakerRefs.IRobotApplicationRef | string;
    /**
     * The current revision id for the robot application.
     *
     * If you provide a value and it matches the latest revision ID, a new version will be created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-robotapplicationversion.html#cfn-robomaker-robotapplicationversion-currentrevisionid
     */
    readonly currentRevisionId?: string;
}
/**
 * The `AWS::RoboMaker::SimulationApplication` resource creates an AWS RoboMaker simulation application.
 *
 * @cloudformationResource AWS::RoboMaker::SimulationApplication
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html
 */
export declare class CfnSimulationApplicationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSimulationApplicationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::RoboMaker::SimulationApplication`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSimulationApplicationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSimulationApplication;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSimulationApplicationPropsMixin {
    /**
     * Information about a rendering engine.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-renderingengine.html
     */
    interface RenderingEngineProperty {
        /**
         * The name of the rendering engine.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-renderingengine.html#cfn-robomaker-simulationapplication-renderingengine-name
         */
        readonly name?: string;
        /**
         * The version of the rendering engine.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-renderingengine.html#cfn-robomaker-simulationapplication-renderingengine-version
         */
        readonly version?: string;
    }
    /**
     * Information about a simulation software suite.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-simulationsoftwaresuite.html
     */
    interface SimulationSoftwareSuiteProperty {
        /**
         * The name of the simulation software suite.
         *
         * `SimulationRuntime` is the only supported value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-simulationsoftwaresuite.html#cfn-robomaker-simulationapplication-simulationsoftwaresuite-name
         */
        readonly name?: string;
        /**
         * The version of the simulation software suite.
         *
         * Not applicable for `SimulationRuntime` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-simulationsoftwaresuite.html#cfn-robomaker-simulationapplication-simulationsoftwaresuite-version
         */
        readonly version?: string;
    }
    /**
     * Information about a robot software suite.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-robotsoftwaresuite.html
     */
    interface RobotSoftwareSuiteProperty {
        /**
         * The name of the robot software suite.
         *
         * `General` is the only supported value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-robotsoftwaresuite.html#cfn-robomaker-simulationapplication-robotsoftwaresuite-name
         */
        readonly name?: string;
        /**
         * The version of the robot software suite.
         *
         * Not applicable for General software suite.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-robotsoftwaresuite.html#cfn-robomaker-simulationapplication-robotsoftwaresuite-version
         */
        readonly version?: string;
    }
    /**
     * Information about a source configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-sourceconfig.html
     */
    interface SourceConfigProperty {
        /**
         * The target processor architecture for the application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-sourceconfig.html#cfn-robomaker-simulationapplication-sourceconfig-architecture
         */
        readonly architecture?: string;
        /**
         * The Amazon S3 bucket name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-sourceconfig.html#cfn-robomaker-simulationapplication-sourceconfig-s3bucket
         */
        readonly s3Bucket?: string;
        /**
         * The s3 object key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-robomaker-simulationapplication-sourceconfig.html#cfn-robomaker-simulationapplication-sourceconfig-s3key
         */
        readonly s3Key?: string;
    }
}
/**
 * Properties for CfnSimulationApplicationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html
 */
export interface CfnSimulationApplicationMixinProps {
    /**
     * The current revision id.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-currentrevisionid
     */
    readonly currentRevisionId?: string;
    /**
     * The environment of the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-environment
     */
    readonly environment?: string;
    /**
     * The name of the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-name
     */
    readonly name?: string;
    /**
     * The rendering engine for the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-renderingengine
     */
    readonly renderingEngine?: cdk.IResolvable | CfnSimulationApplicationPropsMixin.RenderingEngineProperty;
    /**
     * The robot software suite used by the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-robotsoftwaresuite
     */
    readonly robotSoftwareSuite?: cdk.IResolvable | CfnSimulationApplicationPropsMixin.RobotSoftwareSuiteProperty;
    /**
     * The simulation software suite used by the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-simulationsoftwaresuite
     */
    readonly simulationSoftwareSuite?: cdk.IResolvable | CfnSimulationApplicationPropsMixin.SimulationSoftwareSuiteProperty;
    /**
     * The sources of the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-sources
     */
    readonly sources?: Array<cdk.IResolvable | CfnSimulationApplicationPropsMixin.SourceConfigProperty> | cdk.IResolvable;
    /**
     * A map that contains tag keys and tag values that are attached to the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplication.html#cfn-robomaker-simulationapplication-tags
     */
    readonly tags?: Record<string, string>;
}
/**
 * The `AWS::RoboMaker::SimulationApplicationVersion` resource creates a version of an AWS RoboMaker simulation application.
 *
 * @cloudformationResource AWS::RoboMaker::SimulationApplicationVersion
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplicationversion.html
 */
export declare class CfnSimulationApplicationVersionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSimulationApplicationVersionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::RoboMaker::SimulationApplicationVersion`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSimulationApplicationVersionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSimulationApplicationVersion;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnSimulationApplicationVersionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplicationversion.html
 */
export interface CfnSimulationApplicationVersionMixinProps {
    /**
     * The application information for the simulation application.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplicationversion.html#cfn-robomaker-simulationapplicationversion-application
     */
    readonly application?: roboMakerRefs.ISimulationApplicationRef | string;
    /**
     * The current revision id for the simulation application.
     *
     * If you provide a value and it matches the latest revision ID, a new version will be created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-robomaker-simulationapplicationversion.html#cfn-robomaker-simulationapplicationversion-currentrevisionid
     */
    readonly currentRevisionId?: string;
}
