import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-controlcatalog";
/**
 * Returns information about an objective in the AWS Control Catalog.
 *
 * @cloudformationResource AWS::ControlCatalog::Objective
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-controlcatalog-objective.html
 */
export declare class CfnObjectivePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnObjectiveMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ControlCatalog::Objective`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnObjectiveMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnObjective;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnObjectivePropsMixin {
    /**
     * The domain that the objective belongs to.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-objective-domain.html
     */
    interface DomainProperty {
        /**
         * The Amazon Resource Name (ARN) of the related domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-objective-domain.html#cfn-controlcatalog-objective-domain-arn
         */
        readonly arn?: string;
        /**
         * The name of the related domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-controlcatalog-objective-domain.html#cfn-controlcatalog-objective-domain-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnObjectivePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-controlcatalog-objective.html
 */
export interface CfnObjectiveMixinProps {
}
