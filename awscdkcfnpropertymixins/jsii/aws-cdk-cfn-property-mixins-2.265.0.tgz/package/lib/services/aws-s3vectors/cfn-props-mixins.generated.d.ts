import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-s3vectors";
/**
 * The `AWS::S3Vectors::Index` resource defines a vector index within an Amazon S3 vector bucket.
 *
 * For more information, see [Creating a vector index in a vector bucket](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-vectors-create-index.html) in the *Amazon Simple Storage Service User Guide* .
 *
 * You must specify either `VectorBucketName` or `VectorBucketArn` to identify the bucket that contains the index.
 *
 * To control how AWS CloudFormation handles the vector index when the stack is deleted, you can set a deletion policy for your index. You can choose to *retain* the index or to *delete* the index. For more information, see [DeletionPolicy attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-deletionpolicy.html) .
 *
 * - **Permissions** - The required permissions for CloudFormation to use are based on the operations that are performed on the stack.
 *
 * - Create
 *
 * - s3vectors:CreateIndex
 * - s3vectors:GetIndex
 * - Read
 *
 * - s3vectors:GetIndex
 * - Delete
 *
 * - s3vectors:DeleteIndex
 * - s3vectors:GetIndex
 * - List
 *
 * - s3vectors:ListIndexes
 *
 * @cloudformationResource AWS::S3Vectors::Index
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html
 */
export declare class CfnIndexPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIndexMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Vectors::Index`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIndexMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIndex;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIndexPropsMixin {
    /**
     * The encryption configuration for a vector bucket or index.
     *
     * By default, if you don't specify, all new vectors in Amazon S3 vector buckets use server-side encryption with Amazon S3 managed keys (SSE-S3), specifically `AES256` . You can optionally override bucket level encryption settings, and set a specific encryption configuration for a vector index at the time of index creation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-index-encryptionconfiguration.html
     */
    interface EncryptionConfigurationProperty {
        /**
         * AWS Key Management Service (KMS) customer managed key ID to use for the encryption configuration.
         *
         * This parameter is allowed if and only if `sseType` is set to `aws:kms` .
         *
         * To specify the KMS key, you must use the format of the KMS key Amazon Resource Name (ARN).
         *
         * For example, specify Key ARN in the following format: `arn:aws:kms:us-east-2:111122223333:key/1234abcd-12ab-34cd-56ef-1234567890ab`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-index-encryptionconfiguration.html#cfn-s3vectors-index-encryptionconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * The server-side encryption type to use for the encryption configuration of the vector bucket.
         *
         * By default, if you don't specify, all new vectors in Amazon S3 vector buckets use server-side encryption with Amazon S3 managed keys (SSE-S3), specifically `AES256` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-index-encryptionconfiguration.html#cfn-s3vectors-index-encryptionconfiguration-ssetype
         */
        readonly sseType?: string;
    }
    /**
     * The metadata configuration for the vector index.
     *
     * This configuration allows you to specify which metadata keys should be treated as non-filterable.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-index-metadataconfiguration.html
     */
    interface MetadataConfigurationProperty {
        /**
         * Non-filterable metadata keys allow you to enrich vectors with additional context during storage and retrieval.
         *
         * Unlike default metadata keys, these keys can't be used as query filters. Non-filterable metadata keys can be retrieved but can't be searched, queried, or filtered. You can access non-filterable metadata keys of your vectors after finding the vectors.
         *
         * You can specify 1 to 10 non-filterable metadata keys. Each key must be 1 to 63 characters long.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-index-metadataconfiguration.html#cfn-s3vectors-index-metadataconfiguration-nonfilterablemetadatakeys
         */
        readonly nonFilterableMetadataKeys?: Array<string>;
    }
}
/**
 * Properties for CfnIndexPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html
 */
export interface CfnIndexMixinProps {
    /**
     * The data type of the vectors to be inserted into the vector index.
     *
     * Currently, only `float32` is supported, which represents 32-bit floating-point numbers.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-datatype
     */
    readonly dataType?: string;
    /**
     * The dimensions of the vectors to be inserted into the vector index.
     *
     * This value must be between 1 and 4096, inclusive. All vectors stored in the index must have the same number of dimensions.
     *
     * The dimension value affects the storage requirements and search performance. Higher dimensions require more storage space and may impact search latency.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-dimension
     */
    readonly dimension?: number;
    /**
     * The distance metric to be used for similarity search. Valid values are:.
     *
     * - `cosine` - Measures the cosine of the angle between two vectors.
     * - `euclidean` - Measures the straight-line distance between two points in multi-dimensional space. Lower values indicate greater similarity.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-distancemetric
     */
    readonly distanceMetric?: string;
    /**
     * The encryption configuration for a vector index.
     *
     * By default, if you don't specify, all new vectors in the vector index will use the encryption configuration of the vector bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-encryptionconfiguration
     */
    readonly encryptionConfiguration?: CfnIndexPropsMixin.EncryptionConfigurationProperty | cdk.IResolvable;
    /**
     * The name of the vector index to create.
     *
     * The index name must be between 3 and 63 characters long and can contain only lowercase letters, numbers, hyphens (-), and dots (.). The index name must be unique within the vector bucket.
     *
     * If you don't specify a name, AWS CloudFormation generates a unique ID and uses that ID for the index name.
     *
     * > If you specify a name, you can't perform updates that require replacement of this resource. You can perform updates that require no or some interruption. If you need to replace the resource, specify a new name.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-indexname
     */
    readonly indexName?: string;
    /**
     * The metadata configuration for the vector index.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-metadataconfiguration
     */
    readonly metadataConfiguration?: cdk.IResolvable | CfnIndexPropsMixin.MetadataConfigurationProperty;
    /**
     * User tags (key-value pairs) to associate with the index.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The Amazon Resource Name (ARN) of the vector bucket that contains the vector index.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-vectorbucketarn
     */
    readonly vectorBucketArn?: string;
    /**
     * The name of the vector bucket that contains the vector index.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-index.html#cfn-s3vectors-index-vectorbucketname
     */
    readonly vectorBucketName?: string;
}
/**
 * Defines an Amazon S3 vector bucket in the same AWS Region where you create the AWS CloudFormation stack.
 *
 * Vector buckets are specialized storage containers designed for storing and managing vector data used in machine learning and AI applications. They provide optimized storage and retrieval capabilities for high-dimensional vector data.
 *
 * To control how AWS CloudFormation handles the bucket when the stack is deleted, you can set a deletion policy for your bucket. You can choose to *retain* the bucket or to *delete* the bucket. For more information, see [DeletionPolicy attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-deletionpolicy.html) .
 *
 * > You can only delete empty vector buckets. Deletion fails for buckets that have contents.
 *
 * - **Permissions** - The required permissions for CloudFormation to use are based on the operations that are performed on the stack.
 *
 * - Create
 *
 * - s3vectors:CreateVectorBucket
 * - s3vectors:GetVectorBucket
 * - kms:GenerateDataKey (if using KMS encryption)
 * - Read
 *
 * - s3vectors:GetVectorBucket
 * - kms:GenerateDataKey (if using KMS encryption)
 * - Delete
 *
 * - s3vectors:DeleteVectorBucket
 * - s3vectors:GetVectorBucket
 * - kms:GenerateDataKey (if using KMS encryption)
 * - List
 *
 * - s3vectors:ListVectorBuckets
 * - kms:GenerateDataKey (if using KMS encryption)
 *
 * @cloudformationResource AWS::S3Vectors::VectorBucket
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucket.html
 */
export declare class CfnVectorBucketPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVectorBucketMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Vectors::VectorBucket`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVectorBucketMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVectorBucket;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnVectorBucketPropsMixin {
    /**
     * Specifies the encryption configuration for the vector bucket.
     *
     * By default, all new vectors in Amazon S3 vector buckets use server-side encryption with Amazon S3 managed keys (SSE-S3), specifically AES256.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-vectorbucket-encryptionconfiguration.html
     */
    interface EncryptionConfigurationProperty {
        /**
         * AWS Key Management Service (KMS) customer managed key ARN to use for the encryption configuration.
         *
         * This parameter is required if and only if `SseType` is set to `aws:kms` .
         *
         * You must specify the full ARN of the KMS key. Key IDs or key aliases aren't supported.
         *
         * > Amazon S3 Vectors only supports symmetric encryption KMS keys. For more information, see [Asymmetric keys in AWS KMS](https://docs.aws.amazon.com//kms/latest/developerguide/symmetric-asymmetric.html) in the *AWS Key Management Service Developer Guide* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-vectorbucket-encryptionconfiguration.html#cfn-s3vectors-vectorbucket-encryptionconfiguration-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * The server-side encryption type to use for the encryption configuration of the vector bucket.
         *
         * Valid values are `AES256` for Amazon S3 managed keys and `aws:kms` for AWS KMS keys.
         *
         * @default - "AES256"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-s3vectors-vectorbucket-encryptionconfiguration.html#cfn-s3vectors-vectorbucket-encryptionconfiguration-ssetype
         */
        readonly sseType?: string;
    }
}
/**
 * Properties for CfnVectorBucketPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucket.html
 */
export interface CfnVectorBucketMixinProps {
    /**
     * The encryption configuration for the vector bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucket.html#cfn-s3vectors-vectorbucket-encryptionconfiguration
     */
    readonly encryptionConfiguration?: CfnVectorBucketPropsMixin.EncryptionConfigurationProperty | cdk.IResolvable;
    /**
     * User tags (key-value pairs) to associate with the vector bucket.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucket.html#cfn-s3vectors-vectorbucket-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * A name for the vector bucket.
     *
     * The bucket name must contain only lowercase letters, numbers, and hyphens (-). The bucket name must be unique in the same AWS account for each AWS Region. If you don't specify a name, AWS CloudFormation generates a unique ID and uses that ID for the bucket name.
     *
     * The bucket name must be between 3 and 63 characters long and must not contain uppercase characters or underscores.
     *
     * > If you specify a name, you can't perform updates that require replacement of this resource. You can perform updates that require no or some interruption. If you need to replace the resource, specify a new name.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucket.html#cfn-s3vectors-vectorbucket-vectorbucketname
     */
    readonly vectorBucketName?: string;
}
/**
 * The `AWS::S3Vectors::VectorBucketPolicy` resource defines an Amazon S3 vector bucket policy to control access to an Amazon S3 vector bucket.
 *
 * Vector bucket policies are written in JSON and allow you to grant or deny permissions across all (or a subset of) objects within a vector bucket.
 *
 * You must specify either `VectorBucketName` or `VectorBucketArn` to identify the target bucket.
 *
 * To control how AWS CloudFormation handles the vector bucket policy when the stack is deleted, you can set a deletion policy for your policy. You can choose to *retain* the policy or to *delete* the policy. For more information, see [DeletionPolicy attribute](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-attribute-deletionpolicy.html) .
 *
 * - **Permissions** - The required permissions for CloudFormation to use are based on the operations that are performed on the stack.
 *
 * - Create
 *
 * - s3vectors:GetVectorBucketPolicy
 * - s3vectors:PutVectorBucketPolicy
 * - Read
 *
 * - s3vectors:GetVectorBucketPolicy
 * - Update
 *
 * - s3vectors:GetVectorBucketPolicy
 * - s3vectors:PutVectorBucketPolicy
 * - Delete
 *
 * - s3vectors:GetVectorBucketPolicy
 * - s3vectors:DeleteVectorBucketPolicy
 * - List
 *
 * - s3vectors:GetVectorBucketPolicy
 * - s3vectors:ListVectorBuckets
 *
 * @cloudformationResource AWS::S3Vectors::VectorBucketPolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucketpolicy.html
 */
export declare class CfnVectorBucketPolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVectorBucketPolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::S3Vectors::VectorBucketPolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVectorBucketPolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVectorBucketPolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVectorBucketPolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucketpolicy.html
 */
export interface CfnVectorBucketPolicyMixinProps {
    /**
     * A policy document containing permissions to add to the specified vector bucket.
     *
     * In IAM , you must provide policy documents in JSON format. However, in CloudFormation you can provide the policy in JSON or YAML format because CloudFormation converts YAML to JSON before submitting it to IAM .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucketpolicy.html#cfn-s3vectors-vectorbucketpolicy-policy
     */
    readonly policy?: any | cdk.IResolvable | string;
    /**
     * The Amazon Resource Name (ARN) of the S3 vector bucket to which the policy applies.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucketpolicy.html#cfn-s3vectors-vectorbucketpolicy-vectorbucketarn
     */
    readonly vectorBucketArn?: string;
    /**
     * The name of the S3 vector bucket to which the policy applies.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-s3vectors-vectorbucketpolicy.html#cfn-s3vectors-vectorbucketpolicy-vectorbucketname
     */
    readonly vectorBucketName?: string;
}
