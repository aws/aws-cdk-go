import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-backupsearch";
/**
 * Definition of AWS::BackupSearch::SearchJob Resource Type.
 *
 * @cloudformationResource AWS::BackupSearch::SearchJob
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupsearch-searchjob.html
 */
export declare class CfnSearchJobPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSearchJobMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::BackupSearch::SearchJob`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSearchJobMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSearchJob;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSearchJobPropsMixin {
    /**
     * The search scope for the search job.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-backupsearch-searchjob-searchscope.html
     */
    interface SearchScopeProperty {
        /**
         * The resource types included in a search.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-backupsearch-searchjob-searchscope.html#cfn-backupsearch-searchjob-searchscope-backupresourcetypes
         */
        readonly backupResourceTypes?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-backupsearch-searchjob-tagsitems.html
     */
    interface TagsItemsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-backupsearch-searchjob-tagsitems.html#cfn-backupsearch-searchjob-tagsitems-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-backupsearch-searchjob-tagsitems.html#cfn-backupsearch-searchjob-tagsitems-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnSearchJobPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupsearch-searchjob.html
 */
export interface CfnSearchJobMixinProps {
    /**
     * The name of the search job.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupsearch-searchjob.html#cfn-backupsearch-searchjob-name
     */
    readonly name?: string;
    /**
     * The search scope for the search job.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupsearch-searchjob.html#cfn-backupsearch-searchjob-searchscope
     */
    readonly searchScope?: cdk.IResolvable | CfnSearchJobPropsMixin.SearchScopeProperty;
    /**
     * Tags associated with the search job.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-backupsearch-searchjob.html#cfn-backupsearch-searchjob-tags
     */
    readonly tags?: Array<CfnSearchJobPropsMixin.TagsItemsProperty>;
}
