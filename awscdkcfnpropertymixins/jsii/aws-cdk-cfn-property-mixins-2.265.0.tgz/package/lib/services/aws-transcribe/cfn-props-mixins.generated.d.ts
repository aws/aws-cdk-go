import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-transcribe";
/**
 * Resource type definition for an Amazon Transcribe Medical Transcription Job.
 *
 * @cloudformationResource AWS::Transcribe::MedicalTranscriptionJob
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html
 */
export declare class CfnMedicalTranscriptionJobPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMedicalTranscriptionJobMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Transcribe::MedicalTranscriptionJob`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMedicalTranscriptionJobMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMedicalTranscriptionJob;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnMedicalTranscriptionJobPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-media.html
     */
    interface MediaProperty {
        /**
         * The Amazon S3 location of the media file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-media.html#cfn-transcribe-medicaltranscriptionjob-media-mediafileuri
         */
        readonly mediaFileUri?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-medicaltranscriptionsetting.html
     */
    interface MedicalTranscriptionSettingProperty {
        /**
         * Enables channel identification in multi-channel audio.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-medicaltranscriptionsetting.html#cfn-transcribe-medicaltranscriptionjob-medicaltranscriptionsetting-channelidentification
         */
        readonly channelIdentification?: boolean | cdk.IResolvable;
        /**
         * Include alternative transcriptions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-medicaltranscriptionsetting.html#cfn-transcribe-medicaltranscriptionjob-medicaltranscriptionsetting-showalternatives
         */
        readonly showAlternatives?: boolean | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-medicaltranscript.html
     */
    interface MedicalTranscriptProperty {
        /**
         * The Amazon S3 location of the transcript.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-transcribe-medicaltranscriptionjob-medicaltranscript.html#cfn-transcribe-medicaltranscriptionjob-medicaltranscript-transcriptfileuri
         */
        readonly transcriptFileUri?: string;
    }
}
/**
 * Properties for CfnMedicalTranscriptionJobPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html
 */
export interface CfnMedicalTranscriptionJobMixinProps {
    /**
     * The language code for the language spoken in the input media file.
     *
     * Must be en-US.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-languagecode
     */
    readonly languageCode?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-media
     */
    readonly media?: cdk.IResolvable | CfnMedicalTranscriptionJobPropsMixin.MediaProperty;
    /**
     * The format of the input media file.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-mediaformat
     */
    readonly mediaFormat?: string;
    /**
     * The sample rate of the audio in hertz.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-mediasampleratehertz
     */
    readonly mediaSampleRateHertz?: number;
    /**
     * A unique name for the medical transcription job.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-medicaltranscriptionjobname
     */
    readonly medicalTranscriptionJobName?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-settings
     */
    readonly settings?: cdk.IResolvable | CfnMedicalTranscriptionJobPropsMixin.MedicalTranscriptionSettingProperty;
    /**
     * The medical specialty represented in the media.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-specialty
     */
    readonly specialty?: string;
    /**
     * Tags associated with the medical transcription job.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Whether the input media is a dictation or conversation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-medicaltranscriptionjob.html#cfn-transcribe-medicaltranscriptionjob-type
     */
    readonly type?: string;
}
/**
 * Creates a custom vocabulary filter that you can use to mask, delete, or flag specific words from your transcript.
 *
 * @cloudformationResource AWS::Transcribe::VocabularyFilter
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html
 */
export declare class CfnVocabularyFilterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnVocabularyFilterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Transcribe::VocabularyFilter`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnVocabularyFilterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnVocabularyFilter;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnVocabularyFilterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html
 */
export interface CfnVocabularyFilterMixinProps {
    /**
     * The Amazon Resource Name (ARN) of an IAM role that has permissions to access the Amazon S3 bucket that contains your input files.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-dataaccessrolearn
     */
    readonly dataAccessRoleArn?: string;
    /**
     * The language code that represents the language of the entries in your vocabulary filter.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-languagecode
     */
    readonly languageCode?: string;
    /**
     * Tags associated with the vocabulary filter.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The Amazon S3 location of the text file that contains your custom vocabulary filter terms.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-vocabularyfilterfileuri
     */
    readonly vocabularyFilterFileUri?: string;
    /**
     * A unique name, chosen by you, for your custom vocabulary filter.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-vocabularyfiltername
     */
    readonly vocabularyFilterName?: string;
    /**
     * Use this parameter if you want to create your custom vocabulary filter by including all desired terms, as comma-separated values, within your request.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-transcribe-vocabularyfilter.html#cfn-transcribe-vocabularyfilter-words
     */
    readonly words?: Array<string>;
}
