import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-entityresolution";
/**
 * Creates a matching workflow that defines the configuration for a data processing job.
 *
 * The workflow name must be unique. To modify an existing workflow, use `UpdateMatchingWorkflow` .
 *
 * > For workflows where `resolutionType` is `ML_MATCHING` or `PROVIDER` , incremental processing is not supported.
 *
 * @cloudformationResource AWS::EntityResolution::MatchingWorkflow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html
 */
export declare class CfnMatchingWorkflowPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMatchingWorkflowMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EntityResolution::MatchingWorkflow`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMatchingWorkflowMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMatchingWorkflow;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnMatchingWorkflowPropsMixin {
    /**
     * An object which defines the `resolutionType` and the `ruleBasedProperties` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-resolutiontechniques.html
     */
    interface ResolutionTechniquesProperty {
        /**
         * Enables the workflow to use real-time matching.
         *
         * Can only be set on creation for RULE_MATCHING workflows that define RuleConditionProperties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-resolutiontechniques.html#cfn-entityresolution-matchingworkflow-resolutiontechniques-enablerealtimematching
         */
        readonly enableRealTimeMatching?: boolean | cdk.IResolvable;
        /**
         * The properties of the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-resolutiontechniques.html#cfn-entityresolution-matchingworkflow-resolutiontechniques-providerproperties
         */
        readonly providerProperties?: cdk.IResolvable | CfnMatchingWorkflowPropsMixin.ProviderPropertiesProperty;
        /**
         * The type of matching workflow to create. Specify one of the following types:.
         *
         * - `RULE_MATCHING` : Match records using configurable rule-based criteria
         * - `ML_MATCHING` : Match records using machine learning models
         * - `PROVIDER` : Match records using a third-party matching provider
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-resolutiontechniques.html#cfn-entityresolution-matchingworkflow-resolutiontechniques-resolutiontype
         */
        readonly resolutionType?: string;
        /**
         * An object which defines the list of matching rules to run and has a field `rules` , which is a list of rule objects.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-resolutiontechniques.html#cfn-entityresolution-matchingworkflow-resolutiontechniques-rulebasedproperties
         */
        readonly ruleBasedProperties?: cdk.IResolvable | CfnMatchingWorkflowPropsMixin.RuleBasedPropertiesProperty;
        /**
         * An object containing the `rules` for a matching workflow.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-resolutiontechniques.html#cfn-entityresolution-matchingworkflow-resolutiontechniques-ruleconditionproperties
         */
        readonly ruleConditionProperties?: cdk.IResolvable | CfnMatchingWorkflowPropsMixin.RuleConditionPropertiesProperty;
    }
    /**
     * An object which defines the list of matching rules to run in a matching workflow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulebasedproperties.html
     */
    interface RuleBasedPropertiesProperty {
        /**
         * The comparison type. You can choose `ONE_TO_ONE` or `MANY_TO_MANY` as the `attributeMatchingModel` .
         *
         * If you choose `ONE_TO_ONE` , the system can only match attributes if the sub-types are an exact match. For example, for the `Email` attribute type, the system will only consider it a match if the value of the `Email` field of Profile A matches the value of the `Email` field of Profile B.
         *
         * If you choose `MANY_TO_MANY` , the system can match attributes across the sub-types of an attribute type. For example, if the value of the `Email` field of Profile A and the value of `BusinessEmail` field of Profile B matches, the two profiles are matched on the `Email` attribute type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulebasedproperties.html#cfn-entityresolution-matchingworkflow-rulebasedproperties-attributematchingmodel
         */
        readonly attributeMatchingModel?: string;
        /**
         * An indicator of whether to generate IDs and index the data or not.
         *
         * If you choose `IDENTIFIER_GENERATION` , the process generates IDs and indexes the data.
         *
         * If you choose `INDEXING` , the process indexes the data without generating IDs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulebasedproperties.html#cfn-entityresolution-matchingworkflow-rulebasedproperties-matchpurpose
         */
        readonly matchPurpose?: string;
        /**
         * A list of `Rule` objects, each of which have fields `RuleName` and `MatchingKeys` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulebasedproperties.html#cfn-entityresolution-matchingworkflow-rulebasedproperties-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnMatchingWorkflowPropsMixin.RuleProperty> | cdk.IResolvable;
    }
    /**
     * An object containing the `ruleName` and `matchingKeys` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rule.html
     */
    interface RuleProperty {
        /**
         * A list of `MatchingKeys` .
         *
         * The `MatchingKeys` must have been defined in the `SchemaMapping` . Two records are considered to match according to this rule if all of the `MatchingKeys` match.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rule.html#cfn-entityresolution-matchingworkflow-rule-matchingkeys
         */
        readonly matchingKeys?: Array<string>;
        /**
         * A name for the matching rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rule.html#cfn-entityresolution-matchingworkflow-rule-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * The properties of a rule condition that provides the ability to use more complex syntax.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-ruleconditionproperties.html
     */
    interface RuleConditionPropertiesProperty {
        /**
         * Configuration for matching behavior within rule condition properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-ruleconditionproperties.html#cfn-entityresolution-matchingworkflow-ruleconditionproperties-matchingconfig
         */
        readonly matchingConfig?: cdk.IResolvable | CfnMatchingWorkflowPropsMixin.MatchingConfigProperty;
        /**
         * A list of rule objects, each of which have fields `ruleName` and `condition` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-ruleconditionproperties.html#cfn-entityresolution-matchingworkflow-ruleconditionproperties-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnMatchingWorkflowPropsMixin.RuleConditionProperty> | cdk.IResolvable;
    }
    /**
     * An object that defines the `ruleCondition` and the `ruleName` to use in a matching workflow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulecondition.html
     */
    interface RuleConditionProperty {
        /**
         * A statement that specifies the conditions for a matching rule.
         *
         * If your data is accurate, use an Exact matching function: `Exact` or `ExactManyToMany` .
         *
         * If your data has variations in spelling or pronunciation, use a Fuzzy matching function: `Cosine` , `Levenshtein` , or `Soundex` .
         *
         * Use operators if you want to combine ( `AND` ), separate ( `OR` ), or group matching functions `(...)` .
         *
         * For example: `(Cosine(a, 10) AND Exact(b, true)) OR ExactManyToMany(c, d)`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulecondition.html#cfn-entityresolution-matchingworkflow-rulecondition-condition
         */
        readonly condition?: string;
        /**
         * A name for the matching rule.
         *
         * For example: `Rule1`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-rulecondition.html#cfn-entityresolution-matchingworkflow-rulecondition-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * Configuration for matching behavior within rule condition properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-matchingconfig.html
     */
    interface MatchingConfigProperty {
        /**
         * Enables transitive matching to process records across all rule levels and connect unmatched records to existing match groups.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-matchingconfig.html#cfn-entityresolution-matchingworkflow-matchingconfig-enabletransitivematching
         */
        readonly enableTransitiveMatching?: boolean | cdk.IResolvable;
    }
    /**
     * An object containing the `providerServiceARN` , `intermediateSourceConfiguration` , and `providerConfiguration` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-providerproperties.html
     */
    interface ProviderPropertiesProperty {
        /**
         * The Amazon S3 location that temporarily stores your data while it processes.
         *
         * Your information won't be saved permanently.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-providerproperties.html#cfn-entityresolution-matchingworkflow-providerproperties-intermediatesourceconfiguration
         */
        readonly intermediateSourceConfiguration?: CfnMatchingWorkflowPropsMixin.IntermediateSourceConfigurationProperty | cdk.IResolvable;
        /**
         * The required configuration fields to use with the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-providerproperties.html#cfn-entityresolution-matchingworkflow-providerproperties-providerconfiguration
         */
        readonly providerConfiguration?: cdk.IResolvable | Record<string, string>;
        /**
         * The ARN of the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-providerproperties.html#cfn-entityresolution-matchingworkflow-providerproperties-providerservicearn
         */
        readonly providerServiceArn?: string;
    }
    /**
     * The Amazon S3 location that temporarily stores your data while it processes.
     *
     * Your information won't be saved permanently.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-intermediatesourceconfiguration.html
     */
    interface IntermediateSourceConfigurationProperty {
        /**
         * The Amazon S3 location (bucket and prefix).
         *
         * For example: `s3://provider_bucket/DOC-EXAMPLE-BUCKET`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-intermediatesourceconfiguration.html#cfn-entityresolution-matchingworkflow-intermediatesourceconfiguration-intermediates3path
         */
        readonly intermediateS3Path?: string;
    }
    /**
     * An object containing `inputSourceARN` , `schemaName` , and `applyNormalization` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-inputsource.html
     */
    interface InputSourceProperty {
        /**
         * Normalizes the attributes defined in the schema in the input data.
         *
         * For example, if an attribute has an `AttributeType` of `PHONE_NUMBER` , and the data in the input table is in a format of 1234567890, AWS Entity Resolution will normalize this field in the output to (123)-456-7890.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-inputsource.html#cfn-entityresolution-matchingworkflow-inputsource-applynormalization
         */
        readonly applyNormalization?: boolean | cdk.IResolvable;
        /**
         * An object containing `inputSourceARN` , `schemaName` , and `applyNormalization` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-inputsource.html#cfn-entityresolution-matchingworkflow-inputsource-inputsourcearn
         */
        readonly inputSourceArn?: string;
        /**
         * The name of the schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-inputsource.html#cfn-entityresolution-matchingworkflow-inputsource-schemaarn
         */
        readonly schemaArn?: string;
    }
    /**
     * A list of `OutputAttribute` objects, each of which have the fields `Name` and `Hashed` .
     *
     * Each of these objects selects a column to be included in the output table, and whether the values of the column should be hashed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputsource.html
     */
    interface OutputSourceProperty {
        /**
         * Normalizes the attributes defined in the schema in the input data.
         *
         * For example, if an attribute has an `AttributeType` of `PHONE_NUMBER` , and the data in the input table is in a format of 1234567890, AWS Entity Resolution will normalize this field in the output to (123)-456-7890.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputsource.html#cfn-entityresolution-matchingworkflow-outputsource-applynormalization
         */
        readonly applyNormalization?: boolean | cdk.IResolvable;
        /**
         * The Customer Profiles integration configuration for the output source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputsource.html#cfn-entityresolution-matchingworkflow-outputsource-customerprofilesintegrationconfig
         */
        readonly customerProfilesIntegrationConfig?: CfnMatchingWorkflowPropsMixin.CustomerProfilesIntegrationConfigProperty | cdk.IResolvable;
        /**
         * Customer KMS ARN for encryption at rest.
         *
         * If not provided, system will use an AWS Entity Resolution managed KMS key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputsource.html#cfn-entityresolution-matchingworkflow-outputsource-kmsarn
         */
        readonly kmsArn?: string;
        /**
         * A list of `OutputAttribute` objects, each of which have the fields `Name` and `Hashed` .
         *
         * Each of these objects selects a column to be included in the output table, and whether the values of the column should be hashed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputsource.html#cfn-entityresolution-matchingworkflow-outputsource-output
         */
        readonly output?: Array<cdk.IResolvable | CfnMatchingWorkflowPropsMixin.OutputAttributeProperty> | cdk.IResolvable;
        /**
         * The S3 path to which AWS Entity Resolution will write the output table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputsource.html#cfn-entityresolution-matchingworkflow-outputsource-outputs3path
         */
        readonly outputS3Path?: string;
    }
    /**
     * A list of `OutputAttribute` objects, each of which have the fields `Name` and `Hashed` .
     *
     * Each of these objects selects a column to be included in the output table, and whether the values of the column should be hashed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputattribute.html
     */
    interface OutputAttributeProperty {
        /**
         * Enables the ability to hash the column values in the output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputattribute.html#cfn-entityresolution-matchingworkflow-outputattribute-hashed
         */
        readonly hashed?: boolean | cdk.IResolvable;
        /**
         * A name of a column to be written to the output.
         *
         * This must be an `InputField` name in the schema mapping.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-outputattribute.html#cfn-entityresolution-matchingworkflow-outputattribute-name
         */
        readonly name?: string;
    }
    /**
     * The Customer Profiles integration configuration for the output source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-customerprofilesintegrationconfig.html
     */
    interface CustomerProfilesIntegrationConfigProperty {
        /**
         * The Amazon Resource Name (ARN) of the Customer Profiles domain.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-customerprofilesintegrationconfig.html#cfn-entityresolution-matchingworkflow-customerprofilesintegrationconfig-domainarn
         */
        readonly domainArn?: string;
        /**
         * The Amazon Resource Name (ARN) of the Customer Profiles object type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-customerprofilesintegrationconfig.html#cfn-entityresolution-matchingworkflow-customerprofilesintegrationconfig-objecttypearn
         */
        readonly objectTypeArn?: string;
    }
    /**
     * Optional.
     *
     * An object that defines the incremental run type. This object contains only the `incrementalRunType` field, which appears as "Automatic" in the console.
     *
     * > For workflows where `resolutionType` is `ML_MATCHING` or `PROVIDER` , incremental processing is not supported.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-incrementalrunconfig.html
     */
    interface IncrementalRunConfigProperty {
        /**
         * The type of incremental run. The only valid value is `IMMEDIATE` . This appears as "Automatic" in the console.
         *
         * > For workflows where `resolutionType` is `ML_MATCHING` or `PROVIDER` , incremental processing is not supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-matchingworkflow-incrementalrunconfig.html#cfn-entityresolution-matchingworkflow-incrementalrunconfig-incrementalruntype
         */
        readonly incrementalRunType?: string;
    }
}
/**
 * Properties for CfnMatchingWorkflowPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html
 */
export interface CfnMatchingWorkflowMixinProps {
    /**
     * A description of the workflow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-description
     */
    readonly description?: string;
    /**
     * Optional.
     *
     * An object that defines the incremental run type. This object contains only the `incrementalRunType` field, which appears as "Automatic" in the console.
     *
     * > For workflows where `resolutionType` is `ML_MATCHING` or `PROVIDER` , incremental processing is not supported.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-incrementalrunconfig
     */
    readonly incrementalRunConfig?: CfnMatchingWorkflowPropsMixin.IncrementalRunConfigProperty | cdk.IResolvable;
    /**
     * A list of `InputSource` objects, which have the fields `InputSourceARN` and `SchemaName` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-inputsourceconfig
     */
    readonly inputSourceConfig?: Array<CfnMatchingWorkflowPropsMixin.InputSourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * A list of `OutputSource` objects, each of which contains fields `outputS3Path` , `applyNormalization` , `KMSArn` , and `output` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-outputsourceconfig
     */
    readonly outputSourceConfig?: Array<cdk.IResolvable | CfnMatchingWorkflowPropsMixin.OutputSourceProperty> | cdk.IResolvable;
    /**
     * An object which defines the `resolutionType` and the `ruleBasedProperties` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-resolutiontechniques
     */
    readonly resolutionTechniques?: cdk.IResolvable | CfnMatchingWorkflowPropsMixin.ResolutionTechniquesProperty;
    /**
     * The Amazon Resource Name (ARN) of the IAM role.
     *
     * AWS Entity Resolution assumes this role to create resources on your behalf as part of workflow execution.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-rolearn
     */
    readonly roleArn?: string;
    /**
     * The tags used to organize, track, or control access for this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the workflow.
     *
     * There can't be multiple `MatchingWorkflows` with the same name.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-matchingworkflow.html#cfn-entityresolution-matchingworkflow-workflowname
     */
    readonly workflowName?: string;
}
/**
 * Creates a schema mapping, which defines the schema of the input customer records table.
 *
 * The `SchemaMapping` also provides AWS Entity Resolution with some metadata about the table, such as the attribute types of the columns and which columns to match on.
 *
 * @cloudformationResource AWS::EntityResolution::SchemaMapping
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-schemamapping.html
 */
export declare class CfnSchemaMappingPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSchemaMappingMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EntityResolution::SchemaMapping`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSchemaMappingMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSchemaMapping;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSchemaMappingPropsMixin {
    /**
     * A configuration object for defining input data fields in AWS Entity Resolution .
     *
     * The `SchemaInputAttribute` specifies how individual fields in your input data should be processed and matched.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html
     */
    interface SchemaInputAttributeProperty {
        /**
         * A string containing the field name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html#cfn-entityresolution-schemamapping-schemainputattribute-fieldname
         */
        readonly fieldName?: string;
        /**
         * A string that instructs AWS Entity Resolution to combine several columns into a unified column with the identical attribute type.
         *
         * For example, when working with columns such as `NAME_FIRST` , `NAME_MIDDLE` , and `NAME_LAST` , assigning them a common `groupName` will prompt AWS Entity Resolution to concatenate them into a single value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html#cfn-entityresolution-schemamapping-schemainputattribute-groupname
         */
        readonly groupName?: string;
        /**
         * Indicates if the column values are hashed in the schema input.
         *
         * If the value is set to `TRUE` , the column values are hashed.
         *
         * If the value is set to `FALSE` , the column values are cleartext.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html#cfn-entityresolution-schemamapping-schemainputattribute-hashed
         */
        readonly hashed?: boolean | cdk.IResolvable;
        /**
         * A key that allows grouping of multiple input attributes into a unified matching group.
         *
         * For example, consider a scenario where the source table contains various addresses, such as `business_address` and `shipping_address` . By assigning a `matchKey` called `address` to both attributes, AWS Entity Resolution will match records across these fields to create a consolidated matching group.
         *
         * If no `matchKey` is specified for a column, it won't be utilized for matching purposes but will still be included in the output table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html#cfn-entityresolution-schemamapping-schemainputattribute-matchkey
         */
        readonly matchKey?: string;
        /**
         * The subtype of the attribute, selected from a list of values.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html#cfn-entityresolution-schemamapping-schemainputattribute-subtype
         */
        readonly subType?: string;
        /**
         * The type of the attribute, selected from a list of values.
         *
         * LiveRamp supports: `NAME` | `NAME_FIRST` | `NAME_MIDDLE` | `NAME_LAST` | `ADDRESS` | `ADDRESS_STREET1` | `ADDRESS_STREET2` | `ADDRESS_STREET3` | `ADDRESS_CITY` | `ADDRESS_STATE` | `ADDRESS_COUNTRY` | `ADDRESS_POSTALCODE` | `PHONE` | `PHONE_NUMBER` | `EMAIL_ADDRESS` | `UNIQUE_ID` | `PROVIDER_ID`
         *
         * TransUnion supports: `NAME` | `NAME_FIRST` | `NAME_LAST` | `ADDRESS` | `ADDRESS_CITY` | `ADDRESS_STATE` | `ADDRESS_COUNTRY` | `ADDRESS_POSTALCODE` | `PHONE_NUMBER` | `EMAIL_ADDRESS` | `UNIQUE_ID` | `IPV4` | `IPV6` | `MAID`
         *
         * Unified ID 2.0 supports: `PHONE_NUMBER` | `EMAIL_ADDRESS` | `UNIQUE_ID`
         *
         * > Normalization is only supported for `NAME` , `ADDRESS` , `PHONE` , and `EMAIL_ADDRESS` .
         * >
         * > If you want to normalize `NAME_FIRST` , `NAME_MIDDLE` , and `NAME_LAST` , you must group them by assigning them to the `NAME` `groupName` .
         * >
         * > If you want to normalize `ADDRESS_STREET1` , `ADDRESS_STREET2` , `ADDRESS_STREET3` , `ADDRESS_CITY` , `ADDRESS_STATE` , `ADDRESS_COUNTRY` , and `ADDRESS_POSTALCODE` , you must group them by assigning them to the `ADDRESS` `groupName` .
         * >
         * > If you want to normalize `PHONE_NUMBER` and `PHONE_COUNTRYCODE` , you must group them by assigning them to the `PHONE` `groupName` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-schemamapping-schemainputattribute.html#cfn-entityresolution-schemamapping-schemainputattribute-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnSchemaMappingPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-schemamapping.html
 */
export interface CfnSchemaMappingMixinProps {
    /**
     * A description of the schema.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-schemamapping.html#cfn-entityresolution-schemamapping-description
     */
    readonly description?: string;
    /**
     * A list of `MappedInputFields` .
     *
     * Each `MappedInputField` corresponds to a column the source data table, and contains column name plus additional information that AWS Entity Resolution uses for matching.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-schemamapping.html#cfn-entityresolution-schemamapping-mappedinputfields
     */
    readonly mappedInputFields?: Array<cdk.IResolvable | CfnSchemaMappingPropsMixin.SchemaInputAttributeProperty> | cdk.IResolvable;
    /**
     * The name of the schema.
     *
     * There can't be multiple `SchemaMappings` with the same name.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-schemamapping.html#cfn-entityresolution-schemamapping-schemaname
     */
    readonly schemaName?: string;
    /**
     * The tags used to organize, track, or control access for this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-schemamapping.html#cfn-entityresolution-schemamapping-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates an `IdMappingWorkflow` object which stores the configuration of the data processing job to be run.
 *
 * Each `IdMappingWorkflow` must have a unique workflow name. To modify an existing workflow, use the UpdateIdMappingWorkflow API.
 *
 * > Incremental processing is not supported for ID mapping workflows.
 *
 * @cloudformationResource AWS::EntityResolution::IdMappingWorkflow
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html
 */
export declare class CfnIdMappingWorkflowPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIdMappingWorkflowMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EntityResolution::IdMappingWorkflow`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIdMappingWorkflowMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIdMappingWorkflow;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIdMappingWorkflowPropsMixin {
    /**
     * An object containing `inputSourceARN` , `schemaName` , and `type` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowinputsource.html
     */
    interface IdMappingWorkflowInputSourceProperty {
        /**
         * An AWS Glue table Amazon Resource Name (ARN) or a matching workflow ARN for the input source table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowinputsource.html#cfn-entityresolution-idmappingworkflow-idmappingworkflowinputsource-inputsourcearn
         */
        readonly inputSourceArn?: string;
        /**
         * The ARN (Amazon Resource Name) that AWS Entity Resolution generated for the `SchemaMapping` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowinputsource.html#cfn-entityresolution-idmappingworkflow-idmappingworkflowinputsource-schemaarn
         */
        readonly schemaArn?: string;
        /**
         * The type of ID namespace. There are two types: `SOURCE` and `TARGET` .
         *
         * The `SOURCE` contains configurations for `sourceId` data that will be processed in an ID mapping workflow.
         *
         * The `TARGET` contains a configuration of `targetId` which all `sourceIds` will resolve to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowinputsource.html#cfn-entityresolution-idmappingworkflow-idmappingworkflowinputsource-type
         */
        readonly type?: string;
    }
    /**
     * An object which defines the ID mapping technique and any additional configurations.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingtechniques.html
     */
    interface IdMappingTechniquesProperty {
        /**
         * The type of ID mapping.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingtechniques.html#cfn-entityresolution-idmappingworkflow-idmappingtechniques-idmappingtype
         */
        readonly idMappingType?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingtechniques.html#cfn-entityresolution-idmappingworkflow-idmappingtechniques-normalizationversion
         */
        readonly normalizationVersion?: string;
        /**
         * An object which defines any additional configurations required by the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingtechniques.html#cfn-entityresolution-idmappingworkflow-idmappingtechniques-providerproperties
         */
        readonly providerProperties?: cdk.IResolvable | CfnIdMappingWorkflowPropsMixin.ProviderPropertiesProperty;
        /**
         * An object which defines any additional configurations required by rule-based matching.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingtechniques.html#cfn-entityresolution-idmappingworkflow-idmappingtechniques-rulebasedproperties
         */
        readonly ruleBasedProperties?: CfnIdMappingWorkflowPropsMixin.IdMappingRuleBasedPropertiesProperty | cdk.IResolvable;
    }
    /**
     * An object that defines the list of matching rules to run in an ID mapping workflow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingrulebasedproperties.html
     */
    interface IdMappingRuleBasedPropertiesProperty {
        /**
         * The comparison type. You can either choose `ONE_TO_ONE` or `MANY_TO_MANY` as the `attributeMatchingModel` .
         *
         * If you choose `ONE_TO_ONE` , the system can only match attributes if the sub-types are an exact match. For example, for the `Email` attribute type, the system will only consider it a match if the value of the `Email` field of Profile A matches the value of the `Email` field of Profile B.
         *
         * If you choose `MANY_TO_MANY` , the system can match attributes across the sub-types of an attribute type. For example, if the value of the `Email` field of Profile A matches the value of the `BusinessEmail` field of Profile B, the two profiles are matched on the `Email` attribute type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingrulebasedproperties.html#cfn-entityresolution-idmappingworkflow-idmappingrulebasedproperties-attributematchingmodel
         */
        readonly attributeMatchingModel?: string;
        /**
         * The type of matching record that is allowed to be used in an ID mapping workflow.
         *
         * If the value is set to `ONE_SOURCE_TO_ONE_TARGET` , only one record in the source can be matched to the same record in the target.
         *
         * If the value is set to `MANY_SOURCE_TO_ONE_TARGET` , multiple records in the source can be matched to one record in the target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingrulebasedproperties.html#cfn-entityresolution-idmappingworkflow-idmappingrulebasedproperties-recordmatchingmodel
         */
        readonly recordMatchingModel?: string;
        /**
         * The set of rules you can use in an ID mapping workflow.
         *
         * The limitations specified for the source or target to define the match rules must be compatible.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingrulebasedproperties.html#cfn-entityresolution-idmappingworkflow-idmappingrulebasedproperties-ruledefinitiontype
         */
        readonly ruleDefinitionType?: string;
        /**
         * The rules that can be used for ID mapping.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingrulebasedproperties.html#cfn-entityresolution-idmappingworkflow-idmappingrulebasedproperties-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnIdMappingWorkflowPropsMixin.RuleProperty> | cdk.IResolvable;
    }
    /**
     * An object containing the `ruleName` and `matchingKeys` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-rule.html
     */
    interface RuleProperty {
        /**
         * A list of `MatchingKeys` .
         *
         * The `MatchingKeys` must have been defined in the `SchemaMapping` . Two records are considered to match according to this rule if all of the `MatchingKeys` match.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-rule.html#cfn-entityresolution-idmappingworkflow-rule-matchingkeys
         */
        readonly matchingKeys?: Array<string>;
        /**
         * A name for the matching rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-rule.html#cfn-entityresolution-idmappingworkflow-rule-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * An object containing the `providerServiceARN` , `intermediateSourceConfiguration` , and `providerConfiguration` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-providerproperties.html
     */
    interface ProviderPropertiesProperty {
        /**
         * The Amazon S3 location that temporarily stores your data while it processes.
         *
         * Your information won't be saved permanently.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-providerproperties.html#cfn-entityresolution-idmappingworkflow-providerproperties-intermediatesourceconfiguration
         */
        readonly intermediateSourceConfiguration?: CfnIdMappingWorkflowPropsMixin.IntermediateSourceConfigurationProperty | cdk.IResolvable;
        /**
         * The required configuration fields to use with the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-providerproperties.html#cfn-entityresolution-idmappingworkflow-providerproperties-providerconfiguration
         */
        readonly providerConfiguration?: cdk.IResolvable | Record<string, string>;
        /**
         * The ARN of the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-providerproperties.html#cfn-entityresolution-idmappingworkflow-providerproperties-providerservicearn
         */
        readonly providerServiceArn?: string;
    }
    /**
     * The Amazon S3 location that temporarily stores your data while it processes.
     *
     * Your information won't be saved permanently.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-intermediatesourceconfiguration.html
     */
    interface IntermediateSourceConfigurationProperty {
        /**
         * The Amazon S3 location (bucket and prefix).
         *
         * For example: `s3://provider_bucket/DOC-EXAMPLE-BUCKET`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-intermediatesourceconfiguration.html#cfn-entityresolution-idmappingworkflow-intermediatesourceconfiguration-intermediates3path
         */
        readonly intermediateS3Path?: string;
    }
    /**
     * A list of `IdMappingWorkflowOutputSource` objects, each of which contains fields `outputS3Path` and `KMSArn` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowoutputsource.html
     */
    interface IdMappingWorkflowOutputSourceProperty {
        /**
         * Customer AWS  ARN for encryption at rest.
         *
         * If not provided, system will use an AWS Entity Resolution managed KMS key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowoutputsource.html#cfn-entityresolution-idmappingworkflow-idmappingworkflowoutputsource-kmsarn
         */
        readonly kmsArn?: string;
        /**
         * The S3 path to which AWS Entity Resolution will write the output table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingworkflowoutputsource.html#cfn-entityresolution-idmappingworkflow-idmappingworkflowoutputsource-outputs3path
         */
        readonly outputS3Path?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingincrementalrunconfig.html
     */
    interface IdMappingIncrementalRunConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idmappingworkflow-idmappingincrementalrunconfig.html#cfn-entityresolution-idmappingworkflow-idmappingincrementalrunconfig-incrementalruntype
         */
        readonly incrementalRunType?: string;
    }
}
/**
 * Properties for CfnIdMappingWorkflowPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html
 */
export interface CfnIdMappingWorkflowMixinProps {
    /**
     * A description of the workflow.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-description
     */
    readonly description?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-idmappingincrementalrunconfig
     */
    readonly idMappingIncrementalRunConfig?: CfnIdMappingWorkflowPropsMixin.IdMappingIncrementalRunConfigProperty | cdk.IResolvable;
    /**
     * An object which defines the ID mapping technique and any additional configurations.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-idmappingtechniques
     */
    readonly idMappingTechniques?: CfnIdMappingWorkflowPropsMixin.IdMappingTechniquesProperty | cdk.IResolvable;
    /**
     * A list of `InputSource` objects, which have the fields `InputSourceARN` and `SchemaName` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-inputsourceconfig
     */
    readonly inputSourceConfig?: Array<CfnIdMappingWorkflowPropsMixin.IdMappingWorkflowInputSourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * A list of `IdMappingWorkflowOutputSource` objects, each of which contains fields `outputS3Path` and `KMSArn` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-outputsourceconfig
     */
    readonly outputSourceConfig?: Array<CfnIdMappingWorkflowPropsMixin.IdMappingWorkflowOutputSourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the IAM role.
     *
     * AWS Entity Resolution assumes this role to create resources on your behalf as part of workflow execution.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-rolearn
     */
    readonly roleArn?: string;
    /**
     * The tags used to organize, track, or control access for this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The name of the workflow.
     *
     * There can't be multiple `IdMappingWorkflows` with the same name.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idmappingworkflow.html#cfn-entityresolution-idmappingworkflow-workflowname
     */
    readonly workflowName?: string;
}
/**
 * Creates an ID namespace object which will help customers provide metadata explaining their dataset and how to use it.
 *
 * Each ID namespace must have a unique name. To modify an existing ID namespace, use the UpdateIdNamespace API.
 *
 * @cloudformationResource AWS::EntityResolution::IdNamespace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html
 */
export declare class CfnIdNamespacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIdNamespaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EntityResolution::IdNamespace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIdNamespaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIdNamespace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIdNamespacePropsMixin {
    /**
     * An object containing `inputSourceARN` and `schemaName` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceinputsource.html
     */
    interface IdNamespaceInputSourceProperty {
        /**
         * An AWS Glue table Amazon Resource Name (ARN) or a matching workflow ARN for the input source table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceinputsource.html#cfn-entityresolution-idnamespace-idnamespaceinputsource-inputsourcearn
         */
        readonly inputSourceArn?: string;
        /**
         * The name of the schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceinputsource.html#cfn-entityresolution-idnamespace-idnamespaceinputsource-schemaname
         */
        readonly schemaName?: string;
    }
    /**
     * An object containing `idMappingType` , `providerProperties` , and `ruleBasedProperties` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties.html
     */
    interface IdNamespaceIdMappingWorkflowPropertiesProperty {
        /**
         * The type of ID mapping.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties.html#cfn-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties-idmappingtype
         */
        readonly idMappingType?: string;
        /**
         * An object which defines any additional configurations required by the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties.html#cfn-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties-providerproperties
         */
        readonly providerProperties?: cdk.IResolvable | CfnIdNamespacePropsMixin.NamespaceProviderPropertiesProperty;
        /**
         * An object which defines any additional configurations required by rule-based matching.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties.html#cfn-entityresolution-idnamespace-idnamespaceidmappingworkflowproperties-rulebasedproperties
         */
        readonly ruleBasedProperties?: cdk.IResolvable | CfnIdNamespacePropsMixin.NamespaceRuleBasedPropertiesProperty;
    }
    /**
     * The rule-based properties of an ID namespace.
     *
     * These properties define how the ID namespace can be used in an ID mapping workflow.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespacerulebasedproperties.html
     */
    interface NamespaceRuleBasedPropertiesProperty {
        /**
         * The comparison type. You can either choose `ONE_TO_ONE` or `MANY_TO_MANY` as the `attributeMatchingModel` .
         *
         * If you choose `ONE_TO_ONE` , the system can only match attributes if the sub-types are an exact match. For example, for the `Email` attribute type, the system will only consider it a match if the value of the `Email` field of Profile A matches the value of the `Email` field of Profile B.
         *
         * If you choose `MANY_TO_MANY` , the system can match attributes across the sub-types of an attribute type. For example, if the value of the `Email` field of Profile A matches the value of `BusinessEmail` field of Profile B, the two profiles are matched on the `Email` attribute type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespacerulebasedproperties.html#cfn-entityresolution-idnamespace-namespacerulebasedproperties-attributematchingmodel
         */
        readonly attributeMatchingModel?: string;
        /**
         * The type of matching record that is allowed to be used in an ID mapping workflow.
         *
         * If the value is set to `ONE_SOURCE_TO_ONE_TARGET` , only one record in the source is matched to one record in the target.
         *
         * If the value is set to `MANY_SOURCE_TO_ONE_TARGET` , all matching records in the source are matched to one record in the target.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespacerulebasedproperties.html#cfn-entityresolution-idnamespace-namespacerulebasedproperties-recordmatchingmodels
         */
        readonly recordMatchingModels?: Array<string>;
        /**
         * The sets of rules you can use in an ID mapping workflow.
         *
         * The limitations specified for the source and target must be compatible.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespacerulebasedproperties.html#cfn-entityresolution-idnamespace-namespacerulebasedproperties-ruledefinitiontypes
         */
        readonly ruleDefinitionTypes?: Array<string>;
        /**
         * The rules for the ID namespace.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespacerulebasedproperties.html#cfn-entityresolution-idnamespace-namespacerulebasedproperties-rules
         */
        readonly rules?: Array<cdk.IResolvable | CfnIdNamespacePropsMixin.RuleProperty> | cdk.IResolvable;
    }
    /**
     * An object containing the `ruleName` and `matchingKeys` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-rule.html
     */
    interface RuleProperty {
        /**
         * A list of `MatchingKeys` .
         *
         * The `MatchingKeys` must have been defined in the `SchemaMapping` . Two records are considered to match according to this rule if all of the `MatchingKeys` match.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-rule.html#cfn-entityresolution-idnamespace-rule-matchingkeys
         */
        readonly matchingKeys?: Array<string>;
        /**
         * A name for the matching rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-rule.html#cfn-entityresolution-idnamespace-rule-rulename
         */
        readonly ruleName?: string;
    }
    /**
     * An object containing `providerConfiguration` and `providerServiceArn` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespaceproviderproperties.html
     */
    interface NamespaceProviderPropertiesProperty {
        /**
         * An object which defines any additional configurations required by the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespaceproviderproperties.html#cfn-entityresolution-idnamespace-namespaceproviderproperties-providerconfiguration
         */
        readonly providerConfiguration?: cdk.IResolvable | Record<string, string>;
        /**
         * The Amazon Resource Name (ARN) of the provider service.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-entityresolution-idnamespace-namespaceproviderproperties.html#cfn-entityresolution-idnamespace-namespaceproviderproperties-providerservicearn
         */
        readonly providerServiceArn?: string;
    }
}
/**
 * Properties for CfnIdNamespacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html
 */
export interface CfnIdNamespaceMixinProps {
    /**
     * The description of the ID namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-description
     */
    readonly description?: string;
    /**
     * Determines the properties of `IdMappingWorflow` where this `IdNamespace` can be used as a `Source` or a `Target` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-idmappingworkflowproperties
     */
    readonly idMappingWorkflowProperties?: Array<CfnIdNamespacePropsMixin.IdNamespaceIdMappingWorkflowPropertiesProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The name of the ID namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-idnamespacename
     */
    readonly idNamespaceName?: string;
    /**
     * A list of `InputSource` objects, which have the fields `InputSourceARN` and `SchemaName` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-inputsourceconfig
     */
    readonly inputSourceConfig?: Array<CfnIdNamespacePropsMixin.IdNamespaceInputSourceProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the IAM role.
     *
     * AWS Entity Resolution assumes this role to access the resources defined in this `IdNamespace` on your behalf as part of the workflow run.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-rolearn
     */
    readonly roleArn?: string;
    /**
     * The tags used to organize, track, or control access for this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The type of ID namespace. There are two types: `SOURCE` and `TARGET` .
     *
     * The `SOURCE` contains configurations for `sourceId` data that will be processed in an ID mapping workflow.
     *
     * The `TARGET` contains a configuration of `targetId` which all `sourceIds` will resolve to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-idnamespace.html#cfn-entityresolution-idnamespace-type
     */
    readonly type?: string;
}
/**
 * Adds a policy statement object.
 *
 * To retrieve a list of existing policy statements, use the `GetPolicy` API.
 *
 * @cloudformationResource AWS::EntityResolution::PolicyStatement
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html
 */
export declare class CfnPolicyStatementPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPolicyStatementMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EntityResolution::PolicyStatement`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPolicyStatementMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPolicyStatement;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnPolicyStatementPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html
 */
export interface CfnPolicyStatementMixinProps {
    /**
     * The action that the principal can use on the resource.
     *
     * For example, `entityresolution:GetIdMappingJob` , `entityresolution:GetMatchingJob` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html#cfn-entityresolution-policystatement-action
     */
    readonly action?: Array<string>;
    /**
     * The Amazon Resource Name (ARN) of the resource that will be accessed by the principal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html#cfn-entityresolution-policystatement-arn
     */
    readonly arn?: string;
    /**
     * A set of condition keys that you can use in key policies.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html#cfn-entityresolution-policystatement-condition
     */
    readonly condition?: string;
    /**
     * Determines whether the permissions specified in the policy are to be allowed ( `Allow` ) or denied ( `Deny` ).
     *
     * > If you set the value of the `effect` parameter to `Deny` for the `AddPolicyStatement` operation, you must also set the value of the `effect` parameter in the `policy` to `Deny` for the `PutPolicy` operation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html#cfn-entityresolution-policystatement-effect
     */
    readonly effect?: string;
    /**
     * The AWS service or AWS account that can access the resource defined as ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html#cfn-entityresolution-policystatement-principal
     */
    readonly principal?: Array<string>;
    /**
     * A statement identifier that differentiates the statement from others in the same policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-entityresolution-policystatement.html#cfn-entityresolution-policystatement-statementid
     */
    readonly statementId?: string;
}
