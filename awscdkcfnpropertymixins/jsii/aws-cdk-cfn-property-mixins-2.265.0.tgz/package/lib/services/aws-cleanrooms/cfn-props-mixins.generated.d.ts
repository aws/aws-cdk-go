import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-cleanrooms";
/**
 * Creates a new analysis template.
 *
 * @cloudformationResource AWS::CleanRooms::AnalysisTemplate
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html
 */
export declare class CfnAnalysisTemplatePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAnalysisTemplateMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::AnalysisTemplate`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAnalysisTemplateMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAnalysisTemplate;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnAnalysisTemplatePropsMixin {
    /**
     * Optional.
     *
     * The member who can query can provide this placeholder for a literal data value in an analysis template.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysisparameter.html
     */
    interface AnalysisParameterProperty {
        /**
         * Optional.
         *
         * The default value that is applied in the analysis template. The member who can query can override this value in the query editor.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysisparameter.html#cfn-cleanrooms-analysistemplate-analysisparameter-defaultvalue
         */
        readonly defaultValue?: string;
        /**
         * The name of the parameter.
         *
         * The name must use only alphanumeric, underscore (_), or hyphen (-) characters but cannot start or end with a hyphen.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysisparameter.html#cfn-cleanrooms-analysistemplate-analysisparameter-name
         */
        readonly name?: string;
        /**
         * The type of parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysisparameter.html#cfn-cleanrooms-analysistemplate-analysisparameter-type
         */
        readonly type?: string;
    }
    /**
     * The structure that defines the body of the analysis template.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysissource.html
     */
    interface AnalysisSourceProperty {
        /**
         * The artifacts of the analysis source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysissource.html#cfn-cleanrooms-analysistemplate-analysissource-artifacts
         */
        readonly artifacts?: CfnAnalysisTemplatePropsMixin.AnalysisTemplateArtifactsProperty | cdk.IResolvable;
        /**
         * The query text.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysissource.html#cfn-cleanrooms-analysistemplate-analysissource-text
         */
        readonly text?: string;
    }
    /**
     * The analysis template artifacts.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifacts.html
     */
    interface AnalysisTemplateArtifactsProperty {
        /**
         * Additional artifacts for the analysis template.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifacts.html#cfn-cleanrooms-analysistemplate-analysistemplateartifacts-additionalartifacts
         */
        readonly additionalArtifacts?: Array<CfnAnalysisTemplatePropsMixin.AnalysisTemplateArtifactProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The entry point for the analysis template artifacts.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifacts.html#cfn-cleanrooms-analysistemplate-analysistemplateartifacts-entrypoint
         */
        readonly entryPoint?: CfnAnalysisTemplatePropsMixin.AnalysisTemplateArtifactProperty | cdk.IResolvable;
        /**
         * The role ARN for the analysis template artifacts.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifacts.html#cfn-cleanrooms-analysistemplate-analysistemplateartifacts-rolearn
         */
        readonly roleArn?: string;
    }
    /**
     * The analysis template artifact.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifact.html
     */
    interface AnalysisTemplateArtifactProperty {
        /**
         * The artifact location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifact.html#cfn-cleanrooms-analysistemplate-analysistemplateartifact-location
         */
        readonly location?: cdk.IResolvable | CfnAnalysisTemplatePropsMixin.S3LocationProperty;
    }
    /**
     * The S3 location.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-s3location.html
     */
    interface S3LocationProperty {
        /**
         * The bucket name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-s3location.html#cfn-cleanrooms-analysistemplate-s3location-bucket
         */
        readonly bucket?: string;
        /**
         * The object key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-s3location.html#cfn-cleanrooms-analysistemplate-s3location-key
         */
        readonly key?: string;
    }
    /**
     * A relation within an analysis.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysisschema.html
     */
    interface AnalysisSchemaProperty {
        /**
         * The tables referenced in the analysis schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysisschema.html#cfn-cleanrooms-analysistemplate-analysisschema-referencedtables
         */
        readonly referencedTables?: Array<string>;
    }
    /**
     * The analysis source metadata.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysissourcemetadata.html
     */
    interface AnalysisSourceMetadataProperty {
        /**
         * The artifacts of the analysis source metadata.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysissourcemetadata.html#cfn-cleanrooms-analysistemplate-analysissourcemetadata-artifacts
         */
        readonly artifacts?: CfnAnalysisTemplatePropsMixin.AnalysisTemplateArtifactMetadataProperty | cdk.IResolvable;
    }
    /**
     * The analysis template artifact metadata.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifactmetadata.html
     */
    interface AnalysisTemplateArtifactMetadataProperty {
        /**
         * Additional artifact hashes for the analysis template.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifactmetadata.html#cfn-cleanrooms-analysistemplate-analysistemplateartifactmetadata-additionalartifacthashes
         */
        readonly additionalArtifactHashes?: Array<CfnAnalysisTemplatePropsMixin.HashProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The hash of the entry point for the analysis template artifact metadata.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-analysistemplateartifactmetadata.html#cfn-cleanrooms-analysistemplate-analysistemplateartifactmetadata-entrypointhash
         */
        readonly entryPointHash?: CfnAnalysisTemplatePropsMixin.HashProperty | cdk.IResolvable;
    }
    /**
     * Hash.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-hash.html
     */
    interface HashProperty {
        /**
         * The SHA-256 hash value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-hash.html#cfn-cleanrooms-analysistemplate-hash-sha256
         */
        readonly sha256?: string;
    }
    /**
     * A structure that defines the level of detail included in error messages returned by PySpark jobs.
     *
     * This configuration allows you to control the verbosity of error messages to help with troubleshooting PySpark jobs while maintaining appropriate security controls.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-errormessageconfiguration.html
     */
    interface ErrorMessageConfigurationProperty {
        /**
         * The level of detail for error messages returned by the PySpark job.
         *
         * When set to DETAILED, error messages include more information to help troubleshoot issues with your PySpark job.
         *
         * Because this setting may expose sensitive data, it is recommended for development and testing environments.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-errormessageconfiguration.html#cfn-cleanrooms-analysistemplate-errormessageconfiguration-type
         */
        readonly type?: string;
    }
    /**
     * The parameters that control how synthetic data is generated, including privacy settings, column classifications, and other configuration options that affect the data synthesis process.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-syntheticdataparameters.html
     */
    interface SyntheticDataParametersProperty {
        /**
         * The machine learning-specific parameters for synthetic data generation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-syntheticdataparameters.html#cfn-cleanrooms-analysistemplate-syntheticdataparameters-mlsyntheticdataparameters
         */
        readonly mlSyntheticDataParameters?: cdk.IResolvable | CfnAnalysisTemplatePropsMixin.MLSyntheticDataParametersProperty;
    }
    /**
     * Parameters that control the generation of synthetic data for machine learning, including privacy settings and column classification details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-mlsyntheticdataparameters.html
     */
    interface MLSyntheticDataParametersProperty {
        /**
         * Classification details for data columns that specify how each column should be treated during synthetic data generation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-mlsyntheticdataparameters.html#cfn-cleanrooms-analysistemplate-mlsyntheticdataparameters-columnclassification
         */
        readonly columnClassification?: CfnAnalysisTemplatePropsMixin.ColumnClassificationDetailsProperty | cdk.IResolvable;
        /**
         * The epsilon value for differential privacy when generating synthetic data.
         *
         * Lower values provide stronger privacy guarantees but may reduce data utility.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-mlsyntheticdataparameters.html#cfn-cleanrooms-analysistemplate-mlsyntheticdataparameters-epsilon
         */
        readonly epsilon?: number;
        /**
         * The maximum acceptable score for membership inference attack vulnerability.
         *
         * Synthetic data generation fails if the score for the resulting data exceeds this threshold.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-mlsyntheticdataparameters.html#cfn-cleanrooms-analysistemplate-mlsyntheticdataparameters-maxmembershipinferenceattackscore
         */
        readonly maxMembershipInferenceAttackScore?: number;
    }
    /**
     * Contains classification information for data columns, including mappings that specify how columns should be handled during synthetic data generation and privacy analysis.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-columnclassificationdetails.html
     */
    interface ColumnClassificationDetailsProperty {
        /**
         * A mapping that defines the classification of data columns for synthetic data generation and specifies how each column should be handled during the privacy-preserving data synthesis process.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-columnclassificationdetails.html#cfn-cleanrooms-analysistemplate-columnclassificationdetails-columnmapping
         */
        readonly columnMapping?: Array<cdk.IResolvable | CfnAnalysisTemplatePropsMixin.SyntheticDataColumnPropertiesProperty> | cdk.IResolvable;
    }
    /**
     * Properties that define how a specific data column should be handled during synthetic data generation, including its name, type, and role in predictive modeling.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-syntheticdatacolumnproperties.html
     */
    interface SyntheticDataColumnPropertiesProperty {
        /**
         * The name of the data column as it appears in the dataset.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-syntheticdatacolumnproperties.html#cfn-cleanrooms-analysistemplate-syntheticdatacolumnproperties-columnname
         */
        readonly columnName?: string;
        /**
         * The data type of the column, which determines how the synthetic data generation algorithm processes and synthesizes values for this column.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-syntheticdatacolumnproperties.html#cfn-cleanrooms-analysistemplate-syntheticdatacolumnproperties-columntype
         */
        readonly columnType?: string;
        /**
         * Indicates if this column contains predictive values that should be treated as target variables in machine learning models.
         *
         * This affects how the synthetic data generation preserves statistical relationships.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-analysistemplate-syntheticdatacolumnproperties.html#cfn-cleanrooms-analysistemplate-syntheticdatacolumnproperties-ispredictivevalue
         */
        readonly isPredictiveValue?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnAnalysisTemplatePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html
 */
export interface CfnAnalysisTemplateMixinProps {
    /**
     * The parameters of the analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-analysisparameters
     */
    readonly analysisParameters?: Array<CfnAnalysisTemplatePropsMixin.AnalysisParameterProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The description of the analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-description
     */
    readonly description?: string;
    /**
     * The configuration that specifies the level of detail in error messages returned by analyses using this template.
     *
     * When set to `DETAILED` , error messages include more information to help troubleshoot issues with PySpark jobs. Detailed error messages may expose underlying data, including sensitive information. Recommended for faster troubleshooting in development and testing environments.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-errormessageconfiguration
     */
    readonly errorMessageConfiguration?: CfnAnalysisTemplatePropsMixin.ErrorMessageConfigurationProperty | cdk.IResolvable;
    /**
     * The format of the analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-format
     */
    readonly format?: string;
    /**
     * The identifier for a membership resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-membershipidentifier
     */
    readonly membershipIdentifier?: string;
    /**
     * The name of the analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-name
     */
    readonly name?: string;
    /**
     * The entire schema object.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-schema
     */
    readonly schema?: CfnAnalysisTemplatePropsMixin.AnalysisSchemaProperty | cdk.IResolvable;
    /**
     * The source of the analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-source
     */
    readonly source?: CfnAnalysisTemplatePropsMixin.AnalysisSourceProperty | cdk.IResolvable;
    /**
     * The source metadata for the analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-sourcemetadata
     */
    readonly sourceMetadata?: CfnAnalysisTemplatePropsMixin.AnalysisSourceMetadataProperty | cdk.IResolvable;
    /**
     * The parameters used to generate synthetic data for this analysis template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-syntheticdataparameters
     */
    readonly syntheticDataParameters?: cdk.IResolvable | CfnAnalysisTemplatePropsMixin.SyntheticDataParametersProperty;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-analysistemplate.html#cfn-cleanrooms-analysistemplate-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a new collaboration.
 *
 * @cloudformationResource AWS::CleanRooms::Collaboration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html
 */
export declare class CfnCollaborationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCollaborationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::Collaboration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCollaborationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCollaboration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCollaborationPropsMixin {
    /**
     * The settings for client-side encryption for cryptographic computing.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-dataencryptionmetadata.html
     */
    interface DataEncryptionMetadataProperty {
        /**
         * Indicates whether encrypted tables can contain cleartext data ( `TRUE` ) or are to cryptographically process every column ( `FALSE` ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-dataencryptionmetadata.html#cfn-cleanrooms-collaboration-dataencryptionmetadata-allowcleartext
         */
        readonly allowCleartext?: boolean | cdk.IResolvable;
        /**
         * Indicates whether Fingerprint columns can contain duplicate entries ( `TRUE` ) or are to contain only non-repeated values ( `FALSE` ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-dataencryptionmetadata.html#cfn-cleanrooms-collaboration-dataencryptionmetadata-allowduplicates
         */
        readonly allowDuplicates?: boolean | cdk.IResolvable;
        /**
         * Indicates whether Fingerprint columns can be joined on any other Fingerprint column with a different name ( `TRUE` ) or can only be joined on Fingerprint columns of the same name ( `FALSE` ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-dataencryptionmetadata.html#cfn-cleanrooms-collaboration-dataencryptionmetadata-allowjoinsoncolumnswithdifferentnames
         */
        readonly allowJoinsOnColumnsWithDifferentNames?: boolean | cdk.IResolvable;
        /**
         * Indicates whether NULL values are to be copied as NULL to encrypted tables ( `TRUE` ) or cryptographically processed ( `FALSE` ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-dataencryptionmetadata.html#cfn-cleanrooms-collaboration-dataencryptionmetadata-preservenulls
         */
        readonly preserveNulls?: boolean | cdk.IResolvable;
    }
    /**
     * Basic metadata used to construct a new member.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-memberspecification.html
     */
    interface MemberSpecificationProperty {
        /**
         * The identifier used to reference members of the collaboration.
         *
         * Currently only supports AWS account ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-memberspecification.html#cfn-cleanrooms-collaboration-memberspecification-accountid
         */
        readonly accountId?: string;
        /**
         * The member's display name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-memberspecification.html#cfn-cleanrooms-collaboration-memberspecification-displayname
         */
        readonly displayName?: string;
        /**
         * The abilities granted to the collaboration member.
         *
         * *Allowed Values* : `CAN_QUERY` | `CAN_RECEIVE_RESULTS`
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-memberspecification.html#cfn-cleanrooms-collaboration-memberspecification-memberabilities
         */
        readonly memberAbilities?: Array<string>;
        /**
         * The ML abilities granted to the collaboration member.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-memberspecification.html#cfn-cleanrooms-collaboration-memberspecification-mlmemberabilities
         */
        readonly mlMemberAbilities?: cdk.IResolvable | CfnCollaborationPropsMixin.MLMemberAbilitiesProperty;
        /**
         * The collaboration member's payment responsibilities set by the collaboration creator.
         *
         * If the collaboration creator hasn't speciﬁed anyone as the member paying for query compute costs, then the member who can query is the default payer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-memberspecification.html#cfn-cleanrooms-collaboration-memberspecification-paymentconfiguration
         */
        readonly paymentConfiguration?: cdk.IResolvable | CfnCollaborationPropsMixin.PaymentConfigurationProperty;
    }
    /**
     * The ML member abilities for a collaboration member.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-mlmemberabilities.html
     */
    interface MLMemberAbilitiesProperty {
        /**
         * The custom ML member abilities for a collaboration member.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-mlmemberabilities.html#cfn-cleanrooms-collaboration-mlmemberabilities-custommlmemberabilities
         */
        readonly customMlMemberAbilities?: Array<string>;
    }
    /**
     * An object representing the collaboration member's payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-paymentconfiguration.html
     */
    interface PaymentConfigurationProperty {
        /**
         * The compute configuration for the job.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-paymentconfiguration.html#cfn-cleanrooms-collaboration-paymentconfiguration-jobcompute
         */
        readonly jobCompute?: cdk.IResolvable | CfnCollaborationPropsMixin.JobComputePaymentConfigProperty;
        /**
         * An object representing the collaboration member's machine learning payment responsibilities set by the collaboration creator.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-paymentconfiguration.html#cfn-cleanrooms-collaboration-paymentconfiguration-machinelearning
         */
        readonly machineLearning?: cdk.IResolvable | CfnCollaborationPropsMixin.MLPaymentConfigProperty;
        /**
         * The collaboration member's payment responsibilities set by the collaboration creator for query compute costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-paymentconfiguration.html#cfn-cleanrooms-collaboration-paymentconfiguration-querycompute
         */
        readonly queryCompute?: cdk.IResolvable | CfnCollaborationPropsMixin.QueryComputePaymentConfigProperty;
    }
    /**
     * An object representing the collaboration member's payment responsibilities set by the collaboration creator for query and job compute costs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-jobcomputepaymentconfig.html
     */
    interface JobComputePaymentConfigProperty {
        /**
         * Indicates whether the collaboration creator has configured the collaboration member to pay for query and job compute costs ( `TRUE` ) or has not configured the collaboration member to pay for query and job compute costs ( `FALSE` ).
         *
         * Exactly one member can be configured to pay for query and job compute costs. An error is returned if the collaboration creator sets a `TRUE` value for more than one member in the collaboration.
         *
         * An error is returned if the collaboration creator sets a `FALSE` value for the member who can run queries and jobs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-jobcomputepaymentconfig.html#cfn-cleanrooms-collaboration-jobcomputepaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * An object representing the collaboration member's payment responsibilities set by the collaboration creator for query compute costs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-querycomputepaymentconfig.html
     */
    interface QueryComputePaymentConfigProperty {
        /**
         * Indicates whether the collaboration creator has configured the collaboration member to pay for query compute costs ( `TRUE` ) or has not configured the collaboration member to pay for query compute costs ( `FALSE` ).
         *
         * Exactly one member can be configured to pay for query compute costs. An error is returned if the collaboration creator sets a `TRUE` value for more than one member in the collaboration.
         *
         * If the collaboration creator hasn't specified anyone as the member paying for query compute costs, then the member who can query is the default payer. An error is returned if the collaboration creator sets a `FALSE` value for the member who can query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-querycomputepaymentconfig.html#cfn-cleanrooms-collaboration-querycomputepaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * An object representing the collaboration member's machine learning payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-mlpaymentconfig.html
     */
    interface MLPaymentConfigProperty {
        /**
         * The payment responsibilities accepted by the member for model inference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-mlpaymentconfig.html#cfn-cleanrooms-collaboration-mlpaymentconfig-modelinference
         */
        readonly modelInference?: cdk.IResolvable | CfnCollaborationPropsMixin.ModelInferencePaymentConfigProperty;
        /**
         * The payment responsibilities accepted by the member for model training.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-mlpaymentconfig.html#cfn-cleanrooms-collaboration-mlpaymentconfig-modeltraining
         */
        readonly modelTraining?: cdk.IResolvable | CfnCollaborationPropsMixin.ModelTrainingPaymentConfigProperty;
        /**
         * The payment configuration for machine learning synthetic data generation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-mlpaymentconfig.html#cfn-cleanrooms-collaboration-mlpaymentconfig-syntheticdatageneration
         */
        readonly syntheticDataGeneration?: cdk.IResolvable | CfnCollaborationPropsMixin.SyntheticDataGenerationPaymentConfigProperty;
    }
    /**
     * An object representing the collaboration member's model training payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-modeltrainingpaymentconfig.html
     */
    interface ModelTrainingPaymentConfigProperty {
        /**
         * Indicates whether the collaboration creator has configured the collaboration member to pay for model training costs ( `TRUE` ) or has not configured the collaboration member to pay for model training costs ( `FALSE` ).
         *
         * Exactly one member can be configured to pay for model training costs. An error is returned if the collaboration creator sets a `TRUE` value for more than one member in the collaboration.
         *
         * If the collaboration creator hasn't specified anyone as the member paying for model training costs, then the member who can query is the default payer. An error is returned if the collaboration creator sets a `FALSE` value for the member who can query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-modeltrainingpaymentconfig.html#cfn-cleanrooms-collaboration-modeltrainingpaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * An object representing the collaboration member's model inference payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-modelinferencepaymentconfig.html
     */
    interface ModelInferencePaymentConfigProperty {
        /**
         * Indicates whether the collaboration creator has configured the collaboration member to pay for model inference costs ( `TRUE` ) or has not configured the collaboration member to pay for model inference costs ( `FALSE` ).
         *
         * Exactly one member can be configured to pay for model inference costs. An error is returned if the collaboration creator sets a `TRUE` value for more than one member in the collaboration.
         *
         * If the collaboration creator hasn't specified anyone as the member paying for model inference costs, then the member who can query is the default payer. An error is returned if the collaboration creator sets a `FALSE` value for the member who can query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-modelinferencepaymentconfig.html#cfn-cleanrooms-collaboration-modelinferencepaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * Payment configuration for synthetic data generation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-syntheticdatagenerationpaymentconfig.html
     */
    interface SyntheticDataGenerationPaymentConfigProperty {
        /**
         * Indicates who is responsible for paying for synthetic data generation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-collaboration-syntheticdatagenerationpaymentconfig.html#cfn-cleanrooms-collaboration-syntheticdatagenerationpaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnCollaborationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html
 */
export interface CfnCollaborationMixinProps {
    /**
     * The AWS Regions where collaboration query results can be stored.
     *
     * Returns the list of Region identifiers that were specified when the collaboration was created. This list is used to enforce regional storage policies and compliance requirements.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-allowedresultregions
     */
    readonly allowedResultRegions?: Array<string>;
    /**
     * The analytics engine for the collaboration.
     *
     * > After July 16, 2025, the `CLEAN_ROOMS_SQL` parameter will no longer be available.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-analyticsengine
     */
    readonly analyticsEngine?: string;
    /**
     * The types of change requests that are automatically approved for this collaboration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-autoapprovedchangetypes
     */
    readonly autoApprovedChangeTypes?: Array<string>;
    /**
     * A display name of the collaboration creator.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-creatordisplayname
     */
    readonly creatorDisplayName?: string;
    /**
     * The abilities granted to the collaboration creator.
     *
     * *Allowed values* `CAN_QUERY` | `CAN_RECEIVE_RESULTS` | `CAN_RUN_JOB`
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-creatormemberabilities
     */
    readonly creatorMemberAbilities?: Array<string>;
    /**
     * The ML member abilities for a collaboration member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-creatormlmemberabilities
     */
    readonly creatorMlMemberAbilities?: cdk.IResolvable | CfnCollaborationPropsMixin.MLMemberAbilitiesProperty;
    /**
     * An object representing the collaboration member's payment responsibilities set by the collaboration creator.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-creatorpaymentconfiguration
     */
    readonly creatorPaymentConfiguration?: cdk.IResolvable | CfnCollaborationPropsMixin.PaymentConfigurationProperty;
    /**
     * The settings for client-side encryption for cryptographic computing.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-dataencryptionmetadata
     */
    readonly dataEncryptionMetadata?: CfnCollaborationPropsMixin.DataEncryptionMetadataProperty | cdk.IResolvable;
    /**
     * A description of the collaboration provided by the collaboration owner.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-description
     */
    readonly description?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-ismetricsenabled
     */
    readonly isMetricsEnabled?: boolean | cdk.IResolvable;
    /**
     * An indicator as to whether job logging has been enabled or disabled for the collaboration.
     *
     * When `ENABLED` , AWS Clean Rooms logs details about jobs run within this collaboration and those logs can be viewed in Amazon CloudWatch Logs. The default value is `DISABLED` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-joblogstatus
     */
    readonly jobLogStatus?: string;
    /**
     * A list of initial members, not including the creator.
     *
     * This list is immutable.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-members
     */
    readonly members?: Array<cdk.IResolvable | CfnCollaborationPropsMixin.MemberSpecificationProperty> | cdk.IResolvable;
    /**
     * A human-readable identifier provided by the collaboration owner.
     *
     * Display names are not unique.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-name
     */
    readonly name?: string;
    /**
     * An indicator as to whether query logging has been enabled or disabled for the collaboration.
     *
     * When `ENABLED` , AWS Clean Rooms logs details about queries run within this collaboration and those logs can be viewed in Amazon CloudWatch Logs. The default value is `DISABLED` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-querylogstatus
     */
    readonly queryLogStatus?: string;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-collaboration.html#cfn-cleanrooms-collaboration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a new configured table resource.
 *
 * @cloudformationResource AWS::CleanRooms::ConfiguredTable
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html
 */
export declare class CfnConfiguredTablePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConfiguredTableMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::ConfiguredTable`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConfiguredTableMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConfiguredTable;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConfiguredTablePropsMixin {
    /**
     * A pointer to the dataset that underlies this table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-tablereference.html
     */
    interface TableReferenceProperty {
        /**
         * If present, a reference to the Athena table referred to by this table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-tablereference.html#cfn-cleanrooms-configuredtable-tablereference-athena
         */
        readonly athena?: CfnConfiguredTablePropsMixin.AthenaTableReferenceProperty | cdk.IResolvable;
        /**
         * If present, a reference to the AWS Glue table referred to by this table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-tablereference.html#cfn-cleanrooms-configuredtable-tablereference-glue
         */
        readonly glue?: CfnConfiguredTablePropsMixin.GlueTableReferenceProperty | cdk.IResolvable;
        /**
         * If present, a reference to the Snowflake table referred to by this table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-tablereference.html#cfn-cleanrooms-configuredtable-tablereference-snowflake
         */
        readonly snowflake?: cdk.IResolvable | CfnConfiguredTablePropsMixin.SnowflakeTableReferenceProperty;
    }
    /**
     * A reference to a table within an AWS Glue data catalog.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-gluetablereference.html
     */
    interface GlueTableReferenceProperty {
        /**
         * The name of the database the AWS Glue table belongs to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-gluetablereference.html#cfn-cleanrooms-configuredtable-gluetablereference-databasename
         */
        readonly databaseName?: string;
        /**
         * The AWS Region where the AWS Glue table is located.
         *
         * This parameter is required to uniquely identify and access tables across different Regions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-gluetablereference.html#cfn-cleanrooms-configuredtable-gluetablereference-region
         */
        readonly region?: string;
        /**
         * The name of the AWS Glue table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-gluetablereference.html#cfn-cleanrooms-configuredtable-gluetablereference-tablename
         */
        readonly tableName?: string;
    }
    /**
     * A reference to a table within Snowflake.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html
     */
    interface SnowflakeTableReferenceProperty {
        /**
         * The account identifier for the Snowflake table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html#cfn-cleanrooms-configuredtable-snowflaketablereference-accountidentifier
         */
        readonly accountIdentifier?: string;
        /**
         * The name of the database the Snowflake table belongs to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html#cfn-cleanrooms-configuredtable-snowflaketablereference-databasename
         */
        readonly databaseName?: string;
        /**
         * The schema name of the Snowflake table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html#cfn-cleanrooms-configuredtable-snowflaketablereference-schemaname
         */
        readonly schemaName?: string;
        /**
         * The secret ARN of the Snowflake table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html#cfn-cleanrooms-configuredtable-snowflaketablereference-secretarn
         */
        readonly secretArn?: string;
        /**
         * The name of the Snowflake table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html#cfn-cleanrooms-configuredtable-snowflaketablereference-tablename
         */
        readonly tableName?: string;
        /**
         * The schema of the Snowflake table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketablereference.html#cfn-cleanrooms-configuredtable-snowflaketablereference-tableschema
         */
        readonly tableSchema?: cdk.IResolvable | CfnConfiguredTablePropsMixin.SnowflakeTableSchemaProperty;
    }
    /**
     * The schema of a Snowflake table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketableschema.html
     */
    interface SnowflakeTableSchemaProperty {
        /**
         * The schema of a Snowflake table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketableschema.html#cfn-cleanrooms-configuredtable-snowflaketableschema-v1
         */
        readonly v1?: Array<cdk.IResolvable | CfnConfiguredTablePropsMixin.SnowflakeTableSchemaV1Property> | cdk.IResolvable;
    }
    /**
     * The Snowflake table schema.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketableschemav1.html
     */
    interface SnowflakeTableSchemaV1Property {
        /**
         * The column name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketableschemav1.html#cfn-cleanrooms-configuredtable-snowflaketableschemav1-columnname
         */
        readonly columnName?: string;
        /**
         * The column's data type.
         *
         * Supported data types: `ARRAY` , `BIGINT` , `BOOLEAN` , `CHAR` , `DATE` , `DECIMAL` , `DOUBLE` , `DOUBLE PRECISION` , `FLOAT` , `FLOAT4` , `INT` , `INTEGER` , `MAP` , `NUMERIC` , `NUMBER` , `REAL` , `SMALLINT` , `STRING` , `TIMESTAMP` , `TIMESTAMP_LTZ` , `TIMESTAMP_NTZ` , `DATETIME` , `TINYINT` , `VARCHAR` , `TEXT` , `CHARACTER` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-snowflaketableschemav1.html#cfn-cleanrooms-configuredtable-snowflaketableschemav1-columntype
         */
        readonly columnType?: string;
    }
    /**
     * A reference to a table within Athena.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html
     */
    interface AthenaTableReferenceProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html#cfn-cleanrooms-configuredtable-athenatablereference-catalogname
         */
        readonly catalogName?: string;
        /**
         * The database name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html#cfn-cleanrooms-configuredtable-athenatablereference-databasename
         */
        readonly databaseName?: string;
        /**
         * The output location for the Athena table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html#cfn-cleanrooms-configuredtable-athenatablereference-outputlocation
         */
        readonly outputLocation?: string;
        /**
         * The AWS Region where the Athena table is located.
         *
         * This parameter is required to uniquely identify and access tables across different Regions.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html#cfn-cleanrooms-configuredtable-athenatablereference-region
         */
        readonly region?: string;
        /**
         * The table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html#cfn-cleanrooms-configuredtable-athenatablereference-tablename
         */
        readonly tableName?: string;
        /**
         * The workgroup of the Athena table reference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-athenatablereference.html#cfn-cleanrooms-configuredtable-athenatablereference-workgroup
         */
        readonly workGroup?: string;
    }
    /**
     * A specification about how data from the configured table can be used in a query.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrule.html
     */
    interface AnalysisRuleProperty {
        /**
         * A policy that describes the associated data usage limitations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrule.html#cfn-cleanrooms-configuredtable-analysisrule-policy
         */
        readonly policy?: CfnConfiguredTablePropsMixin.ConfiguredTableAnalysisRulePolicyProperty | cdk.IResolvable;
        /**
         * The type of analysis rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrule.html#cfn-cleanrooms-configuredtable-analysisrule-type
         */
        readonly type?: string;
    }
    /**
     * Controls on the query specifications that can be run on a configured table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-configuredtableanalysisrulepolicy.html
     */
    interface ConfiguredTableAnalysisRulePolicyProperty {
        /**
         * Controls on the query specifications that can be run on a configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-configuredtableanalysisrulepolicy.html#cfn-cleanrooms-configuredtable-configuredtableanalysisrulepolicy-v1
         */
        readonly v1?: CfnConfiguredTablePropsMixin.ConfiguredTableAnalysisRulePolicyV1Property | cdk.IResolvable;
    }
    /**
     * Controls on the query specifications that can be run on a configured table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1.html
     */
    interface ConfiguredTableAnalysisRulePolicyV1Property {
        /**
         * Analysis rule type that enables only aggregation queries on a configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1.html#cfn-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1-aggregation
         */
        readonly aggregation?: CfnConfiguredTablePropsMixin.AnalysisRuleAggregationProperty | cdk.IResolvable;
        /**
         * Analysis rule type that enables custom SQL queries on a configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1.html#cfn-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1-custom
         */
        readonly custom?: CfnConfiguredTablePropsMixin.AnalysisRuleCustomProperty | cdk.IResolvable;
        /**
         * Analysis rule type that enables only list queries on a configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1.html#cfn-cleanrooms-configuredtable-configuredtableanalysisrulepolicyv1-list
         */
        readonly list?: CfnConfiguredTablePropsMixin.AnalysisRuleListProperty | cdk.IResolvable;
    }
    /**
     * A type of analysis rule that enables query structure and specified queries that produce aggregate statistics.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html
     */
    interface AnalysisRuleAggregationProperty {
        /**
         * An indicator as to whether additional analyses (such as AWS Clean Rooms ML) can be applied to the output of the direct query.
         *
         * The `additionalAnalyses` parameter is currently supported for the list analysis rule ( `AnalysisRuleList` ) and the custom analysis rule ( `AnalysisRuleCustom` ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-additionalanalyses
         */
        readonly additionalAnalyses?: string;
        /**
         * The columns that query runners are allowed to use in aggregation queries.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-aggregatecolumns
         */
        readonly aggregateColumns?: Array<CfnConfiguredTablePropsMixin.AggregateColumnProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Which logical operators (if any) are to be used in an INNER JOIN match condition.
         *
         * Default is `AND` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-allowedjoinoperators
         */
        readonly allowedJoinOperators?: Array<string>;
        /**
         * The columns that query runners are allowed to select, group by, or filter by.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-dimensioncolumns
         */
        readonly dimensionColumns?: Array<string>;
        /**
         * Columns in configured table that can be used in join statements and/or as aggregate columns.
         *
         * They can never be outputted directly.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-joincolumns
         */
        readonly joinColumns?: Array<string>;
        /**
         * Control that requires member who runs query to do a join with their configured table and/or other configured table in query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-joinrequired
         */
        readonly joinRequired?: string;
        /**
         * Columns that must meet a specific threshold value (after an aggregation function is applied to it) for each output row to be returned.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-outputconstraints
         */
        readonly outputConstraints?: Array<CfnConfiguredTablePropsMixin.AggregationConstraintProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Set of scalar functions that are allowed to be used on dimension columns and the output of aggregation of metrics.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisruleaggregation.html#cfn-cleanrooms-configuredtable-analysisruleaggregation-scalarfunctions
         */
        readonly scalarFunctions?: Array<string>;
    }
    /**
     * Constraint on query output removing output rows that do not meet a minimum number of distinct values of a specified column.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregationconstraint.html
     */
    interface AggregationConstraintProperty {
        /**
         * Column in aggregation constraint for which there must be a minimum number of distinct values in an output row for it to be in the query output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregationconstraint.html#cfn-cleanrooms-configuredtable-aggregationconstraint-columnname
         */
        readonly columnName?: string;
        /**
         * The minimum number of distinct values that an output row must be an aggregation of.
         *
         * Minimum threshold of distinct values for a specified column that must exist in an output row for it to be in the query output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregationconstraint.html#cfn-cleanrooms-configuredtable-aggregationconstraint-minimum
         */
        readonly minimum?: number;
        /**
         * The type of aggregation the constraint allows.
         *
         * The only valid value is currently `COUNT_DISTINCT`.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregationconstraint.html#cfn-cleanrooms-configuredtable-aggregationconstraint-type
         */
        readonly type?: string;
    }
    /**
     * Column in configured table that can be used in aggregate function in query.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregatecolumn.html
     */
    interface AggregateColumnProperty {
        /**
         * Column names in configured table of aggregate columns.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregatecolumn.html#cfn-cleanrooms-configuredtable-aggregatecolumn-columnnames
         */
        readonly columnNames?: Array<string>;
        /**
         * Aggregation function that can be applied to aggregate column in query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-aggregatecolumn.html#cfn-cleanrooms-configuredtable-aggregatecolumn-function
         */
        readonly function?: string;
    }
    /**
     * A type of analysis rule that enables row-level analysis.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulelist.html
     */
    interface AnalysisRuleListProperty {
        /**
         * An indicator as to whether additional analyses (such as AWS Clean Rooms ML) can be applied to the output of the direct query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulelist.html#cfn-cleanrooms-configuredtable-analysisrulelist-additionalanalyses
         */
        readonly additionalAnalyses?: string;
        /**
         * The logical operators (if any) that are to be used in an INNER JOIN match condition.
         *
         * Default is `AND` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulelist.html#cfn-cleanrooms-configuredtable-analysisrulelist-allowedjoinoperators
         */
        readonly allowedJoinOperators?: Array<string>;
        /**
         * Columns that can be used to join a configured table with the table of the member who can query and other members' configured tables.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulelist.html#cfn-cleanrooms-configuredtable-analysisrulelist-joincolumns
         */
        readonly joinColumns?: Array<string>;
        /**
         * Columns that can be listed in the output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulelist.html#cfn-cleanrooms-configuredtable-analysisrulelist-listcolumns
         */
        readonly listColumns?: Array<string>;
    }
    /**
     * A type of analysis rule that enables the table owner to approve custom SQL queries on their configured tables.
     *
     * It supports differential privacy.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulecustom.html
     */
    interface AnalysisRuleCustomProperty {
        /**
         * An indicator as to whether additional analyses (such as AWS Clean Rooms ML) can be applied to the output of the direct query.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulecustom.html#cfn-cleanrooms-configuredtable-analysisrulecustom-additionalanalyses
         */
        readonly additionalAnalyses?: string;
        /**
         * The ARN of the analysis templates that are allowed by the custom analysis rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulecustom.html#cfn-cleanrooms-configuredtable-analysisrulecustom-allowedanalyses
         */
        readonly allowedAnalyses?: Array<string>;
        /**
         * The IDs of the AWS accounts that are allowed to query by the custom analysis rule.
         *
         * Required when `allowedAnalyses` is `ANY_QUERY` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulecustom.html#cfn-cleanrooms-configuredtable-analysisrulecustom-allowedanalysisproviders
         */
        readonly allowedAnalysisProviders?: Array<string>;
        /**
         * The differential privacy configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulecustom.html#cfn-cleanrooms-configuredtable-analysisrulecustom-differentialprivacy
         */
        readonly differentialPrivacy?: CfnConfiguredTablePropsMixin.DifferentialPrivacyProperty | cdk.IResolvable;
        /**
         * A list of columns that aren't allowed to be shown in the query output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-analysisrulecustom.html#cfn-cleanrooms-configuredtable-analysisrulecustom-disallowedoutputcolumns
         */
        readonly disallowedOutputColumns?: Array<string>;
    }
    /**
     * The analysis method allowed for the configured tables.
     *
     * `DIRECT_QUERY` allows SQL queries to be run directly on this table.
     *
     * `DIRECT_JOB` allows PySpark jobs to be run directly on this table.
     *
     * `MULTIPLE` allows both SQL queries and PySpark jobs to be run directly on this table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-differentialprivacy.html
     */
    interface DifferentialPrivacyProperty {
        /**
         * The name of the column, such as user_id, that contains the unique identifier of your users, whose privacy you want to protect.
         *
         * If you want to turn on differential privacy for two or more tables in a collaboration, you must configure the same column as the user identifier column in both analysis rules.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-differentialprivacy.html#cfn-cleanrooms-configuredtable-differentialprivacy-columns
         */
        readonly columns?: Array<CfnConfiguredTablePropsMixin.DifferentialPrivacyColumnProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Specifies the name of the column that contains the unique identifier of your users, whose privacy you want to protect.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-differentialprivacycolumn.html
     */
    interface DifferentialPrivacyColumnProperty {
        /**
         * The name of the column, such as user_id, that contains the unique identifier of your users, whose privacy you want to protect.
         *
         * If you want to turn on differential privacy for two or more tables in a collaboration, you must configure the same column as the user identifier column in both analysis rules.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtable-differentialprivacycolumn.html#cfn-cleanrooms-configuredtable-differentialprivacycolumn-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnConfiguredTablePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html
 */
export interface CfnConfiguredTableMixinProps {
    /**
     * The columns within the underlying AWS Glue table that can be used within collaborations.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-allowedcolumns
     */
    readonly allowedColumns?: Array<string>;
    /**
     * The analysis method for the configured table.
     *
     * `DIRECT_QUERY` allows SQL queries to be run directly on this table.
     *
     * `DIRECT_JOB` allows PySpark jobs to be run directly on this table.
     *
     * `MULTIPLE` allows both SQL queries and PySpark jobs to be run directly on this table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-analysismethod
     */
    readonly analysisMethod?: string;
    /**
     * The analysis rule that was created for the configured table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-analysisrules
     */
    readonly analysisRules?: Array<CfnConfiguredTablePropsMixin.AnalysisRuleProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * A description for the configured table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-description
     */
    readonly description?: string;
    /**
     * A name for the configured table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-name
     */
    readonly name?: string;
    /**
     * The selected analysis methods for the configured table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-selectedanalysismethods
     */
    readonly selectedAnalysisMethods?: Array<string>;
    /**
     * The table that this configured table represents.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-tablereference
     */
    readonly tableReference?: cdk.IResolvable | CfnConfiguredTablePropsMixin.TableReferenceProperty;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtable.html#cfn-cleanrooms-configuredtable-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a configured table association.
 *
 * A configured table association links a configured table with a collaboration.
 *
 * @cloudformationResource AWS::CleanRooms::ConfiguredTableAssociation
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html
 */
export declare class CfnConfiguredTableAssociationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConfiguredTableAssociationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::ConfiguredTableAssociation`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConfiguredTableAssociationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConfiguredTableAssociation;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConfiguredTableAssociationPropsMixin {
    /**
     * An analysis rule for a configured table association.
     *
     * This analysis rule specifies how data from the table can be used within its associated collaboration. In the console, the `ConfiguredTableAssociationAnalysisRule` is referred to as the *collaboration analysis rule* .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrule.html
     */
    interface ConfiguredTableAssociationAnalysisRuleProperty {
        /**
         * The policy of the configured table association analysis rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrule.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrule-policy
         */
        readonly policy?: CfnConfiguredTableAssociationPropsMixin.ConfiguredTableAssociationAnalysisRulePolicyProperty | cdk.IResolvable;
        /**
         * The type of the configured table association analysis rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrule.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrule-type
         */
        readonly type?: string;
    }
    /**
     * Controls on the query specifications that can be run on an associated configured table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicy.html
     */
    interface ConfiguredTableAssociationAnalysisRulePolicyProperty {
        /**
         * The policy for the configured table association analysis rule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicy.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicy-v1
         */
        readonly v1?: CfnConfiguredTableAssociationPropsMixin.ConfiguredTableAssociationAnalysisRulePolicyV1Property | cdk.IResolvable;
    }
    /**
     * Controls on the query specifications that can be run on an associated configured table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1.html
     */
    interface ConfiguredTableAssociationAnalysisRulePolicyV1Property {
        /**
         * Analysis rule type that enables only aggregation queries on a configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1-aggregation
         */
        readonly aggregation?: CfnConfiguredTableAssociationPropsMixin.ConfiguredTableAssociationAnalysisRuleAggregationProperty | cdk.IResolvable;
        /**
         * Analysis rule type that enables the table owner to approve custom SQL queries on their configured tables.
         *
         * It supports differential privacy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1-custom
         */
        readonly custom?: CfnConfiguredTableAssociationPropsMixin.ConfiguredTableAssociationAnalysisRuleCustomProperty | cdk.IResolvable;
        /**
         * Analysis rule type that enables only list queries on a configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulepolicyv1-list
         */
        readonly list?: CfnConfiguredTableAssociationPropsMixin.ConfiguredTableAssociationAnalysisRuleListProperty | cdk.IResolvable;
    }
    /**
     * The configured table association analysis rule applied to a configured table with the list analysis rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulelist.html
     */
    interface ConfiguredTableAssociationAnalysisRuleListProperty {
        /**
         * The list of resources or wildcards (ARNs) that are allowed to perform additional analysis on query output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulelist.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulelist-allowedadditionalanalyses
         */
        readonly allowedAdditionalAnalyses?: Array<string>;
        /**
         * The list of collaboration members who are allowed to receive results of queries run with this configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulelist.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulelist-allowedresultreceivers
         */
        readonly allowedResultReceivers?: Array<string>;
    }
    /**
     * The configured table association analysis rule applied to a configured table with the aggregation analysis rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisruleaggregation.html
     */
    interface ConfiguredTableAssociationAnalysisRuleAggregationProperty {
        /**
         * The list of resources or wildcards (ARNs) that are allowed to perform additional analysis on query output.
         *
         * The `allowedAdditionalAnalyses` parameter is currently supported for the list analysis rule ( `AnalysisRuleList` ) and the custom analysis rule ( `AnalysisRuleCustom` ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisruleaggregation.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisruleaggregation-allowedadditionalanalyses
         */
        readonly allowedAdditionalAnalyses?: Array<string>;
        /**
         * The list of collaboration members who are allowed to receive results of queries run with this configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisruleaggregation.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisruleaggregation-allowedresultreceivers
         */
        readonly allowedResultReceivers?: Array<string>;
    }
    /**
     * The configured table association analysis rule applied to a configured table with the custom analysis rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulecustom.html
     */
    interface ConfiguredTableAssociationAnalysisRuleCustomProperty {
        /**
         * The list of resources or wildcards (ARNs) that are allowed to perform additional analysis on query output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulecustom.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulecustom-allowedadditionalanalyses
         */
        readonly allowedAdditionalAnalyses?: Array<string>;
        /**
         * The list of collaboration members who are allowed to receive results of queries run with this configured table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulecustom.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrulecustom-allowedresultreceivers
         */
        readonly allowedResultReceivers?: Array<string>;
    }
}
/**
 * Properties for CfnConfiguredTableAssociationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html
 */
export interface CfnConfiguredTableAssociationMixinProps {
    /**
     * An analysis rule for a configured table association.
     *
     * This analysis rule specifies how data from the table can be used within its associated collaboration. In the console, the `ConfiguredTableAssociationAnalysisRule` is referred to as the *collaboration analysis rule* .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-configuredtableassociationanalysisrules
     */
    readonly configuredTableAssociationAnalysisRules?: Array<CfnConfiguredTableAssociationPropsMixin.ConfiguredTableAssociationAnalysisRuleProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * A unique identifier for the configured table to be associated to.
     *
     * Currently accepts a configured table ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-configuredtableidentifier
     */
    readonly configuredTableIdentifier?: string;
    /**
     * A description of the configured table association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-description
     */
    readonly description?: string;
    /**
     * The unique ID for the membership this configured table association belongs to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-membershipidentifier
     */
    readonly membershipIdentifier?: string;
    /**
     * The name of the configured table association, in lowercase.
     *
     * The table is identified by this name when running protected queries against the underlying data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-name
     */
    readonly name?: string;
    /**
     * The service will assume this role to access catalog metadata and query the table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-rolearn
     */
    readonly roleArn?: string;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-configuredtableassociation.html#cfn-cleanrooms-configuredtableassociation-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a membership for a specific collaboration identifier and joins the collaboration.
 *
 * @cloudformationResource AWS::CleanRooms::Membership
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html
 */
export declare class CfnMembershipPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnMembershipMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::Membership`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnMembershipMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnMembership;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnMembershipPropsMixin {
    /**
     * Contains configurations for protected query results.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedqueryresultconfiguration.html
     */
    interface MembershipProtectedQueryResultConfigurationProperty {
        /**
         * Configuration for protected query results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedqueryresultconfiguration.html#cfn-cleanrooms-membership-membershipprotectedqueryresultconfiguration-outputconfiguration
         */
        readonly outputConfiguration?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipProtectedQueryOutputConfigurationProperty;
        /**
         * The unique ARN for an IAM role that is used by AWS Clean Rooms to write protected query results to the result location, given by the member who can receive results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedqueryresultconfiguration.html#cfn-cleanrooms-membership-membershipprotectedqueryresultconfiguration-rolearn
         */
        readonly roleArn?: string;
    }
    /**
     * Contains configurations for protected query results.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedqueryoutputconfiguration.html
     */
    interface MembershipProtectedQueryOutputConfigurationProperty {
        /**
         * Required configuration for a protected query with an `s3` output type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedqueryoutputconfiguration.html#cfn-cleanrooms-membership-membershipprotectedqueryoutputconfiguration-s3
         */
        readonly s3?: cdk.IResolvable | CfnMembershipPropsMixin.ProtectedQueryS3OutputConfigurationProperty;
    }
    /**
     * Contains the configuration to write the query results to S3.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedquerys3outputconfiguration.html
     */
    interface ProtectedQueryS3OutputConfigurationProperty {
        /**
         * The S3 bucket to unload the protected query results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedquerys3outputconfiguration.html#cfn-cleanrooms-membership-protectedquerys3outputconfiguration-bucket
         */
        readonly bucket?: string;
        /**
         * The S3 prefix to unload the protected query results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedquerys3outputconfiguration.html#cfn-cleanrooms-membership-protectedquerys3outputconfiguration-keyprefix
         */
        readonly keyPrefix?: string;
        /**
         * Intended file format of the result.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedquerys3outputconfiguration.html#cfn-cleanrooms-membership-protectedquerys3outputconfiguration-resultformat
         */
        readonly resultFormat?: string;
        /**
         * Indicates whether files should be output as a single file ( `TRUE` ) or output as multiple files ( `FALSE` ).
         *
         * This parameter is only supported for analyses with the Spark analytics engine.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedquerys3outputconfiguration.html#cfn-cleanrooms-membership-protectedquerys3outputconfiguration-singlefileoutput
         */
        readonly singleFileOutput?: boolean | cdk.IResolvable;
    }
    /**
     * Contains configurations for protected job results.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedjobresultconfiguration.html
     */
    interface MembershipProtectedJobResultConfigurationProperty {
        /**
         * The output configuration for a protected job result.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedjobresultconfiguration.html#cfn-cleanrooms-membership-membershipprotectedjobresultconfiguration-outputconfiguration
         */
        readonly outputConfiguration?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipProtectedJobOutputConfigurationProperty;
        /**
         * The unique ARN for an IAM role that is used by AWS Clean Rooms to write protected job results to the result location, given by the member who can receive results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedjobresultconfiguration.html#cfn-cleanrooms-membership-membershipprotectedjobresultconfiguration-rolearn
         */
        readonly roleArn?: string;
    }
    /**
     * Contains configurations for protected job results.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedjoboutputconfiguration.html
     */
    interface MembershipProtectedJobOutputConfigurationProperty {
        /**
         * Contains the configuration to write the job results to S3.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipprotectedjoboutputconfiguration.html#cfn-cleanrooms-membership-membershipprotectedjoboutputconfiguration-s3
         */
        readonly s3?: cdk.IResolvable | CfnMembershipPropsMixin.ProtectedJobS3OutputConfigurationInputProperty;
    }
    /**
     * Contains input information for protected jobs with an S3 output type.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedjobs3outputconfigurationinput.html
     */
    interface ProtectedJobS3OutputConfigurationInputProperty {
        /**
         * The S3 bucket for job output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedjobs3outputconfigurationinput.html#cfn-cleanrooms-membership-protectedjobs3outputconfigurationinput-bucket
         */
        readonly bucket?: string;
        /**
         * The S3 prefix to unload the protected job results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-protectedjobs3outputconfigurationinput.html#cfn-cleanrooms-membership-protectedjobs3outputconfigurationinput-keyprefix
         */
        readonly keyPrefix?: string;
    }
    /**
     * An object representing the payment responsibilities accepted by the collaboration member.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershippaymentconfiguration.html
     */
    interface MembershipPaymentConfigurationProperty {
        /**
         * The payment responsibilities accepted by the collaboration member for job compute costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershippaymentconfiguration.html#cfn-cleanrooms-membership-membershippaymentconfiguration-jobcompute
         */
        readonly jobCompute?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipJobComputePaymentConfigProperty;
        /**
         * The payment responsibilities accepted by the collaboration member for machine learning costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershippaymentconfiguration.html#cfn-cleanrooms-membership-membershippaymentconfiguration-machinelearning
         */
        readonly machineLearning?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipMLPaymentConfigProperty;
        /**
         * The payment responsibilities accepted by the collaboration member for query compute costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershippaymentconfiguration.html#cfn-cleanrooms-membership-membershippaymentconfiguration-querycompute
         */
        readonly queryCompute?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipQueryComputePaymentConfigProperty;
    }
    /**
     * An object representing the payment responsibilities accepted by the collaboration member for query compute costs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipquerycomputepaymentconfig.html
     */
    interface MembershipQueryComputePaymentConfigProperty {
        /**
         * Indicates whether the collaboration member has accepted to pay for query compute costs ( `TRUE` ) or has not accepted to pay for query compute costs ( `FALSE` ).
         *
         * If the collaboration creator has not specified anyone to pay for query compute costs, then the member who can query is the default payer.
         *
         * An error message is returned for the following reasons:
         *
         * - If you set the value to `FALSE` but you are responsible to pay for query compute costs.
         * - If you set the value to `TRUE` but you are not responsible to pay for query compute costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipquerycomputepaymentconfig.html#cfn-cleanrooms-membership-membershipquerycomputepaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * An object representing the collaboration member's machine learning payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmlpaymentconfig.html
     */
    interface MembershipMLPaymentConfigProperty {
        /**
         * The payment responsibilities accepted by the member for model inference.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmlpaymentconfig.html#cfn-cleanrooms-membership-membershipmlpaymentconfig-modelinference
         */
        readonly modelInference?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipModelInferencePaymentConfigProperty;
        /**
         * The payment responsibilities accepted by the member for model training.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmlpaymentconfig.html#cfn-cleanrooms-membership-membershipmlpaymentconfig-modeltraining
         */
        readonly modelTraining?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipModelTrainingPaymentConfigProperty;
        /**
         * The payment configuration for synthetic data generation for this machine learning membership.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmlpaymentconfig.html#cfn-cleanrooms-membership-membershipmlpaymentconfig-syntheticdatageneration
         */
        readonly syntheticDataGeneration?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipSyntheticDataGenerationPaymentConfigProperty;
    }
    /**
     * An object representing the collaboration member's model training payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmodeltrainingpaymentconfig.html
     */
    interface MembershipModelTrainingPaymentConfigProperty {
        /**
         * Indicates whether the collaboration member has accepted to pay for model training costs ( `TRUE` ) or has not accepted to pay for model training costs ( `FALSE` ).
         *
         * If the collaboration creator has not specified anyone to pay for model training costs, then the member who can query is the default payer.
         *
         * An error message is returned for the following reasons:
         *
         * - If you set the value to `FALSE` but you are responsible to pay for model training costs.
         * - If you set the value to `TRUE` but you are not responsible to pay for model training costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmodeltrainingpaymentconfig.html#cfn-cleanrooms-membership-membershipmodeltrainingpaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * An object representing the collaboration member's model inference payment responsibilities set by the collaboration creator.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmodelinferencepaymentconfig.html
     */
    interface MembershipModelInferencePaymentConfigProperty {
        /**
         * Indicates whether the collaboration member has accepted to pay for model inference costs ( `TRUE` ) or has not accepted to pay for model inference costs ( `FALSE` ).
         *
         * If the collaboration creator has not specified anyone to pay for model inference costs, then the member who can query is the default payer.
         *
         * An error message is returned for the following reasons:
         *
         * - If you set the value to `FALSE` but you are responsible to pay for model inference costs.
         * - If you set the value to `TRUE` but you are not responsible to pay for model inference costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipmodelinferencepaymentconfig.html#cfn-cleanrooms-membership-membershipmodelinferencepaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * Configuration for payment for synthetic data generation in a membership.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipsyntheticdatagenerationpaymentconfig.html
     */
    interface MembershipSyntheticDataGenerationPaymentConfigProperty {
        /**
         * Indicates if this membership is responsible for paying for synthetic data generation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipsyntheticdatagenerationpaymentconfig.html#cfn-cleanrooms-membership-membershipsyntheticdatagenerationpaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
    /**
     * An object representing the payment responsibilities accepted by the collaboration member for query and job compute costs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipjobcomputepaymentconfig.html
     */
    interface MembershipJobComputePaymentConfigProperty {
        /**
         * Indicates whether the collaboration member has accepted to pay for job compute costs ( `TRUE` ) or has not accepted to pay for query and job compute costs ( `FALSE` ).
         *
         * There is only one member who pays for queries and jobs.
         *
         * An error message is returned for the following reasons:
         *
         * - If you set the value to `FALSE` but you are responsible to pay for query and job compute costs.
         * - If you set the value to `TRUE` but you are not responsible to pay for query and job compute costs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-membership-membershipjobcomputepaymentconfig.html#cfn-cleanrooms-membership-membershipjobcomputepaymentconfig-isresponsible
         */
        readonly isResponsible?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnMembershipPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html
 */
export interface CfnMembershipMixinProps {
    /**
     * The unique ID for the associated collaboration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-collaborationidentifier
     */
    readonly collaborationIdentifier?: string;
    /**
     * The default job result configuration for the membership.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-defaultjobresultconfiguration
     */
    readonly defaultJobResultConfiguration?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipProtectedJobResultConfigurationProperty;
    /**
     * The default protected query result configuration as specified by the member who can receive results.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-defaultresultconfiguration
     */
    readonly defaultResultConfiguration?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipProtectedQueryResultConfigurationProperty;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-ismetricsenabled
     */
    readonly isMetricsEnabled?: boolean | cdk.IResolvable;
    /**
     * An indicator as to whether job logging has been enabled or disabled for the collaboration.
     *
     * When `ENABLED` , AWS Clean Rooms logs details about jobs run within this collaboration and those logs can be viewed in Amazon CloudWatch Logs. The default value is `DISABLED` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-joblogstatus
     */
    readonly jobLogStatus?: string;
    /**
     * The payment responsibilities accepted by the collaboration member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-paymentconfiguration
     */
    readonly paymentConfiguration?: cdk.IResolvable | CfnMembershipPropsMixin.MembershipPaymentConfigurationProperty;
    /**
     * An indicator as to whether query logging has been enabled or disabled for the membership.
     *
     * When `ENABLED` , AWS Clean Rooms logs details about queries run within this collaboration and those logs can be viewed in Amazon CloudWatch Logs. The default value is `DISABLED` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-querylogstatus
     */
    readonly queryLogStatus?: string;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-membership.html#cfn-cleanrooms-membership-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Describes information about the ID mapping table.
 *
 * @cloudformationResource AWS::CleanRooms::IdMappingTable
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html
 */
export declare class CfnIdMappingTablePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIdMappingTableMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::IdMappingTable`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIdMappingTableMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIdMappingTable;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIdMappingTablePropsMixin {
    /**
     * Provides the input reference configuration for the ID mapping table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputreferenceconfig.html
     */
    interface IdMappingTableInputReferenceConfigProperty {
        /**
         * The Amazon Resource Name (ARN) of the referenced resource in AWS Entity Resolution .
         *
         * Valid values are ID mapping workflow ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputreferenceconfig.html#cfn-cleanrooms-idmappingtable-idmappingtableinputreferenceconfig-inputreferencearn
         */
        readonly inputReferenceArn?: string;
        /**
         * When `TRUE` , AWS Clean Rooms manages permissions for the ID mapping table resource.
         *
         * When `FALSE` , the resource owner manages permissions for the ID mapping table resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputreferenceconfig.html#cfn-cleanrooms-idmappingtable-idmappingtableinputreferenceconfig-manageresourcepolicies
         */
        readonly manageResourcePolicies?: boolean | cdk.IResolvable;
    }
    /**
     * The input reference properties for the ID mapping table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputreferenceproperties.html
     */
    interface IdMappingTableInputReferencePropertiesProperty {
        /**
         * The input source of the ID mapping table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputreferenceproperties.html#cfn-cleanrooms-idmappingtable-idmappingtableinputreferenceproperties-idmappingtableinputsource
         */
        readonly idMappingTableInputSource?: Array<CfnIdMappingTablePropsMixin.IdMappingTableInputSourceProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The input source of the ID mapping table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputsource.html
     */
    interface IdMappingTableInputSourceProperty {
        /**
         * The unique identifier of the ID namespace association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputsource.html#cfn-cleanrooms-idmappingtable-idmappingtableinputsource-idnamespaceassociationid
         */
        readonly idNamespaceAssociationId?: string;
        /**
         * The type of the input source of the ID mapping table.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idmappingtable-idmappingtableinputsource.html#cfn-cleanrooms-idmappingtable-idmappingtableinputsource-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnIdMappingTablePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html
 */
export interface CfnIdMappingTableMixinProps {
    /**
     * The description of the ID mapping table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html#cfn-cleanrooms-idmappingtable-description
     */
    readonly description?: string;
    /**
     * The input reference configuration for the ID mapping table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html#cfn-cleanrooms-idmappingtable-inputreferenceconfig
     */
    readonly inputReferenceConfig?: CfnIdMappingTablePropsMixin.IdMappingTableInputReferenceConfigProperty | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the AWS KMS key.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html#cfn-cleanrooms-idmappingtable-kmskeyarn
     */
    readonly kmsKeyArn?: string;
    /**
     * The unique identifier of the membership resource for the ID mapping table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html#cfn-cleanrooms-idmappingtable-membershipidentifier
     */
    readonly membershipIdentifier?: string;
    /**
     * The name of the ID mapping table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html#cfn-cleanrooms-idmappingtable-name
     */
    readonly name?: string;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idmappingtable.html#cfn-cleanrooms-idmappingtable-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Provides information to create the ID namespace association.
 *
 * @cloudformationResource AWS::CleanRooms::IdNamespaceAssociation
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html
 */
export declare class CfnIdNamespaceAssociationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIdNamespaceAssociationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::IdNamespaceAssociation`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIdNamespaceAssociationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIdNamespaceAssociation;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIdNamespaceAssociationPropsMixin {
    /**
     * Provides the information for the ID namespace association input reference configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceconfig.html
     */
    interface IdNamespaceAssociationInputReferenceConfigProperty {
        /**
         * The Amazon Resource Name (ARN) of the AWS Entity Resolution resource that is being associated to the collaboration.
         *
         * Valid resource ARNs are from the ID namespaces that you own.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceconfig.html#cfn-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceconfig-inputreferencearn
         */
        readonly inputReferenceArn?: string;
        /**
         * When `TRUE` , AWS Clean Rooms manages permissions for the ID namespace association resource.
         *
         * When `FALSE` , the resource owner manages permissions for the ID namespace association resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceconfig.html#cfn-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceconfig-manageresourcepolicies
         */
        readonly manageResourcePolicies?: boolean | cdk.IResolvable;
    }
    /**
     * The configuration settings for the ID mapping table.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idmappingconfig.html
     */
    interface IdMappingConfigProperty {
        /**
         * An indicator as to whether you can use your column as a dimension column in the ID mapping table ( `TRUE` ) or not ( `FALSE` ).
         *
         * Default is `FALSE` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idmappingconfig.html#cfn-cleanrooms-idnamespaceassociation-idmappingconfig-allowuseasdimensioncolumn
         */
        readonly allowUseAsDimensionColumn?: boolean | cdk.IResolvable;
    }
    /**
     * Provides the information for the ID namespace association input reference properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceproperties.html
     */
    interface IdNamespaceAssociationInputReferencePropertiesProperty {
        /**
         * Defines how ID mapping workflows are supported for this ID namespace association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceproperties.html#cfn-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceproperties-idmappingworkflowssupported
         */
        readonly idMappingWorkflowsSupported?: Array<any | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The ID namespace type for this ID namespace association.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceproperties.html#cfn-cleanrooms-idnamespaceassociation-idnamespaceassociationinputreferenceproperties-idnamespacetype
         */
        readonly idNamespaceType?: string;
    }
}
/**
 * Properties for CfnIdNamespaceAssociationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html
 */
export interface CfnIdNamespaceAssociationMixinProps {
    /**
     * The description of the ID namespace association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html#cfn-cleanrooms-idnamespaceassociation-description
     */
    readonly description?: string;
    /**
     * The configuration settings for the ID mapping table.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html#cfn-cleanrooms-idnamespaceassociation-idmappingconfig
     */
    readonly idMappingConfig?: CfnIdNamespaceAssociationPropsMixin.IdMappingConfigProperty | cdk.IResolvable;
    /**
     * The input reference configuration for the ID namespace association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html#cfn-cleanrooms-idnamespaceassociation-inputreferenceconfig
     */
    readonly inputReferenceConfig?: CfnIdNamespaceAssociationPropsMixin.IdNamespaceAssociationInputReferenceConfigProperty | cdk.IResolvable;
    /**
     * The unique identifier of the membership that contains the ID namespace association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html#cfn-cleanrooms-idnamespaceassociation-membershipidentifier
     */
    readonly membershipIdentifier?: string;
    /**
     * The name of this ID namespace association.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html#cfn-cleanrooms-idnamespaceassociation-name
     */
    readonly name?: string;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-idnamespaceassociation.html#cfn-cleanrooms-idnamespaceassociation-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Represents an intermediate table that stores cached query results within a collaboration.
 *
 * @cloudformationResource AWS::CleanRooms::IntermediateTable
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html
 */
export declare class CfnIntermediateTablePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnIntermediateTableMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::IntermediateTable`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnIntermediateTableMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnIntermediateTable;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnIntermediateTablePropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-populationanalysisconfiguration.html
     */
    interface PopulationAnalysisConfigurationProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-populationanalysisconfiguration.html#cfn-cleanrooms-intermediatetable-populationanalysisconfiguration-sqlparameters
         */
        readonly sqlParameters?: cdk.IResolvable | CfnIntermediateTablePropsMixin.PopulationAnalysisSqlParametersProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-populationanalysissqlparameters.html
     */
    interface PopulationAnalysisSqlParametersProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-populationanalysissqlparameters.html#cfn-cleanrooms-intermediatetable-populationanalysissqlparameters-analysistemplatearn
         */
        readonly analysisTemplateArn?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-populationanalysissqlparameters.html#cfn-cleanrooms-intermediatetable-populationanalysissqlparameters-querystring
         */
        readonly queryString?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrule.html
     */
    interface IntermediateTableAnalysisRuleProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrule.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrule-policy
         */
        readonly policy?: CfnIntermediateTablePropsMixin.IntermediateTableAnalysisRulePolicyProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrule.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrule-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulepolicy.html
     */
    interface IntermediateTableAnalysisRulePolicyProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulepolicy.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulepolicy-v1
         */
        readonly v1?: CfnIntermediateTablePropsMixin.IntermediateTableAnalysisRulePolicyV1Property | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulepolicyv1.html
     */
    interface IntermediateTableAnalysisRulePolicyV1Property {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulepolicyv1.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulepolicyv1-custom
         */
        readonly custom?: CfnIntermediateTablePropsMixin.IntermediateTableAnalysisRuleCustomProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html
     */
    interface IntermediateTableAnalysisRuleCustomProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom-additionalanalyses
         */
        readonly additionalAnalyses?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom-allowedanalyses
         */
        readonly allowedAnalyses?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom-allowedanalysisproviders
         */
        readonly allowedAnalysisProviders?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom-allowedresultreceivers
         */
        readonly allowedResultReceivers?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom-differentialprivacy
         */
        readonly differentialPrivacy?: CfnIntermediateTablePropsMixin.DifferentialPrivacyProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom.html#cfn-cleanrooms-intermediatetable-intermediatetableanalysisrulecustom-disallowedoutputcolumns
         */
        readonly disallowedOutputColumns?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-differentialprivacy.html
     */
    interface DifferentialPrivacyProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-differentialprivacy.html#cfn-cleanrooms-intermediatetable-differentialprivacy-columns
         */
        readonly columns?: Array<CfnIntermediateTablePropsMixin.DifferentialPrivacyColumnProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-differentialprivacycolumn.html
     */
    interface DifferentialPrivacyColumnProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-intermediatetable-differentialprivacycolumn.html#cfn-cleanrooms-intermediatetable-differentialprivacycolumn-name
         */
        readonly name?: string;
    }
}
/**
 * Properties for CfnIntermediateTablePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html
 */
export interface CfnIntermediateTableMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-analysisrules
     */
    readonly analysisRules?: Array<CfnIntermediateTablePropsMixin.IntermediateTableAnalysisRuleProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-description
     */
    readonly description?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-kmskeyarn
     */
    readonly kmsKeyArn?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-membershipidentifier
     */
    readonly membershipIdentifier?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-populationanalysisconfiguration
     */
    readonly populationAnalysisConfiguration?: cdk.IResolvable | CfnIntermediateTablePropsMixin.PopulationAnalysisConfigurationProperty;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-intermediatetable.html#cfn-cleanrooms-intermediatetable-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * An object that defines the privacy budget template.
 *
 * @cloudformationResource AWS::CleanRooms::PrivacyBudgetTemplate
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html
 */
export declare class CfnPrivacyBudgetTemplatePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPrivacyBudgetTemplateMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::CleanRooms::PrivacyBudgetTemplate`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPrivacyBudgetTemplateMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPrivacyBudgetTemplate;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPrivacyBudgetTemplatePropsMixin {
    /**
     * Specifies the epsilon and noise parameters for the privacy budget template.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-parameters.html
     */
    interface ParametersProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-parameters.html#cfn-cleanrooms-privacybudgettemplate-parameters-budgetparameters
         */
        readonly budgetParameters?: Array<CfnPrivacyBudgetTemplatePropsMixin.BudgetParameterProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The epsilon value that you want to use.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-parameters.html#cfn-cleanrooms-privacybudgettemplate-parameters-epsilon
         */
        readonly epsilon?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-parameters.html#cfn-cleanrooms-privacybudgettemplate-parameters-resourcearn
         */
        readonly resourceArn?: string;
        /**
         * Noise added per query is measured in terms of the number of users whose contributions you want to obscure.
         *
         * This value governs the rate at which the privacy budget is depleted.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-parameters.html#cfn-cleanrooms-privacybudgettemplate-parameters-usersnoiseperquery
         */
        readonly usersNoisePerQuery?: number;
    }
    /**
     * Individual budget parameter configuration that defines specific budget allocation settings for access budgets.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-budgetparameter.html
     */
    interface BudgetParameterProperty {
        /**
         * Whether this individual budget parameter automatically refreshes when the budget period resets.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-budgetparameter.html#cfn-cleanrooms-privacybudgettemplate-budgetparameter-autorefresh
         */
        readonly autoRefresh?: string;
        /**
         * The budget allocation amount for this specific parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-budgetparameter.html#cfn-cleanrooms-privacybudgettemplate-budgetparameter-budget
         */
        readonly budget?: number;
        /**
         * The type of budget parameter being configured.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-cleanrooms-privacybudgettemplate-budgetparameter.html#cfn-cleanrooms-privacybudgettemplate-budgetparameter-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnPrivacyBudgetTemplatePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html
 */
export interface CfnPrivacyBudgetTemplateMixinProps {
    /**
     * How often the privacy budget refreshes.
     *
     * > If you plan to regularly bring new data into the collaboration, use `CALENDAR_MONTH` to automatically get a new privacy budget for the collaboration every calendar month. Choosing this option allows arbitrary amounts of information to be revealed about rows of the data when repeatedly queried across refreshes. Avoid choosing this if the same rows will be repeatedly queried between privacy budget refreshes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html#cfn-cleanrooms-privacybudgettemplate-autorefresh
     */
    readonly autoRefresh?: string;
    /**
     * The identifier for a membership resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html#cfn-cleanrooms-privacybudgettemplate-membershipidentifier
     */
    readonly membershipIdentifier?: string;
    /**
     * Specifies the epsilon and noise parameters for the privacy budget template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html#cfn-cleanrooms-privacybudgettemplate-parameters
     */
    readonly parameters?: cdk.IResolvable | CfnPrivacyBudgetTemplatePropsMixin.ParametersProperty;
    /**
     * Specifies the type of the privacy budget template.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html#cfn-cleanrooms-privacybudgettemplate-privacybudgettype
     */
    readonly privacyBudgetType?: string;
    /**
     * An optional label that you can assign to a resource when you create it.
     *
     * Each tag consists of a key and an optional value, both of which you define. When you use tagging, you can also use tag-based access control in IAM policies to control access to this resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-cleanrooms-privacybudgettemplate.html#cfn-cleanrooms-privacybudgettemplate-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
