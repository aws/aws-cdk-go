import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-datazone";
/**
 * In Amazon DataZone, a connection enables you to connect your resources (domains, projects, and environments) to external resources and services.
 *
 * @cloudformationResource AWS::DataZone::Connection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html
 */
export declare class CfnConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::Connection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConnectionPropsMixin {
    /**
     * The location of a project.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-awslocation.html
     */
    interface AwsLocationProperty {
        /**
         * The access role of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-awslocation.html#cfn-datazone-connection-awslocation-accessrole
         */
        readonly accessRole?: string;
        /**
         * The account ID of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-awslocation.html#cfn-datazone-connection-awslocation-awsaccountid
         */
        readonly awsAccountId?: string;
        /**
         * The Region of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-awslocation.html#cfn-datazone-connection-awslocation-awsregion
         */
        readonly awsRegion?: string;
        /**
         * The IAM connection ID of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-awslocation.html#cfn-datazone-connection-awslocation-iamconnectionid
         */
        readonly iamConnectionId?: string;
    }
    /**
     * A configuration of the connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionconfiguration.html
     */
    interface ConnectionConfigurationProperty {
        /**
         * The classification of the connection configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionconfiguration.html#cfn-datazone-connection-connectionconfiguration-classification
         */
        readonly classification?: string;
        /**
         * Property Map.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionconfiguration.html#cfn-datazone-connection-connectionconfiguration-properties
         */
        readonly properties?: cdk.IResolvable | Record<string, string>;
    }
    /**
     * The properties of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html
     */
    interface ConnectionPropertiesInputProperty {
        /**
         * Amazon Q properties of the connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-amazonqproperties
         */
        readonly amazonQProperties?: CfnConnectionPropsMixin.AmazonQPropertiesInputProperty | cdk.IResolvable;
        /**
         * The Amazon Athena properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-athenaproperties
         */
        readonly athenaProperties?: CfnConnectionPropsMixin.AthenaPropertiesInputProperty | cdk.IResolvable;
        /**
         * The AWS Glue properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-glueproperties
         */
        readonly glueProperties?: CfnConnectionPropsMixin.GluePropertiesInputProperty | cdk.IResolvable;
        /**
         * The hyper pod properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-hyperpodproperties
         */
        readonly hyperPodProperties?: CfnConnectionPropsMixin.HyperPodPropertiesInputProperty | cdk.IResolvable;
        /**
         * The IAM properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-iamproperties
         */
        readonly iamProperties?: CfnConnectionPropsMixin.IamPropertiesInputProperty | cdk.IResolvable;
        /**
         * Lakehouse Properties Input.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-lakehouseproperties
         */
        readonly lakehouseProperties?: cdk.IResolvable | CfnConnectionPropsMixin.LakehousePropertiesInputProperty;
        /**
         * MLflow Properties Input.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-mlflowproperties
         */
        readonly mlflowProperties?: cdk.IResolvable | CfnConnectionPropsMixin.MlflowPropertiesInputProperty;
        /**
         * The Amazon Redshift properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-redshiftproperties
         */
        readonly redshiftProperties?: cdk.IResolvable | CfnConnectionPropsMixin.RedshiftPropertiesInputProperty;
        /**
         * S3 Properties Input.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-s3properties
         */
        readonly s3Properties?: cdk.IResolvable | CfnConnectionPropsMixin.S3PropertiesInputProperty;
        /**
         * The Spark EMR properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-sparkemrproperties
         */
        readonly sparkEmrProperties?: cdk.IResolvable | CfnConnectionPropsMixin.SparkEmrPropertiesInputProperty;
        /**
         * The Spark AWS Glue properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-sparkglueproperties
         */
        readonly sparkGlueProperties?: cdk.IResolvable | CfnConnectionPropsMixin.SparkGluePropertiesInputProperty;
        /**
         * Workflows MWAA Properties Input.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-workflowsmwaaproperties
         */
        readonly workflowsMwaaProperties?: cdk.IResolvable | CfnConnectionPropsMixin.WorkflowsMwaaPropertiesInputProperty;
        /**
         * Workflows Serverless Properties Input.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-connectionpropertiesinput.html#cfn-datazone-connection-connectionpropertiesinput-workflowsserverlessproperties
         */
        readonly workflowsServerlessProperties?: any | cdk.IResolvable;
    }
    /**
     * The Amazon Athena properties of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-athenapropertiesinput.html
     */
    interface AthenaPropertiesInputProperty {
        /**
         * The Amazon Athena workgroup name of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-athenapropertiesinput.html#cfn-datazone-connection-athenapropertiesinput-workgroupname
         */
        readonly workgroupName?: string;
    }
    /**
     * The AWS Glue properties of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-gluepropertiesinput.html
     */
    interface GluePropertiesInputProperty {
        /**
         * The AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-gluepropertiesinput.html#cfn-datazone-connection-gluepropertiesinput-glueconnectioninput
         */
        readonly glueConnectionInput?: CfnConnectionPropsMixin.GlueConnectionInputProperty | cdk.IResolvable;
    }
    /**
     * The AWS Glue connecton input.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html
     */
    interface GlueConnectionInputProperty {
        /**
         * The Amazon Athena properties of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-athenaproperties
         */
        readonly athenaProperties?: cdk.IResolvable | Record<string, string>;
        /**
         * The authentication configuration of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-authenticationconfiguration
         */
        readonly authenticationConfiguration?: CfnConnectionPropsMixin.AuthenticationConfigurationInputProperty | cdk.IResolvable;
        /**
         * The connection properties of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-connectionproperties
         */
        readonly connectionProperties?: cdk.IResolvable | Record<string, string>;
        /**
         * The connection type of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-connectiontype
         */
        readonly connectionType?: string;
        /**
         * The description of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-description
         */
        readonly description?: string;
        /**
         * The match criteria of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-matchcriteria
         */
        readonly matchCriteria?: string;
        /**
         * The name of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-name
         */
        readonly name?: string;
        /**
         * The physical connection requirements for the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-physicalconnectionrequirements
         */
        readonly physicalConnectionRequirements?: cdk.IResolvable | CfnConnectionPropsMixin.PhysicalConnectionRequirementsProperty;
        /**
         * The Python properties of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-pythonproperties
         */
        readonly pythonProperties?: cdk.IResolvable | Record<string, string>;
        /**
         * The Spark properties of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-sparkproperties
         */
        readonly sparkProperties?: cdk.IResolvable | Record<string, string>;
        /**
         * Speciefies whether to validate credentials of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-validatecredentials
         */
        readonly validateCredentials?: boolean | cdk.IResolvable;
        /**
         * Speciefies whether to validate for compute environments of the AWS Glue connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueconnectioninput.html#cfn-datazone-connection-glueconnectioninput-validateforcomputeenvironments
         */
        readonly validateForComputeEnvironments?: Array<string>;
    }
    /**
     * Physical connection requirements of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-physicalconnectionrequirements.html
     */
    interface PhysicalConnectionRequirementsProperty {
        /**
         * The availability zone of the physical connection requirements of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-physicalconnectionrequirements.html#cfn-datazone-connection-physicalconnectionrequirements-availabilityzone
         */
        readonly availabilityZone?: string;
        /**
         * The group ID list of the physical connection requirements of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-physicalconnectionrequirements.html#cfn-datazone-connection-physicalconnectionrequirements-securitygroupidlist
         */
        readonly securityGroupIdList?: Array<string>;
        /**
         * The subnet ID of the physical connection requirements of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-physicalconnectionrequirements.html#cfn-datazone-connection-physicalconnectionrequirements-subnetid
         */
        readonly subnetId?: string;
        /**
         * The subnet ID list of the physical connection requirements of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-physicalconnectionrequirements.html#cfn-datazone-connection-physicalconnectionrequirements-subnetidlist
         */
        readonly subnetIdList?: Array<string>;
    }
    /**
     * The authentication configuration of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html
     */
    interface AuthenticationConfigurationInputProperty {
        /**
         * The authentication type of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html#cfn-datazone-connection-authenticationconfigurationinput-authenticationtype
         */
        readonly authenticationType?: string;
        /**
         * The basic authentication credentials of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html#cfn-datazone-connection-authenticationconfigurationinput-basicauthenticationcredentials
         */
        readonly basicAuthenticationCredentials?: CfnConnectionPropsMixin.BasicAuthenticationCredentialsProperty | cdk.IResolvable;
        /**
         * The custom authentication credentials of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html#cfn-datazone-connection-authenticationconfigurationinput-customauthenticationcredentials
         */
        readonly customAuthenticationCredentials?: cdk.IResolvable | Record<string, string>;
        /**
         * The KMS key ARN of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html#cfn-datazone-connection-authenticationconfigurationinput-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * The oAuth2 properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html#cfn-datazone-connection-authenticationconfigurationinput-oauth2properties
         */
        readonly oAuth2Properties?: cdk.IResolvable | CfnConnectionPropsMixin.OAuth2PropertiesProperty;
        /**
         * The secret ARN of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authenticationconfigurationinput.html#cfn-datazone-connection-authenticationconfigurationinput-secretarn
         */
        readonly secretArn?: string;
    }
    /**
     * The OAuth2 properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html
     */
    interface OAuth2PropertiesProperty {
        /**
         * The authorization code properties of the OAuth2 properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html#cfn-datazone-connection-oauth2properties-authorizationcodeproperties
         */
        readonly authorizationCodeProperties?: CfnConnectionPropsMixin.AuthorizationCodePropertiesProperty | cdk.IResolvable;
        /**
         * The OAuth2 client application of the OAuth2 properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html#cfn-datazone-connection-oauth2properties-oauth2clientapplication
         */
        readonly oAuth2ClientApplication?: cdk.IResolvable | CfnConnectionPropsMixin.OAuth2ClientApplicationProperty;
        /**
         * The OAuth2 credentials of the OAuth2 properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html#cfn-datazone-connection-oauth2properties-oauth2credentials
         */
        readonly oAuth2Credentials?: CfnConnectionPropsMixin.GlueOAuth2CredentialsProperty | cdk.IResolvable;
        /**
         * The OAuth2 grant type of the OAuth2 properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html#cfn-datazone-connection-oauth2properties-oauth2granttype
         */
        readonly oAuth2GrantType?: string;
        /**
         * The OAuth2 token URL of the OAuth2 properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html#cfn-datazone-connection-oauth2properties-tokenurl
         */
        readonly tokenUrl?: string;
        /**
         * The OAuth2 token URL parameter map of the OAuth2 properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2properties.html#cfn-datazone-connection-oauth2properties-tokenurlparametersmap
         */
        readonly tokenUrlParametersMap?: cdk.IResolvable | Record<string, string>;
    }
    /**
     * The OAuth2Client application.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2clientapplication.html
     */
    interface OAuth2ClientApplicationProperty {
        /**
         * The AWS managed client application reference in the OAuth2Client application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2clientapplication.html#cfn-datazone-connection-oauth2clientapplication-awsmanagedclientapplicationreference
         */
        readonly awsManagedClientApplicationReference?: string;
        /**
         * The user managed client application client ID in the OAuth2Client application.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-oauth2clientapplication.html#cfn-datazone-connection-oauth2clientapplication-usermanagedclientapplicationclientid
         */
        readonly userManagedClientApplicationClientId?: string;
    }
    /**
     * The authorization code properties of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authorizationcodeproperties.html
     */
    interface AuthorizationCodePropertiesProperty {
        /**
         * The authorization code of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authorizationcodeproperties.html#cfn-datazone-connection-authorizationcodeproperties-authorizationcode
         */
        readonly authorizationCode?: string;
        /**
         * The redirect URI of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-authorizationcodeproperties.html#cfn-datazone-connection-authorizationcodeproperties-redirecturi
         */
        readonly redirectUri?: string;
    }
    /**
     * The GlueOAuth2 credentials of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueoauth2credentials.html
     */
    interface GlueOAuth2CredentialsProperty {
        /**
         * The access token of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueoauth2credentials.html#cfn-datazone-connection-glueoauth2credentials-accesstoken
         */
        readonly accessToken?: string;
        /**
         * The jwt token of the connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueoauth2credentials.html#cfn-datazone-connection-glueoauth2credentials-jwttoken
         */
        readonly jwtToken?: string;
        /**
         * The refresh token of the connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueoauth2credentials.html#cfn-datazone-connection-glueoauth2credentials-refreshtoken
         */
        readonly refreshToken?: string;
        /**
         * The user managed client application client secret of the connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-glueoauth2credentials.html#cfn-datazone-connection-glueoauth2credentials-usermanagedclientapplicationclientsecret
         */
        readonly userManagedClientApplicationClientSecret?: string;
    }
    /**
     * The basic authentication credentials of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-basicauthenticationcredentials.html
     */
    interface BasicAuthenticationCredentialsProperty {
        /**
         * The password for a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-basicauthenticationcredentials.html#cfn-datazone-connection-basicauthenticationcredentials-password
         */
        readonly password?: string;
        /**
         * The user name for the connecion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-basicauthenticationcredentials.html#cfn-datazone-connection-basicauthenticationcredentials-username
         */
        readonly userName?: string;
    }
    /**
     * The hyper pod properties of a AWS Glue properties patch.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-hyperpodpropertiesinput.html
     */
    interface HyperPodPropertiesInputProperty {
        /**
         * The cluster name the hyper pod properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-hyperpodpropertiesinput.html#cfn-datazone-connection-hyperpodpropertiesinput-clustername
         */
        readonly clusterName?: string;
    }
    /**
     * The IAM properties of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-iampropertiesinput.html
     */
    interface IamPropertiesInputProperty {
        /**
         * Specifies whether AWS Glue lineage sync is enabled for a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-iampropertiesinput.html#cfn-datazone-connection-iampropertiesinput-gluelineagesyncenabled
         */
        readonly glueLineageSyncEnabled?: boolean | cdk.IResolvable;
    }
    /**
     * The Amazon Redshift properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html
     */
    interface RedshiftPropertiesInputProperty {
        /**
         * The Amaon Redshift credentials.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html#cfn-datazone-connection-redshiftpropertiesinput-credentials
         */
        readonly credentials?: cdk.IResolvable | CfnConnectionPropsMixin.RedshiftCredentialsProperty;
        /**
         * The Amazon Redshift database name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html#cfn-datazone-connection-redshiftpropertiesinput-databasename
         */
        readonly databaseName?: string;
        /**
         * The Amazon Redshift host.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html#cfn-datazone-connection-redshiftpropertiesinput-host
         */
        readonly host?: string;
        /**
         * The lineage sync of the Amazon Redshift.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html#cfn-datazone-connection-redshiftpropertiesinput-lineagesync
         */
        readonly lineageSync?: cdk.IResolvable | CfnConnectionPropsMixin.RedshiftLineageSyncConfigurationInputProperty;
        /**
         * The Amaon Redshift port.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html#cfn-datazone-connection-redshiftpropertiesinput-port
         */
        readonly port?: number;
        /**
         * The Amazon Redshift storage.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftpropertiesinput.html#cfn-datazone-connection-redshiftpropertiesinput-storage
         */
        readonly storage?: cdk.IResolvable | CfnConnectionPropsMixin.RedshiftStoragePropertiesProperty;
    }
    /**
     * The Amazon Redshift storage properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftstorageproperties.html
     */
    interface RedshiftStoragePropertiesProperty {
        /**
         * The cluster name in the Amazon Redshift storage properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftstorageproperties.html#cfn-datazone-connection-redshiftstorageproperties-clustername
         */
        readonly clusterName?: string;
        /**
         * The workgroup name in the Amazon Redshift storage properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftstorageproperties.html#cfn-datazone-connection-redshiftstorageproperties-workgroupname
         */
        readonly workgroupName?: string;
    }
    /**
     * Amazon Redshift credentials of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftcredentials.html
     */
    interface RedshiftCredentialsProperty {
        /**
         * The secret ARN of the Amazon Redshift credentials of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftcredentials.html#cfn-datazone-connection-redshiftcredentials-secretarn
         */
        readonly secretArn?: string;
        /**
         * The username and password of the Amazon Redshift credentials of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftcredentials.html#cfn-datazone-connection-redshiftcredentials-usernamepassword
         */
        readonly usernamePassword?: cdk.IResolvable | CfnConnectionPropsMixin.UsernamePasswordProperty;
    }
    /**
     * The username and password of a connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-usernamepassword.html
     */
    interface UsernamePasswordProperty {
        /**
         * The password of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-usernamepassword.html#cfn-datazone-connection-usernamepassword-password
         */
        readonly password?: string;
        /**
         * The username of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-usernamepassword.html#cfn-datazone-connection-usernamepassword-username
         */
        readonly username?: string;
    }
    /**
     * The Amaon Redshift lineage sync configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftlineagesyncconfigurationinput.html
     */
    interface RedshiftLineageSyncConfigurationInputProperty {
        /**
         * Specifies whether the Amaon Redshift lineage sync configuration is enabled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftlineagesyncconfigurationinput.html#cfn-datazone-connection-redshiftlineagesyncconfigurationinput-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The schedule of the Amaon Redshift lineage sync configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-redshiftlineagesyncconfigurationinput.html#cfn-datazone-connection-redshiftlineagesyncconfigurationinput-schedule
         */
        readonly schedule?: cdk.IResolvable | CfnConnectionPropsMixin.LineageSyncScheduleProperty;
    }
    /**
     * The lineage sync schedule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-lineagesyncschedule.html
     */
    interface LineageSyncScheduleProperty {
        /**
         * The lineage sync schedule.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-lineagesyncschedule.html#cfn-datazone-connection-lineagesyncschedule-schedule
         */
        readonly schedule?: string;
    }
    /**
     * The Spark EMR properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html
     */
    interface SparkEmrPropertiesInputProperty {
        /**
         * The compute ARN of Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-computearn
         */
        readonly computeArn?: string;
        /**
         * The instance profile ARN of Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-instanceprofilearn
         */
        readonly instanceProfileArn?: string;
        /**
         * The java virtual env of the Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-javavirtualenv
         */
        readonly javaVirtualEnv?: string;
        /**
         * The log URI of the Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-loguri
         */
        readonly logUri?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-managedendpointarn
         */
        readonly managedEndpointArn?: string;
        /**
         * The Python virtual env of the Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-pythonvirtualenv
         */
        readonly pythonVirtualEnv?: string;
        /**
         * The runtime role of the Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-runtimerole
         */
        readonly runtimeRole?: string;
        /**
         * The certificates S3 URI of the Spark EMR.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkemrpropertiesinput.html#cfn-datazone-connection-sparkemrpropertiesinput-trustedcertificatess3uri
         */
        readonly trustedCertificatesS3Uri?: string;
    }
    /**
     * Amazon Q properties of the connection.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-amazonqpropertiesinput.html
     */
    interface AmazonQPropertiesInputProperty {
        /**
         * The authentication mode of the connection's AmazonQ properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-amazonqpropertiesinput.html#cfn-datazone-connection-amazonqpropertiesinput-authmode
         */
        readonly authMode?: string;
        /**
         * Specifies whether Amazon Q is enabled for the connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-amazonqpropertiesinput.html#cfn-datazone-connection-amazonqpropertiesinput-isenabled
         */
        readonly isEnabled?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-amazonqpropertiesinput.html#cfn-datazone-connection-amazonqpropertiesinput-profilearn
         */
        readonly profileArn?: string;
    }
    /**
     * The Spark AWS Glue properties.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html
     */
    interface SparkGluePropertiesInputProperty {
        /**
         * The additional args in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-additionalargs
         */
        readonly additionalArgs?: cdk.IResolvable | CfnConnectionPropsMixin.SparkGlueArgsProperty;
        /**
         * The AWS Glue connection name in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-glueconnectionname
         */
        readonly glueConnectionName?: string;
        /**
         * The AWS Glue version in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-glueversion
         */
        readonly glueVersion?: string;
        /**
         * The idle timeout in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-idletimeout
         */
        readonly idleTimeout?: number;
        /**
         * The Java virtual env in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-javavirtualenv
         */
        readonly javaVirtualEnv?: string;
        /**
         * The number of workers in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-numberofworkers
         */
        readonly numberOfWorkers?: number;
        /**
         * The Python virtual env in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-pythonvirtualenv
         */
        readonly pythonVirtualEnv?: string;
        /**
         * The worker type in the Spark AWS Glue properties.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkgluepropertiesinput.html#cfn-datazone-connection-sparkgluepropertiesinput-workertype
         */
        readonly workerType?: string;
    }
    /**
     * The Spark AWS Glue args.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkglueargs.html
     */
    interface SparkGlueArgsProperty {
        /**
         * The connection in the Spark AWS Glue args.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-sparkglueargs.html#cfn-datazone-connection-sparkglueargs-connection
         */
        readonly connection?: string;
    }
    /**
     * S3 Properties Input.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-s3propertiesinput.html
     */
    interface S3PropertiesInputProperty {
        /**
         * Specifies whether to register the S3 Access Grant location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-s3propertiesinput.html#cfn-datazone-connection-s3propertiesinput-registers3accessgrantlocation
         */
        readonly registerS3AccessGrantLocation?: boolean | cdk.IResolvable;
        /**
         * The Amazon S3 Access Grant location ID that's part of the Amazon S3 properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-s3propertiesinput.html#cfn-datazone-connection-s3propertiesinput-s3accessgrantlocationid
         */
        readonly s3AccessGrantLocationId?: string;
        /**
         * The Amazon S3 URI that's part of the Amazon S3 properties of a connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-s3propertiesinput.html#cfn-datazone-connection-s3propertiesinput-s3uri
         */
        readonly s3Uri?: string;
    }
    /**
     * MLflow Properties Input.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-mlflowpropertiesinput.html
     */
    interface MlflowPropertiesInputProperty {
        /**
         * The ARN of the MLflow tracking server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-mlflowpropertiesinput.html#cfn-datazone-connection-mlflowpropertiesinput-trackingserverarn
         */
        readonly trackingServerArn?: string;
    }
    /**
     * Workflows MWAA Properties Input.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-workflowsmwaapropertiesinput.html
     */
    interface WorkflowsMwaaPropertiesInputProperty {
        /**
         * The name of the MWAA environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-workflowsmwaapropertiesinput.html#cfn-datazone-connection-workflowsmwaapropertiesinput-mwaaenvironmentname
         */
        readonly mwaaEnvironmentName?: string;
    }
    /**
     * Lakehouse Properties Input.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-lakehousepropertiesinput.html
     */
    interface LakehousePropertiesInputProperty {
        /**
         * Specifies whether Glue lineage sync is enabled for the lakehouse connection.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-connection-lakehousepropertiesinput.html#cfn-datazone-connection-lakehousepropertiesinput-gluelineagesyncenabled
         */
        readonly glueLineageSyncEnabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html
 */
export interface CfnConnectionMixinProps {
    /**
     * The location where the connection is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-awslocation
     */
    readonly awsLocation?: CfnConnectionPropsMixin.AwsLocationProperty | cdk.IResolvable;
    /**
     * The configurations of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-configurations
     */
    readonly configurations?: Array<CfnConnectionPropsMixin.ConnectionConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Connection description.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-description
     */
    readonly description?: string;
    /**
     * The ID of the domain where the connection is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * Specifies whether the trusted identity propagation is enabled.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-enabletrustedidentitypropagation
     */
    readonly enableTrustedIdentityPropagation?: boolean | cdk.IResolvable;
    /**
     * The ID of the environment where the connection is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-environmentidentifier
     */
    readonly environmentIdentifier?: string;
    /**
     * The name of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-name
     */
    readonly name?: string;
    /**
     * The identifier of the project in which the connection should be created.
     *
     * If
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-projectidentifier
     */
    readonly projectIdentifier?: string;
    /**
     * Connection props.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-props
     */
    readonly props?: CfnConnectionPropsMixin.ConnectionPropertiesInputProperty | cdk.IResolvable;
    /**
     * The scope of the connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-connection.html#cfn-datazone-connection-scope
     */
    readonly scope?: string;
}
/**
 * The `AWS::DataZone::DataSource` resource specifies an Amazon DataZone data source that is used to import technical metadata of assets (data) from the source databases or data warehouses into Amazon DataZone.
 *
 * @cloudformationResource AWS::DataZone::DataSource
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html
 */
export declare class CfnDataSourcePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDataSourceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::DataSource`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDataSourceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDataSource;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDataSourcePropsMixin {
    /**
     * The details of a metadata form.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-forminput.html
     */
    interface FormInputProperty {
        /**
         * The content of the metadata form.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-forminput.html#cfn-datazone-datasource-forminput-content
         */
        readonly content?: string;
        /**
         * The name of the metadata form.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-forminput.html#cfn-datazone-datasource-forminput-formname
         */
        readonly formName?: string;
        /**
         * The ID of the metadata form type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-forminput.html#cfn-datazone-datasource-forminput-typeidentifier
         */
        readonly typeIdentifier?: string;
        /**
         * The revision of the metadata form type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-forminput.html#cfn-datazone-datasource-forminput-typerevision
         */
        readonly typeRevision?: string;
    }
    /**
     * The configuration of the data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-datasourceconfigurationinput.html
     */
    interface DataSourceConfigurationInputProperty {
        /**
         * The configuration of the AWS Glue data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-datasourceconfigurationinput.html#cfn-datazone-datasource-datasourceconfigurationinput-gluerunconfiguration
         */
        readonly glueRunConfiguration?: CfnDataSourcePropsMixin.GlueRunConfigurationInputProperty | cdk.IResolvable;
        /**
         * The configuration of the Amazon Redshift data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-datasourceconfigurationinput.html#cfn-datazone-datasource-datasourceconfigurationinput-redshiftrunconfiguration
         */
        readonly redshiftRunConfiguration?: cdk.IResolvable | CfnDataSourcePropsMixin.RedshiftRunConfigurationInputProperty;
        /**
         * The configuration details of the Amazon SageMaker data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-datasourceconfigurationinput.html#cfn-datazone-datasource-datasourceconfigurationinput-sagemakerrunconfiguration
         */
        readonly sageMakerRunConfiguration?: cdk.IResolvable | CfnDataSourcePropsMixin.SageMakerRunConfigurationInputProperty;
    }
    /**
     * The configuration details of the AWS Glue data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-gluerunconfigurationinput.html
     */
    interface GlueRunConfigurationInputProperty {
        /**
         * Specifies whether to automatically import data quality metrics as part of the data source run.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-gluerunconfigurationinput.html#cfn-datazone-datasource-gluerunconfigurationinput-autoimportdataqualityresult
         */
        readonly autoImportDataQualityResult?: boolean | cdk.IResolvable;
        /**
         * The catalog name in the AWS Glue run configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-gluerunconfigurationinput.html#cfn-datazone-datasource-gluerunconfigurationinput-catalogname
         */
        readonly catalogName?: string;
        /**
         * The data access role included in the configuration details of the AWS Glue data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-gluerunconfigurationinput.html#cfn-datazone-datasource-gluerunconfigurationinput-dataaccessrole
         */
        readonly dataAccessRole?: string;
        /**
         * The relational filter configurations included in the configuration details of the AWS Glue data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-gluerunconfigurationinput.html#cfn-datazone-datasource-gluerunconfigurationinput-relationalfilterconfigurations
         */
        readonly relationalFilterConfigurations?: Array<cdk.IResolvable | CfnDataSourcePropsMixin.RelationalFilterConfigurationProperty> | cdk.IResolvable;
    }
    /**
     * The relational filter configuration for the data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-relationalfilterconfiguration.html
     */
    interface RelationalFilterConfigurationProperty {
        /**
         * The database name specified in the relational filter configuration for the data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-relationalfilterconfiguration.html#cfn-datazone-datasource-relationalfilterconfiguration-databasename
         */
        readonly databaseName?: string;
        /**
         * The filter expressions specified in the relational filter configuration for the data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-relationalfilterconfiguration.html#cfn-datazone-datasource-relationalfilterconfiguration-filterexpressions
         */
        readonly filterExpressions?: Array<CfnDataSourcePropsMixin.FilterExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The schema name specified in the relational filter configuration for the data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-relationalfilterconfiguration.html#cfn-datazone-datasource-relationalfilterconfiguration-schemaname
         */
        readonly schemaName?: string;
    }
    /**
     * A filter expression in Amazon DataZone.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-filterexpression.html
     */
    interface FilterExpressionProperty {
        /**
         * The search filter expression.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-filterexpression.html#cfn-datazone-datasource-filterexpression-expression
         */
        readonly expression?: string;
        /**
         * The search filter explresison type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-filterexpression.html#cfn-datazone-datasource-filterexpression-type
         */
        readonly type?: string;
    }
    /**
     * The relational filter configurations included in the configuration details of the Amazon Redshift data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftrunconfigurationinput.html
     */
    interface RedshiftRunConfigurationInputProperty {
        /**
         * The data access role included in the configuration details of the Amazon Redshift data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftrunconfigurationinput.html#cfn-datazone-datasource-redshiftrunconfigurationinput-dataaccessrole
         */
        readonly dataAccessRole?: string;
        /**
         * The details of the credentials required to access an Amazon Redshift cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftrunconfigurationinput.html#cfn-datazone-datasource-redshiftrunconfigurationinput-redshiftcredentialconfiguration
         */
        readonly redshiftCredentialConfiguration?: cdk.IResolvable | CfnDataSourcePropsMixin.RedshiftCredentialConfigurationProperty;
        /**
         * The details of the Amazon Redshift storage as part of the configuration of an Amazon Redshift data source run.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftrunconfigurationinput.html#cfn-datazone-datasource-redshiftrunconfigurationinput-redshiftstorage
         */
        readonly redshiftStorage?: cdk.IResolvable | CfnDataSourcePropsMixin.RedshiftStorageProperty;
        /**
         * The relational filter configurations included in the configuration details of the AWS Glue data source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftrunconfigurationinput.html#cfn-datazone-datasource-redshiftrunconfigurationinput-relationalfilterconfigurations
         */
        readonly relationalFilterConfigurations?: Array<cdk.IResolvable | CfnDataSourcePropsMixin.RelationalFilterConfigurationProperty> | cdk.IResolvable;
    }
    /**
     * The details of the credentials required to access an Amazon Redshift cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftcredentialconfiguration.html
     */
    interface RedshiftCredentialConfigurationProperty {
        /**
         * The ARN of a secret manager for an Amazon Redshift cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftcredentialconfiguration.html#cfn-datazone-datasource-redshiftcredentialconfiguration-secretmanagerarn
         */
        readonly secretManagerArn?: string;
    }
    /**
     * The details of the Amazon Redshift storage as part of the configuration of an Amazon Redshift data source run.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftstorage.html
     */
    interface RedshiftStorageProperty {
        /**
         * The details of the Amazon Redshift cluster source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftstorage.html#cfn-datazone-datasource-redshiftstorage-redshiftclustersource
         */
        readonly redshiftClusterSource?: cdk.IResolvable | CfnDataSourcePropsMixin.RedshiftClusterStorageProperty;
        /**
         * The details of the Amazon Redshift Serverless workgroup source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftstorage.html#cfn-datazone-datasource-redshiftstorage-redshiftserverlesssource
         */
        readonly redshiftServerlessSource?: cdk.IResolvable | CfnDataSourcePropsMixin.RedshiftServerlessStorageProperty;
    }
    /**
     * The details of the Amazon Redshift cluster storage.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftclusterstorage.html
     */
    interface RedshiftClusterStorageProperty {
        /**
         * The name of an Amazon Redshift cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftclusterstorage.html#cfn-datazone-datasource-redshiftclusterstorage-clustername
         */
        readonly clusterName?: string;
    }
    /**
     * The details of the Amazon Redshift Serverless workgroup storage.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftserverlessstorage.html
     */
    interface RedshiftServerlessStorageProperty {
        /**
         * The name of the Amazon Redshift Serverless workgroup.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-redshiftserverlessstorage.html#cfn-datazone-datasource-redshiftserverlessstorage-workgroupname
         */
        readonly workgroupName?: string;
    }
    /**
     * The configuration details of the Amazon SageMaker data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-sagemakerrunconfigurationinput.html
     */
    interface SageMakerRunConfigurationInputProperty {
        /**
         * The tracking assets of the Amazon SageMaker run.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-sagemakerrunconfigurationinput.html#cfn-datazone-datasource-sagemakerrunconfigurationinput-trackingassets
         */
        readonly trackingAssets?: cdk.IResolvable | Record<string, Array<string>>;
    }
    /**
     * The recommendation configuration for the data source.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-recommendationconfiguration.html
     */
    interface RecommendationConfigurationProperty {
        /**
         * Specifies whether automatic business name generation is to be enabled or not as part of the recommendation configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-recommendationconfiguration.html#cfn-datazone-datasource-recommendationconfiguration-enablebusinessnamegeneration
         */
        readonly enableBusinessNameGeneration?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the schedule of the data source runs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-scheduleconfiguration.html
     */
    interface ScheduleConfigurationProperty {
        /**
         * The schedule of the data source runs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-scheduleconfiguration.html#cfn-datazone-datasource-scheduleconfiguration-schedule
         */
        readonly schedule?: string;
        /**
         * The timezone of the data source run.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-datasource-scheduleconfiguration.html#cfn-datazone-datasource-scheduleconfiguration-timezone
         */
        readonly timezone?: string;
    }
}
/**
 * Properties for CfnDataSourcePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html
 */
export interface CfnDataSourceMixinProps {
    /**
     * The metadata forms attached to the assets that the data source works with.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-assetformsinput
     */
    readonly assetFormsInput?: Array<CfnDataSourcePropsMixin.FormInputProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The configuration of the data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-configuration
     */
    readonly configuration?: CfnDataSourcePropsMixin.DataSourceConfigurationInputProperty | cdk.IResolvable;
    /**
     * The unique identifier of a connection used to fetch relevant parameters from connection during Datasource run.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-connectionidentifier
     */
    readonly connectionIdentifier?: string;
    /**
     * The description of the data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-description
     */
    readonly description?: string;
    /**
     * The ID of the Amazon DataZone domain where the data source is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * Specifies whether the data source is enabled.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-enablesetting
     */
    readonly enableSetting?: string;
    /**
     * The unique identifier of the Amazon DataZone environment to which the data source publishes assets.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-environmentidentifier
     */
    readonly environmentIdentifier?: string;
    /**
     * The name of the data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-name
     */
    readonly name?: string;
    /**
     * The identifier of the Amazon DataZone project in which you want to add this data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-projectidentifier
     */
    readonly projectIdentifier?: string;
    /**
     * Specifies whether the assets that this data source creates in the inventory are to be also automatically published to the catalog.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-publishonimport
     */
    readonly publishOnImport?: boolean | cdk.IResolvable;
    /**
     * Specifies whether the business name generation is to be enabled for this data source.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-recommendation
     */
    readonly recommendation?: cdk.IResolvable | CfnDataSourcePropsMixin.RecommendationConfigurationProperty;
    /**
     * The schedule of the data source runs.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-schedule
     */
    readonly schedule?: cdk.IResolvable | CfnDataSourcePropsMixin.ScheduleConfigurationProperty;
    /**
     * The type of the data source.
     *
     * In Amazon DataZone, you can use data sources to import technical metadata of assets (data) from the source databases or data warehouses into Amazon DataZone. In the current release of Amazon DataZone, you can create and run data sources for AWS Glue and Amazon Redshift.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-datasource.html#cfn-datazone-datasource-type
     */
    readonly type?: string;
}
/**
 * The `AWS::DataZone::Domain` resource specifies an Amazon DataZone domain.
 *
 * You can use domains to organize your assets, users, and their projects.
 *
 * @cloudformationResource AWS::DataZone::Domain
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html
 */
export declare class CfnDomainPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDomainMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::Domain`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDomainMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDomain;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDomainPropsMixin {
    /**
     * The single sign-on details in Amazon DataZone.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-domain-singlesignon.html
     */
    interface SingleSignOnProperty {
        /**
         * The ARN of the IDC instance.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-domain-singlesignon.html#cfn-datazone-domain-singlesignon-idcinstancearn
         */
        readonly idcInstanceArn?: string;
        /**
         * The type of single sign-on in Amazon DataZone.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-domain-singlesignon.html#cfn-datazone-domain-singlesignon-type
         */
        readonly type?: string;
        /**
         * The single sign-on user assignment in Amazon DataZone.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-domain-singlesignon.html#cfn-datazone-domain-singlesignon-userassignment
         */
        readonly userAssignment?: string;
    }
}
/**
 * Properties for CfnDomainPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html
 */
export interface CfnDomainMixinProps {
    /**
     * The description of the Amazon DataZone domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-description
     */
    readonly description?: string;
    /**
     * The domain execution role that is created when an Amazon DataZone domain is created.
     *
     * The domain execution role is created in the AWS account that houses the Amazon DataZone domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-domainexecutionrole
     */
    readonly domainExecutionRole?: string;
    /**
     * The domain version.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-domainversion
     */
    readonly domainVersion?: string;
    /**
     * The identifier of the AWS Key Management Service (KMS) key that is used to encrypt the Amazon DataZone domain, metadata, and reporting data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-kmskeyidentifier
     */
    readonly kmsKeyIdentifier?: string;
    /**
     * The name of the Amazon DataZone domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-name
     */
    readonly name?: string;
    /**
     * The service role of the domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-servicerole
     */
    readonly serviceRole?: string;
    /**
     * The single sign-on details in Amazon DataZone.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-singlesignon
     */
    readonly singleSignOn?: cdk.IResolvable | CfnDomainPropsMixin.SingleSignOnProperty;
    /**
     * The tags specified for the Amazon DataZone domain.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domain.html#cfn-datazone-domain-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * The summary of the domain unit.
 *
 * @cloudformationResource AWS::DataZone::DomainUnit
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domainunit.html
 */
export declare class CfnDomainUnitPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDomainUnitMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::DomainUnit`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDomainUnitMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDomainUnit;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnDomainUnitPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domainunit.html
 */
export interface CfnDomainUnitMixinProps {
    /**
     * The description of the domain unit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domainunit.html#cfn-datazone-domainunit-description
     */
    readonly description?: string;
    /**
     * The ID of the domain where you want to crate a domain unit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domainunit.html#cfn-datazone-domainunit-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The name of the domain unit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domainunit.html#cfn-datazone-domainunit-name
     */
    readonly name?: string;
    /**
     * The ID of the parent domain unit.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-domainunit.html#cfn-datazone-domainunit-parentdomainunitidentifier
     */
    readonly parentDomainUnitIdentifier?: string;
}
/**
 * The `AWS::DataZone::Environment` resource specifies an Amazon DataZone environment, which is a collection of zero or more configured resources with a given set of IAM principals who can operate on those resources.
 *
 * @cloudformationResource AWS::DataZone::Environment
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html
 */
export declare class CfnEnvironmentPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEnvironmentMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::Environment`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEnvironmentMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEnvironment;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEnvironmentPropsMixin {
    /**
     * The parameter details of the environment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environment-environmentparameter.html
     */
    interface EnvironmentParameterProperty {
        /**
         * The name of the environment parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environment-environmentparameter.html#cfn-datazone-environment-environmentparameter-name
         */
        readonly name?: string;
        /**
         * The value of the environment parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environment-environmentparameter.html#cfn-datazone-environment-environmentparameter-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnEnvironmentPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html
 */
export interface CfnEnvironmentMixinProps {
    /**
     * The deployment order for the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-deploymentorder
     */
    readonly deploymentOrder?: number;
    /**
     * The description of the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-description
     */
    readonly description?: string;
    /**
     * The identifier of the Amazon DataZone domain in which the environment is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The identifier of the AWS account in which an environment exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-environmentaccountidentifier
     */
    readonly environmentAccountIdentifier?: string;
    /**
     * The AWS Region in which an environment exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-environmentaccountregion
     */
    readonly environmentAccountRegion?: string;
    /**
     * The identifier of the environment blueprint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-environmentblueprintidentifier
     */
    readonly environmentBlueprintIdentifier?: string;
    /**
     * The identifier of the environment configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-environmentconfigurationid
     */
    readonly environmentConfigurationId?: string;
    /**
     * The identifier of the environment profile that is used to create this Amazon DataZone environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-environmentprofileidentifier
     */
    readonly environmentProfileIdentifier?: string;
    /**
     * The ARN of the environment role.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-environmentrolearn
     */
    readonly environmentRoleArn?: string;
    /**
     * The glossary terms that can be used in this Amazon DataZone environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-glossaryterms
     */
    readonly glossaryTerms?: Array<string>;
    /**
     * The name of the Amazon DataZone environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-name
     */
    readonly name?: string;
    /**
     * The identifier of the Amazon DataZone project in which this environment is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-projectidentifier
     */
    readonly projectIdentifier?: string;
    /**
     * The user parameters of this Amazon DataZone environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environment.html#cfn-datazone-environment-userparameters
     */
    readonly userParameters?: Array<CfnEnvironmentPropsMixin.EnvironmentParameterProperty | cdk.IResolvable> | cdk.IResolvable;
}
/**
 * The details about the specified action configured for an environment.
 *
 * For example, the details of the specified console links for an analytics tool that is available in this environment.
 *
 * @cloudformationResource AWS::DataZone::EnvironmentActions
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html
 */
export declare class CfnEnvironmentActionsPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEnvironmentActionsMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::EnvironmentActions`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEnvironmentActionsMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEnvironmentActions;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEnvironmentActionsPropsMixin {
    /**
     * The parameters of the console link specified as part of the environment action.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentactions-awsconsolelinkparameters.html
     */
    interface AwsConsoleLinkParametersProperty {
        /**
         * The URI of the console link specified as part of the environment action.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentactions-awsconsolelinkparameters.html#cfn-datazone-environmentactions-awsconsolelinkparameters-uri
         */
        readonly uri?: string;
    }
}
/**
 * Properties for CfnEnvironmentActionsPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html
 */
export interface CfnEnvironmentActionsMixinProps {
    /**
     * The environment action description.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html#cfn-datazone-environmentactions-description
     */
    readonly description?: string;
    /**
     * The Amazon DataZone domain ID of the environment action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html#cfn-datazone-environmentactions-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The environment ID of the environment action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html#cfn-datazone-environmentactions-environmentidentifier
     */
    readonly environmentIdentifier?: string;
    /**
     * The ID of the environment action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html#cfn-datazone-environmentactions-identifier
     */
    readonly identifier?: string;
    /**
     * The name of the environment action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html#cfn-datazone-environmentactions-name
     */
    readonly name?: string;
    /**
     * The parameters of the environment action.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentactions.html#cfn-datazone-environmentactions-parameters
     */
    readonly parameters?: CfnEnvironmentActionsPropsMixin.AwsConsoleLinkParametersProperty | cdk.IResolvable;
}
/**
 * The configuration details of an environment blueprint.
 *
 * @cloudformationResource AWS::DataZone::EnvironmentBlueprintConfiguration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html
 */
export declare class CfnEnvironmentBlueprintConfigurationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEnvironmentBlueprintConfigurationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::EnvironmentBlueprintConfiguration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEnvironmentBlueprintConfigurationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEnvironmentBlueprintConfiguration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEnvironmentBlueprintConfigurationPropsMixin {
    /**
     * The regional parameters in the environment blueprint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-regionalparameter.html
     */
    interface RegionalParameterProperty {
        /**
         * A string to string map containing parameters for the region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-regionalparameter.html#cfn-datazone-environmentblueprintconfiguration-regionalparameter-parameters
         */
        readonly parameters?: cdk.IResolvable | Record<string, string>;
        /**
         * The region specified in the environment parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-regionalparameter.html#cfn-datazone-environmentblueprintconfiguration-regionalparameter-region
         */
        readonly region?: string;
    }
    /**
     * The provisioning configuration of the blueprint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-provisioningconfiguration.html
     */
    interface ProvisioningConfigurationProperty {
        /**
         * The Lake Formation configuration of the Data Lake blueprint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-provisioningconfiguration.html#cfn-datazone-environmentblueprintconfiguration-provisioningconfiguration-lakeformationconfiguration
         */
        readonly lakeFormationConfiguration?: cdk.IResolvable | CfnEnvironmentBlueprintConfigurationPropsMixin.LakeFormationConfigurationProperty;
    }
    /**
     * The Lake Formation configuration of the Data Lake blueprint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-lakeformationconfiguration.html
     */
    interface LakeFormationConfigurationProperty {
        /**
         * Specifies certain Amazon S3 locations if you do not want Amazon DataZone to automatically register them in hybrid mode.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-lakeformationconfiguration.html#cfn-datazone-environmentblueprintconfiguration-lakeformationconfiguration-locationregistrationexcludes3locations
         */
        readonly locationRegistrationExcludeS3Locations?: Array<string>;
        /**
         * The role that is used to manage read/write access to the chosen Amazon S3 bucket(s) for Data Lake using AWS Lake Formation hybrid access mode.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentblueprintconfiguration-lakeformationconfiguration.html#cfn-datazone-environmentblueprintconfiguration-lakeformationconfiguration-locationregistrationrole
         */
        readonly locationRegistrationRole?: string;
    }
}
/**
 * Properties for CfnEnvironmentBlueprintConfigurationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html
 */
export interface CfnEnvironmentBlueprintConfigurationMixinProps {
    /**
     * The identifier of the Amazon DataZone domain in which an environment blueprint exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The enabled AWS Regions specified in a blueprint configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-enabledregions
     */
    readonly enabledRegions?: Array<string>;
    /**
     * The identifier of the environment blueprint.
     *
     * In the current release, only the following values are supported: `DefaultDataLake` and `DefaultDataWarehouse` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-environmentblueprintidentifier
     */
    readonly environmentBlueprintIdentifier?: string;
    /**
     * The environment role permission boundary.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-environmentrolepermissionboundary
     */
    readonly environmentRolePermissionBoundary?: string;
    /**
     * Region-agnostic environment blueprint parameters.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-globalparameters
     */
    readonly globalParameters?: cdk.IResolvable | Record<string, string>;
    /**
     * The ARN of the manage access role.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-manageaccessrolearn
     */
    readonly manageAccessRoleArn?: string;
    /**
     * The provisioning configuration of a blueprint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-provisioningconfigurations
     */
    readonly provisioningConfigurations?: Array<cdk.IResolvable | CfnEnvironmentBlueprintConfigurationPropsMixin.ProvisioningConfigurationProperty> | cdk.IResolvable;
    /**
     * The ARN of the provisioning role.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-provisioningrolearn
     */
    readonly provisioningRoleArn?: string;
    /**
     * The regional parameters of the environment blueprint.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentblueprintconfiguration.html#cfn-datazone-environmentblueprintconfiguration-regionalparameters
     */
    readonly regionalParameters?: Array<cdk.IResolvable | CfnEnvironmentBlueprintConfigurationPropsMixin.RegionalParameterProperty> | cdk.IResolvable;
}
/**
 * The details of an environment profile.
 *
 * @cloudformationResource AWS::DataZone::EnvironmentProfile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html
 */
export declare class CfnEnvironmentProfilePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEnvironmentProfileMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::EnvironmentProfile`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEnvironmentProfileMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEnvironmentProfile;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEnvironmentProfilePropsMixin {
    /**
     * The parameter details of an environment profile.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentprofile-environmentparameter.html
     */
    interface EnvironmentParameterProperty {
        /**
         * The name specified in the environment parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentprofile-environmentparameter.html#cfn-datazone-environmentprofile-environmentparameter-name
         */
        readonly name?: string;
        /**
         * The value of the environment profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-environmentprofile-environmentparameter.html#cfn-datazone-environmentprofile-environmentparameter-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnEnvironmentProfilePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html
 */
export interface CfnEnvironmentProfileMixinProps {
    /**
     * The identifier of an AWS account in which an environment profile exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-awsaccountid
     */
    readonly awsAccountId?: string;
    /**
     * The AWS Region in which an environment profile exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-awsaccountregion
     */
    readonly awsAccountRegion?: string;
    /**
     * The description of the environment profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-description
     */
    readonly description?: string;
    /**
     * The identifier of the Amazon DataZone domain in which the environment profile exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The identifier of a blueprint with which an environment profile is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-environmentblueprintidentifier
     */
    readonly environmentBlueprintIdentifier?: string;
    /**
     * The name of the environment profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-name
     */
    readonly name?: string;
    /**
     * The identifier of a project in which an environment profile exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-projectidentifier
     */
    readonly projectIdentifier?: string;
    /**
     * The user parameters of this Amazon DataZone environment profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-environmentprofile.html#cfn-datazone-environmentprofile-userparameters
     */
    readonly userParameters?: Array<CfnEnvironmentProfilePropsMixin.EnvironmentParameterProperty | cdk.IResolvable> | cdk.IResolvable;
}
/**
 * The details of the metadata form type.
 *
 * @cloudformationResource AWS::DataZone::FormType
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html
 */
export declare class CfnFormTypePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnFormTypeMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::FormType`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnFormTypeMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnFormType;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnFormTypePropsMixin {
    /**
     * Indicates the smithy model of the API.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-formtype-model.html
     */
    interface ModelProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-formtype-model.html#cfn-datazone-formtype-model-smithy
         */
        readonly smithy?: string;
    }
}
/**
 * Properties for CfnFormTypePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html
 */
export interface CfnFormTypeMixinProps {
    /**
     * The description of the metadata form type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html#cfn-datazone-formtype-description
     */
    readonly description?: string;
    /**
     * The identifier of the Amazon DataZone domain in which the form type exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html#cfn-datazone-formtype-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The model of the form type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html#cfn-datazone-formtype-model
     */
    readonly model?: cdk.IResolvable | CfnFormTypePropsMixin.ModelProperty;
    /**
     * The name of the form type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html#cfn-datazone-formtype-name
     */
    readonly name?: string;
    /**
     * The identifier of the project that owns the form type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html#cfn-datazone-formtype-owningprojectidentifier
     */
    readonly owningProjectIdentifier?: string;
    /**
     * The status of the form type.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-formtype.html#cfn-datazone-formtype-status
     */
    readonly status?: string;
}
/**
 * The details of a group profile in Amazon DataZone.
 *
 * @cloudformationResource AWS::DataZone::GroupProfile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html
 */
export declare class CfnGroupProfilePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnGroupProfileMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::GroupProfile`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnGroupProfileMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnGroupProfile;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnGroupProfilePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html
 */
export interface CfnGroupProfileMixinProps {
    /**
     * The identifier of the Amazon DataZone domain in which a group profile exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html#cfn-datazone-groupprofile-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The ID of the group of a project member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html#cfn-datazone-groupprofile-groupidentifier
     */
    readonly groupIdentifier?: string;
    /**
     * The type of the group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html#cfn-datazone-groupprofile-grouptype
     */
    readonly groupType?: string;
    /**
     * The ARN of the role principal for the group profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html#cfn-datazone-groupprofile-roleprincipalarn
     */
    readonly rolePrincipalArn?: string;
    /**
     * The status of a group profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-groupprofile.html#cfn-datazone-groupprofile-status
     */
    readonly status?: string;
}
/**
 * The owner that you want to add to the entity.
 *
 * @cloudformationResource AWS::DataZone::Owner
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-owner.html
 */
export declare class CfnOwnerPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOwnerMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::Owner`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOwnerMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOwner;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnOwnerPropsMixin {
    /**
     * The properties of a domain unit's owner.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-ownerproperties.html
     */
    interface OwnerPropertiesProperty {
        /**
         * Specifies that the domain unit owner is a group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-ownerproperties.html#cfn-datazone-owner-ownerproperties-group
         */
        readonly group?: cdk.IResolvable | CfnOwnerPropsMixin.OwnerGroupPropertiesProperty;
        /**
         * Specifies that the domain unit owner is a user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-ownerproperties.html#cfn-datazone-owner-ownerproperties-user
         */
        readonly user?: cdk.IResolvable | CfnOwnerPropsMixin.OwnerUserPropertiesProperty;
    }
    /**
     * The properties of the domain unit owners group.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-ownergroupproperties.html
     */
    interface OwnerGroupPropertiesProperty {
        /**
         * The ID of the domain unit owners group.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-ownergroupproperties.html#cfn-datazone-owner-ownergroupproperties-groupidentifier
         */
        readonly groupIdentifier?: string;
    }
    /**
     * The properties of the owner user.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-owneruserproperties.html
     */
    interface OwnerUserPropertiesProperty {
        /**
         * The ID of the owner user.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-owner-owneruserproperties.html#cfn-datazone-owner-owneruserproperties-useridentifier
         */
        readonly userIdentifier?: string;
    }
}
/**
 * Properties for CfnOwnerPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-owner.html
 */
export interface CfnOwnerMixinProps {
    /**
     * The ID of the domain in which you want to add the entity owner.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-owner.html#cfn-datazone-owner-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The ID of the entity to which you want to add an owner.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-owner.html#cfn-datazone-owner-entityidentifier
     */
    readonly entityIdentifier?: string;
    /**
     * The type of an entity.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-owner.html#cfn-datazone-owner-entitytype
     */
    readonly entityType?: string;
    /**
     * The owner that you want to add to the entity.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-owner.html#cfn-datazone-owner-owner
     */
    readonly owner?: cdk.IResolvable | CfnOwnerPropsMixin.OwnerPropertiesProperty;
}
/**
 * Adds a policy grant (an authorization policy) to a specified entity, including domain units, environment blueprint configurations, or environment profiles.
 *
 * @cloudformationResource AWS::DataZone::PolicyGrant
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html
 */
export declare class CfnPolicyGrantPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPolicyGrantMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::PolicyGrant`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPolicyGrantMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPolicyGrant;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPolicyGrantPropsMixin {
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html
     */
    interface PolicyGrantDetailProperty {
        /**
         * Specifies that the policy grant is to be added to the members of the project.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-addtoprojectmemberpool
         */
        readonly addToProjectMemberPool?: CfnPolicyGrantPropsMixin.AddToProjectMemberPoolPolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is a create asset type policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createassettype
         */
        readonly createAssetType?: CfnPolicyGrantPropsMixin.CreateAssetTypePolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is a create domain unit policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createdomainunit
         */
        readonly createDomainUnit?: CfnPolicyGrantPropsMixin.CreateDomainUnitPolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is a create environment policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createenvironment
         */
        readonly createEnvironment?: any | cdk.IResolvable;
        /**
         * The details of the policy of creating an environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createenvironmentfromblueprint
         */
        readonly createEnvironmentFromBlueprint?: any | cdk.IResolvable;
        /**
         * Specifies that this is a create environment profile policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createenvironmentprofile
         */
        readonly createEnvironmentProfile?: CfnPolicyGrantPropsMixin.CreateEnvironmentProfilePolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is a create form type policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createformtype
         */
        readonly createFormType?: CfnPolicyGrantPropsMixin.CreateFormTypePolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is a create glossary policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createglossary
         */
        readonly createGlossary?: CfnPolicyGrantPropsMixin.CreateGlossaryPolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is a create project policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createproject
         */
        readonly createProject?: CfnPolicyGrantPropsMixin.CreateProjectPolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies whether to create a project from project profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-createprojectfromprojectprofile
         */
        readonly createProjectFromProjectProfile?: CfnPolicyGrantPropsMixin.CreateProjectFromProjectProfilePolicyGrantDetailProperty | cdk.IResolvable;
        /**
         * Specifies that this is the delegation of the create environment profile policy.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-delegatecreateenvironmentprofile
         */
        readonly delegateCreateEnvironmentProfile?: any | cdk.IResolvable;
        /**
         * Specifies whether to override domain unit owners.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-overridedomainunitowners
         */
        readonly overrideDomainUnitOwners?: cdk.IResolvable | CfnPolicyGrantPropsMixin.OverrideDomainUnitOwnersPolicyGrantDetailProperty;
        /**
         * Specifies whether to override project owners.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantdetail.html#cfn-datazone-policygrant-policygrantdetail-overrideprojectowners
         */
        readonly overrideProjectOwners?: cdk.IResolvable | CfnPolicyGrantPropsMixin.OverrideProjectOwnersPolicyGrantDetailProperty;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createdomainunitpolicygrantdetail.html
     */
    interface CreateDomainUnitPolicyGrantDetailProperty {
        /**
         * Specifies whether the policy grant is applied to child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createdomainunitpolicygrantdetail.html#cfn-datazone-policygrant-createdomainunitpolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The grant details of the override domain unit owners policy.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-overridedomainunitownerspolicygrantdetail.html
     */
    interface OverrideDomainUnitOwnersPolicyGrantDetailProperty {
        /**
         * Specifies whether the policy is inherited by child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-overridedomainunitownerspolicygrantdetail.html#cfn-datazone-policygrant-overridedomainunitownerspolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-addtoprojectmemberpoolpolicygrantdetail.html
     */
    interface AddToProjectMemberPoolPolicyGrantDetailProperty {
        /**
         * Specifies whether the policy grant is applied to child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-addtoprojectmemberpoolpolicygrantdetail.html#cfn-datazone-policygrant-addtoprojectmemberpoolpolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the override project owners policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-overrideprojectownerspolicygrantdetail.html
     */
    interface OverrideProjectOwnersPolicyGrantDetailProperty {
        /**
         * Specifies whether the policy is inherited by child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-overrideprojectownerspolicygrantdetail.html#cfn-datazone-policygrant-overrideprojectownerspolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createglossarypolicygrantdetail.html
     */
    interface CreateGlossaryPolicyGrantDetailProperty {
        /**
         * Specifies whether the policy grant is applied to child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createglossarypolicygrantdetail.html#cfn-datazone-policygrant-createglossarypolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createformtypepolicygrantdetail.html
     */
    interface CreateFormTypePolicyGrantDetailProperty {
        /**
         * Specifies whether the policy grant is applied to child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createformtypepolicygrantdetail.html#cfn-datazone-policygrant-createformtypepolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createassettypepolicygrantdetail.html
     */
    interface CreateAssetTypePolicyGrantDetailProperty {
        /**
         * Specifies whether the policy grant is applied to child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createassettypepolicygrantdetail.html#cfn-datazone-policygrant-createassettypepolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createprojectpolicygrantdetail.html
     */
    interface CreateProjectPolicyGrantDetailProperty {
        /**
         * Specifies whether the policy grant is applied to child domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createprojectpolicygrantdetail.html#cfn-datazone-policygrant-createprojectpolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The details of the policy grant.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createenvironmentprofilepolicygrantdetail.html
     */
    interface CreateEnvironmentProfilePolicyGrantDetailProperty {
        /**
         * The ID of the domain unit.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createenvironmentprofilepolicygrantdetail.html#cfn-datazone-policygrant-createenvironmentprofilepolicygrantdetail-domainunitid
         */
        readonly domainUnitId?: string;
    }
    /**
     * Specifies whether to create a project from project profile policy grant details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createprojectfromprojectprofilepolicygrantdetail.html
     */
    interface CreateProjectFromProjectProfilePolicyGrantDetailProperty {
        /**
         * Specifies whether to include child domain units when creating a project from project profile policy grant details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createprojectfromprojectprofilepolicygrantdetail.html#cfn-datazone-policygrant-createprojectfromprojectprofilepolicygrantdetail-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
        /**
         * Specifies project profiles when creating a project from project profile policy grant details.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-createprojectfromprojectprofilepolicygrantdetail.html#cfn-datazone-policygrant-createprojectfromprojectprofilepolicygrantdetail-projectprofiles
         */
        readonly projectProfiles?: Array<string>;
    }
    /**
     * The policy grant principal.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantprincipal.html
     */
    interface PolicyGrantPrincipalProperty {
        /**
         * The domain unit of the policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantprincipal.html#cfn-datazone-policygrant-policygrantprincipal-domainunit
         */
        readonly domainUnit?: CfnPolicyGrantPropsMixin.DomainUnitPolicyGrantPrincipalProperty | cdk.IResolvable;
        /**
         * The group of the policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantprincipal.html#cfn-datazone-policygrant-policygrantprincipal-group
         */
        readonly group?: CfnPolicyGrantPropsMixin.GroupPolicyGrantPrincipalProperty | cdk.IResolvable;
        /**
         * The project of the policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantprincipal.html#cfn-datazone-policygrant-policygrantprincipal-project
         */
        readonly project?: cdk.IResolvable | CfnPolicyGrantPropsMixin.ProjectPolicyGrantPrincipalProperty;
        /**
         * The user of the policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-policygrantprincipal.html#cfn-datazone-policygrant-policygrantprincipal-user
         */
        readonly user?: cdk.IResolvable | CfnPolicyGrantPropsMixin.UserPolicyGrantPrincipalProperty;
    }
    /**
     * The user policy grant principal.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-userpolicygrantprincipal.html
     */
    interface UserPolicyGrantPrincipalProperty {
        /**
         * The all users grant filter of the user policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-userpolicygrantprincipal.html#cfn-datazone-policygrant-userpolicygrantprincipal-allusersgrantfilter
         */
        readonly allUsersGrantFilter?: any | cdk.IResolvable;
        /**
         * The user ID of the user policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-userpolicygrantprincipal.html#cfn-datazone-policygrant-userpolicygrantprincipal-useridentifier
         */
        readonly userIdentifier?: string;
    }
    /**
     * The group principal to whom the policy is granted.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-grouppolicygrantprincipal.html
     */
    interface GroupPolicyGrantPrincipalProperty {
        /**
         * The ID Of the group of the group principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-grouppolicygrantprincipal.html#cfn-datazone-policygrant-grouppolicygrantprincipal-groupidentifier
         */
        readonly groupIdentifier?: string;
    }
    /**
     * The project policy grant principal.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-projectpolicygrantprincipal.html
     */
    interface ProjectPolicyGrantPrincipalProperty {
        /**
         * The project designation of the project policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-projectpolicygrantprincipal.html#cfn-datazone-policygrant-projectpolicygrantprincipal-projectdesignation
         */
        readonly projectDesignation?: string;
        /**
         * The project grant filter of the project policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-projectpolicygrantprincipal.html#cfn-datazone-policygrant-projectpolicygrantprincipal-projectgrantfilter
         */
        readonly projectGrantFilter?: cdk.IResolvable | CfnPolicyGrantPropsMixin.ProjectGrantFilterProperty;
        /**
         * The project ID of the project policy grant principal.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-projectpolicygrantprincipal.html#cfn-datazone-policygrant-projectpolicygrantprincipal-projectidentifier
         */
        readonly projectIdentifier?: string;
    }
    /**
     * The project grant filter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-projectgrantfilter.html
     */
    interface ProjectGrantFilterProperty {
        /**
         * The domain unit filter of the project grant filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-projectgrantfilter.html#cfn-datazone-policygrant-projectgrantfilter-domainunitfilter
         */
        readonly domainUnitFilter?: CfnPolicyGrantPropsMixin.DomainUnitFilterForProjectProperty | cdk.IResolvable;
    }
    /**
     * The domain unit filter of the project grant filter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitfilterforproject.html
     */
    interface DomainUnitFilterForProjectProperty {
        /**
         * The domain unit ID to use in the filter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitfilterforproject.html#cfn-datazone-policygrant-domainunitfilterforproject-domainunit
         */
        readonly domainUnit?: string;
        /**
         * Specifies whether to include child domain units.
         *
         * @default - false
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitfilterforproject.html#cfn-datazone-policygrant-domainunitfilterforproject-includechilddomainunits
         */
        readonly includeChildDomainUnits?: boolean | cdk.IResolvable;
    }
    /**
     * The domain unit principal to whom the policy is granted.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitpolicygrantprincipal.html
     */
    interface DomainUnitPolicyGrantPrincipalProperty {
        /**
         * Specifes the designation of the domain unit users.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitpolicygrantprincipal.html#cfn-datazone-policygrant-domainunitpolicygrantprincipal-domainunitdesignation
         */
        readonly domainUnitDesignation?: string;
        /**
         * The grant filter for the domain unit.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitpolicygrantprincipal.html#cfn-datazone-policygrant-domainunitpolicygrantprincipal-domainunitgrantfilter
         */
        readonly domainUnitGrantFilter?: CfnPolicyGrantPropsMixin.DomainUnitGrantFilterProperty | cdk.IResolvable;
        /**
         * The ID of the domain unit.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitpolicygrantprincipal.html#cfn-datazone-policygrant-domainunitpolicygrantprincipal-domainunitidentifier
         */
        readonly domainUnitIdentifier?: string;
    }
    /**
     * The grant filter for the domain unit.
     *
     * In the current release of Amazon DataZone, the only supported filter is the `allDomainUnitsGrantFilter` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitgrantfilter.html
     */
    interface DomainUnitGrantFilterProperty {
        /**
         * Specifies a grant filter containing all domain units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-policygrant-domainunitgrantfilter.html#cfn-datazone-policygrant-domainunitgrantfilter-alldomainunitsgrantfilter
         */
        readonly allDomainUnitsGrantFilter?: any | cdk.IResolvable;
    }
}
/**
 * Properties for CfnPolicyGrantPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html
 */
export interface CfnPolicyGrantMixinProps {
    /**
     * The details of the policy grant member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html#cfn-datazone-policygrant-detail
     */
    readonly detail?: cdk.IResolvable | CfnPolicyGrantPropsMixin.PolicyGrantDetailProperty;
    /**
     * The ID of the domain where you want to add a policy grant.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html#cfn-datazone-policygrant-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The ID of the entity (resource) to which you want to add a policy grant.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html#cfn-datazone-policygrant-entityidentifier
     */
    readonly entityIdentifier?: string;
    /**
     * The type of entity (resource) to which the grant is added.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html#cfn-datazone-policygrant-entitytype
     */
    readonly entityType?: string;
    /**
     * The type of policy that you want to grant.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html#cfn-datazone-policygrant-policytype
     */
    readonly policyType?: string;
    /**
     * The principal of the policy grant member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-policygrant.html#cfn-datazone-policygrant-principal
     */
    readonly principal?: cdk.IResolvable | CfnPolicyGrantPropsMixin.PolicyGrantPrincipalProperty;
}
/**
 * The `AWS::DataZone::Project` resource specifies an Amazon DataZone project.
 *
 * Projects enable a group of users to collaborate on various business use cases that involve publishing, discovering, subscribing to, and consuming data in the Amazon DataZone catalog. Project members consume assets from the Amazon DataZone catalog and produce new assets using one or more analytical workflows.
 *
 * @cloudformationResource AWS::DataZone::Project
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html
 */
export declare class CfnProjectPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnProjectMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::Project`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnProjectMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProject;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnProjectPropsMixin {
    /**
     * The environment configuration user parameters.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentconfigurationuserparameter.html
     */
    interface EnvironmentConfigurationUserParameterProperty {
        /**
         * The environment configuration name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentconfigurationuserparameter.html#cfn-datazone-project-environmentconfigurationuserparameter-environmentconfigurationname
         */
        readonly environmentConfigurationName?: string;
        /**
         * The ID of the environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentconfigurationuserparameter.html#cfn-datazone-project-environmentconfigurationuserparameter-environmentid
         */
        readonly environmentId?: string;
        /**
         * The environment parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentconfigurationuserparameter.html#cfn-datazone-project-environmentconfigurationuserparameter-environmentparameters
         */
        readonly environmentParameters?: Array<CfnProjectPropsMixin.EnvironmentParameterProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The parameter details of an evironment profile.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentparameter.html
     */
    interface EnvironmentParameterProperty {
        /**
         * The name of an environment profile parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentparameter.html#cfn-datazone-project-environmentparameter-name
         */
        readonly name?: string;
        /**
         * The value of an environment profile parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-environmentparameter.html#cfn-datazone-project-environmentparameter-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-resourcetag.html
     */
    interface ResourceTagProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-resourcetag.html#cfn-datazone-project-resourcetag-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-resourcetag.html#cfn-datazone-project-resourcetag-value
         */
        readonly value?: string;
    }
    /**
     * The project membership assignment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-projectmembershipassignment.html
     */
    interface ProjectMembershipAssignmentProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-projectmembershipassignment.html#cfn-datazone-project-projectmembershipassignment-designation
         */
        readonly designation?: string;
        /**
         * The member of the project.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-projectmembershipassignment.html#cfn-datazone-project-projectmembershipassignment-member
         */
        readonly member?: cdk.IResolvable | CfnProjectPropsMixin.MemberProperty;
    }
    /**
     * The member of the project.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-member.html
     */
    interface MemberProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-member.html#cfn-datazone-project-member-groupidentifier
         */
        readonly groupIdentifier?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-project-member.html#cfn-datazone-project-member-useridentifier
         */
        readonly userIdentifier?: string;
    }
}
/**
 * Properties for CfnProjectPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html
 */
export interface CfnProjectMixinProps {
    /**
     * The description of a project.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-description
     */
    readonly description?: string;
    /**
     * The identifier of a Amazon DataZone domain where the project exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The ID of the domain unit.
     *
     * This parameter is not required and if it is not specified, then the project is created at the root domain unit level.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-domainunitid
     */
    readonly domainUnitId?: string;
    /**
     * The glossary terms that can be used in this Amazon DataZone project.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-glossaryterms
     */
    readonly glossaryTerms?: Array<string>;
    /**
     * The project membership assignments.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-membershipassignments
     */
    readonly membershipAssignments?: Array<cdk.IResolvable | CfnProjectPropsMixin.ProjectMembershipAssignmentProperty> | cdk.IResolvable;
    /**
     * The name of a project.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-name
     */
    readonly name?: string;
    /**
     * The project category.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-projectcategory
     */
    readonly projectCategory?: string;
    /**
     * The project execution role ARN.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-projectexecutionrole
     */
    readonly projectExecutionRole?: string;
    /**
     * The ID of the project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-projectprofileid
     */
    readonly projectProfileId?: string;
    /**
     * The project profile version to which the project should be updated.
     *
     * You can only specify the following string for this parameter: `latest` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-projectprofileversion
     */
    readonly projectProfileVersion?: string;
    /**
     * The resource tags of the project.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-resourcetags
     */
    readonly resourceTags?: Array<cdk.IResolvable | CfnProjectPropsMixin.ResourceTagProperty> | cdk.IResolvable;
    /**
     * The user parameters of the project.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-project.html#cfn-datazone-project-userparameters
     */
    readonly userParameters?: Array<CfnProjectPropsMixin.EnvironmentConfigurationUserParameterProperty | cdk.IResolvable> | cdk.IResolvable;
}
/**
 * The `AWS::DataZone::ProjectMembership` resource adds a member to an Amazon DataZone project.
 *
 * Project members consume assets from the Amazon DataZone catalog and produce new assets using one or more analytical workflows.
 *
 * @cloudformationResource AWS::DataZone::ProjectMembership
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectmembership.html
 */
export declare class CfnProjectMembershipPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnProjectMembershipMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::ProjectMembership`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnProjectMembershipMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProjectMembership;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnProjectMembershipPropsMixin {
    /**
     * The details about a project member.
     *
     * Important - this data type is a UNION, so only one of the following members can be specified when used or returned.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectmembership-member.html
     */
    interface MemberProperty {
        /**
         * The ID of the group of a project member.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectmembership-member.html#cfn-datazone-projectmembership-member-groupidentifier
         */
        readonly groupIdentifier?: string;
        /**
         * The user ID of a project member.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectmembership-member.html#cfn-datazone-projectmembership-member-useridentifier
         */
        readonly userIdentifier?: string;
    }
}
/**
 * Properties for CfnProjectMembershipPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectmembership.html
 */
export interface CfnProjectMembershipMixinProps {
    /**
     * The designated role of a project member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectmembership.html#cfn-datazone-projectmembership-designation
     */
    readonly designation?: string;
    /**
     * The ID of the Amazon DataZone domain in which project membership is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectmembership.html#cfn-datazone-projectmembership-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The details about a project member.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectmembership.html#cfn-datazone-projectmembership-member
     */
    readonly member?: cdk.IResolvable | CfnProjectMembershipPropsMixin.MemberProperty;
    /**
     * The ID of the project for which this project membership was created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectmembership.html#cfn-datazone-projectmembership-projectidentifier
     */
    readonly projectIdentifier?: string;
}
/**
 * The summary of a project profile.
 *
 * @cloudformationResource AWS::DataZone::ProjectProfile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html
 */
export declare class CfnProjectProfilePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnProjectProfileMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::ProjectProfile`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnProjectProfileMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProjectProfile;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnProjectProfilePropsMixin {
    /**
     * The configuration of an environment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html
     */
    interface EnvironmentConfigurationProperty {
        /**
         * The AWS account of the environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-awsaccount
         */
        readonly awsAccount?: CfnProjectProfilePropsMixin.AwsAccountProperty | cdk.IResolvable;
        /**
         * The AWS Region of the environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-awsregion
         */
        readonly awsRegion?: cdk.IResolvable | CfnProjectProfilePropsMixin.RegionProperty;
        /**
         * The configuration parameters of the environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-configurationparameters
         */
        readonly configurationParameters?: CfnProjectProfilePropsMixin.EnvironmentConfigurationParametersDetailsProperty | cdk.IResolvable;
        /**
         * The deployment mode of the environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-deploymentmode
         */
        readonly deploymentMode?: string;
        /**
         * The deployment order of the environment.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-deploymentorder
         */
        readonly deploymentOrder?: number;
        /**
         * The environment description.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-description
         */
        readonly description?: string;
        /**
         * The environment blueprint ID.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-environmentblueprintid
         */
        readonly environmentBlueprintId?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-environmentconfigurationid
         */
        readonly environmentConfigurationId?: string;
        /**
         * The environment name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfiguration.html#cfn-datazone-projectprofile-environmentconfiguration-name
         */
        readonly name?: string;
    }
    /**
     * The details of the environment configuration parameter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparametersdetails.html
     */
    interface EnvironmentConfigurationParametersDetailsProperty {
        /**
         * The parameter overrides.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparametersdetails.html#cfn-datazone-projectprofile-environmentconfigurationparametersdetails-parameteroverrides
         */
        readonly parameterOverrides?: Array<CfnProjectProfilePropsMixin.EnvironmentConfigurationParameterProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The resolved environment configuration parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparametersdetails.html#cfn-datazone-projectprofile-environmentconfigurationparametersdetails-resolvedparameters
         */
        readonly resolvedParameters?: Array<CfnProjectProfilePropsMixin.EnvironmentConfigurationParameterProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Ssm path environment configuration parameters.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparametersdetails.html#cfn-datazone-projectprofile-environmentconfigurationparametersdetails-ssmpath
         */
        readonly ssmPath?: string;
    }
    /**
     * The environment configuration parameter.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparameter.html
     */
    interface EnvironmentConfigurationParameterProperty {
        /**
         * Specifies whether the environment parameter is editable.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparameter.html#cfn-datazone-projectprofile-environmentconfigurationparameter-iseditable
         */
        readonly isEditable?: boolean | cdk.IResolvable;
        /**
         * The name of the environment configuration parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparameter.html#cfn-datazone-projectprofile-environmentconfigurationparameter-name
         */
        readonly name?: string;
        /**
         * The value of the environment configuration parameter.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-environmentconfigurationparameter.html#cfn-datazone-projectprofile-environmentconfigurationparameter-value
         */
        readonly value?: string;
    }
    /**
     * The AWS account of the environment.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-awsaccount.html
     */
    interface AwsAccountProperty {
        /**
         * The account ID of a project.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-awsaccount.html#cfn-datazone-projectprofile-awsaccount-awsaccountid
         */
        readonly awsAccountId?: string;
    }
    /**
     * The AWS Region.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-region.html
     */
    interface RegionProperty {
        /**
         * The AWS Region name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-region.html#cfn-datazone-projectprofile-region-regionname
         */
        readonly regionName?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-resourcetagparameter.html
     */
    interface ResourceTagParameterProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-resourcetagparameter.html#cfn-datazone-projectprofile-resourcetagparameter-isvalueeditable
         */
        readonly isValueEditable?: boolean | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-resourcetagparameter.html#cfn-datazone-projectprofile-resourcetagparameter-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-projectprofile-resourcetagparameter.html#cfn-datazone-projectprofile-resourcetagparameter-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnProjectProfilePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html
 */
export interface CfnProjectProfileMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-allowcustomprojectresourcetags
     */
    readonly allowCustomProjectResourceTags?: boolean | cdk.IResolvable;
    /**
     * The description of the project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-description
     */
    readonly description?: string;
    /**
     * A domain ID of the project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * A domain unit ID of the project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-domainunitidentifier
     */
    readonly domainUnitIdentifier?: string;
    /**
     * Environment configurations of a project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-environmentconfigurations
     */
    readonly environmentConfigurations?: Array<CfnProjectProfilePropsMixin.EnvironmentConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The name of a project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-projectresourcetags
     */
    readonly projectResourceTags?: Array<cdk.IResolvable | CfnProjectProfilePropsMixin.ResourceTagParameterProperty> | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-projectresourcetagsdescription
     */
    readonly projectResourceTagsDescription?: string;
    /**
     * The status of a project profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-status
     */
    readonly status?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-projectprofile.html#cfn-datazone-projectprofile-usedefaultconfigurations
     */
    readonly useDefaultConfigurations?: boolean | cdk.IResolvable;
}
/**
 * The `AWS::DataZone::SubscriptionTarget` resource specifies an Amazon DataZone subscription target.
 *
 * Subscription targets enable you to access the data to which you have subscribed in your projects. A subscription target specifies the location (for example, a database or a schema) and the required permissions (for example, an IAM role) that Amazon DataZone can use to establish a connection with the source data and to create the necessary grants so that members of the Amazon DataZone project can start querying the data to which they have subscribed.
 *
 * @cloudformationResource AWS::DataZone::SubscriptionTarget
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html
 */
export declare class CfnSubscriptionTargetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSubscriptionTargetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::SubscriptionTarget`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSubscriptionTargetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSubscriptionTarget;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnSubscriptionTargetPropsMixin {
    /**
     * The details of the subscription target configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-subscriptiontarget-subscriptiontargetform.html
     */
    interface SubscriptionTargetFormProperty {
        /**
         * The content of the subscription target configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-subscriptiontarget-subscriptiontargetform.html#cfn-datazone-subscriptiontarget-subscriptiontargetform-content
         */
        readonly content?: string;
        /**
         * The form name included in the subscription target configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-subscriptiontarget-subscriptiontargetform.html#cfn-datazone-subscriptiontarget-subscriptiontargetform-formname
         */
        readonly formName?: string;
    }
}
/**
 * Properties for CfnSubscriptionTargetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html
 */
export interface CfnSubscriptionTargetMixinProps {
    /**
     * The asset types included in the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-applicableassettypes
     */
    readonly applicableAssetTypes?: Array<string>;
    /**
     * The authorized principals included in the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-authorizedprincipals
     */
    readonly authorizedPrincipals?: Array<string>;
    /**
     * The ID of the Amazon DataZone domain in which subscription target is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The ID of the environment in which subscription target is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-environmentidentifier
     */
    readonly environmentIdentifier?: string;
    /**
     * The manage access role that is used to create the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-manageaccessrole
     */
    readonly manageAccessRole?: string;
    /**
     * The name of the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-name
     */
    readonly name?: string;
    /**
     * The provider of the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-provider
     */
    readonly provider?: string;
    /**
     * The configuration of the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-subscriptiontargetconfig
     */
    readonly subscriptionTargetConfig?: Array<cdk.IResolvable | CfnSubscriptionTargetPropsMixin.SubscriptionTargetFormProperty> | cdk.IResolvable;
    /**
     * The type of the subscription target.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-subscriptiontarget.html#cfn-datazone-subscriptiontarget-type
     */
    readonly type?: string;
}
/**
 * The user type of the user for which the user profile is created.
 *
 * @cloudformationResource AWS::DataZone::UserProfile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html
 */
export declare class CfnUserProfilePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnUserProfileMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DataZone::UserProfile`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnUserProfileMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnUserProfile;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnUserProfilePropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-userprofiledetails.html
     */
    interface UserProfileDetailsProperty {
        /**
         * The details of the IAM User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-userprofiledetails.html#cfn-datazone-userprofile-userprofiledetails-iam
         */
        readonly iam?: CfnUserProfilePropsMixin.IamUserProfileDetailsProperty | cdk.IResolvable;
        /**
         * The details of the SSO User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-userprofiledetails.html#cfn-datazone-userprofile-userprofiledetails-sso
         */
        readonly sso?: cdk.IResolvable | CfnUserProfilePropsMixin.SsoUserProfileDetailsProperty;
    }
    /**
     * The details of the IAM User Profile.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-iamuserprofiledetails.html
     */
    interface IamUserProfileDetailsProperty {
        /**
         * The ARN of the IAM User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-iamuserprofiledetails.html#cfn-datazone-userprofile-iamuserprofiledetails-arn
         */
        readonly arn?: string;
        /**
         * The group profile ID of the IAM User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-iamuserprofiledetails.html#cfn-datazone-userprofile-iamuserprofiledetails-groupprofileid
         */
        readonly groupProfileId?: string;
        /**
         * The session name of the IAM User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-iamuserprofiledetails.html#cfn-datazone-userprofile-iamuserprofiledetails-sessionname
         */
        readonly sessionName?: string;
    }
    /**
     * The details of the SSO User Profile.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-ssouserprofiledetails.html
     */
    interface SsoUserProfileDetailsProperty {
        /**
         * The First Name of the IAM User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-ssouserprofiledetails.html#cfn-datazone-userprofile-ssouserprofiledetails-firstname
         */
        readonly firstName?: string;
        /**
         * The Last Name of the IAM User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-ssouserprofiledetails.html#cfn-datazone-userprofile-ssouserprofiledetails-lastname
         */
        readonly lastName?: string;
        /**
         * The username of the SSO User Profile.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-datazone-userprofile-ssouserprofiledetails.html#cfn-datazone-userprofile-ssouserprofiledetails-username
         */
        readonly username?: string;
    }
}
/**
 * Properties for CfnUserProfilePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html
 */
export interface CfnUserProfileMixinProps {
    /**
     * The identifier of a Amazon DataZone domain in which a user profile exists.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html#cfn-datazone-userprofile-domainidentifier
     */
    readonly domainIdentifier?: string;
    /**
     * The session name of the user profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html#cfn-datazone-userprofile-sessionname
     */
    readonly sessionName?: string;
    /**
     * The status of the user profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html#cfn-datazone-userprofile-status
     */
    readonly status?: string;
    /**
     * The identifier of the user for which the user profile is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html#cfn-datazone-userprofile-useridentifier
     */
    readonly userIdentifier?: string;
    /**
     * The user type of the user for which the user profile is created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-datazone-userprofile.html#cfn-datazone-userprofile-usertype
     */
    readonly userType?: string;
}
