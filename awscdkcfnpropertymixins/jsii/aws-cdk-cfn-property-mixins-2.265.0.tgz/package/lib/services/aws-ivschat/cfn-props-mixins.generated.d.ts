import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-ivschat";
import { aws_ivschat as ivsChatRefs, aws_kinesisfirehose as kinesisFirehoseRefs, aws_lambda as lambdaRefs, aws_logs as logsRefs, aws_s3 as s3Refs } from "aws-cdk-lib/interfaces";
/**
 * The `AWS::IVSChat::LoggingConfiguration` resource specifies an  logging configuration that allows clients to store and record sent messages.
 *
 * For more information, see [CreateLoggingConfiguration](https://docs.aws.amazon.com/ivs/latest/ChatAPIReference/API_CreateLoggingConfiguration.html) in the *Amazon Interactive Video Service Chat API Reference* .
 *
 * @cloudformationResource AWS::IVSChat::LoggingConfiguration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-loggingconfiguration.html
 */
export declare class CfnLoggingConfigurationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnLoggingConfigurationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::IVSChat::LoggingConfiguration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnLoggingConfigurationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnLoggingConfiguration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnLoggingConfigurationPropsMixin {
    /**
     * The DestinationConfiguration property type describes a location where chat logs will be stored.
     *
     * Each member represents the configuration of one log destination. For logging, you define only one type of destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-destinationconfiguration.html
     */
    interface DestinationConfigurationProperty {
        /**
         * An Amazon CloudWatch Logs destination configuration where chat activity will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-destinationconfiguration.html#cfn-ivschat-loggingconfiguration-destinationconfiguration-cloudwatchlogs
         */
        readonly cloudWatchLogs?: CfnLoggingConfigurationPropsMixin.CloudWatchLogsDestinationConfigurationProperty | cdk.IResolvable;
        /**
         * An Amazon Kinesis Data Firehose destination configuration where chat activity will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-destinationconfiguration.html#cfn-ivschat-loggingconfiguration-destinationconfiguration-firehose
         */
        readonly firehose?: CfnLoggingConfigurationPropsMixin.FirehoseDestinationConfigurationProperty | cdk.IResolvable;
        /**
         * An Amazon S3 destination configuration where chat activity will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-destinationconfiguration.html#cfn-ivschat-loggingconfiguration-destinationconfiguration-s3
         */
        readonly s3?: cdk.IResolvable | CfnLoggingConfigurationPropsMixin.S3DestinationConfigurationProperty;
    }
    /**
     * The S3DestinationConfiguration property type specifies an S3 location where chat logs will be stored.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-s3destinationconfiguration.html
     */
    interface S3DestinationConfigurationProperty {
        /**
         * Name of the Amazon S3 bucket where chat activity will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-s3destinationconfiguration.html#cfn-ivschat-loggingconfiguration-s3destinationconfiguration-bucketname
         */
        readonly bucketName?: s3Refs.IBucketRef | string;
    }
    /**
     * The FirehoseDestinationConfiguration property type specifies a Kinesis Firehose location where chat logs will be stored.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-firehosedestinationconfiguration.html
     */
    interface FirehoseDestinationConfigurationProperty {
        /**
         * Name of the Amazon Kinesis Firehose delivery stream where chat activity will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-firehosedestinationconfiguration.html#cfn-ivschat-loggingconfiguration-firehosedestinationconfiguration-deliverystreamname
         */
        readonly deliveryStreamName?: kinesisFirehoseRefs.IDeliveryStreamRef | string;
    }
    /**
     * The CloudWatchLogsDestinationConfiguration property type specifies a CloudWatch Logs location where chat logs will be stored.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-cloudwatchlogsdestinationconfiguration.html
     */
    interface CloudWatchLogsDestinationConfigurationProperty {
        /**
         * Name of the Amazon Cloudwatch Logs destination where chat activity will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-cloudwatchlogsdestinationconfiguration.html#cfn-ivschat-loggingconfiguration-cloudwatchlogsdestinationconfiguration-loggroupname
         */
        readonly logGroupName?: logsRefs.ILogGroupRef | string;
    }
}
/**
 * Properties for CfnLoggingConfigurationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-loggingconfiguration.html
 */
export interface CfnLoggingConfigurationMixinProps {
    /**
     * The DestinationConfiguration is a complex type that contains information about where chat content will be logged.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-loggingconfiguration.html#cfn-ivschat-loggingconfiguration-destinationconfiguration
     */
    readonly destinationConfiguration?: CfnLoggingConfigurationPropsMixin.DestinationConfigurationProperty | cdk.IResolvable;
    /**
     * Logging-configuration name.
     *
     * The value does not need to be unique.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-loggingconfiguration.html#cfn-ivschat-loggingconfiguration-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * For more information, see [Tag](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-loggingconfiguration-tag.html) .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-loggingconfiguration.html#cfn-ivschat-loggingconfiguration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * The `AWS::IVSChat::Room` resource specifies an  room that allows clients to connect and pass messages.
 *
 * For more information, see [CreateRoom](https://docs.aws.amazon.com/ivs/latest/ChatAPIReference/API_CreateRoom.html) in the *Amazon Interactive Video Service Chat API Reference* .
 *
 * @cloudformationResource AWS::IVSChat::Room
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html
 */
export declare class CfnRoomPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRoomMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::IVSChat::Room`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRoomMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRoom;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnRoomPropsMixin {
    /**
     * The MessageReviewHandler property type specifies configuration information for optional message review.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-room-messagereviewhandler.html
     */
    interface MessageReviewHandlerProperty {
        /**
         * Specifies the fallback behavior (whether the message is allowed or denied) if the handler does not return a valid response, encounters an error, or times out.
         *
         * (For the timeout period, see [Service Quotas](https://docs.aws.amazon.com/ivs/latest/userguide/service-quotas.html) .) If allowed, the message is delivered with returned content to all users connected to the room. If denied, the message is not delivered to any user.
         *
         * *Default* : `ALLOW`
         *
         * @default - "ALLOW"
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-room-messagereviewhandler.html#cfn-ivschat-room-messagereviewhandler-fallbackresult
         */
        readonly fallbackResult?: string;
        /**
         * Identifier of the message review handler.
         *
         * Currently this must be an ARN of a lambda function.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-room-messagereviewhandler.html#cfn-ivschat-room-messagereviewhandler-uri
         */
        readonly uri?: lambdaRefs.IFunctionRef | string;
    }
}
/**
 * Properties for CfnRoomPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html
 */
export interface CfnRoomMixinProps {
    /**
     * List of logging-configuration identifiers attached to the room.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html#cfn-ivschat-room-loggingconfigurationidentifiers
     */
    readonly loggingConfigurationIdentifiers?: Array<ivsChatRefs.ILoggingConfigurationRef | string>;
    /**
     * Maximum number of characters in a single message.
     *
     * Messages are expected to be UTF-8 encoded and this limit applies specifically to rune/code-point count, not number of bytes.
     *
     * @default - 500
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html#cfn-ivschat-room-maximummessagelength
     */
    readonly maximumMessageLength?: number;
    /**
     * Maximum number of messages per second that can be sent to the room (by all clients).
     *
     * @default - 10
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html#cfn-ivschat-room-maximummessageratepersecond
     */
    readonly maximumMessageRatePerSecond?: number;
    /**
     * Configuration information for optional review of messages.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html#cfn-ivschat-room-messagereviewhandler
     */
    readonly messageReviewHandler?: cdk.IResolvable | CfnRoomPropsMixin.MessageReviewHandlerProperty;
    /**
     * Room name.
     *
     * The value does not need to be unique.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html#cfn-ivschat-room-name
     */
    readonly name?: string;
    /**
     * An array of key-value pairs to apply to this resource.
     *
     * For more information, see [Tag](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ivschat-room-tag.html) .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ivschat-room.html#cfn-ivschat-room-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
