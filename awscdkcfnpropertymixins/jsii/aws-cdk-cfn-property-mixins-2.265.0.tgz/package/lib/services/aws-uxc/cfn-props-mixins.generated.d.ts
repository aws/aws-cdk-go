import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-uxc";
/**
 * Resource schema for managing AWS account-level UX customization settings, including account color, visible services, and visible regions.
 *
 * @cloudformationResource AWS::UXC::AccountCustomization
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-uxc-accountcustomization.html
 */
export declare class CfnAccountCustomizationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnAccountCustomizationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::UXC::AccountCustomization`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnAccountCustomizationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnAccountCustomization;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnAccountCustomizationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-uxc-accountcustomization.html
 */
export interface CfnAccountCustomizationMixinProps {
    /**
     * The color theme assigned to the account for visual identification in the AWS Console.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-uxc-accountcustomization.html#cfn-uxc-accountcustomization-accountcolor
     */
    readonly accountColor?: string;
    /**
     * A list of AWS region identifiers visible to the account in the AWS Console.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-uxc-accountcustomization.html#cfn-uxc-accountcustomization-visibleregions
     */
    readonly visibleRegions?: Array<string>;
    /**
     * A list of AWS service identifiers visible to the account in the AWS Console.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-uxc-accountcustomization.html#cfn-uxc-accountcustomization-visibleservices
     */
    readonly visibleServices?: Array<string>;
}
