import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-dsql";
/**
 * The `AWS::DSQL::Cluster` resource specifies an cluster. You can use this resource to create, modify, and manage clusters.
 *
 * This resource supports both single-Region clusters and multi-Region clusters through the `MultiRegionProperties` parameter.
 *
 * > Creating multi-Region clusters requires additional IAM permissions beyond those needed for single-Region clusters. > - The witness Region specified in `multiRegionProperties.witnessRegion` cannot be the same as the cluster's Region.
 *
 * *Required permissions*
 *
 * - **dsql:CreateCluster** - Required to create a cluster.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 * - **dsql:TagResource** - Permission to add tags to a resource.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 * - **dsql:PutMultiRegionProperties** - Permission to configure multi-Region properties for a cluster.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 * - **dsql:AddPeerCluster** - When specifying `multiRegionProperties.clusters` , permission to add peer clusters.
 *
 * Resources:
 *
 * - Local cluster: `arn:aws:dsql:region:account-id:cluster/*`
 * - Each peer cluster: exact ARN of each specified peer cluster
 * - **dsql:PutWitnessRegion** - When specifying `multiRegionProperties.witnessRegion` , permission to set a witness Region. This permission is checked both in the cluster Region and in the witness Region.
 *
 * Resources: `arn:aws:dsql:region:account-id:cluster/*`
 *
 * Condition Keys: `dsql:WitnessRegion` (matching the specified witness region)
 *
 * @cloudformationResource AWS::DSQL::Cluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html
 */
export declare class CfnClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::DSQL::Cluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnClusterPropsMixin {
    /**
     * Defines the structure for multi-Region cluster configurations, containing the witness Region and peered cluster settings.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-multiregionproperties.html
     */
    interface MultiRegionPropertiesProperty {
        /**
         * The set of peered clusters that form the multi-Region cluster configuration.
         *
         * Each peered cluster represents a database instance in a different Region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-multiregionproperties.html#cfn-dsql-cluster-multiregionproperties-clusters
         */
        readonly clusters?: Array<string>;
        /**
         * The Region that serves as the witness Region for a multi-Region cluster.
         *
         * The witness Region helps maintain cluster consistency and quorum.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-multiregionproperties.html#cfn-dsql-cluster-multiregionproperties-witnessregion
         */
        readonly witnessRegion?: string;
    }
    /**
     * Configuration details about encryption for the cluster including the AWS  key ARN, encryption type, and encryption status.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-encryptiondetails.html
     */
    interface EncryptionDetailsProperty {
        /**
         * The status of encryption for the cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-encryptiondetails.html#cfn-dsql-cluster-encryptiondetails-encryptionstatus
         */
        readonly encryptionStatus?: string;
        /**
         * The type of encryption that protects the data on your cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-encryptiondetails.html#cfn-dsql-cluster-encryptiondetails-encryptiontype
         */
        readonly encryptionType?: string;
        /**
         * The ARN of the AWS  key that encrypts data in the cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-dsql-cluster-encryptiondetails.html#cfn-dsql-cluster-encryptiondetails-kmskeyarn
         */
        readonly kmsKeyArn?: string;
    }
}
/**
 * Properties for CfnClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html
 */
export interface CfnClusterMixinProps {
    /**
     * Whether deletion protection is enabled on this cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html#cfn-dsql-cluster-deletionprotectionenabled
     */
    readonly deletionProtectionEnabled?: boolean | cdk.IResolvable;
    /**
     * The KMS key that encrypts data on the cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html#cfn-dsql-cluster-kmsencryptionkey
     */
    readonly kmsEncryptionKey?: string;
    /**
     * Defines the structure for multi-Region cluster configurations, containing the witness Region and peered cluster settings.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html#cfn-dsql-cluster-multiregionproperties
     */
    readonly multiRegionProperties?: cdk.IResolvable | CfnClusterPropsMixin.MultiRegionPropertiesProperty;
    /**
     * A resource-based policy document in JSON format.
     *
     * Length constraints: Minimum length of 1. Maximum length of 20480 characters (approximately 20KB).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html#cfn-dsql-cluster-policydocument
     */
    readonly policyDocument?: string;
    /**
     * A map of key and value pairs this cluster is tagged with.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-dsql-cluster.html#cfn-dsql-cluster-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
