import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-smsvoice";
/**
 * Creates a new configuration set.
 *
 * After you create the configuration set, you can add one or more event destinations to it.
 *
 * A configuration set is a set of rules that you apply to the SMS and voice messages that you send.
 *
 * When you send a message, you can optionally specify a single configuration set.
 *
 * @cloudformationResource AWS::SMSVOICE::ConfigurationSet
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html
 */
export declare class CfnConfigurationSetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnConfigurationSetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::ConfigurationSet`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnConfigurationSetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnConfigurationSet;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnConfigurationSetPropsMixin {
    /**
     * Contains information about an event destination.
     *
     * Event destinations are associated with configuration sets, which enable you to publish message sending events to CloudWatch, Firehose, or Amazon SNS.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html
     */
    interface EventDestinationProperty {
        /**
         * An object that contains information about an event destination that sends logging events to Amazon CloudWatch logs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html#cfn-smsvoice-configurationset-eventdestination-cloudwatchlogsdestination
         */
        readonly cloudWatchLogsDestination?: CfnConfigurationSetPropsMixin.CloudWatchLogsDestinationProperty | cdk.IResolvable;
        /**
         * When set to true events will be logged.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html#cfn-smsvoice-configurationset-eventdestination-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
        /**
         * The name of the EventDestination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html#cfn-smsvoice-configurationset-eventdestination-eventdestinationname
         */
        readonly eventDestinationName?: string;
        /**
         * An object that contains information about an event destination for logging to Amazon Data Firehose.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html#cfn-smsvoice-configurationset-eventdestination-kinesisfirehosedestination
         */
        readonly kinesisFirehoseDestination?: cdk.IResolvable | CfnConfigurationSetPropsMixin.KinesisFirehoseDestinationProperty;
        /**
         * An array of event types that determine which events to log.
         *
         * > The `TEXT_SENT` event type is not supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html#cfn-smsvoice-configurationset-eventdestination-matchingeventtypes
         */
        readonly matchingEventTypes?: Array<string>;
        /**
         * An object that contains information about an event destination that sends logging events to Amazon SNS.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-eventdestination.html#cfn-smsvoice-configurationset-eventdestination-snsdestination
         */
        readonly snsDestination?: cdk.IResolvable | CfnConfigurationSetPropsMixin.SnsDestinationProperty;
    }
    /**
     * Contains the destination configuration to use when publishing message sending events.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-cloudwatchlogsdestination.html
     */
    interface CloudWatchLogsDestinationProperty {
        /**
         * The Amazon Resource Name (ARN) of an AWS Identity and Access Management role that is able to write event data to an Amazon CloudWatch destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-cloudwatchlogsdestination.html#cfn-smsvoice-configurationset-cloudwatchlogsdestination-iamrolearn
         */
        readonly iamRoleArn?: string;
        /**
         * The name of the Amazon CloudWatch log group that you want to record events in.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-cloudwatchlogsdestination.html#cfn-smsvoice-configurationset-cloudwatchlogsdestination-loggrouparn
         */
        readonly logGroupArn?: string;
    }
    /**
     * Contains the delivery stream Amazon Resource Name (ARN), and the ARN of the AWS Identity and Access Management (IAM) role associated with a Firehose event destination.
     *
     * Event destinations, such as Firehose, are associated with configuration sets, which enable you to publish message sending events.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-kinesisfirehosedestination.html
     */
    interface KinesisFirehoseDestinationProperty {
        /**
         * The Amazon Resource Name (ARN) of the delivery stream.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-kinesisfirehosedestination.html#cfn-smsvoice-configurationset-kinesisfirehosedestination-deliverystreamarn
         */
        readonly deliveryStreamArn?: string;
        /**
         * The ARN of an AWS Identity and Access Management role that is able to write event data to an Amazon Data Firehose destination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-kinesisfirehosedestination.html#cfn-smsvoice-configurationset-kinesisfirehosedestination-iamrolearn
         */
        readonly iamRoleArn?: string;
    }
    /**
     * An object that defines an Amazon SNS destination for events.
     *
     * You can use Amazon SNS to send notification when certain events occur.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-snsdestination.html
     */
    interface SnsDestinationProperty {
        /**
         * The Amazon Resource Name (ARN) of the Amazon SNS topic that you want to publish events to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-configurationset-snsdestination.html#cfn-smsvoice-configurationset-snsdestination-topicarn
         */
        readonly topicArn?: string;
    }
}
/**
 * Properties for CfnConfigurationSetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html
 */
export interface CfnConfigurationSetMixinProps {
    /**
     * The name of the ConfigurationSet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html#cfn-smsvoice-configurationset-configurationsetname
     */
    readonly configurationSetName?: string;
    /**
     * The default sender ID used by the ConfigurationSet.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html#cfn-smsvoice-configurationset-defaultsenderid
     */
    readonly defaultSenderId?: string;
    /**
     * An array of EventDestination objects that describe any events to log and where to log them.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html#cfn-smsvoice-configurationset-eventdestinations
     */
    readonly eventDestinations?: Array<CfnConfigurationSetPropsMixin.EventDestinationProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Set to true to enable feedback for the message.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html#cfn-smsvoice-configurationset-messagefeedbackenabled
     */
    readonly messageFeedbackEnabled?: boolean | cdk.IResolvable;
    /**
     * The unique identifier for the protect configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html#cfn-smsvoice-configurationset-protectconfigurationid
     */
    readonly protectConfigurationId?: string;
    /**
     * An array of key and value pair tags that's associated with the new configuration set.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-configurationset.html#cfn-smsvoice-configurationset-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a new opt-out list.
 *
 * If the opt-out list name already exists, an error is returned.
 *
 * An opt-out list is a list of phone numbers that are opted out, meaning you can't send SMS or voice messages to them. If end user replies with the keyword "STOP," an entry for the phone number is added to the opt-out list. In addition to STOP, your recipients can use any supported opt-out keyword, such as CANCEL or OPTOUT. For a list of supported opt-out keywords, see [SMS opt out](https://docs.aws.amazon.com/sms-voice/latest/userguide/opt-out-list-keywords.html) in the End User Messaging  User Guide.
 *
 * @cloudformationResource AWS::SMSVOICE::OptOutList
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-optoutlist.html
 */
export declare class CfnOptOutListPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOptOutListMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::OptOutList`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOptOutListMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOptOutList;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnOptOutListPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-optoutlist.html
 */
export interface CfnOptOutListMixinProps {
    /**
     * The name of the OptOutList.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-optoutlist.html#cfn-smsvoice-optoutlist-optoutlistname
     */
    readonly optOutListName?: string;
    /**
     * An array of tags (key and value pairs) to associate with the new OptOutList.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-optoutlist.html#cfn-smsvoice-optoutlist-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Request an origination phone number for use in your account.
 *
 * For more information on phone number request see [Request a phone number](https://docs.aws.amazon.com/sms-voice/latest/userguide/phone-numbers-request.html) in the *End User Messaging  User Guide* .
 *
 * > Registering phone numbers is not supported by AWS CloudFormation . You can import phone numbers and sender IDs that are automatically provisioned at registration.
 *
 * @cloudformationResource AWS::SMSVOICE::PhoneNumber
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html
 */
export declare class CfnPhoneNumberPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPhoneNumberMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::PhoneNumber`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPhoneNumberMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPhoneNumber;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPhoneNumberPropsMixin {
    /**
     * The keywords `HELP` and `STOP` are mandatory keywords that each phone number must have.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-mandatorykeywords.html
     */
    interface MandatoryKeywordsProperty {
        /**
         * Specifies the `HELP` keyword that customers use to obtain customer support for this phone number.
         *
         * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-mandatorykeywords.html#cfn-smsvoice-phonenumber-mandatorykeywords-help
         */
        readonly help?: cdk.IResolvable | CfnPhoneNumberPropsMixin.MandatoryKeywordProperty;
        /**
         * Specifies the `STOP` keyword that customers use to opt out of receiving messages from this phone number.
         *
         * For more information, see [Required opt-out keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords-required.html) in the End User Messaging  User Guide.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-mandatorykeywords.html#cfn-smsvoice-phonenumber-mandatorykeywords-stop
         */
        readonly stop?: cdk.IResolvable | CfnPhoneNumberPropsMixin.MandatoryKeywordProperty;
    }
    /**
     * The keywords `HELP` and `STOP` are mandatory keywords that each phone number must have.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-mandatorykeyword.html
     */
    interface MandatoryKeywordProperty {
        /**
         * The message associated with the keyword.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-mandatorykeyword.html#cfn-smsvoice-phonenumber-mandatorykeyword-message
         */
        readonly message?: string;
    }
    /**
     * The `OptionalKeyword` configuration.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-optionalkeyword.html
     */
    interface OptionalKeywordProperty {
        /**
         * The action to perform when the keyword is used.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-optionalkeyword.html#cfn-smsvoice-phonenumber-optionalkeyword-action
         */
        readonly action?: string;
        /**
         * The new keyword to add.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-optionalkeyword.html#cfn-smsvoice-phonenumber-optionalkeyword-keyword
         */
        readonly keyword?: string;
        /**
         * The message associated with the keyword.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-optionalkeyword.html#cfn-smsvoice-phonenumber-optionalkeyword-message
         */
        readonly message?: string;
    }
    /**
     * The phone number's two-way SMS configuration object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-twoway.html
     */
    interface TwoWayProperty {
        /**
         * The Amazon Resource Name (ARN) of the two way channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-twoway.html#cfn-smsvoice-phonenumber-twoway-channelarn
         */
        readonly channelArn?: string;
        /**
         * An optional IAM Role Arn for a service to assume, to be able to post inbound SMS messages.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-twoway.html#cfn-smsvoice-phonenumber-twoway-channelrole
         */
        readonly channelRole?: string;
        /**
         * By default this is set to false.
         *
         * When set to true you can receive incoming text messages from your end recipients using the TwoWayChannelArn.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-phonenumber-twoway.html#cfn-smsvoice-phonenumber-twoway-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnPhoneNumberPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html
 */
export interface CfnPhoneNumberMixinProps {
    /**
     * By default this is set to false.
     *
     * When set to true the phone number can't be deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-deletionprotectionenabled
     */
    readonly deletionProtectionEnabled?: boolean | cdk.IResolvable;
    /**
     * The two-character code, in ISO 3166-1 alpha-2 format, for the country or region.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-isocountrycode
     */
    readonly isoCountryCode?: string;
    /**
     * Creates or updates a `MandatoryKeyword` configuration on an origination phone number For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-mandatorykeywords
     */
    readonly mandatoryKeywords?: cdk.IResolvable | CfnPhoneNumberPropsMixin.MandatoryKeywordsProperty;
    /**
     * Indicates if the phone number will be used for text messages, voice messages, or both.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-numbercapabilities
     */
    readonly numberCapabilities?: Array<string>;
    /**
     * The type of phone number to request.
     *
     * > The `ShortCode` number type is not supported in AWS CloudFormation .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-numbertype
     */
    readonly numberType?: string;
    /**
     * A keyword is a word that you can search for on a particular phone number or pool.
     *
     * It is also a specific word or phrase that an end user can send to your number to elicit a response, such as an informational message or a special offer. When your number receives a message that begins with a keyword, End User Messaging  responds with a customizable message. Optional keywords are differentiated from mandatory keywords. For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-optionalkeywords
     */
    readonly optionalKeywords?: Array<cdk.IResolvable | CfnPhoneNumberPropsMixin.OptionalKeywordProperty> | cdk.IResolvable;
    /**
     * The name of the OptOutList associated with the phone number.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-optoutlistname
     */
    readonly optOutListName?: string;
    /**
     * When set to false and an end recipient sends a message that begins with HELP or STOP to one of your dedicated numbers, End User Messaging  automatically replies with a customizable message and adds the end recipient to the OptOutList.
     *
     * When set to true you're responsible for responding to HELP and STOP requests. You're also responsible for tracking and honoring opt-out request. For more information see [Self-managed opt-outs](https://docs.aws.amazon.com/sms-voice/latest/userguide/opt-out-list-self-managed.html)
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-selfmanagedoptoutsenabled
     */
    readonly selfManagedOptOutsEnabled?: boolean | cdk.IResolvable;
    /**
     * An array of tags (key and value pairs) to associate with the requested phone number.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Describes the two-way SMS configuration for a phone number.
     *
     * For more information, see [Two-way SMS messaging](https://docs.aws.amazon.com/sms-voice/latest/userguide/two-way-sms.html) in the End User Messaging  User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-phonenumber.html#cfn-smsvoice-phonenumber-twoway
     */
    readonly twoWay?: cdk.IResolvable | CfnPhoneNumberPropsMixin.TwoWayProperty;
}
/**
 * Creates a new pool and associates the specified origination identity to the pool.
 *
 * A pool can include one or more phone numbers and SenderIds that are associated with your AWS account.
 *
 * The new pool inherits its configuration from the specified origination identity. This includes keywords, message type, opt-out list, two-way configuration, and self-managed opt-out configuration. Deletion protection isn't inherited from the origination identity and defaults to false.
 *
 * If the origination identity is a phone number and is already associated with another pool, an error is returned. A sender ID can be associated with multiple pools.
 *
 * @cloudformationResource AWS::SMSVOICE::Pool
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html
 */
export declare class CfnPoolPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPoolMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::Pool`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPoolMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPool;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPoolPropsMixin {
    /**
     * The manadatory keywords, `HELP` and `STOP` to add to the pool.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-mandatorykeywords.html
     */
    interface MandatoryKeywordsProperty {
        /**
         * Specifies the pool's `HELP` keyword.
         *
         * For more information, see [Opt out list required keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/opt-out-list-keywords.html) in the End User Messaging  User Guide.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-mandatorykeywords.html#cfn-smsvoice-pool-mandatorykeywords-help
         */
        readonly help?: cdk.IResolvable | CfnPoolPropsMixin.MandatoryKeywordProperty;
        /**
         * Specifies the pool's opt-out keyword.
         *
         * For more information, see [Required opt-out keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords-required.html) in the End User Messaging  User Guide.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-mandatorykeywords.html#cfn-smsvoice-pool-mandatorykeywords-stop
         */
        readonly stop?: cdk.IResolvable | CfnPoolPropsMixin.MandatoryKeywordProperty;
    }
    /**
     * The keywords `HELP` and `STOP` are mandatory keywords that each phone number must have.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-mandatorykeyword.html
     */
    interface MandatoryKeywordProperty {
        /**
         * The message associated with the keyword.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-mandatorykeyword.html#cfn-smsvoice-pool-mandatorykeyword-message
         */
        readonly message?: string;
    }
    /**
     * The pool's `OptionalKeyword` configuration.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-optionalkeyword.html
     */
    interface OptionalKeywordProperty {
        /**
         * The action to perform when the keyword is used.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-optionalkeyword.html#cfn-smsvoice-pool-optionalkeyword-action
         */
        readonly action?: string;
        /**
         * The new keyword to add.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-optionalkeyword.html#cfn-smsvoice-pool-optionalkeyword-keyword
         */
        readonly keyword?: string;
        /**
         * The message associated with the keyword.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-optionalkeyword.html#cfn-smsvoice-pool-optionalkeyword-message
         */
        readonly message?: string;
    }
    /**
     * The pool's two-way SMS configuration object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-twoway.html
     */
    interface TwoWayProperty {
        /**
         * The Amazon Resource Name (ARN) of the two way channel.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-twoway.html#cfn-smsvoice-pool-twoway-channelarn
         */
        readonly channelArn?: string;
        /**
         * An optional IAM Role Arn for a service to assume, to be able to post inbound SMS messages.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-twoway.html#cfn-smsvoice-pool-twoway-channelrole
         */
        readonly channelRole?: string;
        /**
         * By default this is set to false.
         *
         * When set to true you can receive incoming text messages from your end recipients using the TwoWayChannelArn.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-pool-twoway.html#cfn-smsvoice-pool-twoway-enabled
         */
        readonly enabled?: boolean | cdk.IResolvable;
    }
}
/**
 * Properties for CfnPoolPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html
 */
export interface CfnPoolMixinProps {
    /**
     * When set to true the pool can't be deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-deletionprotectionenabled
     */
    readonly deletionProtectionEnabled?: boolean | cdk.IResolvable;
    /**
     * Creates or updates the pool's `MandatoryKeyword` configuration.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-mandatorykeywords
     */
    readonly mandatoryKeywords?: cdk.IResolvable | CfnPoolPropsMixin.MandatoryKeywordsProperty;
    /**
     * Specifies any optional keywords to associate with the pool.
     *
     * For more information, see [Keywords](https://docs.aws.amazon.com/sms-voice/latest/userguide/keywords.html) in the End User Messaging  User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-optionalkeywords
     */
    readonly optionalKeywords?: Array<cdk.IResolvable | CfnPoolPropsMixin.OptionalKeywordProperty> | cdk.IResolvable;
    /**
     * The name of the OptOutList associated with the pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-optoutlistname
     */
    readonly optOutListName?: string;
    /**
     * The list of origination identities to apply to the pool, either `PhoneNumberArn` or `SenderIdArn` .
     *
     * For more information, see [Registrations](https://docs.aws.amazon.com/sms-voice/latest/userguide/registrations.html) in the End User Messaging  User Guide.
     *
     * > If you are using a shared End User Messaging  resource then you must use the full Amazon Resource Name (ARN).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-originationidentities
     */
    readonly originationIdentities?: Array<string>;
    /**
     * When set to false, an end recipient sends a message that begins with HELP or STOP to one of your dedicated numbers, End User Messaging  automatically replies with a customizable message and adds the end recipient to the OptOutList.
     *
     * When set to true you're responsible for responding to HELP and STOP requests. You're also responsible for tracking and honoring opt-out requests. For more information see [Self-managed opt-outs](https://docs.aws.amazon.com//pinpoint/latest/userguide/settings-sms-managing.html#settings-account-sms-self-managed-opt-out)
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-selfmanagedoptoutsenabled
     */
    readonly selfManagedOptOutsEnabled?: boolean | cdk.IResolvable;
    /**
     * Allows you to enable shared routes on your pool.
     *
     * By default, this is set to `False` . If you set this value to `True` , your messages are sent using phone numbers or sender IDs (depending on the country) that are shared with other users. In some countries, such as the United States, senders aren't allowed to use shared routes and must use a dedicated phone number or short code.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-sharedroutesenabled
     */
    readonly sharedRoutesEnabled?: boolean | cdk.IResolvable;
    /**
     * An array of tags (key and value pairs) associated with the pool.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Describes the two-way SMS configuration for a phone number.
     *
     * For more information, see [Two-way SMS messaging](https://docs.aws.amazon.com/sms-voice/latest/userguide/two-way-sms.html) in the End User Messaging  User Guide.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-pool.html#cfn-smsvoice-pool-twoway
     */
    readonly twoWay?: cdk.IResolvable | CfnPoolPropsMixin.TwoWayProperty;
}
/**
 * Create a new protect configuration.
 *
 * By default all country rule sets for each capability are set to `ALLOW` . A protect configurations name is stored as a Tag with the key set to `Name` and value as the name of the protect configuration.
 *
 * @cloudformationResource AWS::SMSVOICE::ProtectConfiguration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-protectconfiguration.html
 */
export declare class CfnProtectConfigurationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnProtectConfigurationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::ProtectConfiguration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnProtectConfigurationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProtectConfiguration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnProtectConfigurationPropsMixin {
    /**
     * The set of `CountryRules` you specify to control which countries End User Messaging  can send your messages to.
     *
     * > If you don't specify all available ISO country codes in the `CountryRuleSet` for each number capability, the CloudFormation drift detection feature will detect drift. This is because End User Messaging  always returns all country codes.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryruleset.html
     */
    interface CountryRuleSetProperty {
        /**
         * The set of `CountryRule` s to control which destination countries End User Messaging  can send your MMS messages to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryruleset.html#cfn-smsvoice-protectconfiguration-countryruleset-mms
         */
        readonly mms?: Array<CfnProtectConfigurationPropsMixin.CountryRuleProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The set of `CountryRule` s to control which destination countries End User Messaging  can send your SMS messages to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryruleset.html#cfn-smsvoice-protectconfiguration-countryruleset-sms
         */
        readonly sms?: Array<CfnProtectConfigurationPropsMixin.CountryRuleProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The set of `CountryRule` s to control which destination countries End User Messaging  can send your VOICE messages to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryruleset.html#cfn-smsvoice-protectconfiguration-countryruleset-voice
         */
        readonly voice?: Array<CfnProtectConfigurationPropsMixin.CountryRuleProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * Specifies the type of protection to use for a country.
     *
     * For example, to set Canada as allowed, the `CountryRule` would be formatted as follows:
     *
     * `{ "CountryCode": "CA", "ProtectStatus": "ALLOW" }`
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryrule.html
     */
    interface CountryRuleProperty {
        /**
         * The two-character code, in ISO 3166-1 alpha-2 format, for the country or region.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryrule.html#cfn-smsvoice-protectconfiguration-countryrule-countrycode
         */
        readonly countryCode?: string;
        /**
         * The types of protection that can be used.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-smsvoice-protectconfiguration-countryrule.html#cfn-smsvoice-protectconfiguration-countryrule-protectstatus
         */
        readonly protectStatus?: string;
    }
}
/**
 * Properties for CfnProtectConfigurationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-protectconfiguration.html
 */
export interface CfnProtectConfigurationMixinProps {
    /**
     * The set of `CountryRules` you specify to control which countries End User Messaging  can send your messages to.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-protectconfiguration.html#cfn-smsvoice-protectconfiguration-countryruleset
     */
    readonly countryRuleSet?: CfnProtectConfigurationPropsMixin.CountryRuleSetProperty | cdk.IResolvable;
    /**
     * The status of deletion protection for the protect configuration.
     *
     * When set to true deletion protection is enabled. By default this is set to false.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-protectconfiguration.html#cfn-smsvoice-protectconfiguration-deletionprotectionenabled
     */
    readonly deletionProtectionEnabled?: boolean | cdk.IResolvable;
    /**
     * An array of key and value pair tags that are associated with the resource.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-protectconfiguration.html#cfn-smsvoice-protectconfiguration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * A registration that has been created.
 *
 * @cloudformationResource AWS::SMSVOICE::Registration
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-registration.html
 */
export declare class CfnRegistrationPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRegistrationMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::Registration`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRegistrationMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRegistration;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnRegistrationPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-registration.html
 */
export interface CfnRegistrationMixinProps {
    /**
     * The type of registration form to create.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-registration.html#cfn-smsvoice-registration-registrationtype
     */
    readonly registrationType?: string;
    /**
     * An array of tags (key and value pairs) to associate with the registration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-registration.html#cfn-smsvoice-registration-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Attaches a resource-based policy to a End User Messaging  resource(phone number, sender Id, phone poll, or opt-out list) that is used for sharing the resource.
 *
 * A shared resource can be a Pool, Opt-out list, Sender Id, or Phone number. For more information about resource-based policies, see [Working with shared resources](https://docs.aws.amazon.com/sms-voice/latest/userguide/shared-resources.html) in the *End User Messaging  User Guide* .
 *
 * @cloudformationResource AWS::SMSVOICE::ResourcePolicy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-resourcepolicy.html
 */
export declare class CfnResourcePolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnResourcePolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::ResourcePolicy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnResourcePolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnResourcePolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnResourcePolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-resourcepolicy.html
 */
export interface CfnResourcePolicyMixinProps {
    /**
     * The JSON formatted resource-based policy to attach.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-resourcepolicy.html#cfn-smsvoice-resourcepolicy-policydocument
     */
    readonly policyDocument?: any | cdk.IResolvable;
    /**
     * The Amazon Resource Name (ARN) of the End User Messaging  resource attached to the resource-based policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-resourcepolicy.html#cfn-smsvoice-resourcepolicy-resourcearn
     */
    readonly resourceArn?: string;
}
/**
 * Request a new sender ID that doesn't require registration.
 *
 * @cloudformationResource AWS::SMSVOICE::SenderId
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-senderid.html
 */
export declare class CfnSenderIdPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSenderIdMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SMSVOICE::SenderId`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSenderIdMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSenderId;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnSenderIdPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-senderid.html
 */
export interface CfnSenderIdMixinProps {
    /**
     * By default this is set to false.
     *
     * When set to true the sender ID can't be deleted.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-senderid.html#cfn-smsvoice-senderid-deletionprotectionenabled
     */
    readonly deletionProtectionEnabled?: boolean | cdk.IResolvable;
    /**
     * The two-character code, in ISO 3166-1 alpha-2 format, for the country or region.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-senderid.html#cfn-smsvoice-senderid-isocountrycode
     */
    readonly isoCountryCode?: string;
    /**
     * The sender ID string to request.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-senderid.html#cfn-smsvoice-senderid-senderid
     */
    readonly senderId?: string;
    /**
     * An array of tags (key and value pairs) to associate with the sender ID.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-smsvoice-senderid.html#cfn-smsvoice-senderid-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
