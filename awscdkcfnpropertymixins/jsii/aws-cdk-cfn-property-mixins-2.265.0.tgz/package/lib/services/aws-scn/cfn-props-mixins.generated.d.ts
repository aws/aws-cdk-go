import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-scn";
/**
 * Represents an AWS Supply Chain data lake dataset.
 *
 * @cloudformationResource AWS::SCN::Dataset
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html
 */
export declare class CfnDatasetPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDatasetMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SCN::Dataset`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDatasetMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDataset;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDatasetPropsMixin {
    /**
     * The schema of the dataset.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html
     */
    interface SchemaProperty {
        /**
         * The list of field details of the dataset schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html#cfn-scn-dataset-schema-fields
         */
        readonly fields?: Array<CfnDatasetPropsMixin.DataLakeDatasetSchemaFieldProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The name of the dataset schema.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html#cfn-scn-dataset-schema-name
         */
        readonly name?: string;
        /**
         * The list of primary key fields for the dataset.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-schema.html#cfn-scn-dataset-schema-primarykeys
         */
        readonly primaryKeys?: Array<CfnDatasetPropsMixin.DataLakeDatasetPrimaryKeyFieldProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The dataset field details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html
     */
    interface DataLakeDatasetSchemaFieldProperty {
        /**
         * Indicate if the field is required or not.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html#cfn-scn-dataset-datalakedatasetschemafield-isrequired
         */
        readonly isRequired?: boolean | cdk.IResolvable;
        /**
         * The dataset field name.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html#cfn-scn-dataset-datalakedatasetschemafield-name
         */
        readonly name?: string;
        /**
         * The dataset field type.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetschemafield.html#cfn-scn-dataset-datalakedatasetschemafield-type
         */
        readonly type?: string;
    }
    /**
     * The primary key field details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetprimarykeyfield.html
     */
    interface DataLakeDatasetPrimaryKeyFieldProperty {
        /**
         * The name of the primary key field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetprimarykeyfield.html#cfn-scn-dataset-datalakedatasetprimarykeyfield-name
         */
        readonly name?: string;
    }
    /**
     * The partition specification of the dataset.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-partitionspec.html
     */
    interface PartitionSpecProperty {
        /**
         * The partition fields.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-partitionspec.html#cfn-scn-dataset-partitionspec-fields
         */
        readonly fields?: Array<CfnDatasetPropsMixin.DataLakeDatasetPartitionFieldProperty | cdk.IResolvable> | cdk.IResolvable;
    }
    /**
     * The partition field details.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetpartitionfield.html
     */
    interface DataLakeDatasetPartitionFieldProperty {
        /**
         * The name of the partition field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetpartitionfield.html#cfn-scn-dataset-datalakedatasetpartitionfield-name
         */
        readonly name?: string;
        /**
         * The transformation of the partition field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-datalakedatasetpartitionfield.html#cfn-scn-dataset-datalakedatasetpartitionfield-transform
         */
        readonly transform?: cdk.IResolvable | CfnDatasetPropsMixin.TransformProperty;
    }
    /**
     * The transformation of the partition field.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-transform.html
     */
    interface TransformProperty {
        /**
         * The type of partitioning transformation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-scn-dataset-transform.html#cfn-scn-dataset-transform-type
         */
        readonly type?: string;
    }
}
/**
 * Properties for CfnDatasetPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html
 */
export interface CfnDatasetMixinProps {
    /**
     * The description of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-description
     */
    readonly description?: string;
    /**
     * The Amazon Web Services Supply Chain instance identifier.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-instanceid
     */
    readonly instanceId?: string;
    /**
     * The name of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-name
     */
    readonly name?: string;
    /**
     * The namespace of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-namespace
     */
    readonly namespace?: string;
    /**
     * The partition specification of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-partitionspec
     */
    readonly partitionSpec?: cdk.IResolvable | CfnDatasetPropsMixin.PartitionSpecProperty;
    /**
     * The schema of the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-schema
     */
    readonly schema?: cdk.IResolvable | CfnDatasetPropsMixin.SchemaProperty;
    /**
     * The tags for the dataset.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-dataset.html#cfn-scn-dataset-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Definition of AWS::SCN::Namespace Resource Type.
 *
 * @cloudformationResource AWS::SCN::Namespace
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html
 */
export declare class CfnNamespacePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnNamespaceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SCN::Namespace`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnNamespaceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnNamespace;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnNamespacePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html
 */
export interface CfnNamespaceMixinProps {
    /**
     * The description of the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-description
     */
    readonly description?: string;
    /**
     * The Amazon Web Services Supply Chain instance identifier.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-instanceid
     */
    readonly instanceId?: string;
    /**
     * The name of the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-name
     */
    readonly name?: string;
    /**
     * The tags for the namespace.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-scn-namespace.html#cfn-scn-namespace-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
