import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-billing";
/**
 * Creates a billing view with the specified billing view attributes.
 *
 * @cloudformationResource AWS::Billing::BillingView
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html
 */
export declare class CfnBillingViewPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnBillingViewMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Billing::BillingView`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnBillingViewMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnBillingView;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnBillingViewPropsMixin {
    /**
     * See [Expression](https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/API_billing_Expression.html) . Billing view only supports `LINKED_ACCOUNT` and `Tags` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-datafilterexpression.html
     */
    interface DataFilterExpressionProperty {
        /**
         * The specific `Dimension` to use for `Expression` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-datafilterexpression.html#cfn-billing-billingview-datafilterexpression-dimensions
         */
        readonly dimensions?: CfnBillingViewPropsMixin.DimensionsProperty | cdk.IResolvable;
        /**
         * The specific `Tag` to use for `Expression` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-datafilterexpression.html#cfn-billing-billingview-datafilterexpression-tags
         */
        readonly tags?: CfnBillingViewPropsMixin.TagsProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-datafilterexpression.html#cfn-billing-billingview-datafilterexpression-timerange
         */
        readonly timeRange?: cdk.IResolvable | CfnBillingViewPropsMixin.TimeRangeProperty;
    }
    /**
     * The specific `Dimension` to use for `Expression` .
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-dimensions.html
     */
    interface DimensionsProperty {
        /**
         * The key that's associated with the tag.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-dimensions.html#cfn-billing-billingview-dimensions-key
         */
        readonly key?: string;
        /**
         * The metadata that you can use to filter and group your results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-dimensions.html#cfn-billing-billingview-dimensions-values
         */
        readonly values?: Array<string>;
    }
    /**
     * Tags associated with the billing view resource.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-tags.html
     */
    interface TagsProperty {
        /**
         * A list of tag key value pairs that are associated with the resource.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-tags.html#cfn-billing-billingview-tags-key
         */
        readonly key?: string;
        /**
         * The metadata values that you can use to filter and group your results.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-tags.html#cfn-billing-billingview-tags-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-timerange.html
     */
    interface TimeRangeProperty {
        /**
         * The time in ISO 8601 format, UTC time (YYYY-MM-DDTHH:MM:SSZ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-timerange.html#cfn-billing-billingview-timerange-begindateinclusive
         */
        readonly beginDateInclusive?: string;
        /**
         * The time in ISO 8601 format, UTC time (YYYY-MM-DDTHH:MM:SSZ).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-billing-billingview-timerange.html#cfn-billing-billingview-timerange-enddateinclusive
         */
        readonly endDateInclusive?: string;
    }
}
/**
 * Properties for CfnBillingViewPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html
 */
export interface CfnBillingViewMixinProps {
    /**
     * See [Expression](https://docs.aws.amazon.com/aws-cost-management/latest/APIReference/API_billing_Expression.html) . Billing view only supports `LINKED_ACCOUNT` and `Tags` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html#cfn-billing-billingview-datafilterexpression
     */
    readonly dataFilterExpression?: CfnBillingViewPropsMixin.DataFilterExpressionProperty | cdk.IResolvable;
    /**
     * The description of the billing view.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html#cfn-billing-billingview-description
     */
    readonly description?: string;
    /**
     * The name of the billing view.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html#cfn-billing-billingview-name
     */
    readonly name?: string;
    /**
     * A list of billing views used as the data source for the custom billing view.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html#cfn-billing-billingview-sourceviews
     */
    readonly sourceViews?: Array<string>;
    /**
     * A list of key value map specifying tags associated to the billing view being created.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-billing-billingview.html#cfn-billing-billingview-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
