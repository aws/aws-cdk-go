import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-bcm";
/**
 * Definition of AWS::BCM::Dashboard Resource Type.
 *
 * @cloudformationResource AWS::BCM::Dashboard
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html
 */
export declare class CfnDashboardPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnDashboardMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::BCM::Dashboard`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnDashboardMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnDashboard;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnDashboardPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html
     */
    interface WidgetProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-configs
         */
        readonly configs?: Array<cdk.IResolvable | CfnDashboardPropsMixin.WidgetConfigProperty> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-description
         */
        readonly description?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-height
         */
        readonly height?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-horizontaloffset
         */
        readonly horizontalOffset?: number;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-title
         */
        readonly title?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widget.html#cfn-bcm-dashboard-widget-width
         */
        readonly width?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widgetconfig.html
     */
    interface WidgetConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widgetconfig.html#cfn-bcm-dashboard-widgetconfig-displayconfig
         */
        readonly displayConfig?: CfnDashboardPropsMixin.DisplayConfigProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-widgetconfig.html#cfn-bcm-dashboard-widgetconfig-queryparameters
         */
        readonly queryParameters?: cdk.IResolvable | CfnDashboardPropsMixin.QueryParametersProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html
     */
    interface QueryParametersProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-costandusage
         */
        readonly costAndUsage?: CfnDashboardPropsMixin.CostAndUsageQueryProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-reservationcoverage
         */
        readonly reservationCoverage?: cdk.IResolvable | CfnDashboardPropsMixin.ReservationCoverageQueryProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-reservationutilization
         */
        readonly reservationUtilization?: cdk.IResolvable | CfnDashboardPropsMixin.ReservationUtilizationQueryProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-savingsplanscoverage
         */
        readonly savingsPlansCoverage?: cdk.IResolvable | CfnDashboardPropsMixin.SavingsPlansCoverageQueryProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-queryparameters.html#cfn-bcm-dashboard-queryparameters-savingsplansutilization
         */
        readonly savingsPlansUtilization?: cdk.IResolvable | CfnDashboardPropsMixin.SavingsPlansUtilizationQueryProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html
     */
    interface CostAndUsageQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-metrics
         */
        readonly metrics?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusagequery.html#cfn-bcm-dashboard-costandusagequery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimerange.html
     */
    interface DateTimeRangeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimerange.html#cfn-bcm-dashboard-datetimerange-endtime
         */
        readonly endTime?: CfnDashboardPropsMixin.DateTimeValueProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimerange.html#cfn-bcm-dashboard-datetimerange-starttime
         */
        readonly startTime?: CfnDashboardPropsMixin.DateTimeValueProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimevalue.html
     */
    interface DateTimeValueProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimevalue.html#cfn-bcm-dashboard-datetimevalue-type
         */
        readonly type?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-datetimevalue.html#cfn-bcm-dashboard-datetimevalue-value
         */
        readonly value?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-groupdefinition.html
     */
    interface GroupDefinitionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-groupdefinition.html#cfn-bcm-dashboard-groupdefinition-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-groupdefinition.html#cfn-bcm-dashboard-groupdefinition-type
         */
        readonly type?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html
     */
    interface CostAndUsageExpressionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-and
         */
        readonly and?: Array<CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-costcategories
         */
        readonly costCategories?: CfnDashboardPropsMixin.CostCategoryValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-dimensions
         */
        readonly dimensions?: CfnDashboardPropsMixin.DimensionValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-not
         */
        readonly not?: CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-or
         */
        readonly or?: Array<CfnDashboardPropsMixin.CostAndUsageExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costandusageexpression.html#cfn-bcm-dashboard-costandusageexpression-tags
         */
        readonly tags?: CfnDashboardPropsMixin.TagValuesProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html
     */
    interface DimensionValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html#cfn-bcm-dashboard-dimensionvalues-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html#cfn-bcm-dashboard-dimensionvalues-matchoptions
         */
        readonly matchOptions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-dimensionvalues.html#cfn-bcm-dashboard-dimensionvalues-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html
     */
    interface TagValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html#cfn-bcm-dashboard-tagvalues-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html#cfn-bcm-dashboard-tagvalues-matchoptions
         */
        readonly matchOptions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-tagvalues.html#cfn-bcm-dashboard-tagvalues-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html
     */
    interface CostCategoryValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html#cfn-bcm-dashboard-costcategoryvalues-key
         */
        readonly key?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html#cfn-bcm-dashboard-costcategoryvalues-matchoptions
         */
        readonly matchOptions?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-costcategoryvalues.html#cfn-bcm-dashboard-costcategoryvalues-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html
     */
    interface SavingsPlansCoverageQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-metrics
         */
        readonly metrics?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplanscoveragequery.html#cfn-bcm-dashboard-savingsplanscoveragequery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html
     */
    interface ExpressionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-and
         */
        readonly and?: Array<CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-costcategories
         */
        readonly costCategories?: CfnDashboardPropsMixin.CostCategoryValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-dimensions
         */
        readonly dimensions?: CfnDashboardPropsMixin.DimensionValuesProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-not
         */
        readonly not?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-expression.html#cfn-bcm-dashboard-expression-tags
         */
        readonly tags?: CfnDashboardPropsMixin.TagValuesProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html
     */
    interface SavingsPlansUtilizationQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html#cfn-bcm-dashboard-savingsplansutilizationquery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html#cfn-bcm-dashboard-savingsplansutilizationquery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-savingsplansutilizationquery.html#cfn-bcm-dashboard-savingsplansutilizationquery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html
     */
    interface ReservationCoverageQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-metrics
         */
        readonly metrics?: Array<string>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationcoveragequery.html#cfn-bcm-dashboard-reservationcoveragequery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html
     */
    interface ReservationUtilizationQueryProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-filter
         */
        readonly filter?: CfnDashboardPropsMixin.ExpressionProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-granularity
         */
        readonly granularity?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-groupby
         */
        readonly groupBy?: Array<CfnDashboardPropsMixin.GroupDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-reservationutilizationquery.html#cfn-bcm-dashboard-reservationutilizationquery-timerange
         */
        readonly timeRange?: CfnDashboardPropsMixin.DateTimeRangeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-displayconfig.html
     */
    interface DisplayConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-displayconfig.html#cfn-bcm-dashboard-displayconfig-graph
         */
        readonly graph?: cdk.IResolvable | Record<string, CfnDashboardPropsMixin.GraphDisplayConfigProperty | cdk.IResolvable>;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-displayconfig.html#cfn-bcm-dashboard-displayconfig-table
         */
        readonly table?: any | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-graphdisplayconfig.html
     */
    interface GraphDisplayConfigProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-bcm-dashboard-graphdisplayconfig.html#cfn-bcm-dashboard-graphdisplayconfig-visualtype
         */
        readonly visualType?: string;
    }
}
/**
 * Properties for CfnDashboardPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html
 */
export interface CfnDashboardMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-description
     */
    readonly description?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-bcm-dashboard.html#cfn-bcm-dashboard-widgets
     */
    readonly widgets?: Array<cdk.IResolvable | CfnDashboardPropsMixin.WidgetProperty> | cdk.IResolvable;
}
