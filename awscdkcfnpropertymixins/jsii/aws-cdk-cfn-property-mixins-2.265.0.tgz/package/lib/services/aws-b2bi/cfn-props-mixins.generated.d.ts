import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-b2bi";
/**
 * Instantiates a capability based on the specified parameters.
 *
 * A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
 *
 * @cloudformationResource AWS::B2BI::Capability
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html
 */
export declare class CfnCapabilityPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCapabilityMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::B2BI::Capability`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCapabilityMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCapability;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCapabilityPropsMixin {
    /**
     * A capability object.
     *
     * Currently, only EDI (electronic data interchange) capabilities are supported. A trading capability contains the information required to transform incoming EDI documents into JSON or XML outputs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-capabilityconfiguration.html
     */
    interface CapabilityConfigurationProperty {
        /**
         * An EDI (electronic data interchange) configuration object.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-capabilityconfiguration.html#cfn-b2bi-capability-capabilityconfiguration-edi
         */
        readonly edi?: CfnCapabilityPropsMixin.EdiConfigurationProperty | cdk.IResolvable;
    }
    /**
     * Specifies the details for the EDI (electronic data interchange) transformation.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-ediconfiguration.html
     */
    interface EdiConfigurationProperty {
        /**
         * Specifies whether this is capability is for inbound or outbound transformations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-ediconfiguration.html#cfn-b2bi-capability-ediconfiguration-capabilitydirection
         */
        readonly capabilityDirection?: string;
        /**
         * Contains the Amazon S3 bucket and prefix for the location of the input file, which is contained in an `S3Location` object.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-ediconfiguration.html#cfn-b2bi-capability-ediconfiguration-inputlocation
         */
        readonly inputLocation?: cdk.IResolvable | CfnCapabilityPropsMixin.S3LocationProperty;
        /**
         * Contains the Amazon S3 bucket and prefix for the location of the output file, which is contained in an `S3Location` object.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-ediconfiguration.html#cfn-b2bi-capability-ediconfiguration-outputlocation
         */
        readonly outputLocation?: cdk.IResolvable | CfnCapabilityPropsMixin.S3LocationProperty;
        /**
         * Returns the system-assigned unique identifier for the transformer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-ediconfiguration.html#cfn-b2bi-capability-ediconfiguration-transformerid
         */
        readonly transformerId?: string;
        /**
         * Returns the type of the capability.
         *
         * Currently, only `edi` is supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-ediconfiguration.html#cfn-b2bi-capability-ediconfiguration-type
         */
        readonly type?: CfnCapabilityPropsMixin.EdiTypeProperty | cdk.IResolvable;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-editype.html
     */
    interface EdiTypeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-editype.html#cfn-b2bi-capability-editype-x12details
         */
        readonly x12Details?: cdk.IResolvable | CfnCapabilityPropsMixin.X12DetailsProperty;
    }
    /**
     * A structure that contains the X12 transaction set and version.
     *
     * The X12 structure is used when the system transforms an EDI (electronic data interchange) file.
     *
     * > If an EDI input file contains more than one transaction, each transaction must have the same transaction set and version, for example 214/4010. If not, the transformer cannot parse the file.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-x12details.html
     */
    interface X12DetailsProperty {
        /**
         * Returns an enumerated type where each value identifies an X12 transaction set.
         *
         * Transaction sets are maintained by the X12 Accredited Standards Committee.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-x12details.html#cfn-b2bi-capability-x12details-transactionset
         */
        readonly transactionSet?: string;
        /**
         * Returns the version to use for the specified X12 transaction set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-x12details.html#cfn-b2bi-capability-x12details-version
         */
        readonly version?: string;
    }
    /**
     * Specifies the details for the Amazon S3 file location that is being used with AWS B2B Data Interchange.
     *
     * File locations in Amazon S3 are identified using a combination of the bucket and key.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-s3location.html
     */
    interface S3LocationProperty {
        /**
         * Specifies the name of the Amazon S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-s3location.html#cfn-b2bi-capability-s3location-bucketname
         */
        readonly bucketName?: string;
        /**
         * Specifies the Amazon S3 key for the file location.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-capability-s3location.html#cfn-b2bi-capability-s3location-key
         */
        readonly key?: string;
    }
}
/**
 * Properties for CfnCapabilityPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html
 */
export interface CfnCapabilityMixinProps {
    /**
     * Specifies a structure that contains the details for a capability.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html#cfn-b2bi-capability-configuration
     */
    readonly configuration?: CfnCapabilityPropsMixin.CapabilityConfigurationProperty | cdk.IResolvable;
    /**
     * Specifies one or more locations in Amazon S3, each specifying an EDI document that can be used with this capability.
     *
     * Each item contains the name of the bucket and the key, to identify the document's location.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html#cfn-b2bi-capability-instructionsdocuments
     */
    readonly instructionsDocuments?: Array<cdk.IResolvable | CfnCapabilityPropsMixin.S3LocationProperty> | cdk.IResolvable;
    /**
     * The display name of the capability.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html#cfn-b2bi-capability-name
     */
    readonly name?: string;
    /**
     * Specifies the key-value pairs assigned to ARNs that you can use to group and search for resources by type.
     *
     * You can attach this metadata to resources (capabilities, partnerships, and so on) for any purpose.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html#cfn-b2bi-capability-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Returns the type of the capability.
     *
     * Currently, only `edi` is supported.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-capability.html#cfn-b2bi-capability-type
     */
    readonly type?: string;
}
/**
 * Creates a partnership between a customer and a trading partner, based on the supplied parameters.
 *
 * A partnership represents the connection between you and your trading partner. It ties together a profile and one or more trading capabilities.
 *
 * @cloudformationResource AWS::B2BI::Partnership
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html
 */
export declare class CfnPartnershipPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPartnershipMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::B2BI::Partnership`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPartnershipMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPartnership;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPartnershipPropsMixin {
    /**
     * Contains the details for an Outbound EDI capability.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-capabilityoptions.html
     */
    interface CapabilityOptionsProperty {
        /**
         * A structure that contains the inbound EDI options for the capability.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-capabilityoptions.html#cfn-b2bi-partnership-capabilityoptions-inboundedi
         */
        readonly inboundEdi?: CfnPartnershipPropsMixin.InboundEdiOptionsProperty | cdk.IResolvable;
        /**
         * A structure that contains the outbound EDI options.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-capabilityoptions.html#cfn-b2bi-partnership-capabilityoptions-outboundedi
         */
        readonly outboundEdi?: cdk.IResolvable | CfnPartnershipPropsMixin.OutboundEdiOptionsProperty;
    }
    /**
     * A container for outbound EDI options.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-outboundedioptions.html
     */
    interface OutboundEdiOptionsProperty {
        /**
         * A structure that contains an X12 envelope structure.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-outboundedioptions.html#cfn-b2bi-partnership-outboundedioptions-x12
         */
        readonly x12?: cdk.IResolvable | CfnPartnershipPropsMixin.X12EnvelopeProperty;
    }
    /**
     * A wrapper structure for an X12 definition object.
     *
     * the X12 envelope ensures the integrity of the data and the efficiency of the information exchange. The X12 message structure has hierarchical levels. From highest to the lowest, they are:
     *
     * - Interchange Envelope
     * - Functional Group
     * - Transaction Set
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12envelope.html
     */
    interface X12EnvelopeProperty {
        /**
         * A container for the X12 outbound EDI headers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12envelope.html#cfn-b2bi-partnership-x12envelope-common
         */
        readonly common?: cdk.IResolvable | CfnPartnershipPropsMixin.X12OutboundEdiHeadersProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12envelope.html#cfn-b2bi-partnership-x12envelope-wrapoptions
         */
        readonly wrapOptions?: cdk.IResolvable | CfnPartnershipPropsMixin.WrapOptionsProperty;
    }
    /**
     * A structure containing the details for an outbound EDI object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html
     */
    interface X12OutboundEdiHeadersProperty {
        /**
         * Specifies control number configuration for outbound X12 EDI headers.
         *
         * These settings determine the starting values for interchange, functional group, and transaction set control numbers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html#cfn-b2bi-partnership-x12outboundediheaders-controlnumbers
         */
        readonly controlNumbers?: cdk.IResolvable | CfnPartnershipPropsMixin.X12ControlNumbersProperty;
        /**
         * The delimiters, for example semicolon ( `;` ), that separates sections of the headers for the X12 object.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html#cfn-b2bi-partnership-x12outboundediheaders-delimiters
         */
        readonly delimiters?: cdk.IResolvable | CfnPartnershipPropsMixin.X12DelimitersProperty;
        /**
         * The functional group headers for the X12 object.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html#cfn-b2bi-partnership-x12outboundediheaders-functionalgroupheaders
         */
        readonly functionalGroupHeaders?: cdk.IResolvable | CfnPartnershipPropsMixin.X12FunctionalGroupHeadersProperty;
        /**
         * Specifies the time format in the GS05 element (time) of the functional group header.
         *
         * The following formats use 24-hour clock time:
         *
         * - `HHMM` - Hours and minutes
         * - `HHMMSS` - Hours, minutes, and seconds
         * - `HHMMSSDD` - Hours, minutes, seconds, and decimal seconds
         *
         * Where:
         *
         * - `HH` - Hours (00-23)
         * - `MM` - Minutes (00-59)
         * - `SS` - Seconds (00-59)
         * - `DD` - Hundredths of seconds (00-99)
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html#cfn-b2bi-partnership-x12outboundediheaders-gs05timeformat
         */
        readonly gs05TimeFormat?: string;
        /**
         * In X12 EDI messages, delimiters are used to mark the end of segments or elements, and are defined in the interchange control header.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html#cfn-b2bi-partnership-x12outboundediheaders-interchangecontrolheaders
         */
        readonly interchangeControlHeaders?: cdk.IResolvable | CfnPartnershipPropsMixin.X12InterchangeControlHeadersProperty;
        /**
         * Specifies whether or not to validate the EDI for this X12 object: `TRUE` or `FALSE` .
         *
         * When enabled, this performs both standard EDI validation and applies any configured custom validation rules including element length constraints, code list validations, and element requirement checks. Validation results are returned in the response validation messages.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12outboundediheaders.html#cfn-b2bi-partnership-x12outboundediheaders-validateedi
         */
        readonly validateEdi?: boolean | cdk.IResolvable;
    }
    /**
     * In X12, the Interchange Control Header is the first segment of an EDI document and is part of the Interchange Envelope.
     *
     * It contains information about the sender and receiver, the date and time of transmission, and the X12 version being used. It also includes delivery information, such as the sender and receiver IDs.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html
     */
    interface X12InterchangeControlHeadersProperty {
        /**
         * Located at position ISA-14 in the header.
         *
         * The value "1" indicates that the sender is requesting an interchange acknowledgment at receipt of the interchange. The value "0" is used otherwise.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-acknowledgmentrequestedcode
         */
        readonly acknowledgmentRequestedCode?: string;
        /**
         * Located at position ISA-08 in the header.
         *
         * This value (along with the `receiverIdQualifier` ) identifies the intended recipient of the interchange.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-receiverid
         */
        readonly receiverId?: string;
        /**
         * Located at position ISA-07 in the header.
         *
         * Qualifier for the receiver ID. Together, the ID and qualifier uniquely identify the receiving trading partner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-receiveridqualifier
         */
        readonly receiverIdQualifier?: string;
        /**
         * Located at position ISA-11 in the header.
         *
         * This string makes it easier when you need to group similar adjacent element values together without using extra segments.
         *
         * > This parameter is only honored for version greater than 401 ( `VERSION_4010` and higher).
         * >
         * > For versions less than 401, this field is called [StandardsId](https://docs.aws.amazon.com/https://www.stedi.com/edi/x12-004010/segment/ISA#ISA-11) , in which case our service sets the value to `U` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-repetitionseparator
         */
        readonly repetitionSeparator?: string;
        /**
         * Located at position ISA-06 in the header.
         *
         * This value (along with the `senderIdQualifier` ) identifies the sender of the interchange.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-senderid
         */
        readonly senderId?: string;
        /**
         * Located at position ISA-05 in the header.
         *
         * Qualifier for the sender ID. Together, the ID and qualifier uniquely identify the sending trading partner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-senderidqualifier
         */
        readonly senderIdQualifier?: string;
        /**
         * Located at position ISA-15 in the header. Specifies how this interchange is being used:.
         *
         * - `T` indicates this interchange is for testing.
         * - `P` indicates this interchange is for production.
         * - `I` indicates this interchange is informational.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12interchangecontrolheaders.html#cfn-b2bi-partnership-x12interchangecontrolheaders-usageindicatorcode
         */
        readonly usageIndicatorCode?: string;
    }
    /**
     * Part of the X12 message structure.
     *
     * These are the functional group headers for the X12 EDI object.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12functionalgroupheaders.html
     */
    interface X12FunctionalGroupHeadersProperty {
        /**
         * A value representing the code used to identify the party receiving a message, at position GS-03.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12functionalgroupheaders.html#cfn-b2bi-partnership-x12functionalgroupheaders-applicationreceivercode
         */
        readonly applicationReceiverCode?: string;
        /**
         * A value representing the code used to identify the party transmitting a message, at position GS-02.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12functionalgroupheaders.html#cfn-b2bi-partnership-x12functionalgroupheaders-applicationsendercode
         */
        readonly applicationSenderCode?: string;
        /**
         * A code that identifies the issuer of the standard, at position GS-07.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12functionalgroupheaders.html#cfn-b2bi-partnership-x12functionalgroupheaders-responsibleagencycode
         */
        readonly responsibleAgencyCode?: string;
    }
    /**
     * In X12 EDI messages, delimiters are used to mark the end of segments or elements, and are defined in the interchange control header.
     *
     * The delimiters are part of the message's syntax and divide up its different elements.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12delimiters.html
     */
    interface X12DelimitersProperty {
        /**
         * The component, or sub-element, separator.
         *
         * The default value is `:` (colon).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12delimiters.html#cfn-b2bi-partnership-x12delimiters-componentseparator
         */
        readonly componentSeparator?: string;
        /**
         * The data element separator.
         *
         * The default value is `*` (asterisk).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12delimiters.html#cfn-b2bi-partnership-x12delimiters-dataelementseparator
         */
        readonly dataElementSeparator?: string;
        /**
         * The segment terminator.
         *
         * The default value is `~` (tilde).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12delimiters.html#cfn-b2bi-partnership-x12delimiters-segmentterminator
         */
        readonly segmentTerminator?: string;
    }
    /**
     * Contains configuration for X12 control numbers used in X12 EDI generation.
     *
     * Control numbers are used to uniquely identify interchanges, functional groups, and transaction sets.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12controlnumbers.html
     */
    interface X12ControlNumbersProperty {
        /**
         * Specifies the starting functional group control number (GS06) to use for X12 EDI generation.
         *
         * This number is incremented for each new functional group. For the GS (functional group) envelope, AWS B2B Data Interchange generates a functional group control number that is unique to the sender ID, receiver ID, and functional identifier code combination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12controlnumbers.html#cfn-b2bi-partnership-x12controlnumbers-startingfunctionalgroupcontrolnumber
         */
        readonly startingFunctionalGroupControlNumber?: number;
        /**
         * Specifies the starting interchange control number (ISA13) to use for X12 EDI generation.
         *
         * This number is incremented for each new interchange. For the ISA (interchange) envelope, AWS B2B Data Interchange generates an interchange control number that is unique for the ISA05 and ISA06 (sender) & ISA07 and ISA08 (receiver) combination.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12controlnumbers.html#cfn-b2bi-partnership-x12controlnumbers-startinginterchangecontrolnumber
         */
        readonly startingInterchangeControlNumber?: number;
        /**
         * Specifies the starting transaction set control number (ST02) to use for X12 EDI generation.
         *
         * This number is incremented for each new transaction set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12controlnumbers.html#cfn-b2bi-partnership-x12controlnumbers-startingtransactionsetcontrolnumber
         */
        readonly startingTransactionSetControlNumber?: number;
    }
    /**
     * Contains options for wrapping (line folding) in X12 EDI files.
     *
     * Wrapping controls how long lines are handled in the EDI output.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-wrapoptions.html
     */
    interface WrapOptionsProperty {
        /**
         * Specifies the maximum length of a line before wrapping occurs.
         *
         * This value is used when `wrapBy` is set to `LINE_LENGTH` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-wrapoptions.html#cfn-b2bi-partnership-wrapoptions-linelength
         */
        readonly lineLength?: number;
        /**
         * Specifies the character sequence used to terminate lines when wrapping. Valid values:.
         *
         * - `CRLF` : carriage return and line feed
         * - `LF` : line feed)
         * - `CR` : carriage return
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-wrapoptions.html#cfn-b2bi-partnership-wrapoptions-lineterminator
         */
        readonly lineTerminator?: string;
        /**
         * Specifies the method used for wrapping lines in the EDI output. Valid values:.
         *
         * - `SEGMENT` : Wraps by segment.
         * - `ONE_LINE` : Indicates that the entire content is on a single line.
         *
         * > When you specify `ONE_LINE` , do not provide either the line length nor the line terminator value.
         * - `LINE_LENGTH` : Wraps by character count, as specified by `lineLength` value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-wrapoptions.html#cfn-b2bi-partnership-wrapoptions-wrapby
         */
        readonly wrapBy?: string;
    }
    /**
     * Contains options for processing inbound EDI files.
     *
     * These options allow for customizing how incoming EDI documents are processed.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-inboundedioptions.html
     */
    interface InboundEdiOptionsProperty {
        /**
         * A structure that contains X12-specific options for processing inbound X12 EDI files.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-inboundedioptions.html#cfn-b2bi-partnership-inboundedioptions-x12
         */
        readonly x12?: cdk.IResolvable | CfnPartnershipPropsMixin.X12InboundEdiOptionsProperty;
    }
    /**
     * Contains options specific to processing inbound X12 EDI files.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12inboundedioptions.html
     */
    interface X12InboundEdiOptionsProperty {
        /**
         * Specifies acknowledgment options for inbound X12 EDI files.
         *
         * These options control how functional and technical acknowledgments are handled.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12inboundedioptions.html#cfn-b2bi-partnership-x12inboundedioptions-acknowledgmentoptions
         */
        readonly acknowledgmentOptions?: cdk.IResolvable | CfnPartnershipPropsMixin.X12AcknowledgmentOptionsProperty;
    }
    /**
     * Contains options for configuring X12 acknowledgments.
     *
     * These options control how functional and technical acknowledgments are handled.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12acknowledgmentoptions.html
     */
    interface X12AcknowledgmentOptionsProperty {
        /**
         * Specifies whether functional acknowledgments (997/999) should be generated for incoming X12 transactions.
         *
         * Valid values are `DO_NOT_GENERATE` , `GENERATE_ALL_SEGMENTS` and `GENERATE_WITHOUT_TRANSACTION_SET_RESPONSE_LOOP` .
         *
         * If you choose `GENERATE_WITHOUT_TRANSACTION_SET_RESPONSE_LOOP` , AWS B2B Data Interchange skips the AK2_Loop when generating an acknowledgment document.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12acknowledgmentoptions.html#cfn-b2bi-partnership-x12acknowledgmentoptions-functionalacknowledgment
         */
        readonly functionalAcknowledgment?: string;
        /**
         * Specifies whether technical acknowledgments (TA1) should be generated for incoming X12 interchanges.
         *
         * Valid values are `DO_NOT_GENERATE` and `GENERATE_ALL_SEGMENTS` and.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-partnership-x12acknowledgmentoptions.html#cfn-b2bi-partnership-x12acknowledgmentoptions-technicalacknowledgment
         */
        readonly technicalAcknowledgment?: string;
    }
}
/**
 * Properties for CfnPartnershipPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html
 */
export interface CfnPartnershipMixinProps {
    /**
     * Returns one or more capabilities associated with this partnership.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-capabilities
     */
    readonly capabilities?: Array<string>;
    /**
     * Contains the details for an Outbound EDI capability.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-capabilityoptions
     */
    readonly capabilityOptions?: CfnPartnershipPropsMixin.CapabilityOptionsProperty | cdk.IResolvable;
    /**
     * Specifies the email address associated with this trading partner.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-email
     */
    readonly email?: string;
    /**
     * Returns the name of the partnership.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-name
     */
    readonly name?: string;
    /**
     * Specifies the phone number associated with the partnership.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-phone
     */
    readonly phone?: string;
    /**
     * Returns the unique, system-generated identifier for the profile connected to this partnership.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-profileid
     */
    readonly profileId?: string;
    /**
     * A key-value pair for a specific partnership.
     *
     * Tags are metadata that you can use to search for and group capabilities for various purposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-partnership.html#cfn-b2bi-partnership-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a customer profile.
 *
 * You can have up to five customer profiles, each representing a distinct private network. A profile is the mechanism used to create the concept of a private network.
 *
 * @cloudformationResource AWS::B2BI::Profile
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html
 */
export declare class CfnProfilePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnProfileMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::B2BI::Profile`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnProfileMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnProfile;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnProfilePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html
 */
export interface CfnProfileMixinProps {
    /**
     * Returns the name for the business associated with this profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html#cfn-b2bi-profile-businessname
     */
    readonly businessName?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html#cfn-b2bi-profile-email
     */
    readonly email?: string;
    /**
     * Specifies whether or not logging is enabled for this profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html#cfn-b2bi-profile-logging
     */
    readonly logging?: string;
    /**
     * Returns the display name for profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html#cfn-b2bi-profile-name
     */
    readonly name?: string;
    /**
     * Specifies the phone number associated with the profile.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html#cfn-b2bi-profile-phone
     */
    readonly phone?: string;
    /**
     * A key-value pair for a specific profile.
     *
     * Tags are metadata that you can use to search for and group capabilities for various purposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-profile.html#cfn-b2bi-profile-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a transformer. AWS B2B Data Interchange currently supports two scenarios:.
 *
 * - *Inbound EDI* : the AWS customer receives an EDI file from their trading partner. AWS B2B Data Interchange converts this EDI file into a JSON or XML file with a service-defined structure. A mapping template provided by the customer, in JSONata or XSLT format, is optionally applied to this file to produce a JSON or XML file with the structure the customer requires.
 * - *Outbound EDI* : the AWS customer has a JSON or XML file containing data that they wish to use in an EDI file. A mapping template, provided by the customer (in either JSONata or XSLT format) is applied to this file to generate a JSON or XML file in the service-defined structure. This file is then converted to an EDI file.
 *
 * > The following fields are provided for backwards compatibility only: `fileFormat` , `mappingTemplate` , `ediType` , and `sampleDocument` .
 * >
 * > - Use the `mapping` data type in place of `mappingTemplate` and `fileFormat`
 * > - Use the `sampleDocuments` data type in place of `sampleDocument`
 * > - Use either the `inputConversion` or `outputConversion` in place of `ediType`
 *
 * @cloudformationResource AWS::B2BI::Transformer
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html
 */
export declare class CfnTransformerPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnTransformerMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::B2BI::Transformer`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnTransformerMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnTransformer;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnTransformerPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-editype.html
     */
    interface EdiTypeProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-editype.html#cfn-b2bi-transformer-editype-x12details
         */
        readonly x12Details?: cdk.IResolvable | CfnTransformerPropsMixin.X12DetailsProperty;
    }
    /**
     * A structure that contains the X12 transaction set and version.
     *
     * The X12 structure is used when the system transforms an EDI (electronic data interchange) file.
     *
     * > If an EDI input file contains more than one transaction, each transaction must have the same transaction set and version, for example 214/4010. If not, the transformer cannot parse the file.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12details.html
     */
    interface X12DetailsProperty {
        /**
         * Returns an enumerated type where each value identifies an X12 transaction set.
         *
         * Transaction sets are maintained by the X12 Accredited Standards Committee.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12details.html#cfn-b2bi-transformer-x12details-transactionset
         */
        readonly transactionSet?: string;
        /**
         * Returns the version to use for the specified X12 transaction set.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12details.html#cfn-b2bi-transformer-x12details-version
         */
        readonly version?: string;
    }
    /**
     * Contains the input formatting options for an inbound transformer (takes an X12-formatted EDI document as input and converts it to JSON or XML.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-inputconversion.html
     */
    interface InputConversionProperty {
        /**
         * Specifies advanced options for the input conversion process.
         *
         * These options provide additional control over how EDI files are processed during transformation.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-inputconversion.html#cfn-b2bi-transformer-inputconversion-advancedoptions
         */
        readonly advancedOptions?: CfnTransformerPropsMixin.AdvancedOptionsProperty | cdk.IResolvable;
        /**
         * A structure that contains the formatting options for an inbound transformer.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-inputconversion.html#cfn-b2bi-transformer-inputconversion-formatoptions
         */
        readonly formatOptions?: CfnTransformerPropsMixin.FormatOptionsProperty | cdk.IResolvable;
        /**
         * The format for the transformer input: currently on `X12` is supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-inputconversion.html#cfn-b2bi-transformer-inputconversion-fromformat
         */
        readonly fromFormat?: string;
    }
    /**
     * A structure that contains the X12 transaction set and version.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-formatoptions.html
     */
    interface FormatOptionsProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-formatoptions.html#cfn-b2bi-transformer-formatoptions-x12
         */
        readonly x12?: cdk.IResolvable | CfnTransformerPropsMixin.X12DetailsProperty;
    }
    /**
     * A structure that contains advanced options for EDI processing.
     *
     * Currently, only X12 advanced options are supported.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-advancedoptions.html
     */
    interface AdvancedOptionsProperty {
        /**
         * A structure that contains X12-specific advanced options, such as split options for processing X12 EDI files.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-advancedoptions.html#cfn-b2bi-transformer-advancedoptions-x12
         */
        readonly x12?: cdk.IResolvable | CfnTransformerPropsMixin.X12AdvancedOptionsProperty;
    }
    /**
     * Contains advanced options specific to X12 EDI processing, such as splitting large X12 files into smaller units.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12advancedoptions.html
     */
    interface X12AdvancedOptionsProperty {
        /**
         * Specifies options for splitting X12 EDI files.
         *
         * These options control how large X12 files are divided into smaller, more manageable units.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12advancedoptions.html#cfn-b2bi-transformer-x12advancedoptions-splitoptions
         */
        readonly splitOptions?: cdk.IResolvable | CfnTransformerPropsMixin.X12SplitOptionsProperty;
        /**
         * Specifies validation options for X12 EDI processing.
         *
         * These options control how validation rules are applied during EDI document processing, including custom validation rules for element length constraints, code list validations, and element requirement checks.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12advancedoptions.html#cfn-b2bi-transformer-x12advancedoptions-validationoptions
         */
        readonly validationOptions?: cdk.IResolvable | CfnTransformerPropsMixin.X12ValidationOptionsProperty;
    }
    /**
     * Contains options for splitting X12 EDI files into smaller units.
     *
     * This is useful for processing large EDI files more efficiently.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12splitoptions.html
     */
    interface X12SplitOptionsProperty {
        /**
         * Specifies the method used to split X12 EDI files.
         *
         * Valid values include `TRANSACTION` (split by individual transaction sets), or `NONE` (no splitting).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12splitoptions.html#cfn-b2bi-transformer-x12splitoptions-splitby
         */
        readonly splitBy?: string;
    }
    /**
     * Contains configuration options for X12 EDI validation.
     *
     * This structure allows you to specify custom validation rules that will be applied during EDI document processing, including element length constraints, code list modifications, and element requirement changes. These validation options provide flexibility to accommodate trading partner-specific requirements while maintaining EDI compliance. The validation rules are applied in addition to standard X12 validation to ensure documents meet both standard and custom requirements.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12validationoptions.html
     */
    interface X12ValidationOptionsProperty {
        /**
         * Specifies a list of validation rules to apply during EDI document processing.
         *
         * These rules can include code list modifications, element length constraints, and element requirement changes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12validationoptions.html#cfn-b2bi-transformer-x12validationoptions-validationrules
         */
        readonly validationRules?: Array<cdk.IResolvable | CfnTransformerPropsMixin.X12ValidationRuleProperty> | cdk.IResolvable;
    }
    /**
     * Represents a single validation rule that can be applied during X12 EDI processing.
     *
     * This is a union type that can contain one of several specific validation rule types: code list validation rules for modifying allowed element codes, element length validation rules for enforcing custom length constraints, or element requirement validation rules for changing mandatory/optional status. Each validation rule targets specific aspects of EDI document validation to ensure compliance with trading partner requirements and business rules.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12validationrule.html
     */
    interface X12ValidationRuleProperty {
        /**
         * Specifies a code list validation rule that modifies the allowed code values for a specific X12 element.
         *
         * This rule enables you to customize which codes are considered valid for an element, allowing for trading partner-specific code requirements.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12validationrule.html#cfn-b2bi-transformer-x12validationrule-codelistvalidationrule
         */
        readonly codeListValidationRule?: cdk.IResolvable | CfnTransformerPropsMixin.X12CodeListValidationRuleProperty;
        /**
         * Specifies an element length validation rule that defines custom length constraints for a specific X12 element.
         *
         * This rule allows you to enforce minimum and maximum length requirements that may differ from the standard X12 specification.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12validationrule.html#cfn-b2bi-transformer-x12validationrule-elementlengthvalidationrule
         */
        readonly elementLengthValidationRule?: cdk.IResolvable | CfnTransformerPropsMixin.X12ElementLengthValidationRuleProperty;
        /**
         * Specifies an element requirement validation rule that modifies whether a specific X12 element is required or optional within a segment.
         *
         * This rule provides flexibility to accommodate different trading partner requirements for element presence.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12validationrule.html#cfn-b2bi-transformer-x12validationrule-elementrequirementvalidationrule
         */
        readonly elementRequirementValidationRule?: cdk.IResolvable | CfnTransformerPropsMixin.X12ElementRequirementValidationRuleProperty;
    }
    /**
     * Code list validation rule configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12codelistvalidationrule.html
     */
    interface X12CodeListValidationRuleProperty {
        /**
         * Specifies a list of code values to add to the element's allowed values.
         *
         * These codes will be considered valid for the specified element in addition to the standard codes defined by the X12 specification.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12codelistvalidationrule.html#cfn-b2bi-transformer-x12codelistvalidationrule-codestoadd
         */
        readonly codesToAdd?: Array<string>;
        /**
         * Specifies a list of code values to remove from the element's allowed values.
         *
         * These codes will be considered invalid for the specified element, even if they are part of the standard codes defined by the X12 specification.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12codelistvalidationrule.html#cfn-b2bi-transformer-x12codelistvalidationrule-codestoremove
         */
        readonly codesToRemove?: Array<string>;
        /**
         * Specifies the four-digit element ID to which the code list modifications apply.
         *
         * This identifies which X12 element will have its allowed code values modified.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12codelistvalidationrule.html#cfn-b2bi-transformer-x12codelistvalidationrule-elementid
         */
        readonly elementId?: string;
    }
    /**
     * Defines a validation rule that specifies custom length constraints for a specific X12 element.
     *
     * This rule allows you to override the standard minimum and maximum length requirements for an element, enabling validation of trading partner-specific length requirements that may differ from the X12 specification. Both minimum and maximum length values must be specified.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementlengthvalidationrule.html
     */
    interface X12ElementLengthValidationRuleProperty {
        /**
         * Specifies the four-digit element ID to which the length constraints will be applied.
         *
         * This identifies which X12 element will have its length requirements modified.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementlengthvalidationrule.html#cfn-b2bi-transformer-x12elementlengthvalidationrule-elementid
         */
        readonly elementId?: string;
        /**
         * Specifies the maximum allowed length for the identified element.
         *
         * This value defines the upper limit for the element's content length.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementlengthvalidationrule.html#cfn-b2bi-transformer-x12elementlengthvalidationrule-maxlength
         */
        readonly maxLength?: number;
        /**
         * Specifies the minimum required length for the identified element.
         *
         * This value defines the lower limit for the element's content length.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementlengthvalidationrule.html#cfn-b2bi-transformer-x12elementlengthvalidationrule-minlength
         */
        readonly minLength?: number;
    }
    /**
     * Defines a validation rule that modifies the requirement status of a specific X12 element within a segment.
     *
     * This rule allows you to make optional elements mandatory or mandatory elements optional, providing flexibility to accommodate different trading partner requirements and business rules. The rule targets a specific element position within a segment and sets its requirement status to either OPTIONAL or MANDATORY.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementrequirementvalidationrule.html
     */
    interface X12ElementRequirementValidationRuleProperty {
        /**
         * Specifies the position of the element within an X12 segment for which the requirement status will be modified.
         *
         * The format follows the pattern of segment identifier followed by element position (e.g., "ST-01" for the first element of the ST segment).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementrequirementvalidationrule.html#cfn-b2bi-transformer-x12elementrequirementvalidationrule-elementposition
         */
        readonly elementPosition?: string;
        /**
         * Specifies the requirement status for the element at the specified position.
         *
         * Valid values are OPTIONAL (the element may be omitted) or MANDATORY (the element must be present).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-x12elementrequirementvalidationrule.html#cfn-b2bi-transformer-x12elementrequirementvalidationrule-requirement
         */
        readonly requirement?: string;
    }
    /**
     * Specifies the mapping template for the transformer.
     *
     * This template is used to map the parsed EDI file using JSONata or XSLT.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-mapping.html
     */
    interface MappingProperty {
        /**
         * A string that represents the mapping template, in the transformation language specified in `templateLanguage` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-mapping.html#cfn-b2bi-transformer-mapping-template
         */
        readonly template?: string;
        /**
         * The transformation language for the template, either XSLT or JSONATA.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-mapping.html#cfn-b2bi-transformer-mapping-templatelanguage
         */
        readonly templateLanguage?: string;
    }
    /**
     * Contains the formatting options for an outbound transformer (takes JSON or XML as input and converts it to an EDI document (currently only X12 format is supported).
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-outputconversion.html
     */
    interface OutputConversionProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-outputconversion.html#cfn-b2bi-transformer-outputconversion-advancedoptions
         */
        readonly advancedOptions?: CfnTransformerPropsMixin.AdvancedOptionsProperty | cdk.IResolvable;
        /**
         * A structure that contains the X12 transaction set and version for the transformer output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-outputconversion.html#cfn-b2bi-transformer-outputconversion-formatoptions
         */
        readonly formatOptions?: CfnTransformerPropsMixin.FormatOptionsProperty | cdk.IResolvable;
        /**
         * The format for the output from an outbound transformer: only X12 is currently supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-outputconversion.html#cfn-b2bi-transformer-outputconversion-toformat
         */
        readonly toFormat?: string;
    }
    /**
     * Describes a structure that contains the Amazon S3 bucket and an array of the corresponding keys used to identify the location for your sample documents.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-sampledocuments.html
     */
    interface SampleDocumentsProperty {
        /**
         * Contains the Amazon S3 bucket that is used to hold your sample documents.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-sampledocuments.html#cfn-b2bi-transformer-sampledocuments-bucketname
         */
        readonly bucketName?: string;
        /**
         * Contains an array of the Amazon S3 keys used to identify the location for your sample documents.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-sampledocuments.html#cfn-b2bi-transformer-sampledocuments-keys
         */
        readonly keys?: Array<cdk.IResolvable | CfnTransformerPropsMixin.SampleDocumentKeysProperty> | cdk.IResolvable;
    }
    /**
     * An array of the Amazon S3 keys used to identify the location for your sample documents.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-sampledocumentkeys.html
     */
    interface SampleDocumentKeysProperty {
        /**
         * An array of keys for your input sample documents.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-sampledocumentkeys.html#cfn-b2bi-transformer-sampledocumentkeys-input
         */
        readonly input?: string;
        /**
         * An array of keys for your output sample documents.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-b2bi-transformer-sampledocumentkeys.html#cfn-b2bi-transformer-sampledocumentkeys-output
         */
        readonly output?: string;
    }
}
/**
 * Properties for CfnTransformerPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html
 */
export interface CfnTransformerMixinProps {
    /**
     * @deprecated this property has been deprecated
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-editype
     */
    readonly ediType?: CfnTransformerPropsMixin.EdiTypeProperty | cdk.IResolvable;
    /**
     * @deprecated this property has been deprecated
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-fileformat
     */
    readonly fileFormat?: string;
    /**
     * Returns a structure that contains the format options for the transformation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-inputconversion
     */
    readonly inputConversion?: CfnTransformerPropsMixin.InputConversionProperty | cdk.IResolvable;
    /**
     * Returns the structure that contains the mapping template and its language (either XSLT or JSONATA).
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-mapping
     */
    readonly mapping?: cdk.IResolvable | CfnTransformerPropsMixin.MappingProperty;
    /**
     * This shape is deprecated: This is a legacy trait.
     *
     * Please use input-conversion or output-conversion.
     *
     * @deprecated this property has been deprecated
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-mappingtemplate
     */
    readonly mappingTemplate?: string;
    /**
     * Returns the descriptive name for the transformer.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-name
     */
    readonly name?: string;
    /**
     * Returns the `OutputConversion` object, which contains the format options for the outbound transformation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-outputconversion
     */
    readonly outputConversion?: cdk.IResolvable | CfnTransformerPropsMixin.OutputConversionProperty;
    /**
     * This shape is deprecated: This is a legacy trait.
     *
     * Please use input-conversion or output-conversion.
     *
     * @deprecated this property has been deprecated
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-sampledocument
     */
    readonly sampleDocument?: string;
    /**
     * Returns a structure that contains the Amazon S3 bucket and an array of the corresponding keys used to identify the location for your sample documents.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-sampledocuments
     */
    readonly sampleDocuments?: cdk.IResolvable | CfnTransformerPropsMixin.SampleDocumentsProperty;
    /**
     * Returns the state of the newly created transformer.
     *
     * The transformer can be either `active` or `inactive` . For the transformer to be used in a capability, its status must `active` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-status
     */
    readonly status?: string;
    /**
     * A key-value pair for a specific transformer.
     *
     * Tags are metadata that you can use to search for and group capabilities for various purposes.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-b2bi-transformer.html#cfn-b2bi-transformer-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
