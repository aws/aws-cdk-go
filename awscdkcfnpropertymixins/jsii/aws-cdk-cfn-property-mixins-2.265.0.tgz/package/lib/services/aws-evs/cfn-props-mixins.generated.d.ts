import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-evs";
/**
 * Creates an Amazon EVS environment that runs VCF software, such as SDDC Manager, NSX Manager, and vCenter Server.
 *
 * During environment creation, Amazon EVS performs validations on DNS settings, provisions VLAN subnets and hosts, and deploys the supplied version of VCF.
 *
 * It can take several hours to create an environment. After the deployment completes, you can configure VCF in the vSphere user interface according to your needs.
 *
 * > You cannot use the `dedicatedHostId` and `placementGroupId` parameters together in the same `CreateEnvironment` action. This results in a `ValidationException` response.
 *
 * @cloudformationResource AWS::EVS::Environment
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html
 */
export declare class CfnEnvironmentPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnEnvironmentMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::EVS::Environment`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnEnvironmentMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnEnvironment;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnEnvironmentPropsMixin {
    /**
     * The license information that Amazon EVS requires to create an environment.
     *
     * Amazon EVS requires two license keys: a VCF solution key and a vSAN license key.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-licenseinfo.html
     */
    interface LicenseInfoProperty {
        /**
         * The VCF solution key.
         *
         * This license unlocks VMware VCF product features, including vSphere, NSX, SDDC Manager, and vCenter Server. The VCF solution key must cover a minimum of 256 cores.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-licenseinfo.html#cfn-evs-environment-licenseinfo-solutionkey
         */
        readonly solutionKey?: string;
        /**
         * The VSAN license key.
         *
         * This license unlocks vSAN features. The vSAN license key must provide at least 110 TiB of vSAN capacity.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-licenseinfo.html#cfn-evs-environment-licenseinfo-vsankey
         */
        readonly vsanKey?: string;
    }
    /**
     * The initial VLAN subnets for the environment.
     *
     * Amazon EVS VLAN subnets have a minimum CIDR block size of /28 and a maximum size of /24. Amazon EVS VLAN subnet CIDR blocks must not overlap with other subnets in the VPC.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html
     */
    interface InitialVlansProperty {
        /**
         * The edge VTEP VLAN subnet.
         *
         * This VLAN subnet manages traffic flowing between the internal network and external networks, including internet access and other site connections.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-edgevtep
         */
        readonly edgeVTep?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * An additional VLAN subnet that can be used to extend VCF capabilities once configured.
         *
         * For example, you can configure an expansion VLAN subnet to use NSX Federation for centralized management and synchronization of multiple NSX deployments across different locations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-expansionvlan1
         */
        readonly expansionVlan1?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * An additional VLAN subnet that can be used to extend VCF capabilities once configured.
         *
         * For example, you can configure an expansion VLAN subnet to use NSX Federation for centralized management and synchronization of multiple NSX deployments across different locations.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-expansionvlan2
         */
        readonly expansionVlan2?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * The HCX VLAN subnet.
         *
         * This VLAN subnet allows the HCX Interconnnect (IX) and HCX Network Extension (NE) to reach their peers and enable HCX Service Mesh creation.
         *
         * If you plan to use a public HCX VLAN subnet, the following requirements must be met:
         *
         * - Must have a /28 netmask and be allocated from the IPAM public pool. Required for HCX internet access configuration.
         * - The HCX public VLAN CIDR block must be added to the VPC as a secondary CIDR block.
         * - Must have at least two Elastic IP addresses to be allocated from the public IPAM pool for HCX components.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-hcx
         */
        readonly hcx?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * A unique ID for a network access control list that the HCX VLAN uses.
         *
         * Required when `isHcxPublic` is set to `true` .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-hcxnetworkaclid
         */
        readonly hcxNetworkAclId?: string;
        /**
         * Determines if the HCX VLAN that Amazon EVS provisions is public or private.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-ishcxpublic
         */
        readonly isHcxPublic?: boolean | cdk.IResolvable;
        /**
         * The NSX uplink VLAN subnet.
         *
         * This VLAN subnet allows connectivity to the NSX overlay network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-nsxuplink
         */
        readonly nsxUpLink?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * The host VMkernel management VLAN subnet.
         *
         * This VLAN subnet carries traffic for managing ESXi hosts and communicating with VMware vCenter Server.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-vmkmanagement
         */
        readonly vmkManagement?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * The VM management VLAN subnet.
         *
         * This VLAN subnet carries traffic for vSphere virtual machines.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-vmmanagement
         */
        readonly vmManagement?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * The vMotion VLAN subnet.
         *
         * This VLAN subnet carries traffic for vSphere vMotion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-vmotion
         */
        readonly vMotion?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * The vSAN VLAN subnet.
         *
         * This VLAN subnet carries the communication between ESXi hosts to implement a vSAN shared storage pool.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-vsan
         */
        readonly vSan?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
        /**
         * The VTEP VLAN subnet.
         *
         * This VLAN subnet handles internal network traffic between virtual machines within a VCF instance.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlans.html#cfn-evs-environment-initialvlans-vtep
         */
        readonly vTep?: CfnEnvironmentPropsMixin.InitialVlanInfoProperty | cdk.IResolvable;
    }
    /**
     * An object that represents an initial VLAN subnet for the Amazon EVS environment.
     *
     * Amazon EVS creates initial VLAN subnets when you first create the environment. Amazon EVS creates the following 10 VLAN subnets: host management VLAN, vMotion VLAN, vSAN VLAN, VTEP VLAN, Edge VTEP VLAN, Management VM VLAN, HCX uplink VLAN, NSX uplink VLAN, expansion VLAN 1, expansion VLAN 2.
     *
     * > For each Amazon EVS VLAN subnet, you must specify a non-overlapping CIDR block. Amazon EVS VLAN subnets have a minimum CIDR block size of /28 and a maximum size of /24.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlaninfo.html
     */
    interface InitialVlanInfoProperty {
        /**
         * The CIDR block that you provide to create an Amazon EVS VLAN subnet.
         *
         * Amazon EVS VLAN subnets have a minimum CIDR block size of /28 and a maximum size of /24. Amazon EVS VLAN subnet CIDR blocks must not overlap with other subnets in the VPC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-initialvlaninfo.html#cfn-evs-environment-initialvlaninfo-cidr
         */
        readonly cidr?: string;
    }
    /**
     * An object that represents a host.
     *
     * > You cannot use `dedicatedHostId` and `placementGroupId` together in the same `HostInfoForCreate` object. This results in a `ValidationException` response.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-hostinfoforcreate.html
     */
    interface HostInfoForCreateProperty {
        /**
         * The unique ID of the Amazon EC2 Dedicated Host.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-hostinfoforcreate.html#cfn-evs-environment-hostinfoforcreate-dedicatedhostid
         */
        readonly dedicatedHostId?: string;
        /**
         * The DNS hostname of the host.
         *
         * DNS hostnames for hosts must be unique across Amazon EVS environments and within VCF.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-hostinfoforcreate.html#cfn-evs-environment-hostinfoforcreate-hostname
         */
        readonly hostName?: string;
        /**
         * The EC2 instance type that represents the host.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-hostinfoforcreate.html#cfn-evs-environment-hostinfoforcreate-instancetype
         */
        readonly instanceType?: string;
        /**
         * The name of the SSH key that is used to access the host.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-hostinfoforcreate.html#cfn-evs-environment-hostinfoforcreate-keyname
         */
        readonly keyName?: string;
        /**
         * The unique ID of the placement group where the host is placed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-hostinfoforcreate.html#cfn-evs-environment-hostinfoforcreate-placementgroupid
         */
        readonly placementGroupId?: string;
    }
    /**
     * The connectivity configuration for the environment.
     *
     * Amazon EVS requires that you specify two route server peer IDs. During environment creation, the route server endpoints peer with the NSX uplink VLAN for connectivity to the NSX overlay network.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-connectivityinfo.html
     */
    interface ConnectivityInfoProperty {
        /**
         * The unique IDs for private route server peers.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-connectivityinfo.html#cfn-evs-environment-connectivityinfo-privaterouteserverpeerings
         */
        readonly privateRouteServerPeerings?: Array<string>;
    }
    /**
     * The DNS hostnames that Amazon EVS uses to install VMware vCenter Server, NSX, SDDC Manager, and Cloud Builder.
     *
     * Each hostname must be unique, and resolve to a domain name that you've registered in your DNS service of choice. Hostnames cannot be changed.
     *
     * VMware VCF requires the deployment of two NSX Edge nodes, and three NSX Manager virtual machines.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html
     */
    interface VcfHostnamesProperty {
        /**
         * The hostname for VMware Cloud Builder.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-cloudbuilder
         */
        readonly cloudBuilder?: string;
        /**
         * The VMware NSX hostname.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-nsx
         */
        readonly nsx?: string;
        /**
         * The hostname for the first NSX Edge node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-nsxedge1
         */
        readonly nsxEdge1?: string;
        /**
         * The hostname for the second NSX Edge node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-nsxedge2
         */
        readonly nsxEdge2?: string;
        /**
         * The hostname for the first VMware NSX Manager virtual machine (VM).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-nsxmanager1
         */
        readonly nsxManager1?: string;
        /**
         * The hostname for the second VMware NSX Manager virtual machine (VM).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-nsxmanager2
         */
        readonly nsxManager2?: string;
        /**
         * The hostname for the third VMware NSX Manager virtual machine (VM).
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-nsxmanager3
         */
        readonly nsxManager3?: string;
        /**
         * The hostname for SDDC Manager.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-sddcmanager
         */
        readonly sddcManager?: string;
        /**
         * The VMware vCenter hostname.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-vcfhostnames.html#cfn-evs-environment-vcfhostnames-vcenter
         */
        readonly vCenter?: string;
    }
    /**
     * The security groups that allow traffic between the Amazon EVS control plane and your VPC for Amazon EVS service access.
     *
     * If a security group is not specified, Amazon EVS uses the default security group in your account for service access.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-serviceaccesssecuritygroups.html
     */
    interface ServiceAccessSecurityGroupsProperty {
        /**
         * The security groups that allow service access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-serviceaccesssecuritygroups.html#cfn-evs-environment-serviceaccesssecuritygroups-securitygroups
         */
        readonly securityGroups?: Array<string>;
    }
    /**
     * A check on the environment to identify environment health and validate VMware VCF licensing compliance.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-check.html
     */
    interface CheckProperty {
        /**
         * The time when environment health began to be impaired.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-check.html#cfn-evs-environment-check-impairedsince
         */
        readonly impairedSince?: string;
        /**
         * The check result.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-check.html#cfn-evs-environment-check-result
         */
        readonly result?: string;
        /**
         * The check type. Amazon EVS performs the following checks.
         *
         * - `KEY_REUSE` : checks that the VCF license key is not used by another Amazon EVS environment. This check fails if a used license is added to the environment.
         * - `KEY_COVERAGE` : checks that your VCF license key allocates sufficient vCPU cores for all deployed hosts. The check fails when any assigned hosts in the EVS environment are not covered by license keys, or when any unassigned hosts cannot be covered by available vCPU cores in keys.
         * - `REACHABILITY` : checks that the Amazon EVS control plane has a persistent connection to SDDC Manager. If Amazon EVS cannot reach the environment, this check fails.
         * - `HOST_COUNT` : Checks that your environment has a minimum of 4 hosts, which is a requirement for VCF 5.2.1.
         *
         * If this check fails, you will need to add hosts so that your environment meets this minimum requirement. Amazon EVS only supports environments with 4-16 hosts.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-check.html#cfn-evs-environment-check-type
         */
        readonly type?: string;
    }
    /**
     * A managed secret that contains the credentials for installing vCenter Server, NSX, and SDDC Manager.
     *
     * During environment creation, the Amazon EVS control plane uses AWS Secrets Manager to create, encrypt, validate, and store secrets. If you choose to delete your environment, Amazon EVS also deletes the secrets that are associated with your environment. Amazon EVS does not provide managed rotation of secrets. We recommend that you rotate secrets regularly to ensure that secrets are not long-lived.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-secret.html
     */
    interface SecretProperty {
        /**
         * The Amazon Resource Name (ARN) of the secret.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-evs-environment-secret.html#cfn-evs-environment-secret-secretarn
         */
        readonly secretArn?: string;
    }
}
/**
 * Properties for CfnEnvironmentPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html
 */
export interface CfnEnvironmentMixinProps {
    /**
     * The connectivity configuration for the environment.
     *
     * Amazon EVS requires that you specify two route server peer IDs. During environment creation, the route server endpoints peer with the NSX uplink VLAN for connectivity to the NSX overlay network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-connectivityinfo
     */
    readonly connectivityInfo?: CfnEnvironmentPropsMixin.ConnectivityInfoProperty | cdk.IResolvable;
    /**
     * The name of the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-environmentname
     */
    readonly environmentName?: string;
    /**
     * Required for environment resource creation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-hosts
     */
    readonly hosts?: Array<CfnEnvironmentPropsMixin.HostInfoForCreateProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * > Amazon EVS is in public preview release and is subject to change.
     *
     * The initial VLAN subnets for the environment. Amazon EVS VLAN subnets have a minimum CIDR block size of /28 and a maximum size of /24. Amazon EVS VLAN subnet CIDR blocks must not overlap with other subnets in the VPC.
     *
     * Required for environment resource creation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-initialvlans
     */
    readonly initialVlans?: CfnEnvironmentPropsMixin.InitialVlansProperty | cdk.IResolvable;
    /**
     * The AWS KMS key ID that AWS Secrets Manager uses to encrypt secrets that are associated with the environment.
     *
     * These secrets contain the VCF credentials that are needed to install vCenter Server, NSX, and SDDC Manager.
     *
     * By default, Amazon EVS use the AWS Secrets Manager managed key `aws/secretsmanager` . You can also specify a customer managed key.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * The license information that Amazon EVS requires to create an environment.
     *
     * Amazon EVS requires two license keys: a VCF solution key and a vSAN license key. The VCF solution key must cover a minimum of 256 cores. The vSAN license key must provide at least 110 TiB of vSAN capacity.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-licenseinfo
     */
    readonly licenseInfo?: cdk.IResolvable | CfnEnvironmentPropsMixin.LicenseInfoProperty;
    /**
     * The security groups that allow traffic between the Amazon EVS control plane and your VPC for service access.
     *
     * If a security group is not specified, Amazon EVS uses the default security group in your account for service access.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-serviceaccesssecuritygroups
     */
    readonly serviceAccessSecurityGroups?: cdk.IResolvable | CfnEnvironmentPropsMixin.ServiceAccessSecurityGroupsProperty;
    /**
     * The subnet that is used to establish connectivity between the Amazon EVS control plane and VPC.
     *
     * Amazon EVS uses this subnet to perform validations and create the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-serviceaccesssubnetid
     */
    readonly serviceAccessSubnetId?: string;
    /**
     * The Broadcom Site ID that is associated with your Amazon EVS environment.
     *
     * Amazon EVS uses the Broadcom Site ID that you provide to meet Broadcom VCF license usage reporting requirements for Amazon EVS.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-siteid
     */
    readonly siteId?: string;
    /**
     * Metadata that assists with categorization and organization.
     *
     * Each tag consists of a key and an optional value. You define both. Tags don't propagate to any other cluster or AWS resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * Customer confirmation that the customer has purchased and will continue to maintain the required number of VCF software licenses to cover all physical processor cores in the Amazon EVS environment.
     *
     * Information about your VCF software in Amazon EVS will be shared with Broadcom to verify license compliance. Amazon EVS does not validate license keys. To validate license keys, visit the Broadcom support portal.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-termsaccepted
     */
    readonly termsAccepted?: boolean | cdk.IResolvable;
    /**
     * The DNS hostnames to be used by the VCF management appliances in your environment.
     *
     * For environment creation to be successful, each hostname entry must resolve to a domain name that you've registered in your DNS service of choice and configured in the DHCP option set of your VPC. DNS hostnames cannot be changed after environment creation has started.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-vcfhostnames
     */
    readonly vcfHostnames?: cdk.IResolvable | CfnEnvironmentPropsMixin.VcfHostnamesProperty;
    /**
     * The VCF version of the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-vcfversion
     */
    readonly vcfVersion?: string;
    /**
     * The VPC associated with the environment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-evs-environment.html#cfn-evs-environment-vpcid
     */
    readonly vpcId?: string;
}
