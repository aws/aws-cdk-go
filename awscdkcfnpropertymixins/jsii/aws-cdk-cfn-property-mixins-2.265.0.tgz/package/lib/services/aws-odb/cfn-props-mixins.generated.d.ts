import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-odb";
/**
 * The `AWS::ODB::CloudAutonomousVmCluster` resource creates an Autonomous VM cluster.
 *
 * An Autonomous VM cluster provides the infrastructure for running Autonomous Databases.
 *
 * @cloudformationResource AWS::ODB::CloudAutonomousVmCluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html
 */
export declare class CfnCloudAutonomousVmClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCloudAutonomousVmClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ODB::CloudAutonomousVmCluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCloudAutonomousVmClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCloudAutonomousVmCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCloudAutonomousVmClusterPropsMixin {
    /**
     * The scheduling details for the maintenance window.
     *
     * Patching and system updates take place during the maintenance window.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html
     */
    interface MaintenanceWindowProperty {
        /**
         * The days of the week when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow-daysofweek
         */
        readonly daysOfWeek?: Array<string>;
        /**
         * The hours of the day when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow-hoursofday
         */
        readonly hoursOfDay?: Array<number> | cdk.IResolvable;
        /**
         * The lead time in weeks before the maintenance window.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow-leadtimeinweeks
         */
        readonly leadTimeInWeeks?: number;
        /**
         * The months when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow-months
         */
        readonly months?: Array<string>;
        /**
         * The preference for the maintenance window scheduling.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow-preference
         */
        readonly preference?: string;
        /**
         * The weeks of the month when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-maintenancewindow.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow-weeksofmonth
         */
        readonly weeksOfMonth?: Array<number> | cdk.IResolvable;
    }
    /**
     * An AWS Identity and Access Management (IAM) service role associated with the Autonomous VM cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-iamrole.html
     */
    interface IamRoleProperty {
        /**
         * The AWS integration configuration settings for the AWS Identity and Access Management (IAM) service role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-iamrole.html#cfn-odb-cloudautonomousvmcluster-iamrole-awsintegration
         */
        readonly awsIntegration?: string;
        /**
         * The Amazon Resource Name (ARN) of the AWS Identity and Access Management (IAM) service role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-iamrole.html#cfn-odb-cloudautonomousvmcluster-iamrole-iamrolearn
         */
        readonly iamRoleArn?: string;
        /**
         * The current status of the AWS Identity and Access Management (IAM) service role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudautonomousvmcluster-iamrole.html#cfn-odb-cloudautonomousvmcluster-iamrole-status
         */
        readonly status?: string;
    }
}
/**
 * Properties for CfnCloudAutonomousVmClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html
 */
export interface CfnCloudAutonomousVmClusterMixinProps {
    /**
     * The data storage size allocated for Autonomous Databases in the Autonomous VM cluster, in TB.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-autonomousdatastoragesizeintbs
     */
    readonly autonomousDataStorageSizeInTBs?: number;
    /**
     * The unique identifier of the Cloud Exadata Infrastructure containing this Autonomous VM cluster.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-cloudexadatainfrastructureid
     */
    readonly cloudExadataInfrastructureId?: string;
    /**
     * The number of CPU cores enabled per node in the Autonomous VM cluster.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-cpucorecountpernode
     */
    readonly cpuCoreCountPerNode?: number;
    /**
     * The list of database servers associated with the Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-dbservers
     */
    readonly dbServers?: Array<string>;
    /**
     * The user-provided description of the Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-description
     */
    readonly description?: string;
    /**
     * The display name of the Autonomous VM cluster.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-displayname
     */
    readonly displayName?: string;
    /**
     * The AWS Identity and Access Management (IAM) service roles associated with the Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-iamroles
     */
    readonly iamRoles?: Array<CfnCloudAutonomousVmClusterPropsMixin.IamRoleProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Specifies whether mutual TLS (mTLS) authentication is enabled for the Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-ismtlsenabledvmcluster
     */
    readonly isMtlsEnabledVmCluster?: boolean | cdk.IResolvable;
    /**
     * The Oracle license model that applies to the Autonomous VM cluster.
     *
     * Valid values are `LICENSE_INCLUDED` or `BRING_YOUR_OWN_LICENSE` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-licensemodel
     */
    readonly licenseModel?: string;
    /**
     * The scheduling details for the maintenance window.
     *
     * Patching and system updates take place during the maintenance window.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-maintenancewindow
     */
    readonly maintenanceWindow?: cdk.IResolvable | CfnCloudAutonomousVmClusterPropsMixin.MaintenanceWindowProperty;
    /**
     * The amount of memory allocated per Oracle Compute Unit, in GB.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-memoryperoraclecomputeunitingbs
     */
    readonly memoryPerOracleComputeUnitInGBs?: number;
    /**
     * The unique identifier of the ODB network associated with this Autonomous VM cluster.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-odbnetworkid
     */
    readonly odbNetworkId?: string;
    /**
     * The SCAN listener port for non-TLS (TCP) protocol.
     *
     * The default is 1521.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-scanlistenerportnontls
     */
    readonly scanListenerPortNonTls?: number;
    /**
     * The SCAN listener port for TLS (TCP) protocol.
     *
     * The default is 2484.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-scanlistenerporttls
     */
    readonly scanListenerPortTls?: number;
    /**
     * Tags to assign to the Autonomous Vm Cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The time zone of the Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-timezone
     */
    readonly timeZone?: string;
    /**
     * The total number of Autonomous Container Databases that can be created with the allocated local storage.
     *
     * Required when creating an Autonomous VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudautonomousvmcluster.html#cfn-odb-cloudautonomousvmcluster-totalcontainerdatabases
     */
    readonly totalContainerDatabases?: number;
}
/**
 * The `AWS::ODB::CloudExadataInfrastructure` resource creates an Exadata infrastructure.
 *
 * An Exadata infrastructure provides the underlying compute and storage resources for Oracle Database workloads.
 *
 * @cloudformationResource AWS::ODB::CloudExadataInfrastructure
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html
 */
export declare class CfnCloudExadataInfrastructurePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCloudExadataInfrastructureMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ODB::CloudExadataInfrastructure`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCloudExadataInfrastructureMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCloudExadataInfrastructure;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCloudExadataInfrastructurePropsMixin {
    /**
     * The scheduling details for the maintenance window.
     *
     * Patching and system updates take place during the maintenance window.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html
     */
    interface MaintenanceWindowProperty {
        /**
         * The custom action timeout in minutes for the maintenance window.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-customactiontimeoutinmins
         */
        readonly customActionTimeoutInMins?: number;
        /**
         * The days of the week when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-daysofweek
         */
        readonly daysOfWeek?: Array<string>;
        /**
         * The hours of the day when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-hoursofday
         */
        readonly hoursOfDay?: Array<number> | cdk.IResolvable;
        /**
         * Indicates whether custom action timeout is enabled for the maintenance window.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-iscustomactiontimeoutenabled
         */
        readonly isCustomActionTimeoutEnabled?: boolean | cdk.IResolvable;
        /**
         * The lead time in weeks before the maintenance window.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-leadtimeinweeks
         */
        readonly leadTimeInWeeks?: number;
        /**
         * The months when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-months
         */
        readonly months?: Array<string>;
        /**
         * The patching mode for the maintenance window.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-patchingmode
         */
        readonly patchingMode?: string;
        /**
         * The preference for the maintenance window scheduling.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-preference
         */
        readonly preference?: string;
        /**
         * The weeks of the month when maintenance can be performed.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-maintenancewindow.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow-weeksofmonth
         */
        readonly weeksOfMonth?: Array<number> | cdk.IResolvable;
    }
    /**
     * A contact to receive notification from Oracle about maintenance updates for a specific Exadata infrastructure.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-customercontact.html
     */
    interface CustomerContactProperty {
        /**
         * The email address of the contact.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudexadatainfrastructure-customercontact.html#cfn-odb-cloudexadatainfrastructure-customercontact-email
         */
        readonly email?: string;
    }
}
/**
 * Properties for CfnCloudExadataInfrastructurePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html
 */
export interface CfnCloudExadataInfrastructureMixinProps {
    /**
     * The name of the Availability Zone (AZ) where the Exadata infrastructure is located.
     *
     * Required when creating an Exadata infrastructure. Specify either AvailabilityZone or AvailabilityZoneId to define the location of the infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-availabilityzone
     */
    readonly availabilityZone?: string;
    /**
     * The AZ ID of the AZ where the Exadata infrastructure is located.
     *
     * Required when creating an Exadata infrastructure. Specify either AvailabilityZone or AvailabilityZoneId to define the location of the infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-availabilityzoneid
     */
    readonly availabilityZoneId?: string;
    /**
     * The number of database servers for the Exadata infrastructure.
     *
     * Required when creating an Exadata infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-computecount
     */
    readonly computeCount?: number;
    /**
     * The email addresses of contacts to receive notification from Oracle about maintenance updates for the Exadata infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-customercontactstosendtooci
     */
    readonly customerContactsToSendToOci?: Array<CfnCloudExadataInfrastructurePropsMixin.CustomerContactProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The database server model type of the Exadata infrastructure.
     *
     * For the list of valid model names, use the `ListDbSystemShapes` operation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-databaseservertype
     */
    readonly databaseServerType?: string;
    /**
     * The user-friendly name for the Exadata infrastructure.
     *
     * Required when creating an Exadata infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-displayname
     */
    readonly displayName?: string;
    /**
     * The scheduling details for the maintenance window.
     *
     * Patching and system updates take place during the maintenance window.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-maintenancewindow
     */
    readonly maintenanceWindow?: cdk.IResolvable | CfnCloudExadataInfrastructurePropsMixin.MaintenanceWindowProperty;
    /**
     * The model name of the Exadata infrastructure.
     *
     * Required when creating an Exadata infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-shape
     */
    readonly shape?: string;
    /**
     * The number of storage servers that are activated for the Exadata infrastructure.
     *
     * Required when creating an Exadata infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-storagecount
     */
    readonly storageCount?: number;
    /**
     * The storage server model type of the Exadata infrastructure.
     *
     * For the list of valid model names, use the `ListDbSystemShapes` operation.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-storageservertype
     */
    readonly storageServerType?: string;
    /**
     * Tags to assign to the Exadata Infrastructure.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudexadatainfrastructure.html#cfn-odb-cloudexadatainfrastructure-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * The `AWS::ODB::CloudVmCluster` resource creates a VM cluster on the specified Exadata infrastructure in the Oracle Database.
 *
 * A VM cluster provides the compute resources for Oracle Database workloads.
 *
 * @cloudformationResource AWS::ODB::CloudVmCluster
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html
 */
export declare class CfnCloudVmClusterPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnCloudVmClusterMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ODB::CloudVmCluster`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnCloudVmClusterMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnCloudVmCluster;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnCloudVmClusterPropsMixin {
    /**
     * Information about the data collection options enabled for a VM cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-datacollectionoptions.html
     */
    interface DataCollectionOptionsProperty {
        /**
         * Specifies whether diagnostic collection is enabled for the VM cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-datacollectionoptions.html#cfn-odb-cloudvmcluster-datacollectionoptions-isdiagnosticseventsenabled
         */
        readonly isDiagnosticsEventsEnabled?: boolean | cdk.IResolvable;
        /**
         * Specifies whether health monitoring is enabled for the VM cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-datacollectionoptions.html#cfn-odb-cloudvmcluster-datacollectionoptions-ishealthmonitoringenabled
         */
        readonly isHealthMonitoringEnabled?: boolean | cdk.IResolvable;
        /**
         * Specifies whether incident logs are enabled for the VM cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-datacollectionoptions.html#cfn-odb-cloudvmcluster-datacollectionoptions-isincidentlogsenabled
         */
        readonly isIncidentLogsEnabled?: boolean | cdk.IResolvable;
    }
    /**
     * Information about a DB node.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html
     */
    interface DbNodeProperty {
        /**
         * The Oracle Cloud ID (OCID) of the backup IP address that's associated with the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-backupipid
         */
        readonly backupIpId?: string;
        /**
         * The OCID of the second backup VNIC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-backupvnic2id
         */
        readonly backupVnic2Id?: string;
        /**
         * Number of CPU cores enabled on the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-cpucorecount
         */
        readonly cpuCoreCount?: number;
        /**
         * The Amazon Resource Name (ARN) of the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-dbnodearn
         */
        readonly dbNodeArn?: string;
        /**
         * The unique identifier of the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-dbnodeid
         */
        readonly dbNodeId?: string;
        /**
         * The amount of local node storage, in gigabytes (GBs), that's allocated on the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-dbnodestoragesizeingbs
         */
        readonly dbNodeStorageSizeInGBs?: number;
        /**
         * The unique identifier of the Db server that is associated with the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-dbserverid
         */
        readonly dbServerId?: string;
        /**
         * The OCID of the DB system.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-dbsystemid
         */
        readonly dbSystemId?: string;
        /**
         * The OCID of the host IP address that's associated with the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-hostipid
         */
        readonly hostIpId?: string;
        /**
         * The host name for the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-hostname
         */
        readonly hostname?: string;
        /**
         * The allocated memory in GBs on the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-memorysizeingbs
         */
        readonly memorySizeInGBs?: number;
        /**
         * The OCID of the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-ocid
         */
        readonly ocid?: string;
        /**
         * The current status of the DB node.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-status
         */
        readonly status?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-tags
         */
        readonly tags?: Array<cdk.CfnTag>;
        /**
         * The OCID of the second VNIC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-vnic2id
         */
        readonly vnic2Id?: string;
        /**
         * The OCID of the VNIC.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-dbnode.html#cfn-odb-cloudvmcluster-dbnode-vnicid
         */
        readonly vnicId?: string;
    }
    /**
     * An AWS Identity and Access Management (IAM) service role associated with the VM cluster.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-iamrole.html
     */
    interface IamRoleProperty {
        /**
         * The AWS integration configuration settings for the AWS Identity and Access Management (IAM) service role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-iamrole.html#cfn-odb-cloudvmcluster-iamrole-awsintegration
         */
        readonly awsIntegration?: string;
        /**
         * The Amazon Resource Name (ARN) of the AWS Identity and Access Management (IAM) service role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-iamrole.html#cfn-odb-cloudvmcluster-iamrole-iamrolearn
         */
        readonly iamRoleArn?: string;
        /**
         * The current status of the AWS Identity and Access Management (IAM) service role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-cloudvmcluster-iamrole.html#cfn-odb-cloudvmcluster-iamrole-status
         */
        readonly status?: string;
    }
}
/**
 * Properties for CfnCloudVmClusterPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html
 */
export interface CfnCloudVmClusterMixinProps {
    /**
     * The unique identifier of the Exadata infrastructure that this VM cluster belongs to.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-cloudexadatainfrastructureid
     */
    readonly cloudExadataInfrastructureId?: string;
    /**
     * The name of the Grid Infrastructure (GI) cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-clustername
     */
    readonly clusterName?: string;
    /**
     * The number of CPU cores enabled on the VM cluster.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-cpucorecount
     */
    readonly cpuCoreCount?: number;
    /**
     * The set of diagnostic collection options enabled for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-datacollectionoptions
     */
    readonly dataCollectionOptions?: CfnCloudVmClusterPropsMixin.DataCollectionOptionsProperty | cdk.IResolvable;
    /**
     * The size of the data disk group, in terabytes (TB), that's allocated for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-datastoragesizeintbs
     */
    readonly dataStorageSizeInTBs?: number;
    /**
     * The DB nodes that are implicitly created and managed as part of this VM Cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-dbnodes
     */
    readonly dbNodes?: Array<CfnCloudVmClusterPropsMixin.DbNodeProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The amount of local node storage, in gigabytes (GB), that's allocated for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-dbnodestoragesizeingbs
     */
    readonly dbNodeStorageSizeInGBs?: number;
    /**
     * The list of database servers for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-dbservers
     */
    readonly dbServers?: Array<string>;
    /**
     * The user-friendly name for the VM cluster.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-displayname
     */
    readonly displayName?: string;
    /**
     * The software version of the Oracle Grid Infrastructure (GI) for the VM cluster.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-giversion
     */
    readonly giVersion?: string;
    /**
     * The host name for the VM cluster.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-hostname
     */
    readonly hostname?: string;
    /**
     * The AWS Identity and Access Management (IAM) service roles associated with the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-iamroles
     */
    readonly iamRoles?: Array<CfnCloudVmClusterPropsMixin.IamRoleProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Specifies whether database backups to local Exadata storage are enabled for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-islocalbackupenabled
     */
    readonly isLocalBackupEnabled?: boolean | cdk.IResolvable;
    /**
     * Specifies whether the VM cluster is configured with a sparse disk group.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-issparsediskgroupenabled
     */
    readonly isSparseDiskgroupEnabled?: boolean | cdk.IResolvable;
    /**
     * The Oracle license model applied to the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-licensemodel
     */
    readonly licenseModel?: string;
    /**
     * The amount of memory, in gigabytes (GB), that's allocated for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-memorysizeingbs
     */
    readonly memorySizeInGBs?: number;
    /**
     * The unique identifier of the ODB network for the VM cluster.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-odbnetworkid
     */
    readonly odbNetworkId?: string;
    /**
     * The port number for TCP connections to the single client access name (SCAN) listener.
     *
     * Valid values: `1024–8999` with the following exceptions: `2484` , `6100` , `6200` , `7060` , `7070` , `7085` , and `7879`
     *
     * Default: `1521`
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-scanlistenerporttcp
     */
    readonly scanListenerPortTcp?: number;
    /**
     * The public key portion of one or more key pairs used for SSH access to the VM cluster.
     *
     * Required when creating a VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-sshpublickeys
     */
    readonly sshPublicKeys?: Array<string>;
    /**
     * The operating system version of the image chosen for the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-systemversion
     */
    readonly systemVersion?: string;
    /**
     * Tags to assign to the Vm Cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The time zone of the VM cluster.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-cloudvmcluster.html#cfn-odb-cloudvmcluster-timezone
     */
    readonly timeZone?: string;
}
/**
 * The `AWS::ODB::OdbNetwork` resource creates an ODB network.
 *
 * An ODB network provides the networking foundation for Oracle Database resources.
 *
 * @cloudformationResource AWS::ODB::OdbNetwork
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html
 */
export declare class CfnOdbNetworkPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOdbNetworkMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ODB::OdbNetwork`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOdbNetworkMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOdbNetwork;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnOdbNetworkPropsMixin {
    /**
     * The managed services configuration for the ODB network.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html
     */
    interface ManagedServicesProperty {
        /**
         * The access configuration for the cross-Region Amazon S3 database restore source.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-crossregions3restoresourcesaccess
         */
        readonly crossRegionS3RestoreSourcesAccess?: Array<CfnOdbNetworkPropsMixin.CrossRegionS3RestoreSourcesAccessProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * The AWS Key Management Service (KMS) access configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-kmsaccess
         */
        readonly kmsAccess?: cdk.IResolvable | CfnOdbNetworkPropsMixin.KmsAccessProperty;
        /**
         * The managed Amazon S3 backup access configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-manageds3backupaccess
         */
        readonly managedS3BackupAccess?: cdk.IResolvable | CfnOdbNetworkPropsMixin.ManagedS3BackupAccessProperty;
        /**
         * The IPv4 CIDR blocks for the managed services.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-managedservicesipv4cidrs
         */
        readonly managedServicesIpv4Cidrs?: Array<string>;
        /**
         * The Amazon Resource Name (ARN) of the resource gateway.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-resourcegatewayarn
         */
        readonly resourceGatewayArn?: string;
        /**
         * The Amazon S3 access configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-s3access
         */
        readonly s3Access?: cdk.IResolvable | CfnOdbNetworkPropsMixin.S3AccessProperty;
        /**
         * The Amazon Resource Name (ARN) of the service network.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-servicenetworkarn
         */
        readonly serviceNetworkArn?: string;
        /**
         * The service network endpoint configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-servicenetworkendpoint
         */
        readonly serviceNetworkEndpoint?: cdk.IResolvable | CfnOdbNetworkPropsMixin.ServiceNetworkEndpointProperty;
        /**
         * The AWS Security Token Service (STS) access configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-stsaccess
         */
        readonly stsAccess?: cdk.IResolvable | CfnOdbNetworkPropsMixin.StsAccessProperty;
        /**
         * The Zero-ETL access configuration.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-managedservices.html#cfn-odb-odbnetwork-managedservices-zeroetlaccess
         */
        readonly zeroEtlAccess?: cdk.IResolvable | CfnOdbNetworkPropsMixin.ZeroEtlAccessProperty;
    }
    /**
     * The configuration for a service network endpoint.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-servicenetworkendpoint.html
     */
    interface ServiceNetworkEndpointProperty {
        /**
         * The identifier of the VPC endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-servicenetworkendpoint.html#cfn-odb-odbnetwork-servicenetworkendpoint-vpcendpointid
         */
        readonly vpcEndpointId?: string;
        /**
         * The type of the VPC endpoint.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-servicenetworkendpoint.html#cfn-odb-odbnetwork-servicenetworkendpoint-vpcendpointtype
         */
        readonly vpcEndpointType?: string;
    }
    /**
     * The configuration for managed Amazon S3 backup access from the ODB network.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-manageds3backupaccess.html
     */
    interface ManagedS3BackupAccessProperty {
        /**
         * The IPv4 addresses for the managed Amazon S3 backup access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-manageds3backupaccess.html#cfn-odb-odbnetwork-manageds3backupaccess-ipv4addresses
         */
        readonly ipv4Addresses?: Array<string>;
        /**
         * The status of the managed Amazon S3 backup access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-manageds3backupaccess.html#cfn-odb-odbnetwork-manageds3backupaccess-status
         */
        readonly status?: string;
    }
    /**
     * The configuration for Zero-ETL access from the ODB network.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-zeroetlaccess.html
     */
    interface ZeroEtlAccessProperty {
        /**
         * The CIDR block for the Zero-ETL access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-zeroetlaccess.html#cfn-odb-odbnetwork-zeroetlaccess-cidr
         */
        readonly cidr?: string;
        /**
         * The status of the Zero-ETL access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-zeroetlaccess.html#cfn-odb-odbnetwork-zeroetlaccess-status
         */
        readonly status?: string;
    }
    /**
     * The configuration for Amazon S3 access from the ODB network.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-s3access.html
     */
    interface S3AccessProperty {
        /**
         * The domain name for the Amazon S3 access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-s3access.html#cfn-odb-odbnetwork-s3access-domainname
         */
        readonly domainName?: string;
        /**
         * The IPv4 addresses for the Amazon S3 access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-s3access.html#cfn-odb-odbnetwork-s3access-ipv4addresses
         */
        readonly ipv4Addresses?: Array<string>;
        /**
         * The endpoint policy for the Amazon S3 access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-s3access.html#cfn-odb-odbnetwork-s3access-s3policydocument
         */
        readonly s3PolicyDocument?: string;
        /**
         * The status of the Amazon S3 access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-s3access.html#cfn-odb-odbnetwork-s3access-status
         */
        readonly status?: string;
    }
    /**
     * The AWS Key Management Service (KMS) access configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-kmsaccess.html
     */
    interface KmsAccessProperty {
        /**
         * The domain name for the AWS KMS access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-kmsaccess.html#cfn-odb-odbnetwork-kmsaccess-domainname
         */
        readonly domainName?: string;
        /**
         * The IPv4 addresses for the AWS KMS access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-kmsaccess.html#cfn-odb-odbnetwork-kmsaccess-ipv4addresses
         */
        readonly ipv4Addresses?: Array<string>;
        /**
         * The endpoint policy for the AWS KMS access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-kmsaccess.html#cfn-odb-odbnetwork-kmsaccess-kmspolicydocument
         */
        readonly kmsPolicyDocument?: string;
        /**
         * The status of the managed resource access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-kmsaccess.html#cfn-odb-odbnetwork-kmsaccess-status
         */
        readonly status?: string;
    }
    /**
     * The AWS Security Token Service (STS) access configuration.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-stsaccess.html
     */
    interface StsAccessProperty {
        /**
         * The domain name for the AWS STS access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-stsaccess.html#cfn-odb-odbnetwork-stsaccess-domainname
         */
        readonly domainName?: string;
        /**
         * The IPv4 addresses for the AWS STS access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-stsaccess.html#cfn-odb-odbnetwork-stsaccess-ipv4addresses
         */
        readonly ipv4Addresses?: Array<string>;
        /**
         * The status of the managed resource access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-stsaccess.html#cfn-odb-odbnetwork-stsaccess-status
         */
        readonly status?: string;
        /**
         * The endpoint policy for the AWS STS access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-stsaccess.html#cfn-odb-odbnetwork-stsaccess-stspolicydocument
         */
        readonly stsPolicyDocument?: string;
    }
    /**
     * The configuration access for the cross-Region Amazon S3 database restore source for the ODB network.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-crossregions3restoresourcesaccess.html
     */
    interface CrossRegionS3RestoreSourcesAccessProperty {
        /**
         * The IPv4 addresses allowed for cross-Region Amazon S3 restore access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-crossregions3restoresourcesaccess.html#cfn-odb-odbnetwork-crossregions3restoresourcesaccess-ipv4addresses
         */
        readonly ipv4Addresses?: Array<string>;
        /**
         * The AWS-Region for cross-Region Amazon S3 restore access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-crossregions3restoresourcesaccess.html#cfn-odb-odbnetwork-crossregions3restoresourcesaccess-region
         */
        readonly region?: string;
        /**
         * The status of the managed resource access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-odb-odbnetwork-crossregions3restoresourcesaccess.html#cfn-odb-odbnetwork-crossregions3restoresourcesaccess-status
         */
        readonly status?: string;
    }
}
/**
 * Properties for CfnOdbNetworkPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html
 */
export interface CfnOdbNetworkMixinProps {
    /**
     * The Availability Zone (AZ) where the ODB network is located.
     *
     * Required when creating an ODB network. Specify either AvailabilityZone or AvailabilityZoneId to define the location of the network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-availabilityzone
     */
    readonly availabilityZone?: string;
    /**
     * The AZ ID of the AZ where the ODB network is located.
     *
     * Required when creating an ODB network. Specify either AvailabilityZone or AvailabilityZoneId to define the location of the network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-availabilityzoneid
     */
    readonly availabilityZoneId?: string;
    /**
     * The CIDR range of the backup subnet in the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-backupsubnetcidr
     */
    readonly backupSubnetCidr?: string;
    /**
     * The CIDR range of the client subnet in the ODB network.
     *
     * Required when creating an ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-clientsubnetcidr
     */
    readonly clientSubnetCidr?: string;
    /**
     * The cross-Region Amazon S3 restore sources for the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-crossregions3restoresources
     */
    readonly crossRegionS3RestoreSources?: Array<string>;
    /**
     * The domain name for the resources in the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-customdomainname
     */
    readonly customDomainName?: string;
    /**
     * The DNS prefix to the default DNS domain name.
     *
     * The default DNS domain name is oraclevcn.com.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-defaultdnsprefix
     */
    readonly defaultDnsPrefix?: string;
    /**
     * Specifies whether to delete associated OCI networking resources along with the ODB network.
     *
     * Required when creating an ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-deleteassociatedresources
     */
    readonly deleteAssociatedResources?: boolean | cdk.IResolvable;
    /**
     * The user-friendly name of the ODB network.
     *
     * Required when creating an ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-displayname
     */
    readonly displayName?: string;
    /**
     * The AWS Key Management Service (KMS) access configuration for the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-kmsaccess
     */
    readonly kmsAccess?: string;
    /**
     * The AWS Key Management Service (KMS) policy document that defines permissions for key usage within the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-kmspolicydocument
     */
    readonly kmsPolicyDocument?: string;
    /**
     * The configuration for Amazon S3 access from the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-s3access
     */
    readonly s3Access?: string;
    /**
     * Specifies the endpoint policy for Amazon S3 access from the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-s3policydocument
     */
    readonly s3PolicyDocument?: string;
    /**
     * The AWS Security Token Service (STS) access configuration for the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-stsaccess
     */
    readonly stsAccess?: string;
    /**
     * The AWS Security Token Service (STS) policy document that defines permissions for token service usage within the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-stspolicydocument
     */
    readonly stsPolicyDocument?: string;
    /**
     * Tags to assign to the Odb Network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
    /**
     * The configuration for Zero-ETL access from the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbnetwork.html#cfn-odb-odbnetwork-zeroetlaccess
     */
    readonly zeroEtlAccess?: string;
}
/**
 * Creates a peering connection between an ODB network and a VPC.
 *
 * A peering connection enables private connectivity between the networks for application-tier communication.
 *
 * @cloudformationResource AWS::ODB::OdbPeeringConnection
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html
 */
export declare class CfnOdbPeeringConnectionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnOdbPeeringConnectionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ODB::OdbPeeringConnection`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnOdbPeeringConnectionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnOdbPeeringConnection;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnOdbPeeringConnectionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html
 */
export interface CfnOdbPeeringConnectionMixinProps {
    /**
     * The additional CIDR blocks for the ODB peering connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html#cfn-odb-odbpeeringconnection-additionalpeernetworkcidrs
     */
    readonly additionalPeerNetworkCidrs?: Array<string>;
    /**
     * The display name of the ODB peering connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html#cfn-odb-odbpeeringconnection-displayname
     */
    readonly displayName?: string;
    /**
     * The unique identifier of the ODB network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html#cfn-odb-odbpeeringconnection-odbnetworkid
     */
    readonly odbNetworkId?: string;
    /**
     * The unique identifier of the peer network.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html#cfn-odb-odbpeeringconnection-peernetworkid
     */
    readonly peerNetworkId?: string;
    /**
     * The unique identifier of the VPC route table for which a route to the ODB network is automatically created during peering connection establishment.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html#cfn-odb-odbpeeringconnection-peernetworkroutetableids
     */
    readonly peerNetworkRouteTableIds?: Array<string>;
    /**
     * Tags to assign to the Odb peering connection.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-odb-odbpeeringconnection.html#cfn-odb-odbpeeringconnection-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
