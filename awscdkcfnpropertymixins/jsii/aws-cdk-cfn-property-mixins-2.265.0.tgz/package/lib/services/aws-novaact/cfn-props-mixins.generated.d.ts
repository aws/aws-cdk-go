import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-novaact";
/**
 * Definition of AWS::NovaAct::WorkflowDefinition Resource Type.
 *
 * @cloudformationResource AWS::NovaAct::WorkflowDefinition
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-novaact-workflowdefinition.html
 */
export declare class CfnWorkflowDefinitionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnWorkflowDefinitionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::NovaAct::WorkflowDefinition`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnWorkflowDefinitionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnWorkflowDefinition;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnWorkflowDefinitionPropsMixin {
    /**
     * Configuration settings for exporting workflow execution data and logs to Amazon S3.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-novaact-workflowdefinition-workflowexportconfig.html
     */
    interface WorkflowExportConfigProperty {
        /**
         * The name of the Amazon S3 bucket for exporting workflow data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-novaact-workflowdefinition-workflowexportconfig.html#cfn-novaact-workflowdefinition-workflowexportconfig-s3bucketname
         */
        readonly s3BucketName?: string;
        /**
         * An optional prefix for Amazon S3 object keys to organize exported data.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-novaact-workflowdefinition-workflowexportconfig.html#cfn-novaact-workflowdefinition-workflowexportconfig-s3keyprefix
         */
        readonly s3KeyPrefix?: string;
    }
}
/**
 * Properties for CfnWorkflowDefinitionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-novaact-workflowdefinition.html
 */
export interface CfnWorkflowDefinitionMixinProps {
    /**
     * An optional description of the workflow definition's purpose and functionality.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-novaact-workflowdefinition.html#cfn-novaact-workflowdefinition-description
     */
    readonly description?: string;
    /**
     * Configuration settings for exporting workflow execution data and logs to Amazon S3.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-novaact-workflowdefinition.html#cfn-novaact-workflowdefinition-exportconfig
     */
    readonly exportConfig?: cdk.IResolvable | CfnWorkflowDefinitionPropsMixin.WorkflowExportConfigProperty;
    /**
     * The name of the workflow definition.
     *
     * Must be unique within your account and region.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-novaact-workflowdefinition.html#cfn-novaact-workflowdefinition-name
     */
    readonly name?: string;
}
