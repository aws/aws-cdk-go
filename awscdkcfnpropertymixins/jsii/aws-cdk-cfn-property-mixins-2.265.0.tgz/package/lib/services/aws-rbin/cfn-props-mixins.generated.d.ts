import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-rbin";
/**
 * Creates a Recycle Bin retention rule. You can create two types of retention rules:.
 *
 * - *Tag-level retention rules* - These retention rules use resource tags to identify the resources to protect. For each retention rule, you specify one or more tag key and value pairs. Resources (of the specified type) that have at least one of these tag key and value pairs are automatically retained in the Recycle Bin upon deletion. Use this type of retention rule to protect specific resources in your account based on their tags.
 * - *Region-level retention rules* - These retention rules, by default, apply to all of the resources (of the specified type) in the Region, even if the resources are not tagged. However, you can specify exclusion tags to exclude resources that have specific tags. Use this type of retention rule to protect all resources of a specific type in a Region.
 *
 * For more information, see [Create Recycle Bin retention rules](https://docs.aws.amazon.com/ebs/latest/userguide/recycle-bin.html) in the *Amazon EBS User Guide* .
 *
 * @cloudformationResource AWS::Rbin::Rule
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html
 */
export declare class CfnRulePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnRuleMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::Rbin::Rule`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnRuleMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnRule;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnRulePropsMixin {
    /**
     * [Tag-level retention rules only] Information about the resource tags used to identify resources that are retained by the retention rule.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-resourcetag.html
     */
    interface ResourceTagProperty {
        /**
         * The tag key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-resourcetag.html#cfn-rbin-rule-resourcetag-resourcetagkey
         */
        readonly resourceTagKey?: string;
        /**
         * The tag value.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-resourcetag.html#cfn-rbin-rule-resourcetag-resourcetagvalue
         */
        readonly resourceTagValue?: string;
    }
    /**
     * Information about the retention period for which the retention rule is to retain resources.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-retentionperiod.html
     */
    interface RetentionPeriodProperty {
        /**
         * The unit of time in which the retention period is measured.
         *
         * Currently, only `DAYS` is supported.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-retentionperiod.html#cfn-rbin-rule-retentionperiod-retentionperiodunit
         */
        readonly retentionPeriodUnit?: string;
        /**
         * The period value for which the retention rule is to retain resources, measured in days.
         *
         * The supported retention periods are:
         *
         * - EBS volumes: 1 - 7 days
         * - EBS snapshots and EBS-backed AMIs: 1 - 365 days
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-retentionperiod.html#cfn-rbin-rule-retentionperiod-retentionperiodvalue
         */
        readonly retentionPeriodValue?: number;
    }
    /**
     * Information about the retention rule unlock delay.
     *
     * The unlock delay is the period after which a retention rule can be modified or edited after it has been unlocked by a user with the required permissions. The retention rule can't be modified or deleted during the unlock delay.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-unlockdelay.html
     */
    interface UnlockDelayProperty {
        /**
         * The unit of time in which to measure the unlock delay.
         *
         * Currently, the unlock delay can be measured only in days.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-unlockdelay.html#cfn-rbin-rule-unlockdelay-unlockdelayunit
         */
        readonly unlockDelayUnit?: string;
        /**
         * The unlock delay period, measured in the unit specified for *UnlockDelayUnit* .
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-rbin-rule-unlockdelay.html#cfn-rbin-rule-unlockdelay-unlockdelayvalue
         */
        readonly unlockDelayValue?: number;
    }
}
/**
 * Properties for CfnRulePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html
 */
export interface CfnRuleMixinProps {
    /**
     * The retention rule description.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-description
     */
    readonly description?: string;
    /**
     * [Region-level retention rules only] Specifies the exclusion tags to use to identify resources that are to be excluded, or ignored, by a Region-level retention rule.
     *
     * Resources that have any of these tags are not retained by the retention rule upon deletion.
     *
     * You can't specify exclusion tags for tag-level retention rules.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-excluderesourcetags
     */
    readonly excludeResourceTags?: Array<cdk.IResolvable | CfnRulePropsMixin.ResourceTagProperty> | cdk.IResolvable;
    /**
     * Information about the retention rule lock configuration.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-lockconfiguration
     */
    readonly lockConfiguration?: cdk.IResolvable | CfnRulePropsMixin.UnlockDelayProperty;
    /**
     * [Tag-level retention rules only] Specifies the resource tags to use to identify resources that are to be retained by a tag-level retention rule.
     *
     * For tag-level retention rules, only deleted resources, of the specified resource type, that have one or more of the specified tag key and value pairs are retained. If a resource is deleted, but it does not have any of the specified tag key and value pairs, it is immediately deleted without being retained by the retention rule.
     *
     * You can add the same tag key and value pair to a maximum or five retention rules.
     *
     * To create a Region-level retention rule, omit this parameter. A Region-level retention rule does not have any resource tags specified. It retains all deleted resources of the specified resource type in the Region in which the rule is created, even if the resources are not tagged.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-resourcetags
     */
    readonly resourceTags?: Array<cdk.IResolvable | CfnRulePropsMixin.ResourceTagProperty> | cdk.IResolvable;
    /**
     * The resource type to be retained by the retention rule.
     *
     * Currently, only EBS volumes, EBS snapshots, and EBS-backed AMIs are supported.
     *
     * - To retain EBS volumes, specify `EBS_VOLUME` .
     * - To retain EBS snapshots, specify `EBS_SNAPSHOT`
     * - To retain EBS-backed AMIs, specify `EC2_IMAGE` .
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-resourcetype
     */
    readonly resourceType?: string;
    /**
     * Information about the retention period for which the retention rule is to retain resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-retentionperiod
     */
    readonly retentionPeriod?: cdk.IResolvable | CfnRulePropsMixin.RetentionPeriodProperty;
    /**
     * The state of the retention rule.
     *
     * Only retention rules that are in the `available` state retain resources.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-status
     */
    readonly status?: string;
    /**
     * Information about the tags to assign to the retention rule.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-rbin-rule.html#cfn-rbin-rule-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
