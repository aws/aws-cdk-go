import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-ssmguiconnect";
/**
 * Specify new or changed connection recording preferences for your AWS Systems Manager GUI Connect connections.
 *
 * @cloudformationResource AWS::SSMGuiConnect::Preferences
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ssmguiconnect-preferences.html
 */
export declare class CfnPreferencesPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPreferencesMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::SSMGuiConnect::Preferences`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPreferencesMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPreferences;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPreferencesPropsMixin {
    /**
     * The set of preferences used for recording RDP connections in the requesting AWS account and AWS Region .
     *
     * This includes details such as which S3 bucket recordings are stored in.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-connectionrecordingpreferences.html
     */
    interface ConnectionRecordingPreferencesProperty {
        /**
         * The ARN of a AWS  key that is used to encrypt data while it is being processed by the service.
         *
         * This key must exist in the same AWS Region as the node you start an RDP connection to.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-connectionrecordingpreferences.html#cfn-ssmguiconnect-preferences-connectionrecordingpreferences-kmskeyarn
         */
        readonly kmsKeyArn?: string;
        /**
         * Determines where recordings of RDP connections are stored.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-connectionrecordingpreferences.html#cfn-ssmguiconnect-preferences-connectionrecordingpreferences-recordingdestinations
         */
        readonly recordingDestinations?: cdk.IResolvable | CfnPreferencesPropsMixin.RecordingDestinationsProperty;
    }
    /**
     * Determines where recordings of RDP connections are stored.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-recordingdestinations.html
     */
    interface RecordingDestinationsProperty {
        /**
         * The S3 bucket where RDP connection recordings are stored.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-recordingdestinations.html#cfn-ssmguiconnect-preferences-recordingdestinations-s3buckets
         */
        readonly s3Buckets?: Array<cdk.IResolvable | CfnPreferencesPropsMixin.S3BucketProperty> | cdk.IResolvable;
    }
    /**
     * The S3 bucket where RDP connection recordings are stored.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-s3bucket.html
     */
    interface S3BucketProperty {
        /**
         * The name of the S3 bucket where RDP connection recordings are stored.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-s3bucket.html#cfn-ssmguiconnect-preferences-s3bucket-bucketname
         */
        readonly bucketName?: string;
        /**
         * The AWS account number that owns the S3 bucket.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ssmguiconnect-preferences-s3bucket.html#cfn-ssmguiconnect-preferences-s3bucket-bucketowner
         */
        readonly bucketOwner?: string;
    }
}
/**
 * Properties for CfnPreferencesPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ssmguiconnect-preferences.html
 */
export interface CfnPreferencesMixinProps {
    /**
     * The set of preferences used for recording RDP connections in the requesting AWS account and AWS Region .
     *
     * This includes details such as which S3 bucket recordings are stored in.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ssmguiconnect-preferences.html#cfn-ssmguiconnect-preferences-connectionrecordingpreferences
     */
    readonly connectionRecordingPreferences?: CfnPreferencesPropsMixin.ConnectionRecordingPreferencesProperty | cdk.IResolvable;
}
