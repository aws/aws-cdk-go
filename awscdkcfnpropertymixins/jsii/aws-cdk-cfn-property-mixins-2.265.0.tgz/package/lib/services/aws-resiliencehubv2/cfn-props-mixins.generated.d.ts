import * as cdk from "aws-cdk-lib/core";
import * as constructs from "constructs";
import * as mixins from "../../mixins";
import * as service from "aws-cdk-lib/aws-resiliencehubv2";
/**
 * Creates a resilience policy that defines availability and disaster recovery requirements.
 *
 * @cloudformationResource AWS::ResilienceHubV2::Policy
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html
 */
export declare class CfnPolicyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnPolicyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ResilienceHubV2::Policy`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnPolicyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnPolicy;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnPolicyPropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-availabilityslo.html
     */
    interface AvailabilitySloProperty {
        /**
         * Availability target percentage.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-availabilityslo.html#cfn-resiliencehubv2-policy-availabilityslo-target
         */
        readonly target?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiaztargets.html
     */
    interface MultiAzTargetsProperty {
        /**
         * Multi-AZ disaster recovery approach.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiaztargets.html#cfn-resiliencehubv2-policy-multiaztargets-disasterrecoveryapproach
         */
        readonly disasterRecoveryApproach?: string;
        /**
         * Recovery Point Objective in minutes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiaztargets.html#cfn-resiliencehubv2-policy-multiaztargets-rpoinminutes
         */
        readonly rpoInMinutes?: number;
        /**
         * Recovery Time Objective in minutes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiaztargets.html#cfn-resiliencehubv2-policy-multiaztargets-rtoinminutes
         */
        readonly rtoInMinutes?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiregiontargets.html
     */
    interface MultiRegionTargetsProperty {
        /**
         * Multi-Region disaster recovery approach.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiregiontargets.html#cfn-resiliencehubv2-policy-multiregiontargets-disasterrecoveryapproach
         */
        readonly disasterRecoveryApproach?: string;
        /**
         * Recovery Point Objective in minutes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiregiontargets.html#cfn-resiliencehubv2-policy-multiregiontargets-rpoinminutes
         */
        readonly rpoInMinutes?: number;
        /**
         * Recovery Time Objective in minutes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-multiregiontargets.html#cfn-resiliencehubv2-policy-multiregiontargets-rtoinminutes
         */
        readonly rtoInMinutes?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-datarecoverytargets.html
     */
    interface DataRecoveryTargetsProperty {
        /**
         * Time between backups in minutes.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-policy-datarecoverytargets.html#cfn-resiliencehubv2-policy-datarecoverytargets-timebetweenbackupsinminutes
         */
        readonly timeBetweenBackupsInMinutes?: number;
    }
}
/**
 * Properties for CfnPolicyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html
 */
export interface CfnPolicyMixinProps {
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-availabilityslo
     */
    readonly availabilitySlo?: CfnPolicyPropsMixin.AvailabilitySloProperty | cdk.IResolvable;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-datarecovery
     */
    readonly dataRecovery?: CfnPolicyPropsMixin.DataRecoveryTargetsProperty | cdk.IResolvable;
    /**
     * The description of the policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-description
     */
    readonly description?: string;
    /**
     * The KMS key ID for encrypting policy data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-multiaz
     */
    readonly multiAz?: cdk.IResolvable | CfnPolicyPropsMixin.MultiAzTargetsProperty;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-multiregion
     */
    readonly multiRegion?: cdk.IResolvable | CfnPolicyPropsMixin.MultiRegionTargetsProperty;
    /**
     * The name of the policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-name
     */
    readonly name?: string;
    /**
     * Tags assigned to the policy.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-policy.html#cfn-resiliencehubv2-policy-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a resilience-managed service with associated systems, input sources, assertions, and service functions.
 *
 * @cloudformationResource AWS::ResilienceHubV2::Service
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html
 */
export declare class CfnServicePropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnServiceMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ResilienceHubV2::Service`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnServiceMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnService;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
export declare namespace CfnServicePropsMixin {
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-associatedsystem.html
     */
    interface AssociatedSystemProperty {
        /**
         * The system ARN.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-associatedsystem.html#cfn-resiliencehubv2-service-associatedsystem-systemarn
         */
        readonly systemArn?: string;
        /**
         * User journey IDs associated with this system.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-associatedsystem.html#cfn-resiliencehubv2-service-associatedsystem-userjourneyids
         */
        readonly userJourneyIds?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-permissionmodel.html
     */
    interface PermissionModelProperty {
        /**
         * Cross-account role ARNs.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-permissionmodel.html#cfn-resiliencehubv2-service-permissionmodel-crossaccountrolearns
         */
        readonly crossAccountRoleArns?: Array<CfnServicePropsMixin.CrossAccountRoleConfigurationProperty | cdk.IResolvable> | cdk.IResolvable;
        /**
         * Name of the invoker IAM role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-permissionmodel.html#cfn-resiliencehubv2-service-permissionmodel-invokerrolename
         */
        readonly invokerRoleName?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-crossaccountroleconfiguration.html
     */
    interface CrossAccountRoleConfigurationProperty {
        /**
         * ARN of the cross-account IAM role.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-crossaccountroleconfiguration.html#cfn-resiliencehubv2-service-crossaccountroleconfiguration-crossaccountrolearn
         */
        readonly crossAccountRoleArn?: string;
        /**
         * External ID for cross-account access.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-crossaccountroleconfiguration.html#cfn-resiliencehubv2-service-crossaccountroleconfiguration-externalid
         */
        readonly externalId?: string;
    }
    /**
     * Configuration for automatic report generation on a Service.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-servicereportconfiguration.html
     */
    interface ServiceReportConfigurationProperty {
        /**
         * Output destinations for generated reports.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-servicereportconfiguration.html#cfn-resiliencehubv2-service-servicereportconfiguration-reportoutput
         */
        readonly reportOutput?: Array<cdk.IResolvable | CfnServicePropsMixin.ReportOutputConfigurationProperty> | cdk.IResolvable;
    }
    /**
     * Configuration for a report output destination.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-reportoutputconfiguration.html
     */
    interface ReportOutputConfigurationProperty {
        /**
         * S3 configuration for report output.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-reportoutputconfiguration.html#cfn-resiliencehubv2-service-reportoutputconfiguration-s3
         */
        readonly s3?: cdk.IResolvable | CfnServicePropsMixin.S3ReportOutputConfigurationProperty;
    }
    /**
     * S3 configuration for report output.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-s3reportoutputconfiguration.html
     */
    interface S3ReportOutputConfigurationProperty {
        /**
         * Account ID of the bucket owner.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-s3reportoutputconfiguration.html#cfn-resiliencehubv2-service-s3reportoutputconfiguration-bucketowner
         */
        readonly bucketOwner?: string;
        /**
         * S3 bucket path where reports will be written.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-s3reportoutputconfiguration.html#cfn-resiliencehubv2-service-s3reportoutputconfiguration-bucketpath
         */
        readonly bucketPath?: string;
    }
    /**
     * An input source for the service.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-inputsourcedefinition.html
     */
    interface InputSourceDefinitionProperty {
        /**
         * Resource configuration for an input source.
         *
         * Provide exactly one field.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-inputsourcedefinition.html#cfn-resiliencehubv2-service-inputsourcedefinition-resourceconfiguration
         */
        readonly resourceConfiguration?: cdk.IResolvable | CfnServicePropsMixin.ResourceConfigurationProperty;
    }
    /**
     * Resource configuration for an input source.
     *
     * Provide exactly one field.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourceconfiguration.html
     */
    interface ResourceConfigurationProperty {
        /**
         * ARN of a CloudFormation stack.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourceconfiguration.html#cfn-resiliencehubv2-service-resourceconfiguration-cfnstackarn
         */
        readonly cfnStackArn?: string;
        /**
         * S3 URL of a design file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourceconfiguration.html#cfn-resiliencehubv2-service-resourceconfiguration-designfiles3url
         */
        readonly designFileS3Url?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourceconfiguration.html#cfn-resiliencehubv2-service-resourceconfiguration-eks
         */
        readonly eks?: CfnServicePropsMixin.EksSourceProperty | cdk.IResolvable;
        /**
         * Resource tags to discover resources.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourceconfiguration.html#cfn-resiliencehubv2-service-resourceconfiguration-resourcetags
         */
        readonly resourceTags?: Array<cdk.IResolvable | CfnServicePropsMixin.ResourceTagProperty> | cdk.IResolvable;
        /**
         * URL of a Terraform state file.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourceconfiguration.html#cfn-resiliencehubv2-service-resourceconfiguration-tfstatefileurl
         */
        readonly tfStateFileUrl?: string;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourcetag.html
     */
    interface ResourceTagProperty {
        /**
         * Tag key.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourcetag.html#cfn-resiliencehubv2-service-resourcetag-key
         */
        readonly key?: string;
        /**
         * Tag values.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-resourcetag.html#cfn-resiliencehubv2-service-resourcetag-values
         */
        readonly values?: Array<string>;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-ekssource.html
     */
    interface EksSourceProperty {
        /**
         * ARN of the EKS cluster.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-ekssource.html#cfn-resiliencehubv2-service-ekssource-clusterarn
         */
        readonly clusterArn?: string;
        /**
         * EKS namespaces.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-ekssource.html#cfn-resiliencehubv2-service-ekssource-namespaces
         */
        readonly namespaces?: Array<string>;
    }
    /**
     * An assertion about the service's resilience posture.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-assertiondefinition.html
     */
    interface AssertionDefinitionProperty {
        /**
         * The text of the assertion.
         *
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-assertiondefinition.html#cfn-resiliencehubv2-service-assertiondefinition-text
         */
        readonly text?: string;
    }
    /**
     * Effective policy values computed from the associated policy.
     *
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html
     */
    interface EffectivePolicyValuesProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-availabilityslo
         */
        readonly availabilitySlo?: cdk.IResolvable | CfnServicePropsMixin.SloSourceProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-multiazdrapproach
         */
        readonly multiAzDrApproach?: CfnServicePropsMixin.DisasterRecoverySourceProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-multiazrpo
         */
        readonly multiAzRpo?: cdk.IResolvable | CfnServicePropsMixin.TargetSourceProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-multiazrto
         */
        readonly multiAzRto?: cdk.IResolvable | CfnServicePropsMixin.TargetSourceProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-multiregiondrapproach
         */
        readonly multiRegionDrApproach?: CfnServicePropsMixin.DisasterRecoverySourceProperty | cdk.IResolvable;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-multiregionrpo
         */
        readonly multiRegionRpo?: cdk.IResolvable | CfnServicePropsMixin.TargetSourceProperty;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-effectivepolicyvalues.html#cfn-resiliencehubv2-service-effectivepolicyvalues-multiregionrto
         */
        readonly multiRegionRto?: cdk.IResolvable | CfnServicePropsMixin.TargetSourceProperty;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-slosource.html
     */
    interface SloSourceProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-slosource.html#cfn-resiliencehubv2-service-slosource-policyname
         */
        readonly policyName?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-slosource.html#cfn-resiliencehubv2-service-slosource-value
         */
        readonly value?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-targetsource.html
     */
    interface TargetSourceProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-targetsource.html#cfn-resiliencehubv2-service-targetsource-policyname
         */
        readonly policyName?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-targetsource.html#cfn-resiliencehubv2-service-targetsource-value
         */
        readonly value?: number;
    }
    /**
     * @struct
     * @stability external
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-disasterrecoverysource.html
     */
    interface DisasterRecoverySourceProperty {
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-disasterrecoverysource.html#cfn-resiliencehubv2-service-disasterrecoverysource-policyname
         */
        readonly policyName?: string;
        /**
         * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-resiliencehubv2-service-disasterrecoverysource.html#cfn-resiliencehubv2-service-disasterrecoverysource-value
         */
        readonly value?: string;
    }
}
/**
 * Properties for CfnServicePropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html
 */
export interface CfnServiceMixinProps {
    /**
     * Assertions associated with this service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-assertions
     */
    readonly assertions?: Array<CfnServicePropsMixin.AssertionDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Systems associated with this service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-associatedsystems
     */
    readonly associatedSystems?: Array<CfnServicePropsMixin.AssociatedSystemProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * Dependency discovery state.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-dependencydiscovery
     */
    readonly dependencyDiscovery?: string;
    /**
     * The description of the service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-description
     */
    readonly description?: string;
    /**
     * Input sources for this service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-inputsources
     */
    readonly inputSources?: Array<CfnServicePropsMixin.InputSourceDefinitionProperty | cdk.IResolvable> | cdk.IResolvable;
    /**
     * The KMS key ID for encrypting service data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * The name of the service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-name
     */
    readonly name?: string;
    /**
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-permissionmodel
     */
    readonly permissionModel?: cdk.IResolvable | CfnServicePropsMixin.PermissionModelProperty;
    /**
     * The ARN of the resilience policy to associate.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-policyarn
     */
    readonly policyArn?: string;
    /**
     * AWS regions for the service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-regions
     */
    readonly regions?: Array<string>;
    /**
     * Configuration for automatic report generation on a Service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-reportconfiguration
     */
    readonly reportConfiguration?: cdk.IResolvable | CfnServicePropsMixin.ServiceReportConfigurationProperty;
    /**
     * Tags assigned to the service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-service.html#cfn-resiliencehubv2-service-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a service function within a Resilience Hub service.
 *
 * @cloudformationResource AWS::ResilienceHubV2::ServiceFunction
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-servicefunction.html
 */
export declare class CfnServiceFunctionPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnServiceFunctionMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ResilienceHubV2::ServiceFunction`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnServiceFunctionMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnServiceFunction;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnServiceFunctionPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-servicefunction.html
 */
export interface CfnServiceFunctionMixinProps {
    /**
     * The criticality of the service function.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-servicefunction.html#cfn-resiliencehubv2-servicefunction-criticality
     */
    readonly criticality?: string;
    /**
     * The description of the service function.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-servicefunction.html#cfn-resiliencehubv2-servicefunction-description
     */
    readonly description?: string;
    /**
     * The name of the service function.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-servicefunction.html#cfn-resiliencehubv2-servicefunction-name
     */
    readonly name?: string;
    /**
     * The ARN of the parent service.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-servicefunction.html#cfn-resiliencehubv2-servicefunction-servicearn
     */
    readonly serviceArn?: string;
}
/**
 * Creates a system that represents a logical grouping of services.
 *
 * @cloudformationResource AWS::ResilienceHubV2::System
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html
 */
export declare class CfnSystemPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnSystemMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ResilienceHubV2::System`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnSystemMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnSystem;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnSystemPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html
 */
export interface CfnSystemMixinProps {
    /**
     * The description of the system.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html#cfn-resiliencehubv2-system-description
     */
    readonly description?: string;
    /**
     * The KMS key ID for encrypting system data.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html#cfn-resiliencehubv2-system-kmskeyid
     */
    readonly kmsKeyId?: string;
    /**
     * The name of the system.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html#cfn-resiliencehubv2-system-name
     */
    readonly name?: string;
    /**
     * Whether the system is enabled to be shared with other members of the Organization.
     *
     * Only applicable if the system owner is a management account or delegated admin.
     *
     * @default - false
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html#cfn-resiliencehubv2-system-sharingenabled
     */
    readonly sharingEnabled?: boolean | cdk.IResolvable;
    /**
     * Tags assigned to the system.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-system.html#cfn-resiliencehubv2-system-tags
     */
    readonly tags?: Array<cdk.CfnTag>;
}
/**
 * Creates a user journey within a Resilience Hub system.
 *
 * @cloudformationResource AWS::ResilienceHubV2::UserJourney
 * @mixin true
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-userjourney.html
 */
export declare class CfnUserJourneyPropsMixin extends cdk.Mixin implements constructs.IMixin {
    protected static readonly CFN_PROPERTY_KEYS: Array<string>;
    protected readonly props: CfnUserJourneyMixinProps;
    protected readonly strategy: cdk.IMergeStrategy;
    /**
     * Create a mixin to apply properties to `AWS::ResilienceHubV2::UserJourney`.
     *
     * @param props L1 properties to apply
     * @param options Mixin options
     */
    constructor(props: CfnUserJourneyMixinProps, options?: mixins.CfnPropertyMixinOptions);
    /**
     * Check if this mixin supports the given construct
     */
    supports(construct: constructs.IConstruct): construct is service.CfnUserJourney;
    /**
     * Apply the mixin properties to the construct
     */
    applyTo(construct: constructs.IConstruct): void;
}
/**
 * Properties for CfnUserJourneyPropsMixin
 *
 * @struct
 * @stability external
 * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-userjourney.html
 */
export interface CfnUserJourneyMixinProps {
    /**
     * The description of the user journey.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-userjourney.html#cfn-resiliencehubv2-userjourney-description
     */
    readonly description?: string;
    /**
     * The name of the user journey.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-userjourney.html#cfn-resiliencehubv2-userjourney-name
     */
    readonly name?: string;
    /**
     * The ARN of the resilience policy to associate with this user journey.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-userjourney.html#cfn-resiliencehubv2-userjourney-policyarn
     */
    readonly policyArn?: string;
    /**
     * The system ARN or system ID that owns this user journey.
     *
     * @see http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-resiliencehubv2-userjourney.html#cfn-resiliencehubv2-userjourney-systemidentifier
     */
    readonly systemIdentifier?: string;
}
